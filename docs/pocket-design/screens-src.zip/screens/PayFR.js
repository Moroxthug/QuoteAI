    var tab = this.g('tab', 'period'), pi = this.g('pi', 1), exOpen = this.g('exOpen', false), exported = this.g('exported', '');
    var claim = this.g('claim', 'pending'), freq = this.g('freq', 1), preset = this.g('preset', 1);
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var whole = function (n) { return Math.round(n).toLocaleString('fr-CA').replace(/\s/g, ' ') + ' $'; };
    var h = function (n) { return n.toFixed(1).replace('.', ',') + ' h'; };
    var d1 = function (n) { return n.toFixed(1).replace('.', ','); };
    var PER = [
      { label: '31 août au 13 sept.', sub: 'Aux 2 semaines · payée le 18 sept.', status: 'Exportée le 15 sept.', st: 'st-ok' },
      { label: '14 au 27 sept.', sub: 'Aux 2 semaines · paie le ven. 2 oct.', status: 'Prête à exporter', st: 'st-acc' },
      { label: '28 sept. au 11 oct.', sub: 'Aux 2 semaines · paie le ven. 16 oct.', status: 'En cours · 2 jours saisis', st: 'st-mute' }
    ];
    var per = PER[pi];
    if (pi === 1 && exported) per = { label: per.label, sub: per.sub, status: 'Exportée aujourd’hui', st: 'st-ok' };
    // name, ini, tint, role, rate, reg h, ot h, travel label, travel amt, flag
    var E = [
      ['Luca Bianchi', 'LB', 'tn1', 'Chef peintre', 34, 80, 6, 'Déplacement · 4 jours', 60, ''],
      ['Amara Okafor', 'AO', 'tn4', 'Plâtrière', 31, 80, 8, '', 0, ''],
      ['Dev Patel', 'DP', 'tn3', 'Menuisier', 33, 76, 0, 'Indemnité journalière · 3 jours', 135, ''],
      ['Sofia Marin', 'SM', 'tn2', 'Apprentie', 21, 72.5, 0, '', 0, 'Aucun numéro de paie']
    ];
    var gT = 0, vT = 0, trT = 0, hT = 0, otT = 0;
    var emps = E.map(function (e) {
      var reg = e[4] * e[5], ot = e[4] * 1.5 * e[6], vac = Math.round((reg + ot) * 0.04 * 100) / 100, gross = reg + ot + vac + e[8];
      gT += gross; vT += vac; trT += e[8]; hT += e[5] + e[6]; otT += e[6];
      var lines = [{ label: 'Régulières', qty: h(e[5]) + ' × ' + money(e[4]), amt: money(reg) }];
      if (e[6]) lines.push({ label: 'Heures sup.', qty: h(e[6]) + ' × ' + money(e[4] * 1.5), amt: money(ot) });
      lines.push({ label: 'Paie de vacances', qty: '4 %', amt: money(vac) });
      if (e[8]) lines.push({ label: e[7].split(' · ')[0], qty: e[7].split(' · ')[1], amt: money(e[8]) });
      return { name: e[0], ini: e[1], tn: e[2], role: e[3] + ' · ' + money(e[4]) + '/h', gross: money(gross), hours: h(e[5] + e[6]), lines: lines, flag: e[9] };
    });
    var TG = [['Fichier CSV', 'Tout logiciel de paie ou tableur', 'doc', 'slate'], ['Wagepoint', 'Connecté · 4 sur 4 associés', 'sync', 'teal'], ['Payworks', 'Fichier d’importation', 'export', 'azure'], ['QuickBooks Payroll', 'Connecté', 'bank', 'sage']];
    // job, client, hours, ot, travel, icon
    var J = [['Finition du sous-sol', 'Tom & Lena Hart', 168.5, 10, 60, ['house', 'teal']], ['Plancher du corridor', 'Okoye Condo', 78, 4, 135, ['building', 'violet']], ['Ordre de changement, sous-sol', 'Tom & Lena Hart', 52, 0, 0, ['doc', 'amber']], ['Atelier et cueillettes', 'Aucun chantier', 24, 0, 0, ['truck', 'slate']]];
    var AVG = 30.4;
    var jobs = J.map(function (j) {
      var st = (j[2] - j[3]) * AVG, prem = j[3] * AVG * 0.5 + j[3] * AVG, burden = (st + prem) * 0.18, cost = st + prem + burden + j[4];
      return { name: j[0], client: j[1], ic: ic(j[5][0], j[5][1]), c: cost, cost: whole(cost), cells: [
        { l: 'Heures', v: d1(j[2]) }, { l: 'Heures sup.', v: d1(j[3]) }, { l: 'Taux normal', v: whole(st) },
        { l: 'Majoration', v: whole(prem) }, { l: 'Charges', v: whole(burden) }, { l: 'Déplacement', v: whole(j[4]) }] };
    });
    var jT = jobs.reduce(function (a, j) { return a + j.c; }, 0);
    jobs.forEach(function (j) { j.bar = 'width: ' + (j.c / jT * 100).toFixed(1) + '%'; });
    var FQ = ['Hebdo', 'Aux 2 sem.', '2 fois/mois'];
    var FN = ['Paie chaque vendredi', 'Paie le vendredi suivant la fin de la période', 'Paie le 15 et le dernier jour du mois'];
    var PR = [['Ontario général', 'Après 44 h par semaine', '1,5×', 'Non requis'], ['Ontario construction', 'Après 44 h par semaine', '1,5×', 'Sam. et fériés à 1,5×'], ['Québec R-20', 'Après 40 h par semaine', '1,5×', 'Après 50 h à 2×'], ['C.-B.', 'Après 8 h par jour', '1,5×', 'Après 12 h par jour à 2×']];
    var p = PR[preset];
    return {
      tabs: [['period', 'Période de paie'], ['jobs', 'Par chantier'], ['rules', 'Règles et export']].map(function (t) { var on = t[0] === tab; return { label: t[1], on: on, cls: on ? 'on' : '', pick: function () { set({ tab: t[0], exOpen: false }); } }; }),
      isPeriod: tab === 'period', isJobs: tab === 'jobs', isRules: tab === 'rules',
      per: per,
      prevP: function () { if (pi > 0) set({ pi: pi - 1 }); }, nextP: function () { if (pi < 2) set({ pi: pi + 1 }); },
      prevStyle: pi === 0 ? 'opacity: .3' : '', nextStyle: pi === 2 ? 'opacity: .3' : '',
      exportOpen: exOpen, toggleExport: function () { set({ exOpen: !exOpen }); },
      exportLabel: exported ? 'Exporter de nouveau' : 'Exporter la période',
      targets: TG.map(function (t, i) { return { label: t[0], sub: t[1], ic: ic(t[2], t[3]), last: i === 1, pick: function () { set({ exported: t[0], exOpen: false }); } }; }),
      exported: exported, okIc: ic('check', 'sage'), grossTotal: money(gT),
      warnings: [
        { title: '4 entrées à approuver', sub: 'Luca, Amara et Dev · 31,5 h', tag: 'À revoir', st: 'st-warn', ic: ic('clock', 'amber'), href: 'Team.dc.html' },
        { title: '2 entrées modifiées', sub: 'Le 28 sept., après le dernier CSV', tag: 'Modifiées', st: 'st-warn', ic: ic('sync', 'clay'), href: '#' },
        { title: 'Sofia sans n° de paie', sub: 'Requis par Wagepoint', tag: 'Manquant', st: 'st-bad', ic: ic('user', 'rose'), href: 'Team.dc.html' },
        { title: 'Action de grâce le lun. 12 oct.', sub: 'Jour férié dans la prochaine période', tag: 'À venir', st: 'st-info', ic: ic('cal', 'azure'), href: '#' }
      ],
      totals: [
        { label: 'Paie brute', value: money(gT), sub: 'Avant retenues', sep: '' },
        { label: 'Heures', value: d1(hT), sub: d1(otT) + ' en heures sup.', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Paie de vacances', value: money(vT), sub: '4 % des gains', sep: 'border-top: 1px solid var(--line)' },
        { label: 'Déplacements et indemnités', value: money(trT), sub: claim === 'ok' ? '+ 97,98 $ de kilométrage' : '1 demande en attente', sep: 'border-top: 1px solid var(--line); border-left: 1px solid var(--line)' }
      ],
      emps: emps,
      claimPending: claim === 'pending', claimCount: claim === 'pending' ? '1 à approuver' : 'Tout est fait',
      claimWord: claim === 'pending' ? 'À approuver' : claim === 'ok' ? 'Approuvée' : 'Refusée', claimSt: claim === 'pending' ? 'st-warn' : claim === 'ok' ? 'st-ok' : 'st-mute',
      approveClaim: function () { set({ claim: 'ok' }); }, rejectClaim: function () { set({ claim: 'no' }); },
      jobs: jobs, jobTotal: whole(jT),
      freqInd: 'width: calc((100% - 4px) / 3); transform: translateX(' + (freq * 100) + '%)',
      freqs: FQ.map(function (f, i) { var on = i === freq; return { label: f, on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ freq: i }); } }; }),
      freqNote: FN[freq],
      presets: PR.map(function (x, i) { var on = i === preset; return { label: x[0], on: on, cls: on ? 'on' : '', pick: function () { set({ preset: i }); } }; }),
      otRows: [{ l: 'Début des heures sup.', v: p[1] }, { l: 'Taux des heures sup.', v: p[2] }, { l: 'Temps majoré', v: p[3] }],
      ruleRows: [
        { l: 'Jours fériés', sub: 'Ontario · prochain : Action de grâce, 12 oct.', v: '9 par an', ic: ic('cal', 'azure') },
        { l: 'Paie de vacances', sub: '6 % après 5 ans', v: '4 %', ic: ic('sun', 'gold') },
        { l: 'Taux de déplacement', sub: 'Véhicule personnel', v: '0,69 $/km', ic: ic('truck', 'teal') },
        { l: 'Indemnité journalière', sub: 'Chantiers à plus de 80 km', v: '45 $/jour', ic: ic('pin', 'rose') }
      ],
      exportRows: [
        { l: 'Exporter vers', sub: 'Wagepoint, à chaque période de paie', subCls: '', tag: '', st: '', ic: ic('export', 'violet') },
        { l: 'Codes de gains', sub: 'REG · OT · VAC · TRV · PD', subCls: 'mono', tag: '', st: '', ic: ic('code', 'slate') },
        { l: 'Numéros de paie', sub: '3 employés sur 4', subCls: '', tag: '1 manquant', st: 'st-warn', ic: ic('users', 'indigo') }
      ]
    };
