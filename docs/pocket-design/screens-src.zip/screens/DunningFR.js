    var R = this.props.role || 'owner', own = R === 'owner';
    var W = function (t, g, tone) { return { t: t, ic: ic(g, tone) }; };
    return {
      firstName: own ? 'Marco' : 'Luca',
      intro: own ? 'Ce que vous et votre équipe voyez, étape par étape. Vous pouvez régler le tout en tout temps sur quoteai.ca.' : 'Ce que vous voyez quand le paiement de l’entreprise échoue. Seul Marco Rossi (propriétaire) peut le régler.',
      failTitle: own ? 'Votre paiement n’est pas passé.' : 'Le paiement de Rossi Renovations n’est pas passé.',
      failText: own ? 'Mettez votre carte à jour sur quoteai.ca pour que tout continue de fonctionner.' : 'Marco Rossi peut le mettre à jour sur quoteai.ca.',
      actLabel: own ? 'Ouvrir quoteai.ca' : 'Écrire à Marco', actHref: own ? '#' : 'Teammate.dc.html',
      graceTitle: own ? 'Mettez à jour votre mode de paiement sur quoteai.ca d’ici le 6 oct.' : 'Marco doit mettre à jour le mode de paiement d’ici le 6 oct.',
      graceText: own ? 'Votre carte se terminant par 4417 a été refusée. Rien ne change pour votre équipe ni vos clients d’ici là.' : 'Rien ne change pour vous d’ici là. Nous avons aussi écrit à Marco par courriel.',
      teamText: own ? '4 accès suspendus' : 'Votre accès est suspendu',
      roText: own ? 'Mettez à jour le paiement sur quoteai.ca pour modifier de nouveau.' : 'Demandez à Marco Rossi de mettre à jour le mode de paiement.',
      cardIc: ic('card', 'rose'), clockIc: ic('clock', 'amber'), lockIc: ic('lock', 'amber'), tierIc: ic('tier1', 'sky'), okIc: ic('check', 'sage'),
      docIc: ic('doc', 'violet'), coneIc: ic('cone', 'amber'), usersIc: ic('users', 'azure'),
      works: [W('Voir chaque soumission, chantier et facture', 'eye', 'sage'), W('Les clients peuvent payer les factures ouvertes', 'card', 'sage'), W('Liens d’équipe, pointage et photos', 'users', 'sage'), W('Exporter vos données', 'export', 'sage')],
      paused: [W('Nouvelles soumissions et modifications', 'lock', 'slate'), W('Envoi des soumissions et factures', 'lock', 'slate'), W('Assistant et rappels automatiques', 'lock', 'slate')]
    };
