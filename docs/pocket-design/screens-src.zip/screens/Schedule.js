    var day = this.g('day', 1), by = this.g('by', 'person'), sheet = this.g('sheet', false), sel = this.g('sel', 'b4');
    var edits = this.g('edits', {}), added = this.g('added', []), saved = this.g('saved', false);
    var P = {
      AO: ['Amara Okafor', 'Drywall', 'tn3'], SM: ['Sofia Marin', 'Apprentice', 'tn2'], LB: ['Luca Bianchi', 'Painter lead', 'tn1'],
      DP: ['Dev Patel', 'Carpenter', 'tn5'], JR: ['Jonah Reyes', 'Electrician · sub', 'tn4']
    };
    var PK = ['AO', 'SM', 'LB', 'DP', 'JR'];
    var J = {
      hart: ['Hart basement', 'Tom & Lena Hart', 'background: var(--acc)', 'Drywall'],
      harb: ['Harbourfront Dental', 'Clinic hallway refresh', 'background: var(--info)', 'Prep and prime'],
      gill: ['Gill Residence', 'Fence and gate', 'background: var(--ok-dot)', 'Stain gate'],
      shop: ['Shop day', 'Yard and van', 'background: var(--faint)', 'Tools and stock']
    };
    var JK = ['hart', 'harb', 'gill', 'shop'];
    var WD = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], DN = [28, 29, 30, 1, 2, 3, 4];
    var LONG = ['Monday, Sep 28', 'Tuesday, Sep 29', 'Wednesday, Sep 30', 'Thursday, Oct 1', 'Friday, Oct 2', 'Saturday, Oct 3', 'Sunday, Oct 4'];
    var SHORT = ['Mon, Sep 28', 'Tue, Sep 29', 'Wed, Sep 30', 'Thu, Oct 1', 'Fri, Oct 2', 'Sat, Oct 3', 'Sun, Oct 4'];
    // id, day, person, job, milestone, start, end, notes
    var BASE = [
      ['a0', 0, 'AO', 'hart', 'Drywall', 7.5, 15.5], ['s0', 0, 'SM', 'hart', 'Drywall', 8, 16], ['l0', 0, 'LB', 'harb', 'Prep and prime', 8, 16], ['d0', 0, 'DP', 'gill', 'Fence posts', 8, 16],
      ['b1', 1, 'AO', 'hart', 'Drywall · second coat', 7.5, 15.5], ['b2', 1, 'SM', 'hart', 'Drywall · sanding', 8, 16], ['b3', 1, 'LB', 'harb', 'Prep and prime', 8, 12],
      ['b4', 1, 'LB', 'gill', 'Stain gate', 11, 15], ['b5', 1, 'DP', 'gill', 'Fence posts', 8, 12], ['b6', 1, 'JR', 'hart', 'Panel labels', 10.5, 11.5],
      ['a2', 2, 'AO', 'hart', 'Drywall', 7.5, 15.5], ['s2', 2, 'SM', 'hart', 'Drywall', 8, 16], ['l2', 2, 'LB', 'harb', 'Prep and prime', 8, 16],
      ['a3', 3, 'AO', 'hart', 'Drywall', 7.5, 15.5], ['s3', 3, 'SM', 'hart', 'Drywall', 8, 16], ['l3', 3, 'LB', 'harb', 'First coat', 8, 16], ['d3', 3, 'DP', 'gill', 'Hang gate', 9, 13],
      ['a4', 4, 'AO', 'hart', 'Drywall · sand and prime', 7.5, 12], ['s4', 4, 'SM', 'hart', 'Drywall · cleanup', 8, 16], ['l4', 4, 'LB', 'gill', 'Stain fence', 8, 12], ['j4', 4, 'JR', 'hart', 'Final check', 13, 15]
    ];
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { Directions: 'Opened', Call: 'Calling', Order: 'Ordered', Check: 'Checked' };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: r[6] || function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); } }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    // where, client, what to bring (job-level)
    var SITE = {
      hart: { addr: ['48 Galloway Rd', 'Scarborough · side door, basement stairs'], client: ['Tom & Lena Hart', 'Lena is home until 4:00'], bring: 'Sanding poles, 2 pails of mud, drop sheets', outside: false },
      harb: { addr: ['Queens Quay W', 'Harbourfront Dental · park on Lower Simcoe'], client: ['Harbourfront Dental', 'Front desk · patients from 9:00, keep the hall clear'], bring: 'Primer, rollers, 6 drop sheets, low-odour only', outside: false },
      gill: { addr: ['31 Thorncrest Rd', 'Etobicoke · side gate, dog stays inside'], client: ['The Gills', 'Home all day · text before you ring'], bring: 'Post-hole digger, 12 bags of concrete, level', outside: true },
      shop: { addr: ['The yard', '1180 Dundas St W'], client: null, bring: 'Van keys, stock list', outside: false }
    };
    var BRING = { b4: 'Stain and brushes are in the garage, code 4471', d3: 'Gate hinges, drill, level', l4: 'Stain, 2 brushes, drop sheets', b6: 'Label maker and the panel schedule', j4: 'Tester, ESA sign-off form' };
    var WX = ['Dry, 18°', 'Dry, 17° · rain from Thursday', 'Cloudy, 16° · dry', 'Rain, 80% from 10:00', 'Showers, 60%', 'Sunny, 15°', 'Sunny, 16°'];
    var detail = function (b) {
      var site = SITE[b.j], same = all.filter(function (o) { return o.day === b.day && o.j === b.j; }).sort(function (x, y) { return x.s - y.s; });
      var names = same.map(function (o) { return P[o.p][0].split(' ')[0]; }).filter(function (n, i, a) { return a.indexOf(n) === i; });
      var who = names.length > 1 ? names.slice(0, -1).join(', ') + ' and ' + names[names.length - 1] : names[0];
      var c = clashWith(b);
      var rows = [
        [site.addr[0], site.addr[1], '', '', 'Directions'],
        [who, same.map(function (o) { return P[o.p][0].split(' ')[0] + ' ' + hh(o.s) + ' – ' + hh(o.e); }).join(' · '), c ? 'Clashes with ' + J[c.j][0] : '', c ? 'st-bad si-alert' : '', 'Move', '', function () { set({ sheet: true, sel: b.id, saved: false }); }],
        ['Bring', BRING[b.id] || site.bring]
      ];
      if (site.outside) { var wet = b.day === 3 || b.day === 4; rows.push(['Weather', WX[b.day], wet ? 'Rain risk' : 'Good for outside work', wet ? 'st-warn si-clock' : 'st-ok si-check', wet ? 'Check' : '']); }
      if (site.client) rows.push([site.client[0], site.client[1], '', '', 'Call']);
      var mk2 = b.id + 'msg', md = !!xd[mk2];
      return { cap: J[b.j][1] + ' · ' + b.ms, hasCap: true, rows: rowsOf(b.id, rows),
        msgLabel: md ? 'Messaged' : 'Message crew', msgCls: md ? 'dn' : '', msg: function () { var n = Object.assign({}, self.g('xd', {})); n[mk2] = !n[mk2]; set({ xd: n }); } };
    };
    var NOTES = { b4: 'Gate only today. Stain and brushes are in the garage, code 4471.' };
    var all = BASE.concat(added).map(function (b) {
      var e = edits[b[0]] || {};
      return { id: b[0], day: b[1], p: e.p || b[2], j: e.j || b[3], ms: e.ms || b[4], s: e.s !== undefined ? e.s : b[5], e: e.e !== undefined ? e.e : b[6], all: !!e.all };
    });
    var hh = function (x) { var h = Math.floor(x), m = Math.round((x - h) * 60); return h + ':' + (m < 10 ? '0' : '') + m; };
    var clashWith = function (b) { return all.filter(function (o) { return o.id !== b.id && o.day === b.day && o.p === b.p && o.s < b.e && b.s < o.e; })[0]; };
    var todays = all.filter(function (b) { return b.day === day; });
    var clashes = todays.filter(function (b) { return clashWith(b); });
    var open = function (id) { return function () { set({ sheet: true, sel: id, saved: false }); }; };
    var pct = function (x) { return ((x - 7) / 11 * 100).toFixed(2) + '%'; };
    var mkBlock = function (b, forJob) {
      var c = clashWith(b), ov = c ? Math.min(b.e, c.e) - Math.max(b.s, c.s) : 0;
      return {
        title: forJob ? P[b.p][0] : J[b.j][0], sub: forJob ? b.ms : b.ms, time: hh(b.s) + ' – ' + hh(b.e), col: J[b.j][2],
        isClash: !!c, ok: !c, cls: c ? 'clash' : '', clashLabel: 'Clash ' + (ov === 1 ? '1 h' : ov + ' h'), open: open(b.id),
        isOpen: xo === b.id, xcls: xo === b.id ? 'open' : '', toggle: toggleOf(b.id), x: detail(b)
      };
    };
    var segsFor = function (bs) {
      var out = bs.map(function (b) { return { style: 'left: ' + pct(b.s) + '; width: calc(' + pct(b.e) + ' - ' + pct(b.s) + '); ' + J[b.j][2] + '; opacity: .85' }; });
      bs.forEach(function (b) { var c = clashWith(b); if (c && b.s > c.s) { var s = Math.max(b.s, c.s), e = Math.min(b.e, c.e); out.push({ style: 'left: ' + pct(s) + '; width: calc(' + pct(e) + ' - ' + pct(s) + '); background: var(--bad)' }); } });
      return out;
    };
    var hours = function (bs) { var t = bs.reduce(function (a, b) { return a + (b.e - b.s); }, 0); return (t % 1 ? t.toFixed(1) : t) + ' h'; };
    var weekend = day >= 5;
    var lanes;
    if (by === 'person') {
      lanes = PK.map(function (k) {
        var bs = todays.filter(function (b) { return b.p === k; }).sort(function (a, b) { return a.s - b.s; });
        var frees = [];
        if (!weekend) {
          var cur = 7.5;
          bs.forEach(function (b) { if (b.s - cur >= 2) frees.push([cur, b.s]); cur = Math.max(cur, b.e); });
          if (16 - cur >= 2) frees.push([cur, 16]);
        }
        return {
          person: true, job: false, ini: k, tn: P[k][2], title: P[k][0], sub: P[k][1], hrs: bs.length ? hours(bs) : '', segs: segsFor(bs),
          blocks: bs.map(function (b) { return mkBlock(b, false); }), openCls: bs.some(function (b) { return b.id === xo; }) ? 'has-open' : '', off: bs.length === 0 && weekend,
          frees: frees.map(function (f) { return { time: hh(f[0]) + ' – ' + hh(f[1]), book: function () { var id = 'n' + (added.length + 1); set({ added: added.concat([[id, day, k, 'hart', 'Drywall', f[0], Math.min(f[1], f[0] + 4)]]), sheet: true, sel: id, saved: false }); } }; })
        };
      });
    } else {
      lanes = JK.map(function (k) {
        var bs = todays.filter(function (b) { return b.j === k; }).sort(function (a, b) { return a.s - b.s; });
        return { person: false, job: true, col: J[k][2], title: J[k][0], sub: J[k][1], hrs: bs.length ? hours(bs) : '', segs: segsFor(bs), blocks: bs.map(function (b) { return mkBlock(b, true); }), openCls: bs.some(function (b) { return b.id === xo; }) ? 'has-open' : '', frees: [], off: bs.length === 0, has: bs.length > 0 || !weekend };
      }).filter(function (l) { return l.blocks.length > 0; });
    }
    // editor
    var B = all.filter(function (b) { return b.id === sel; })[0] || all[0];
    var C = clashWith(B);
    var patch = function (o) { var e = Object.assign({}, edits), cur = Object.assign({}, e[B.id] || {}); Object.keys(o).forEach(function (k) { cur[k] = o[k]; }); e[B.id] = cur; set({ edits: e, saved: false }); };
    var dur = B.e - B.s;
    var ed = {
      ini: B.p, tn: P[B.p][2], worker: P[B.p][0], role: P[B.p][1], job: J[B.j][0], col: J[B.j][2], ms: B.ms, date: SHORT[B.day],
      timed: !B.all, s: hh(B.s), e: hh(B.e), conflict: !!C, clear: !C,
      cTitle: C ? 'Clashes with ' + J[C.j][0] + ',' : '', cText: C ? hh(C.s) + ' – ' + hh(C.e) + '.' : '',
      fixLabel: C ? 'Start ' + hh(C.e) : '',
      clearText: P[B.p][0].split(' ')[0] + ' is free for this block.',
      notes: NOTES[B.id] || '', remind: B.id === 'b4' ? 'Reminder already sent to Luca at 7:00. Saving sends an update.' : 'A reminder goes out the evening before.'
    };
    return {
      dayTitle: LONG[day], daySub: todays.length ? todays.length + ' blocks · ' + hours(todays) + (clashes.length ? ' · 1 clash' : '') : 'Nothing booked',
      goToday: function () { set({ day: 1 }); },
      days: WD.map(function (w, i) {
        var on = i === day, cl = all.some(function (b) { return b.day === i && clashWith(b); });
        return { wd: w, n: DN[i], on: on, clash: cl && !on, style: on ? 'color: var(--on-inv)' : i >= 5 ? 'color: var(--faint)' : 'color: var(--ink)', pick: function () { set({ day: i }); } };
      }),
      slide: 'transform: translateX(' + (day * 100) + '%)',
      segInd: by === 'person' ? 'transform: translateX(0)' : 'transform: translateX(100%)', isPerson: by === 'person', isJob: by === 'job',
      pStyle: by === 'person' ? 'color: var(--ink)' : 'color: var(--muted)', jStyle: by === 'job' ? 'color: var(--ink)' : 'color: var(--muted)',
      byPerson: function () { set({ by: 'person' }); }, byJob: function () { set({ by: 'job' }); },
      hasClash: clashes.length > 0, clashTitle: clashes.length ? P[clashes[0].p][0].split(' ')[0] + ' is double-booked.' : '',
      clashText: clashes.length ? J[clashes[0].j][0] + ' and ' + J[clashWith(clashes[0]).j][0] + ' overlap.' : '',
      warnIc: ic('warn', 'rose'), okIc: ic('check', 'sage'), bellIc: ic('bell', 'amber'),
      lanes: lanes,
      addBlock: function () { var id = 'n' + (added.length + 1); var d = day >= 5 ? 0 : day; set({ added: added.concat([[id, d, 'JR', 'hart', 'Final check', 13, 15]]), sheet: true, sel: id, saved: false }); },
      sheet: sheet, close: function () { set({ sheet: false }); },
      shTitle: B.id.charAt(0) === 'n' ? 'New block' : 'Edit block', shSub: P[B.p][0] + ' · ' + SHORT[B.day],
      ed: ed,
      nextWorker: function () { patch({ p: PK[(PK.indexOf(B.p) + 1) % PK.length] }); },
      nextJob: function () { var nj = JK[(JK.indexOf(B.j) + 1) % JK.length]; patch({ j: nj, ms: J[nj][3] }); },
      adInd: B.all ? 'transform: translateX(100%)' : 'transform: translateX(0)', hStyle: B.all ? 'color: var(--muted)' : 'color: var(--ink)', aStyle: B.all ? 'color: var(--ink)' : 'color: var(--muted)',
      setHours: function () { patch({ all: false }); }, setAllDay: function () { patch({ all: true, s: 7.5, e: 16 }); },
      sDec: function () { patch({ s: Math.max(6, B.s - 0.5) }); }, sInc: function () { if (B.s + 0.5 < B.e) patch({ s: B.s + 0.5 }); },
      eDec: function () { if (B.e - 0.5 > B.s) patch({ e: B.e - 0.5 }); }, eInc: function () { patch({ e: Math.min(18, B.e + 0.5) }); },
      fix: function () { if (C) patch({ s: C.e, e: Math.min(18, C.e + dur) }); },
      save: function () { set({ saved: true, sheet: false }); }, saveLabel: C ? 'Save anyway' : 'Save block'
    };
