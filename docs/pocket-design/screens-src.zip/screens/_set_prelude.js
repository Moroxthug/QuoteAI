    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
