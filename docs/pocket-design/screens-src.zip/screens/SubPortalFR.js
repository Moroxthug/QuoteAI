    var ST = this.props.state || 'default';
    var expired = ST === 'expired';
    var up = this.g('up_' + ST, ''); // '', 'busy', 'done'
    var J = function (a) { return a.join(' '); };
    var upload = function () {
      if (self.g('up_' + ST, '')) return;
      var o = {}; o['up_' + ST] = 'busy'; set(o);
      setTimeout(function () { var p = {}; p['up_' + ST] = 'done'; set(p); }, 1400);
    };
    var wsib = up === 'done'
      ? { w: 'En révision', st: J(['st-acc', 'si-q2']), sub: 'Nouvelle attestation · envoyée le 29 sept.', until: 'au 31 déc.', bar: 100, btn: '', hasBtn: false }
      : expired
        ? { w: 'Expirée', st: J(['st-bad', 'si-alert']), sub: 'Requise par Harbourfront Dental avant le 8 oct.', until: 'fin le 25 sept.', bar: 0, btn: up === 'busy' ? 'Envoi…' : 'Déposer', hasBtn: true }
        : { w: 'Expire le 20 oct.', st: J(['st-warn', 'si-clock']), sub: 'Requise par Harbourfront Dental avant le 8 oct.', until: 'au 20 oct.', bar: 8, btn: up === 'busy' ? 'Envoi…' : 'Déposer', hasBtn: true };
    var doc = function (icn, tone, title, sub, w, st, until, bar, btn, hasBtn, act, primary) {
      return { ic: ic(icn, tone), title: title, sub: sub, w: w, st: st, hasExp: !!until, until: until,
        barStyle: 'width: ' + bar + '%; background: ' + (bar < 12 ? 'var(--bad)' : bar < 30 ? 'var(--warn-dot)' : 'var(--ok-dot)'),
        btn: btn, hasBtn: hasBtn, act: act || function () {}, busy: btn === 'Envoi…', btnCls: primary ? 'btn-p' : 'btn-s' };
    };
    var docs = [
      doc('shield', 'teal', 'Attestation de la CSPAAT', wsib.sub, wsib.w, wsib.st, wsib.until, wsib.bar, wsib.btn, wsib.hasBtn, upload, true),
      doc('file', 'azure', 'Assurance responsabilité', 'Responsabilité civile de 2 M$ · Intact', 'Expire le 14 nov.', J(['st-warn', 'si-clock']), 'au 14 nov.', 22, 'Déposer', true, null, false),
      doc('bolt', 'gold', 'Licence d’entrepreneur électricien', 'ECRA/ESA · #7012345', 'Valide', J(['st-ok', 'si-check']), 'au 31 mars 2027', 78, 'Remplacer', true, null, false),
      doc('receipt', 'violet', 'Numéro de TVH', '81234 5678 RT0001', 'Au dossier', J(['st-ok', 'si-check']), '', 0, '', false, null, false)
    ];
    return {
      bannerWarn: !expired && up !== 'done', bannerBad: expired && up !== 'done', bannerOk: up === 'done',
      warnIc: ic('warn', 'amber'), badIc: ic('warn', 'rose'), okIc: ic('check', 'sage'),
      docMeta: up === 'done' ? '4 au dossier' : (expired ? '1 expiré' : '2 à renouveler'),
      docs: docs,
      jobs: [
        { dow: 'mer.', day: '7', title: 'Sous-sol Hart', sub: 'Finition électrique · appareils et étiquettes du panneau', time: '7 h 30', addr: '48 Galloway Rd', w: 'Planifié', st: J(['st-info', 'si-q1']) },
        { dow: 'jeu.', day: '8', title: 'Harbourfront Dental', sub: 'Encastrés, réception', time: '8 h', addr: 'Queens Quay W',
          w: up === 'done' ? 'Planifié' : (expired ? 'En pause' : 'CSPAAT requise'), st: up === 'done' ? J(['st-info', 'si-q1']) : (expired ? J(['st-warn', 'si-pause']) : J(['st-warn', 'si-clock'])) },
        { dow: 'mar.', day: '13', title: 'Marchetti Bakery', sub: 'Appel de service · le disjoncteur saute', time: '9 h', addr: 'Dundas St W', w: 'À confirmer', st: J(['st-warn', 'si-clock']) }
      ],
      invoices: [
        { ic: ic('receipt', 'amber'), title: 'Sous-sol Hart, préfilage', id: 'RE-121', sub: 'payée le 2 oct.', amt: '2 180,00 $', w: 'Approuvée', st: J(['st-ok', 'si-check']) },
        { ic: ic('receipt', 'violet'), title: 'Appel de service Marchetti', id: 'RE-124', sub: 'envoyée le 27 sept.', amt: '420,00 $', w: 'En révision', st: J(['st-acc', 'si-q2']) },
        { ic: ic('receipt', 'sage'), title: 'Gill Residence, panneau', id: 'RE-118', sub: '18 sept.', amt: '3 450,00 $', w: 'Payée', st: J(['st-ok', 'si-check']) }
      ]
    };
