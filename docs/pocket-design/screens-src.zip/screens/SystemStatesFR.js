    var phs = self.g('phs', 'idle'), rjGone = self.g('rj', '');
    var cf = self.g('cf', { dep: 'mine', start: '' });
    var CF = [['dep', 'Dépôt', '30 %', '25 %', 'Luca'], ['start', 'Date de début', 'lun. 5 oct.', 'mer. 7 oct.', 'bureau']];
    var nPicked = CF.filter(function (c) { return cf[c[0]]; }).length;
    return {
      i: { cloud: ic('cloud', 'amber'), sync: ic('sync', 'sky'), photo: ic('photo', 'sky'), warn: ic('warn', 'clay'), sync2: ic('sync', 'violet'), star: ic('star', 'violet'), cloud2: ic('cloud', 'slate'),
        lock: ic('lock', 'violet'), eye: ic('eye', 'sky'), shield: ic('shield', 'slate'), cone: ic('cone', 'amber'), gift: ic('gift', 'violet'), lock2: ic('lock', 'violet'), face: ic('face', 'lilac'), face2: ic('face', 'violet') },
      ph: {
        title: phs === 'done' ? 'Photos envoyées' : '6 photos en attente du Wi-Fi',
        sub: phs === 'busy' ? 'Envoi de 38 Mo sur données mobiles…' : phs === 'done' ? 'Ajoutées au sous-sol Hart · à l’instant' : '38 Mo · Sous-sol Hart, étape du gypse',
        idle: phs === 'idle', busy: phs === 'busy', done: phs === 'done',
        send: function () { set({ phs: 'busy' }); setTimeout(function () { set({ phs: 'done' }); }, 2300); }
      },
      rj: {
        title: rjGone ? 'Rien en attente' : '1 modification non envoyée',
        sub: rjGone ? 'Tout est à jour sur ce téléphone.' : 'Touchez Réessayer, ou Annuler pour garder la version du serveur.',
        items: rjGone ? [] : [{ what: 'Prix sur Q-2026-119, ligne 3', from: '860,00 $', to: '920,00 $', at: '9 h 52', why: 'La soumission a été envoyée à Dana avant l’arrivée de cette modif.',
          retry: function () { set({ rj: 'retried' }); }, discard: function () { set({ rj: 'discarded' }); } }],
        clear: !!rjGone, clearMsg: rjGone === 'retried' ? 'Envoyée au nouvel essai à 9 h 54.' : 'Modification annulée. La soumission garde 860,00 $.',
        reset: function () { set({ rj: '' }); }
      },
      cf: CF.map(function (c) {
        var v = cf[c[0]];
        var pick = function (w) { return function () { var o = Object.assign({}, self.g('cf', { dep: 'mine', start: '' })); o[c[0]] = w; set({ cf: o }); }; };
        return { field: c[1], mine: c[2], theirs: c[3], who: c[4], mineOn: v === 'mine', theirsOn: v === 'theirs', mineCls: v === 'mine' ? 'on' : '', theirsCls: v === 'theirs' ? 'on' : '', pickMine: pick('mine'), pickTheirs: pick('theirs') };
      }),
      cfNotReady: nPicked < CF.length, cfBtn: nPicked < CF.length ? 'Encore ' + (CF.length - nPicked) + ' à choisir' : 'Enregistrer mes choix',
      meters: [
        { ic: ic('receipt', 'amber'), label: 'Reçus numérisés', used: 42, max: 100, hasSt: false, st: '', status: '', bar: 'width: 42%', note: 'Remise à zéro le 1er oct.' },
        { ic: ic('chat', 'sage'), label: 'WhatsApp', used: 184, max: 200, hasSt: true, st: 'st-warn', status: 'Presque épuisé', bar: 'width: 92%; background: var(--warn-dot)', note: '16 restants · remise à zéro le 1er oct.' },
        { ic: ic('phone', 'sky'), label: 'Textos SMS', used: 250, max: 250, hasSt: true, st: 'st-bad', status: 'Épuisé', bar: 'width: 100%; background: var(--bad)', note: 'Textos suspendus jusqu’au 1er oct. Courriel et WhatsApp fonctionnent toujours.' }
      ],
      perms: [
        { ic: ic('camera', 'sky'), title: 'Autoriser l’appareil photo', body: 'Pour les reçus et les photos de chantier. Rien n’est pris sans votre accord.' },
        { ic: ic('mic', 'violet'), title: 'Autoriser le micro', body: 'Seulement quand le micro est ouvert, pour décrire les travaux et dicter des notes.' },
        { ic: ic('pin', 'clay'), title: 'Autoriser la position au pointage', body: 'Seulement à l’arrivée et au départ, pour confirmer votre présence sur le chantier.' },
        { ic: ic('bell', 'violet'), title: 'Autoriser les notifications', body: 'Sachez quand une soumission est consultée, signée ou payée.' }
      ]
    };
