    var R = this.props.role || 'owner', own = R === 'owner';
    var W = function (t, g, tone) { return { t: t, ic: ic(g, tone) }; };
    return {
      firstName: own ? 'Marco' : 'Luca',
      intro: own ? 'What you and your team see, step by step. You can fix it at any point on quoteai.ca.' : 'What you see when the company’s payment fails. Only Marco Rossi (Owner) can fix it.',
      failTitle: own ? 'Your payment didn’t go through.' : 'Rossi Renovations’ payment didn’t go through.',
      failText: own ? 'Update your card on quoteai.ca to keep everything running.' : 'Marco Rossi can update it on quoteai.ca.',
      actLabel: own ? 'Open quoteai.ca' : 'Message Marco', actHref: own ? '#' : 'Teammate.dc.html',
      graceTitle: own ? 'Update your payment method on quoteai.ca by Oct 6' : 'Marco needs to update the payment method by Oct 6',
      graceText: own ? 'Your card ending in 4417 was declined. Nothing changes for your team or clients until then.' : 'Nothing changes for you until then. We’ve emailed Marco too.',
      teamText: own ? '4 teammates can’t sign in' : 'Your login pauses until it’s fixed',
      roText: own ? 'Update payment on quoteai.ca to make changes again.' : 'Ask Marco Rossi to update the payment method.',
      cardIc: ic('card', 'rose'), clockIc: ic('clock', 'amber'), lockIc: ic('lock', 'amber'), tierIc: ic('tier1', 'sky'), okIc: ic('check', 'sage'),
      docIc: ic('doc', 'violet'), coneIc: ic('cone', 'amber'), usersIc: ic('users', 'azure'),
      works: [W('See every quote, job and invoice', 'eye', 'sage'), W('Clients can pay open invoices', 'card', 'sage'), W('Crew links, clock-in and photos', 'users', 'sage'), W('Export your data', 'export', 'sage')],
      paused: [W('New quotes and edits', 'lock', 'slate'), W('Sending quotes and invoices', 'lock', 'slate'), W('Assistant and automatic reminders', 'lock', 'slate')]
    };
