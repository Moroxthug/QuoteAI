    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var ts = self.g('ts', ST !== 'twoStepOff');
    var sched = self.g('sched', ST === 'deleteScheduled');
    var chromeOn = self.g('chrome', true), ipadOn = self.g('ipad', true);
    var exp = self.g('exp', 'idle');
    var signRows = [
      lnk('key', 'violet', 'Mot de passe', 'Modifié le 12 mai', 'Modifier', 'ForgotPassword.dc.html'),
      sw('face', true, 'face', 'slate', 'Face ID', 'Déverrouillage après 5 min d’absence'),
      sw('ts', ST !== 'twoStepOff', 'shield', 'indigo', 'Vérification en deux étapes', ts ? 'Code par texto au (416) 555-0142' : 'Désactivée. Un code en plus du mot de passe')
    ];
    if (ts) {
      signRows.push(seg('tsBy', 0, 'chat', 'sky', 'Envoyer les codes par', '', ['Texto', 'Authentificateur']));
      signRows.push(lnk('list', 'stone', 'Codes de secours', 'Si vous perdez votre téléphone', '8 restants', 'TwoStep.dc.html'));
    } else {
      signRows.push(lnk('shield', 'amber', 'Activer les deux étapes', 'Environ une minute', '', 'TwoStep.dc.html'));
    }
    var sess = [ stat(mk('phone', 'violet', 'Cet iPhone', 'iPhone 15 Pro · Toronto'), 'Actif', 'st-ok') ];
    if (chromeOn) sess.push(btnRow('globe', 'azure', 'Chrome sur Windows', 'Toronto · il y a 2 h', 'Déconnecter', function () { set({ chrome: false, lastOut: 'Chrome sur Windows' }); }));
    if (ipadOn) sess.push(btnRow('photo', 'teal', 'Safari sur iPad', 'Mississauga · 21 sept.', 'Déconnecter', function () { set({ ipad: false, lastOut: 'Safari sur iPad' }); }));
    var others = (chromeOn ? 1 : 0) + (ipadOn ? 1 : 0);
    var lastOut = self.g('lastOut', '');
    var expRow;
    if (exp === 'idle') expRow = lnk('export', 'stone', 'Exporter mes données', 'Soumissions, clients, factures et photos', '', '');
    else if (exp === 'prep') expRow = stat(mk('export', 'stone', 'Exporter mes données', 'Préparation des fichiers. Vous recevrez aussi un courriel.'), 'En cours', 'st-info');
    else expRow = btnRow('export', 'sage', 'Exportation prête', '214 Mo · lien valide jusqu’au 6 oct.', 'Télécharger', function () {}, 'btn-p');
    if (exp === 'idle') { expRow.isA = false; expRow.notA = true; expRow.isLink = false; expRow.isBtn = true; expRow.btn = 'Exporter'; expRow.act = function () { set({ exp: 'prep' }); setTimeout(function () { set({ exp: 'ready' }); }, 1800); }; }
    var typed = self.g('typed', '');
    var delOpen = self.g('delOpen', false) && !sched;
    return {
      roBanner: roBanner, sched: sched, cancelled: self.g('cancelled', false), tsOffBanner: !ts,
      warnIc: ic('warn', 'rose'), okIc: ic('check', 'sage'), shieldWarn: ic('shield', 'amber'),
      gSign: grp('Connexion', signRows, '', 60),
      gSessions: grp('Appareils connectés', sess, lastOut ? 'Déconnecté de ' + lastOut + '.' : 'Un appareil inconnu ? Déconnectez-le et changez votre mot de passe.', 120),
      signOutAll: function () { set({ chrome: false, ipad: false, lastOut: 'tous les autres appareils' }); },
      onlyThis: others === 0, allStyle: others === 0 ? 'opacity: .45' : '',
      allLabel: others === 0 ? 'Seul ce téléphone est connecté' : 'Déconnecter les autres appareils',
      gActivity: grp('Activité récente', [
        val('globe', 'azure', 'Nouvelle connexion', 'Chrome sur Windows · Toronto', '27 sept.', true),
        val('shield', 'indigo', ST === 'twoStepOff' ? 'Deux étapes désactivées' : 'Deux étapes activées', 'Sur cet iPhone', '2 sept.', true),
        val('key', 'violet', 'Mot de passe modifié', 'Sur cet iPhone', '12 mai', true)
      ], '', 180),
      gData: grp('Vos données', [expRow], 'Conservez vos dossiers 6 ans pour l’ARC. L’exportation est le moyen le plus simple.', 240),
      grace: [
        { ic: ic('clock', 'amber'), t: '30 jours pour changer d’avis', s: 'Connectez-vous avant le 29 oct. pour annuler. Rien n’est perdu.' },
        { ic: ic('lock', 'slate'), t: 'Les liens client cessent de fonctionner', s: 'Soumissions ouvertes, factures et portail ferment au jour 30.' },
        { ic: ic('warn', 'rose'), t: 'Puis tout est effacé pour de bon', s: 'Soumissions, clients, factures, photos et heures de l’équipe.' }
      ],
      showDelBtn: !delOpen && !sched, delOpen: delOpen, typed: typed,
      openDelete: function () { set({ delOpen: true }); }, closeDelete: function () { set({ delOpen: false, typed: '' }); },
      onType: function (e) { set({ typed: e.target.value }); },
      delDisabled: typed.trim().toUpperCase() !== 'SUPPRIMER', delBtnStyle: typed.trim().toUpperCase() !== 'SUPPRIMER' ? 'opacity: .45' : '',
      confirmDelete: function () { if (self.g('typed', '').trim().toUpperCase() !== 'SUPPRIMER') return; set({ sched: true, delOpen: false, cancelled: false }); },
      cancelDelete: function () { set({ sched: false, cancelled: true }); }
    };
