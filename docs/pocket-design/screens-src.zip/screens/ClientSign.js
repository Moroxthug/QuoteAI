    var lang = this.g('lang', 'en'), fr = lang === 'fr';
    var folded = this.g('folded', true), reviewed = this.g('reviewed', false);
    var code = this.g('code', '418'), verified = this.g('verified', false), codeBad = this.g('codeBad', false);
    var mode = this.g('mode', 0), hasSig = this.g('sig', true), typed = this.g('typed', 'Dana Whitfield');
    var consent = this.g('consent', false), signed = this.g('signed', false), declining = this.g('declining', false);
    var EN = {
      from: 'From', contract: 'Contract', title: 'Painting contract, bedrooms and bath ceiling',
      steps: ['Review', 'Verify', 'Sign'], s1: '1. Review the contract', s2: '2. Verify it’s you', s3: '3. Sign',
      readEnd: 'Read', verified: 'Verified', more: 'Read the whole contract', less: 'Show less',
      codeSent: 'Enter the 6-digit code we sent to', codeLabel: 'Verification code', codeBad: 'That code does not match. Check the latest email.',
      resend: 'Send a new code', verify: 'Verify', modes: ['Draw', 'Type'], padLabel: 'Signature area', signHere: 'Sign here with your finger',
      typeName: 'Your full name', clear: 'Clear', consent: 'I agree to sign electronically and to the terms of this contract.',
      sign: 'Sign', need: ['Read the contract to the end', 'Verify your email first', 'Add your signature', 'Tick the box to agree'], ready: 'You will get a signed copy by email',
      decline: 'Decline to sign', whyLabel: 'Tell Marco why', whyPh: 'Optional. For example: I want to change the start date', cancel: 'Cancel', declineSend: 'Decline',
      doneTitle: 'Contract signed', doneSub: 'Everyone has signed. A copy is on its way to your email.', hstIncl: 'HST included',
      signedAt: 'Sep 29, 2026 · 10:14 am · email verified', marcoAt: 'Rossi Renovations · Sep 28, 2026', signedSt: 'Signed',
      download: 'Download a copy', portal: 'Go to your portal', review: 'See the signing steps again',
      sigDate: 'Sep 29, 2026',
      terms: [['Total, HST included', '$4,131.05'], ['Deposit on signing', '$1,239.32'], ['Start', 'Tue, Oct 13'], ['Workmanship warranty', '1 year']]
    };
    var FR = {
      from: 'De la part de', contract: 'Contrat', title: 'Contrat de peinture, chambres et plafond de salle de bain',
      steps: ['Lire', 'Vérifier', 'Signer'], s1: '1. Lisez le contrat', s2: '2. Confirmez votre identité', s3: '3. Signez',
      readEnd: 'Lu', verified: 'Vérifié', more: 'Lire tout le contrat', less: 'Réduire',
      codeSent: 'Entrez le code à 6 chiffres envoyé à', codeLabel: 'Code de vérification', codeBad: 'Ce code ne correspond pas. Vérifiez le dernier courriel.',
      resend: 'Envoyer un nouveau code', verify: 'Vérifier', modes: ['Dessiner', 'Taper'], padLabel: 'Zone de signature', signHere: 'Signez ici avec votre doigt',
      typeName: 'Votre nom complet', clear: 'Effacer', consent: "J'accepte de signer électroniquement et les conditions de ce contrat.",
      sign: 'Signer', need: ["Lisez le contrat jusqu'à la fin", "Vérifiez d'abord votre courriel", 'Ajoutez votre signature', 'Cochez la case pour accepter'], ready: 'Vous recevrez une copie signée par courriel',
      decline: 'Refuser de signer', whyLabel: 'Dites à Marco pourquoi', whyPh: 'Facultatif. Par exemple : je veux changer la date de début', cancel: 'Annuler', declineSend: 'Refuser',
      doneTitle: 'Contrat signé', doneSub: 'Tout le monde a signé. Une copie est envoyée à votre courriel.', hstIncl: 'TVH incluse',
      signedAt: '29 sept. 2026 · 10 h 14 · courriel vérifié', marcoAt: 'Rossi Renovations · 28 sept. 2026', signedSt: 'Signé',
      download: 'Télécharger une copie', portal: 'Aller à votre portail', review: 'Revoir les étapes de signature',
      sigDate: '29 sept. 2026',
      terms: [['Total, TVH incluse', '4 131,05 $'], ['Dépôt à la signature', '1 239,32 $'], ['Début', 'mar. 13 oct.'], ['Garantie main-d’œuvre', '1 an']]
    };
    var t = fr ? FR : EN;
    var CL = fr ? [
      ['1. Travaux', 'Peinture des murs et plafonds de trois chambres et du couloir, deux couches, et réparation du plafond de la salle de bain endommagé par l’eau, tel que décrit dans la soumission Q-2026-119.'],
      ['2. Prix et paiement', 'Le prix total est de 4 131,05 $, TVH de 13 % incluse. Un dépôt de 30 % est dû à la signature. Le solde est dû à la fin des travaux, dans les 7 jours suivant la facture.'],
      ['3. Calendrier', 'Les travaux commencent le mardi 13 octobre 2026 et durent environ quatre jours ouvrables, de 8 h à 17 h.'],
      ['4. Modifications', 'Tout changement aux travaux fait l’objet d’un avenant écrit signé par les deux parties avant d’être réalisé.'],
      ['5. Garantie', 'Rossi Renovations garantit la main-d’œuvre pendant un an. Les produits sont couverts par la garantie du fabricant.'],
      ['6. Annulation', 'Vous pouvez annuler dans les 10 jours suivant la réception de ce contrat, conformément à la Loi de 2002 sur la protection du consommateur.']
    ] : [
      ['1. Work', 'Paint walls and ceilings of three bedrooms and the hallway, two coats, and repair the water-damaged bath ceiling, as set out in quote Q-2026-119.'],
      ['2. Price and payment', 'The total price is $4,131.05 including 13% HST. A 30% deposit is due on signing. The balance is due on completion, within 7 days of the invoice.'],
      ['3. Schedule', 'Work starts Tuesday, October 13, 2026 and takes about four working days, 8 am to 5 pm.'],
      ['4. Changes', 'Any change to the work is agreed in a written change order signed by both parties before it is done.'],
      ['5. Warranty', 'Rossi Renovations warrants its workmanship for one year. Products carry the manufacturer’s warranty.'],
      ['6. Cancellation', 'You may cancel within 10 days of receiving this contract, as provided by the Ontario Consumer Protection Act, 2002.']
    ];
    var step = !reviewed ? 0 : (!verified ? 1 : 2);
    var steps = t.steps.map(function (l, i) {
      var done = i < step, cur = i === step;
      return {
        label: l, mark: done ? '✓' : String(i + 1),
        bar: done ? 'background: var(--ok-dot)' : (cur ? 'background: var(--inv)' : 'background: var(--sunk)'),
        txt: done ? 'color: var(--ok)' : (cur ? 'color: var(--ink)' : 'color: var(--faint)'),
        disc: done ? 'background: var(--ok-soft); color: var(--ok)' : (cur ? 'background: var(--inv); color: var(--on-inv)' : 'background: var(--sunk); color: var(--faint)')
      };
    });
    var digits = code.split('');
    var boxes = [0, 1, 2, 3, 4, 5].map(function (i) {
      var active = !verified && i === digits.length;
      var st = verified ? 'background: var(--ok-soft); color: var(--ok); box-shadow: none'
        : (codeBad ? 'background: var(--card); box-shadow: 0 0 0 1.5px var(--bad)'
          : (active ? 'background: var(--card); box-shadow: 0 0 0 2px var(--acc)' : 'background: var(--card); box-shadow: 0 0 0 1px var(--line2)'));
      return { d: digits[i] || '', style: st };
    });
    var haveSig = mode === 0 ? hasSig : typed.trim().length > 2;
    var need = !reviewed ? 0 : (!verified ? 1 : (!haveSig ? 2 : (!consent ? 3 : -1)));
    var sigRender = mode === 0 && hasSig;
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      signed: signed, notSigned: !signed, steps: steps,
      terms: t.terms.map(function (k, i) { return { label: k[0], value: k[1], sep: (i % 2 ? 'border-left: 1px solid var(--line);' : '') + (i > 1 ? ' border-top: 1px solid var(--line)' : '') }; }),
      clauses: CL.map(function (c) { return { h: c[0], p: c[1] }; }),
      folded: folded, foldStyle: folded ? 'max-height: 250px' : 'max-height: 1400px',
      foldLabel: folded ? t.more : t.less, foldRot: folded ? 'transform: rotate(0deg)' : 'transform: rotate(180deg)',
      toggleFold: function () { var f = self.g('folded', true); self.setState({ folded: !f, reviewed: true }); },
      reviewed: reviewed,
      boxes: boxes, code: code, verified: verified, notVerified: !verified, codeBad: codeBad, codeShort: code.length < 6,
      onCode: function (e) { var v = (e.target.value || '').replace(/\D/g, '').slice(0, 6); if (!self.g('verified', false)) self.setState({ code: v, codeBad: false }); },
      verify: function () { var c = self.g('code', '418'); if (c.length < 6) return; if (c === '000000') { self.setState({ codeBad: true }); return; } self.setState({ verified: true, reviewed: true }); },
      modes: t.modes.map(function (l, i) { var o = i === mode; return { label: l, on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ mode: i }); } }; }),
      modeInd: 'transform: translateX(' + (mode * 100) + '%)', isDraw: mode === 0, isType: mode === 1,
      sigDash: sigRender ? 'stroke-dashoffset: 0' : 'stroke-dashoffset: 1400', noSig: mode === 0 && !hasSig,
      drawSig: function () { self.setState({ sig: true }); },
      clearSig: function () { if (self.g('mode', 0) === 0) self.setState({ sig: false }); else self.setState({ typed: '' }); },
      typed: typed, onTyped: function (e) { self.setState({ typed: e.target.value }); },
      consent: consent, toggleConsent: function () { self.setState({ consent: !self.g('consent', false) }); },
      consentBox: consent ? 'background: var(--inv); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
      consentCheck: consent ? 'opacity: 1' : 'opacity: 0',
      cantSign: need !== -1, signLabel: t.sign + ' · ' + (fr ? '4 131,05 $' : '$4,131.05'),
      signHint: need === -1 ? t.ready : t.need[need],
      sign: function () { self.setState({ signed: true }); },
      declining: declining, notDeclining: !declining,
      startDecline: function () { self.setState({ declining: true }); }, cancelDecline: function () { self.setState({ declining: false }); },
      okIc: ic('check', 'sage'),
      reset: function () { self.setState({ signed: false }); }
    };
