    var st = this.props.state || 'default';
    var offline = st === 'offline', emptySt = st === 'empty';
    var f = this.g('f', 'all'), undone = this.g('undone', {}), toast = this.g('toast', null);
    // id, time, group, glyph, tone, title, detail, who, whoKind, cat, action(undo|void|open|none), fixedWord, fixedSt, undoToast
    var D = [
      ['a1', '10:12 am', 'today', 'receipt', 'amber', 'Added a $212.40 cost to Hart basement', 'Home Depot receipt · screws and joint tape', 'Rule · Receipts', 'auto', 'money', 'undo', '', '', '$212.40 cost removed from Hart basement.'],
      ['a2', '9:58 am', 'today', 'cal', 'sky', 'Moved Okoye hallway flooring to Fri Oct 2', 'Dev got a text with the new day', 'Marco · voice', 'you', 'jobs', 'undo', '', '', 'Okoye flooring is back on Thu Oct 1. Dev gets a text.'],
      ['a3', '9:41 am', 'today', 'chat', 'teal', 'Texted Luca and Sofia tomorrow’s plan', 'Gill deck, on site 7:30 am', 'Rule · Crew messages', 'auto', 'msg', 'none', 'Sent', 'st-info si-q1', ''],
      ['a4', '8:30 am', 'today', 'bank', 'gold', 'Recorded a $1,200.00 e-Transfer from Chen', 'INV-0415 is now partly paid', 'Marco · typed', 'you', 'money', 'void', '', '', 'Payment voided. INV-0415 is back to $2,480.00 owing.'],
      ['a5', '7:05 am', 'today', 'receipt', 'violet', 'Drafted invoice INV-0421 for Harbourfront', 'Progress bill 2 of 4 · $3,210.00', 'Rule · Invoices', 'auto', 'money', 'open', '', '', ''],
      ['b1', '5:47 pm', 'yesterday', 'mail', 'violet', 'Followed up with the Gills on Q-2026-116', 'Email · deck refinish · $2,980.00', 'Rule · Follow-ups', 'auto', 'msg', 'none', 'Opened', 'st-acc si-q2', ''],
      ['b2', '3:20 pm', 'yesterday', 'list', 'indigo', 'Added “Order trim paint” to Marchetti Bakery', 'Task for Luca, due Fri', 'Marco · voice', 'you', 'jobs', 'none', 'Undone', 'st-mute' + ' si-x', ''],
      ['b3', '2:02 pm', 'yesterday', 'send', 'azure', 'Sent quote Q-2026-119 to Dana Whitfield', '$4,131.05 · read back before sending', 'Marco · voice', 'you', 'msg', 'none', 'Sent', 'st-info si-q1', ''],
      ['b4', '11:15 am', 'yesterday', 'receipt', 'amber', 'Filed an $86.14 Rona receipt to Gill deck', 'Stain and brushes', 'Rule · Receipts', 'auto', 'money', 'undo', '', '', '$86.14 cost removed from Gill deck.'],
      ['b5', '8:02 am', 'yesterday', 'bell', 'amber', 'Reminded Harbourfront Dental about INV-0419', 'SMS · $780.00 · 3 days late', 'Rule · Invoice reminders', 'auto', 'msg', 'none', 'Sent', 'st-info si-q1', '']
    ];
    if (emptySt) D = [];
    var FIL = [['all', 'All', function () { return true; }], ['you', 'You asked', function (d) { return d[8] === 'you'; }], ['auto', 'Automatic', function (d) { return d[8] === 'auto'; }],
      ['msg', 'Messages', function (d) { return d[9] === 'msg'; }], ['money', 'Money', function (d) { return d[9] === 'money'; }], ['jobs', 'Jobs', function (d) { return d[9] === 'jobs'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var rows = D.filter(fn);
    var mk = function (d) {
      var u = undone[d[0]], act = d[10];
      var canUndo = !u && (act === 'undo' || act === 'void');
      var word = d[11], stc = d[12];
      if (u) { word = u === 'pending' ? 'Undo pending' : (act === 'void' ? 'Voided' : 'Undone'); stc = u === 'pending' ? 'st-warn si-clock' : 'st-mute' + ' si-x'; }
      return {
        ic: ic(d[3], d[4]), title: d[5], detail: d[6], time: d[1], who: d[7], whoCls: d[8] === 'auto' ? 'tag-acc' : '',
        cls: (u === 'done' || d[11] === 'Undone') ? 'undone' : '',
        canUndo: canUndo, undoLabel: act === 'void' ? 'Void' : 'Undo', undoAria: (act === 'void' ? 'Void: ' : 'Undo: ') + d[5],
        canOpen: act === 'open', href: 'Invoice.dc.html',
        hasSt: !!word && !canUndo, word: word, st: stc,
        undo: function () {
          var n = Object.assign({}, self.g('undone', {})); n[d[0]] = offline ? 'pending' : 'done';
          var tid = Date.now();
          set({ undone: n, toast: { id: d[0], t: tid, b: offline ? 'Saved.' : (act === 'void' ? 'Voided.' : 'Undone.'), s: offline ? 'It runs when you’re back online.' : d[13] } });
          setTimeout(function () { var t = self.g('toast', null); if (t && t.t === tid) set({ toast: null }); }, 6000);
        }
      };
    };
    var groups = [['today', 'Today', 'Tue Sep 29'], ['yesterday', 'Yesterday', 'Mon Sep 28']].map(function (g) {
      var rs = rows.filter(function (d) { return d[2] === g[0]; });
      return { title: g[1], count: g[2], rows: rs.map(mk), has: rs.length > 0 };
    }).filter(function (g) { return g.has; });
    return {
      offline: offline, hasData: !emptySt,
      pendingCount: '4', hasCount: true,
      kpis: [
        { label: 'Today', value: emptySt ? '0' : '5', sub: emptySt ? 'actions' : '2 you asked', sep: '' },
        { label: 'This month', value: emptySt ? '0' : '86', sub: 'actions', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Undone', value: emptySt ? '0' : '3', sub: 'this month', sep: 'border-left: 1px solid var(--line)' }
      ],
      minUsed: emptySt ? '0' : '142', minTotal: '300 min', minPct: emptySt ? '0%' : '47%',
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: D.filter(x[2]).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, noMatch: !emptySt && groups.length === 0, isEmpty: emptySt, clear: function () { set({ f: 'all' }); },
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '',
      redo: function () { var t = self.g('toast', null); if (!t) return; var n = Object.assign({}, self.g('undone', {})); delete n[t.id]; set({ undone: n, toast: null }); },
      cloudIc: ic('cloud', 'amber'), searchIc: ic('search', 'slate'), orbIc: ic('orb', 'violet'), propIc: ic('bell', 'violet'), permIc: ic('shield', 'indigo')
    };
