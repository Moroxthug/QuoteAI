    var ent = this.g('ent', {}), peek = this.g('peek', 'e1'), inv = this.g('inv', false), role = this.g('role', 0), email = this.g('email', '');
    var invited = this.g('invited', []), codes = this.g('codes', false);
    var W = [
      ['Luca Bianchi', 'LB', 'tn1', 'Employee', 'Painter lead', '$34.00/h · burden 18%', 148.5, 'Link active', 'st-ok si-live'],
      ['Amara Okafor', 'AO', 'tn4', 'Employee', 'Drywall', '$31.00/h · burden 18%', 152.0, 'Link active', 'st-ok si-live'],
      ['Dev Patel', 'DP', 'tn3', 'Employee', 'Carpenter', '$33.00/h · burden 18%', 139.0, 'Link sent', 'st-info si-q1'],
      ['Sofia Marin', 'SM', 'tn2', 'Employee', 'Apprentice', '$21.00/h · no payroll number', 128.5, 'No link', 'st-mute si-off'],
      ['Jonah Reyes', 'JR', 'tn5', 'Subcontractor', 'Electrician', '$85.00/h · bills by invoice', 44.0, 'Link active', 'st-ok si-live']
    ];
    // today, [week hours, week note], rate, cert, link  (row: title, sub, status, status class, button, amount)
    var WX = {
      'Luca Bianchi': { today: ['Harbourfront Dental', 'Clocked in 8:02 · prep and prime', 'On site', 'st-ok si-live'], week: ['38.5 h'], rate: ['$34.00/h · burden 18%', 'Owner only · costs $40.12/h loaded'], cert: ['WHMIS', 'Valid to Jun 2027', 'Valid', 'st-ok si-check'], link: ['Crew link', 'Opened today at 8:02', 'Active', 'st-ok si-live'] },
      'Amara Okafor': { today: ['Hart basement', 'Clocked in 7:15 · 48 Galloway Rd', 'On site', 'st-ok si-live'], week: ['42.4 h'], rate: ['$31.00/h · burden 18%', 'Owner only · costs $36.58/h loaded'], cert: ['Working at Heights', 'IHSA · expires Nov 12', 'Expires soon', 'st-warn si-clock', 'Renew'], link: ['Crew link', 'Opened today at 7:15', 'Active', 'st-ok si-live'] },
      'Dev Patel': { today: ['Gill Residence', 'Clocked in 8:00 · fence posts', 'On site', 'st-ok si-live'], week: ['30.5 h'], rate: ['$33.00/h · burden 18%', 'Owner only · costs $38.94/h loaded'], cert: ['Working at Heights', 'IHSA · expires Oct 14', 'In 15 days', 'st-bad si-alert', 'Remind'], link: ['Crew link', 'Sent Sep 27 · not opened', 'Sent', 'st-info si-q1', 'Resend'] },
      'Sofia Marin': { today: ['Hart basement', 'Clocked in 7:30 · by Amara', 'On site', 'st-ok si-live'], week: ['32.0 h'], rate: ['$21.00/h · apprentice', 'Owner only · no payroll number yet', 'Missing', 'st-warn si-alert'], cert: ['WHMIS', 'Valid to Mar 2027', 'Valid', 'st-ok si-check'], link: ['Crew link', 'She clocks in through Amara', 'No link', 'st-mute si-off', 'Send link'] },
      'Jonah Reyes': { today: ['Hart basement at 10:30', 'Panel labels · one hour', 'Booked', 'st-info si-q1'], week: ['3.5 h'], rate: ['$85.00/h · subcontractor', 'Owner only · no burden, invoices monthly'], cert: ['ESA licence', 'Master electrician · valid to 2028', 'Valid', 'st-ok si-check'], link: ['Crew link', 'Opened Sep 25', 'Active', 'st-ok si-live'] }
    };
    var E = [
      ['e1', 'Luca Bianchi', 'LB', 'tn1', 'Mon Sep 28', '7:02 am – 3:48 pm', 'Basement finish · Tom & Lena Hart', 8.3, [['Logged by the worker', 'st-mute si-dot']]],
      ['e2', 'Amara Okafor', 'AO', 'tn4', 'Mon Sep 28', '7:15 am – 6:10 pm', 'Hallway flooring · Okoye Condo', 10.4, [['Overtime 2.4 h', 'st-warn si-clock']]],
      ['e3', 'Dev Patel', 'DP', 'tn3', 'Sat Sep 26', '8:00 am – 2:30 pm', 'Hallway flooring · Okoye Condo', 6.5, [['Off site at clock-in', 'st-bad si-alert'], ['Saturday', 'st-info si-dot']]],
      ['e4', 'Luca Bianchi', 'LB', 'tn1', 'Sat Sep 26', '9:00 am – 3:18 pm', 'Basement finish · Tom & Lena Hart', 6.3, [['Saturday', 'st-info si-dot']]]
    ];
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { Call: 'Calling', Text: 'Texted', Remind: 'Reminded', Renew: 'Asked', Resend: 'Resent', 'Send link': 'Link sent', Review: 'Reviewed', Approve: 'Approved' };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: r[6] || function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); } }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var upd = function (k, v) { var o = {}; for (var x in ent) o[x] = ent[x]; o[k] = v; set({ ent: o, peek: '' }); };
    var pend = E.filter(function (e) { return !ent[e[0]]; });
    var approvedN = E.filter(function (e) { return ent[e[0]] === 'ok'; }), rejectedN = E.filter(function (e) { return ent[e[0]] === 'no'; });
    var hrs = approvedN.reduce(function (a, e) { return a + e[7]; }, 0);
    var R = [['Office', 'Quotes, invoices, books · no payroll'], ['Foreman', 'Jobs, crew and time · no money'], ['Crew lead', 'Their jobs and tasks only']];
    var members = [
      { name: 'Marco Rossi', ini: 'MR', tn: 'tn5', sub: 'marco@rossireno.ca · you', role: 'Owner', st: 'st-acc' },
      { name: 'Luca Bianchi', ini: 'LB', tn: 'tn1', sub: 'Last active today', role: 'Foreman', st: 'st-mute' },
      { name: 'office@rossireno.ca', ini: '@', tn: 'tn4', sub: 'Invited Sep 24 · not joined', role: 'Office', st: 'st-info' }
    ].concat(invited.map(function (i) { return { name: i.email, ini: '@', tn: 'tn2', sub: 'Invited just now', role: i.role, st: 'st-info' }; }));
    var used = members.length;
    var equip = [
      { name: 'Graco airless sprayer', meta: '$45/day · 12 days charged', fin: '', charged: '$540', kind: 'Owned', st: 'st-mute', ic: ic('wave', 'violet'), n: 540 },
      { name: 'Scissor lift, 19 ft', meta: 'Sunbelt · $185/day · back Oct 2', fin: '', charged: '$1,110', kind: 'Rented', st: 'st-info', ic: ic('box', 'amber'), n: 1110 },
      { name: 'Ford Transit 2024', meta: '$38/day · 20 days charged', fin: 'RBC · $912/month · 31 months left', charged: '$760', kind: 'Financed', st: 'st-acc', ic: ic('truck', 'teal'), n: 760 }
    ];
    var eqT = equip.reduce(function (a, q) { return a + q.n; }, 0);
    var okEmail = /.+@.+\..+/.test(email);
    return {
      kpis: [
        { label: 'Crew', value: '5', sub: '4 staff · 1 sub', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Hours this month', value: '612', sub: '↑ 8% on Aug', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'To approve', value: String(pend.length), sub: pend.length ? pend.reduce(function (a, e) { return a + e[7]; }, 0).toFixed(1) + ' h' : 'All clear', subStyle: pend.length ? 'color: var(--warn)' : 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'),
        bars: W.map(function (w) { return { name: w[0].split(' ')[0], h: w[6].toFixed(1), w: 'width: ' + (w[6] / 160 * 100).toFixed(1) + '%' + (w[6] > 150 ? '; background: var(--warn-dot)' : '') }; }),
        rows: rowsOf('kpi', [
          ['Overtime this month', 'Amara 6.4 h · Luca 2.0 h', 'Over 44 h a week', 'st-warn si-clock', 'Review', '8.4 h'],
          ['Working at Heights · Dev', 'IHSA card expires Oct 14', 'In 15 days', 'st-warn si-clock', 'Remind'],
          ['Working at Heights · Amara', 'IHSA card expires Nov 12', 'In 44 days', 'st-mute si-clock']]) },
      workersOpen: W.some(function (w) { return xo === w[0]; }) ? 'has-open' : '',
      workers: W.map(function (w) {
        var mine = pend.filter(function (e) { return e[1] === w[0]; }), mh = mine.reduce(function (a, e) { return a + e[7]; }, 0);
        var x = WX[w[0]], id = w[0];
        var weekRow = mine.length
          ? ['Last 7 days', mine.length + ' ' + (mine.length > 1 ? 'entries' : 'entry') + ' to approve, ' + mh.toFixed(1) + ' h', '', '', 'Approve', x.week[0], function () { var o = Object.assign({}, self.g('ent', {})); mine.forEach(function (e) { o[e[0]] = 'ok'; }); set({ ent: o, peek: '' }); }]
          : ['Last 7 days', w[3] === 'Subcontractor' ? 'Bills by invoice' : 'All entries approved', '', '', '', x.week[0]];
        var rows = rowsOf(id, [x.today, weekRow, x.rate, x.cert, x.link]);
        if (!mine.length && E.some(function (e) { return e[1] === w[0] && ent[e[0]] === 'ok'; })) { rows[1].hasBtn = true; rows[1].btnLabel = 'Approved'; rows[1].btnCls = 'done'; rows[1].act = function () { var o = Object.assign({}, self.g('ent', {})); E.forEach(function (e) { if (e[1] === w[0]) delete o[e[0]]; }); set({ ent: o }); }; }
        var cd = !!xd[id + 'call'], td = !!xd[id + 'text'];
        return { name: w[0], ini: w[1], tn: w[2], type: w[3], trade: w[4], rate: w[5], hours: w[6].toFixed(1) + ' h', link: w[7], st: w[8],
          open: xo === id, xcls: xo === id ? 'open' : '', toggle: toggleOf(id),
          x: { rows: rows, callLabel: cd ? 'Calling' : 'Call', callCls: cd ? 'dn' : '', call: flip(id + 'call'), textLabel: td ? 'Texted' : 'Text', textCls: td ? 'dn' : '', text: flip(id + 'text') } };
      }),
      hasPending: pend.length > 0, allDone: pend.length === 0,
      doneMsg: approvedN.length + ' approved, ' + hrs.toFixed(1) + ' h' + (rejectedN.length ? ' · ' + rejectedN.length + ' rejected' : ''),
      okIc: ic('check', 'sage'),
      approveAll: function () { var o = {}; for (var x in ent) o[x] = ent[x]; pend.forEach(function (e) { o[e[0]] = 'ok'; }); set({ ent: o, peek: '' }); },
      undoAll: function () { set({ ent: {}, peek: 'e1' }); },
      entries: pend.map(function (e, i) {
        return { name: e[1], ini: e[2], tn: e[3], day: e[4], span: e[5], job: e[6], hours: e[7].toFixed(1) + ' h',
          flags: e[8].map(function (f) { return { label: f[0], st: f[1] }; }),
          sep: i ? 'border-top: 1px solid var(--line)' : '',
          shift: peek === e[0] ? 'transform: translateX(96px); box-shadow: -1px 0 0 var(--line)' : (peek === e[0] + 'r' ? 'transform: translateX(-96px)' : 'transform: translateX(0)'),
          peek: function () { set({ peek: peek === e[0] ? e[0] + 'r' : (peek === e[0] + 'r' ? '' : e[0]) }); },
          approve: function () { upd(e[0], 'ok'); }, reject: function () { upd(e[0], 'no'); } };
      }),
      equip: equip, equipTotal: '$' + eqT.toLocaleString('en-CA'),
      seatsUsed: used, seatBar: 'width: ' + (used / 5 * 100) + '%',
      inviteOpen: inv, toggleInvite: function () { set({ inv: !inv }); },
      invEmail: email, onInvEmail: function (e) { set({ email: e.target.value }); },
      roles: R.map(function (r, i) { var on = i === role; return { label: r[0], on: on, cls: on ? 'on' : '', pick: function () { set({ role: i }); } }; }),
      roleNote: R[role][1],
      sendStyle: okEmail && used < 5 ? '' : 'opacity: .4',
      sendInvite: function () { if (!okEmail || used >= 5) return; set({ invited: invited.concat([{ email: email, role: R[role][0] }]), email: '', inv: false }); },
      members: members,
      keyIc: ic('lock', 'indigo'),
      codeSub: codes ? '4 new · Crew lead' : '2 active · Crew lead',
      codeBtn: codes ? 'Done' : 'Create codes', makeCodes: function () { set({ codes: !codes }); },
      codesShown: codes, codes: [{ code: 'RSR-4K7Q' }, { code: 'RSR-9MP2' }, { code: 'RSR-T3XH' }, { code: 'RSR-6WDN' }]
    };
