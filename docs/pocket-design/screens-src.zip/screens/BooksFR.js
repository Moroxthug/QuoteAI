    var na = this.g('na', {}), ls = this.g('ls', {}), bf = this.g('bf', 'open'), closed = this.g('closed', false);
    var money = function (n) { return (n < 0 ? '−' : '+') + Math.abs(n).toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var upd = function (key, obj, k, v) { var o = {}; for (var x in obj) o[x] = obj[x]; if (v === null) delete o[k]; else o[k] = v; var s = {}; s[key] = o; set(s); };
    // id, date, desc, amt, hint, match label, icon, tone, initial state
    var B = [
      ['b1', '28 sept.', 'Dépôt Interac · L HART', 2340.00, 'Semble être INV-0412 · Tom & Lena Hart', 'Lier', 'receipt', 'violet', ''],
      ['b2', '26 sept.', 'Home Depot #7011 Toronto', -412.66, 'Correspond à un reçu numérisé par Luca le 26 sept.', 'Lier', 'photo', 'amber', ''],
      ['b3', '25 sept.', 'Sunbelt Rentals', -1110.00, 'Nacelle ciseaux, 6 jours · aucun coût encore', 'Lier…', 'truck', 'teal', ''],
      ['b4', '24 sept.', 'Dépôt de chèque mobile', 780.00, 'Pourrait être INV-0419 · Harbourfront Dental', 'Lier', 'receipt', 'violet', ''],
      ['b5', '22 sept.', 'Frais mensuels RBC', -12.95, 'Aucune correspondance', 'Lier…', 'search', 'slate', ''],
      ['b6', '22 sept.', 'Dépôt Interac · OKOYE', 2497.30, 'INV-0418 · Okoye Condo', '', 'receipt', 'sage', 'match'],
      ['b7', '16 sept.', 'Dépôt Interac · GILL', 1010.22, 'INV-0417 · Gill Residence', '', 'receipt', 'sage', 'match'],
      ['b8', '18 sept.', 'Virement à l’épargne ••9020', -5000.00, 'Entre vos propres comptes', '', 'bank', 'slate', 'ignore']
    ];
    var stateOf = function (b) { return ls[b[0]] !== undefined ? ls[b[0]] : b[8]; };
    var bucket = function (s) { return s === '' ? 'open' : s === 'ignore' ? 'ignored' : 'matched'; };
    var pending = B.filter(function (b) { return stateOf(b) === ''; }).length;
    var I = [
      ['bank', 'Lignes non liées', 'À une facture, un paiement ou un coût', pending, '#'],
      ['pay', 'Paiements hors banque', 'Inscrits, sans ligne bancaire encore', 2, 'Invoices.dc.html'],
      ['cost', 'Coûts en attente', 'Reçus sans catégorie', 3, '#'],
      ['claim', 'Réclamations sans reçu', 'Amara et Dev', 2, 'Team.dc.html'],
      ['tax', 'TVH non ventilée', 'Chaque coût a sa taxe ventilée', 0, '#'],
      ['draft', 'Factures non envoyées', 'Brouillons INV-0422 et INV-0423', 2, 'Invoices.dc.html'],
      ['hours', 'Heures non approuvées', '4 entrées de temps', 4, 'Team.dc.html'],
      ['qb', 'Pas encore dans QuickBooks', 'Tout synchronisé à 7 h 40', 0, '#']
    ];
    var items = I.map(function (it) {
      var isNa = !!na[it[0]], open = it[3] > 0 && !isNa, done = !open;
      return {
        title: it[1], sub: isNa ? 'Marqué sans objet ce mois‑ci' : (it[3] > 0 ? it[2] : it[2]), count: it[3], href: it[4],
        open: open, closed: done, isNa: isNa,
        badge: open ? 'background: rgba(214,149,36,.14); color: var(--warn)' : 'background: var(--ok-soft); color: var(--ok)',
        fade: done ? '' : '',
        naLabel: 'Marquer sans objet : ' + it[1], openLabel: 'Ouvrir : ' + it[1],
        na: function () { upd('na', na, it[0], true); }, undo: function () { upd('na', na, it[0], null); }
      };
    });
    var openCount = items.filter(function (i) { return i.open; }).length;
    var isClosed = closed && openCount === 0;
    var lines = B.filter(function (b) { return bucket(stateOf(b)) === bf; }).map(function (b, i) {
      var s = stateOf(b);
      var ST = { match: ['Liée', 'st-ok si-check'], cost: ['Inscrite en coût', 'st-info si-dot'], ignore: ['Ignorée', 'st-mute si-off'] };
      return {
        date: b[1], desc: b[2], amt: money(b[3]), amtColor: b[3] > 0 ? 'color: var(--ok)' : '',
        hint: s === 'match' && b[8] === '' ? b[4].replace(/^(Semble être|Pourrait être|Correspond à) /, '') : b[4], hintColor: s === '' ? 'color: var(--t2)' : 'color: var(--muted)',
        ic: ic(b[6], b[7]), matchLabel: b[5], sep: i ? 'border-top: 1px solid var(--line)' : '',
        pending: s === '', done: s !== '', status: s ? ST[s][0] : '', st: s ? ST[s][1] : '',
        match: function () { upd('ls', ls, b[0], 'match'); }, cost: function () { upd('ls', ls, b[0], 'cost'); }, ignore: function () { upd('ls', ls, b[0], 'ignore'); },
        undo: function () { upd('ls', ls, b[0], ''); }
      };
    });
    var cnt = function (k) { return B.filter(function (b) { return bucket(stateOf(b)) === k; }).length; };
    return {
      months: [['Juil.', 'Fermé'], ['Août', 'Fermé'], ['Sept.', isClosed ? 'Fermé' : 'Ouvert']].map(function (m, i) { var on = i === 2; return { label: m[0], tag: m[1], on: on, cls: on ? 'on' : '' }; }),
      openCount: openCount, openWord: openCount === 1 ? 'point ouvert' : 'points ouverts', doneCount: items.length - openCount, doneWord: (items.length - openCount) === 1 ? 'terminé' : 'terminés',
      monthWord: isClosed ? 'Fermé' : 'Ouvert', monthSt: isClosed ? 'st-ok' : 'st-warn',
      ticks: items.map(function (i) { return { bg: i.open ? 'background: var(--sunk)' : 'background: var(--ok-dot)' }; }),
      closeLabel: isClosed ? 'Septembre est fermé' : 'Fermer septembre',
      closeStyle: isClosed ? 'background: var(--ok-soft); color: var(--ok)' : (openCount > 0 ? 'opacity: .4' : ''),
      closeNote: isClosed ? 'Verrouillé le 29 sept. · rouvrir depuis ⋯' : (openCount > 0 ? 'Terminez ou marquez S.O. chaque point ouvert d’abord' : 'Verrouille septembre et l’envoie à QuickBooks'),
      closeMonth: function () { if (openCount === 0) set({ closed: true }); },
      checkLabel: (items.length - openCount) + ' sur ' + items.length,
      items: items,
      bf: [['open', 'Non liées'], ['matched', 'Liées'], ['ignored', 'Ignorées']].map(function (f) { var on = f[0] === bf; return { label: f[1], count: cnt(f[0]), on: on, cls: on ? 'on' : '', pick: function () { set({ bf: f[0] }); } }; }),
      lines: lines, noLines: lines.length === 0, bankIc: ic('bank', 'sage')
    };
