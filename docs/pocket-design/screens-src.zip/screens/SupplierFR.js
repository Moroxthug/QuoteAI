    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var menuOpen = this.g('menu', false), called = this.g('called', false), priceDone = this.g('priceDone', false), matched = this.g('matched', null);
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var spark = function (vals) {
      var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), rg = mx - mn || 1;
      var pts = vals.map(function (v, i) { return [2 + i * (60 / (vals.length - 1)), mx === mn ? 14 : 24 - (v - mn) / rg * 20]; });
      return { pts: pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' '), ex: pts[pts.length - 1][0].toFixed(1), ey: pts[pts.length - 1][1].toFixed(1) };
    };
    var P = [
      ['Gypse 1/2 po 4×8', 'la feuille', [18.40, 18.40, 18.95, 19.25, 19.60, 19.95], '15 sept.'],
      ['Composé à joints 17 L', 'le seau', [24.97, 24.97, 25.48, 25.48, 26.48, 26.48], '30 août'],
      ['Montant SPF 2×4×8', 'le montant', [5.98, 5.98, 5.79, 5.62, 5.49, 5.49], '12 août'],
      ['Vis à gypse 1 5/8 po, 5 lb', 'la boîte', [38.97, 38.97, 38.97, 38.97, 38.97, 38.97], 'Stable']
    ];
    var prices = P.map(function (p) {
      var a = p[2][0], b = p[2][p[2].length - 1], d = (b - a) / a * 100, s = spark(p[2]);
      return { name: p[0], unit: p[1], from: money(a), to: money(b), pts: s.pts, ex: s.ex, ey: s.ey, when: p[3],
        delta: Math.abs(d) < 0.05 ? '0 %' : (d > 0 ? '+' : '−') + Math.abs(d).toFixed(1).replace('.', ',') + ' %',
        color: d > 0.05 ? 'color: var(--warn)' : d < -0.05 ? 'color: var(--ok)' : 'color: var(--faint)' };
    });
    var orders = [
      ['Sous-sol Hart · 27 sept.', 'Gypse, 64 feuilles', '', 1842.10, 'Livrée', 'st-ok', 'si-check', 'truck', 'amber'],
      ['Sous-sol Hart · pour jeu.', 'Composé et ruban', '', 312.44, 'Prête à ramasser', 'st-ok', 'si-check', 'box', 'amber'],
      ['Chambres Whitfield · 22 sept.', 'Apprêt, rouleaux, poly', '', 486.06, 'Ramassée', 'st-mute', 'si-check', 'box', 'stone'],
      ['Service Okoye Condo · 28 sept.', 'Clous à plancher, cales', '', 64.00, 'En rupture', 'st-warn', 'si-clock', 'clock', 'slate']
    ].map(function (o) { return { no: o[0], job: o[1], meta: o[2], amt: money(o[3]), status: o[4], st: o[5] + ' ' + o[6], ic: ic(o[7], o[8]) }; });
    var R = [
      ['r1', '27 sept. · commande de gypse', 1842.10, 'Lié à Sous-sol Hart', false],
      ['r2', '22 sept. · fournitures de peinture', 486.06, 'Lié à Chambres Whitfield', false],
      ['r3', '24 sept. · achat au comptoir', 57.23, 'Photo de Luca, sans chantier', true]
    ];
    var receipts = R.map(function (r) {
      var needs = r[4] && !matched;
      return { title: r[1] + (needs ? '' : ''), meta: needs ? money(r[2]) + ' · ' + r[3] : (r[4] ? 'Lié à ' + matched : r[3]),
        amt: money(r[2]), needs: needs && !RO, done: !needs || RO, status: needs ? 'À lier' : 'Lié', st: needs ? 'st-warn si-clock' : 'st-ok si-check',
        ic: ic('receipt', needs ? 'amber' : 'sage'), match: function () { set({ matched: 'Service Okoye Condo' }); } };
    });
    var nMatched = receipts.filter(function (r) { return r.status === 'Lié'; }).length;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'Vous êtes hors ligne.', 'Prix et commandes de ce matin. Les appels fonctionnent toujours.'],
      readOnly: ['b-info', 'eye', 'sky', 'Consultation seulement.', 'Votre rôle peut voir ce fournisseur, mais pas le modifier.']
    };
    var b = B[ST];
    var closeAll = function () { set({ menu: false }); };
    return {
      hdIc: ic('house', 'amber'), warnIc: ic('warn', 'amber'), okIc: ic('check', 'sage'),
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      call: function () { set({ called: true }); }, callLabel: called ? 'Appel…' : 'Appeler',
      prices: prices,
      showNudge: !priceDone && !RO, priceDone: priceDone && !RO,
      updatePrice: function () { set({ priceDone: true }); }, undoPrice: function () { set({ priceDone: false }); },
      orders: orders, receipts: receipts, rcSummary: nMatched + ' sur 3 liés',
      menuOpen: menuOpen, openMenu: function () { set({ menu: true }); }, closeAll: closeAll,
      menu: [
        { label: 'Modifier le fournisseur', sub: 'Contacts, compte et modalités', ic: ic('pen', 'indigo'), style: RO ? 'opacity: .45' : '' },
        { label: 'Partager la liste de commande', sub: 'Texto ou courriel de ce qu’il vous faut', ic: ic('list', 'azure'), style: '' },
        { label: 'Relevé', sub: 'Septembre · PDF', ic: ic('doc', 'azure'), style: '' },
        { label: 'Ajouter un contact', sub: 'Un autre représentant ou la cour', ic: ic('user', 'sage'), style: RO ? 'opacity: .45' : '' },
        { label: 'Archiver le fournisseur', sub: 'Conserve les commandes et reçus passés', ic: ic('box', 'stone'), style: RO ? 'opacity: .45' : 'color: var(--bad)' }
      ]
    };
