    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var failed = ST === 'paymentFailed', down = ST === 'downgraded', member = ST === 'member';
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('en-CA'), total: total.toLocaleString('en-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : '', sub: sub, subStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : 'color: var(--muted)' };
    };
    var meters = down ? [
      meter('Logins', 2, 2, 'Luca Bianchi’s login is paused'),
      meter('Quotes', 51, 60, 'Almost used · resets Oct 1'),
      meter('Active jobs', 3, 3, 'Finish one to start another'),
      meter('Receipt scans', 38, 100, 'Resets Oct 1')
    ] : [
      meter('Logins', 3, 5, 'Marco, Luca and the office'),
      meter('AI quotes', 142, 500, 'Resets Oct 1'),
      meter('Texts', 412, 1000, 'Resets Oct 1'),
      meter('Receipt scans', 38, 200, 'Resets Oct 1')
    ];
    var B = ['Unlimited quotes and jobs', 'Team time and crew links', 'Assistant', 'Analytics', 'QuickBooks and Wave sync', 'Calendar sync', 'Card payments', 'Send from Gmail'];
    var inc;
    if (down) {
      var P = ['60 quotes a month', 'Price book and contracts', '3 active jobs', 'Costs and invoicing', '2 logins'];
      var L = ['Team time and crew links', 'Assistant', 'Analytics', 'QuickBooks and Wave sync', 'Card payments'];
      inc = P.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; })
        .concat(L.map(function (t) { return { t: t, ic: ic('lock', 'slate'), locked: true, style: 'color: var(--muted)' }; }));
    } else inc = B.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; });
    inc.forEach(function (f, i) { f.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
    var bn = failed ? { show: true, cls: 'b-bad', ic: ic('card', 'rose'), t: 'Your last payment didn’t go through.', s: 'Update your payment method on quoteai.ca by Oct 6. Everything keeps working until then.' }
      : down ? { show: true, cls: 'b-info', ic: ic('tier2', 'azure'), t: 'You’re on Pro since Sep 14.', s: 'Business features are paused, not deleted. Your crew hours and reports are still here.' }
      : member ? { show: true, cls: 'b-info', ic: ic('lock', 'slate'), t: 'Usage only.', s: 'Your role can see how much of the plan is used.' }
      : { show: false, cls: '', ic: ic('dot', 'slate'), t: '', s: '' };
    var billRows = [
      failed ? stat(val('card', 'violet', 'Payment method', 'Visa ending 4242', ''), 'Declined', 'st-bad si-x') : val('card', 'violet', 'Payment method', 'On file at quoteai.ca', 'Visa ••4242', true),
      val('receipt', 'stone', 'Receipts', 'Emailed to marco@rossireno.ca', 'Monthly')
    ];
    return {
      roBanner: roBanner, bn: bn, member: member, canManage: !member,
      plan: down ? 'Pro' : 'Business', tierIc: down ? ic('tier2', 'azure') : ic('tier3', 'violet'),
      planSt: failed ? { w: 'Payment due Oct 6', cls: 'st-bad si-alert' } : down ? { w: 'Changed Sep 14', cls: 'st-mute si-check' } : { w: 'Active', cls: 'st-ok si-live' },
      k1: failed ? { l: 'Update by', v: 'Oct 6', st: 'color: var(--bad)' } : { l: 'Renews', v: 'Oct 14, 2026', st: '' },
      k2: { l: 'Logins', v: down ? '2 of 2' : '3 of 5' },
      meters: meters, incTitle: down ? 'On Pro' : 'Included in Business', inc: inc,
      gBill: grp('Billing', billRows, '', 190),
      webIc: ic('globe', 'violet')
    };
