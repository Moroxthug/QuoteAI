    var mode = this.g('mode', 0), txt = this.g('txt', ''), trade = this.g('trade', -1), lay = this.g('lay', 1), cl = this.g('cl', 'dw'), w = this.g('w', 0), remember = this.g('rem', true);
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var seg = function (key, cur, labels) {
      var n = labels.length;
      return { cols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))', ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { var o = {}; o[key] = i; set(o); } }; }) };
    };
    // ---------- AI mode ----------
    var EX = [
      ['Painting', 'Repaint 3 bedrooms and the hallway, about 1,120 sq ft of walls and ceilings, two coats. Bath ceiling has water damage, cut out and patch. We supply paint.'],
      ['Drywall', 'Board, tape and mud a 600 sq ft basement rec room, level 4 finish, one bulkhead around the duct.'],
      ['Flooring', 'Remove carpet in 2 bedrooms (320 sq ft) and install click vinyl plank with new baseboards.'],
      ['Decks', 'Power wash and stain a 14 by 16 ft cedar deck with 30 ft of railing, two coats semi-transparent.'],
      ['Bathrooms', 'Gut and redo a 5 by 8 ft main bath: tub to walk-in shower, tile floor and walls, new vanity and toilet.'],
      ['Kitchens', 'Paint 24 cabinet doors and boxes, new hardware, and a subway tile backsplash, about 30 sq ft.'],
      ['Basements', 'Finish 750 sq ft basement: framing, insulation, drywall, pot lights, LVP floor and a 3-piece bath rough-in.']
    ];
    var examples = EX.map(function (e, i) { var on = i === trade; return { label: e[0], cls: on ? 'on' : '', on: on, pick: function () { set({ trade: i, txt: e[1] }); } }; });
    var clients = [['dw', 'Dana Whitfield', '17 Castle Frank Cres', 'tn1'], ['pn', 'Priya Nair', '212 Dovercourt Rd', 'tn2'], ['th', 'Tom & Lena Hart', '48 Galloway Rd, Scarborough', 'tn3'], ['hd', 'Harbourfront Dental', 'Queens Quay W', 'tn4']].map(function (c) {
      var on = cl === c[0];
      return { id: c[0], name: c[1], addr: c[2], tn: c[3], ini: c[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (x) { return x[0]; }).join('').slice(0, 2).toUpperCase(), on: on,
        radio: on ? 'box-shadow: inset 0 0 0 6px var(--ink)' : 'box-shadow: inset 0 0 0 1.5px var(--line2)', pick: function () { set({ cl: c[0] }); } };
    });
    var newOn = cl === 'new';
    var clientName = newOn ? 'a new client' : clients.filter(function (c) { return c.on; })[0].name;
    var STEPS = ['Reading your description', 'Measuring rooms and quantities', 'Pricing from your price list', 'Adding HST, Ontario 13%', 'Laying out the PDF'];
    var wsteps = STEPS.map(function (s, i) {
      var done = w > i + 1, cur = w === i + 1;
      return { label: s, done: done, cur: cur, todo: !done && !cur, lab: done ? 'color: var(--ink)' : cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--faint)' };
    });
    var tick = function (n) { setTimeout(function () { self.setState({ w: n }); if (n < 6) tick(n + 1); }, 750); };
    // ---------- Manual mode ----------
    var ml = this.g('ml', {});
    var CH = [
      ['Preparation', [['Floor protection and cleanup', 'lump sum', 1, 180], ['Bath ceiling water-damage repair', 'lump sum', 1, 640], ['Stain-blocking primer', 'sq ft', 48, 1.85]]],
      ['Painting', [['Walls and ceilings, 3 bedrooms and hallway', 'sq ft', 1120, 2.10], ['Paint and sundries', 'lump sum', 1, 395]]]
    ];
    var exempt = this.g('ex', false), terms = this.g('terms', 0);
    var sub = 0;
    var chapters = CH.map(function (c, ci) {
      var cs = 0;
      var lines = c[1].map(function (l, li) {
        var kq = ci + '-' + li + 'q', kp = ci + '-' + li + 'p';
        var qv = ml[kq] !== undefined ? ml[kq] : String(l[2]), pv = ml[kp] !== undefined ? ml[kp] : l[3].toFixed(2);
        var tot = Math.round((parseFloat(String(qv).replace(/,/g, '')) || 0) * (parseFloat(String(pv).replace(/[$,]/g, '')) || 0) * 100) / 100;
        cs += tot;
        var upd = function (k) { return function (e) { var o = Object.assign({}, self.g('ml', {})); o[k] = e.target.value; set({ ml: o }); }; };
        return { desc: l[0], unit: l[1], q: qv, p: pv, total: money(tot), onQ: upd(kq), onP: upd(kp), sep: li ? 'border-top: 1px solid var(--line)' : '', idq: 'q' + kq, idp: 'p' + kp, aiIc: ic('orb', 'violet') };
      });
      cs = Math.round(cs * 100) / 100; sub += cs;
      return { n: (ci + 1) + '', title: c[0], lines: lines, subtotal: money(cs) };
    });
    sub = Math.round(sub * 100) / 100;
    var tax = exempt ? 0 : Math.round(sub * 0.13 * 100) / 100;
    var TERMS = ['30% deposit, rest on completion', '50% now, 50% on completion', 'All on completion', 'Net 15'];
    // ---------- Price list ----------
    var pq = this.g('pq', ''), pcat = this.g('pcat', 0), sel = this.g('sel', { p1: 1120, p3: 48, p8: 1 });
    var CATS = ['All', 'Painting', 'Drywall', 'Flooring', 'Site'];
    var PB = [
      ['p1', 'Interior walls, two coats', 'Painting', 'sq ft', 2.10, 100, 20],
      ['p2', 'Ceilings, two coats', 'Painting', 'sq ft', 1.65, 100, 20],
      ['p3', 'Stain-blocking primer', 'Painting', 'sq ft', 1.85, 40, 4],
      ['p4', 'Drywall patch, small', 'Drywall', 'each', 85, 1, 1],
      ['p5', 'Skim coat, level 5', 'Drywall', 'sq ft', 1.40, 100, 20],
      ['p6', 'Vinyl plank, supply and install', 'Flooring', 'sq ft', 6.80, 100, 20],
      ['p7', 'Baseboard, supply and install', 'Flooring', 'ln ft', 4.25, 50, 10],
      ['p8', 'Floor protection and cleanup', 'Site', 'lump sum', 180, 1, 1],
      ['p9', 'Disposal bin, 14 yd', 'Site', 'each', 425, 1, 1]
    ];
    var catIc = { Painting: ['pen', 'violet'], Drywall: ['box', 'stone'], Flooring: ['ruler', 'amber'], Site: ['truck', 'teal'] };
    var pql = pq.trim().toLowerCase();
    var items = PB.filter(function (p) { return (pcat === 0 || p[2] === CATS[pcat]) && (!pql || p[1].toLowerCase().indexOf(pql) >= 0); }).map(function (p) {
      var on = sel[p[0]] !== undefined;
      return { name: p[1], rate: money(p[4]) + ' / ' + p[3], cat: p[2], ic: ic(catIc[p[2]][0], catIc[p[2]][1]), on: on, off: !on,
        toggle: function () { var o = Object.assign({}, self.g('sel', { p1: 1120, p3: 48, p8: 1 })); if (o[p[0]] !== undefined) delete o[p[0]]; else o[p[0]] = p[5]; set({ sel: o }); } };
    });
    var picked = PB.filter(function (p) { return sel[p[0]] !== undefined; });
    var ptot = 0;
    var selRows = picked.map(function (p, i) {
      var q = sel[p[0]], t = Math.round(q * p[4] * 100) / 100; ptot += t;
      var chg = function (d) { return function () { var o = Object.assign({}, self.g('sel', { p1: 1120, p3: 48, p8: 1 })); o[p[0]] = Math.max(p[6], o[p[0]] + d); set({ sel: o }); }; };
      return { name: p[1], qty: q.toLocaleString('en-CA') + ' ' + (p[3] === 'lump sum' ? '' : p[3]), total: money(t), dec: chg(-p[6]), inc: chg(p[6]), sep: i ? 'border-top: 1px solid var(--line)' : '', decL: 'Less ' + p[1], incL: 'More ' + p[1] };
    });
    ptot = Math.round(ptot * 100) / 100;
    var modeSeg = seg('mode', mode, ['Write with AI', 'Manual', 'Price list']);
    return {
      modeSeg: modeSeg, isAI: mode === 0, isMan: mode === 1, isPB: mode === 2,
      // AI
      aiForm: mode === 0 && w === 0, aiWriting: mode === 0 && w > 0, txt: txt, onTxt: function (e) { set({ txt: e.target.value, trade: -1 }); },
      examples: examples, laySeg: seg('lay', lay, ['Standard', 'Professional', 'Elegant']),
      clients: clients, newOn: newOn, newRadio: newOn ? 'box-shadow: inset 0 0 0 6px var(--ink)' : 'box-shadow: inset 0 0 0 1.5px var(--line2)', pickNew: function () { set({ cl: 'new' }); },
      remTrack: remember ? 'background: var(--acc)' : 'background: var(--track-off)', remKnob: remember ? 'transform: translateX(20px)' : 'transform: translateX(0)', remember: remember, flipRem: function () { set({ rem: !self.g('rem', true) }); },
      micIc: ic('mic', 'violet'), orbIc: ic('orb', 'violet'), photoIc: ic('photo', 'sky'), fileIc: ic('file', 'clay'), sheetIc: ic('bars', 'sage'),
      write: function () { set({ w: 1 }); tick(2); },
      wsteps: wsteps, wDone: w >= 6, wBusy: w > 0 && w < 6,
      wTitle: w >= 6 ? 'Your quote is ready' : 'Writing your quote', wSub: 'For ' + clientName + ' · ' + ['Standard', 'Professional', 'Elegant'][lay] + ' layout',
      restart: function () { set({ w: 0 }); },
      aiPrimary: mode === 0 && w < 6, aiOpen: mode === 0 && w >= 6, aiLabel: w > 0 ? 'Writing…' : 'Write my quote', aiBtnStyle: w > 0 ? 'opacity: .55' : '',
      // Manual
      chapters: chapters, exempt: exempt, exTrack: exempt ? 'background: var(--acc)' : 'background: var(--track-off)', exKnob: exempt ? 'transform: translateX(20px)' : 'transform: translateX(0)', flipEx: function () { set({ ex: !self.g('ex', false) }); },
      mSub: money(sub), mTax: exempt ? 'Exempt' : money(tax), mTaxLabel: exempt ? 'Tax' : 'HST, Ontario 13%', mTotal: money(Math.round((sub + tax) * 100) / 100),
      terms: TERMS.map(function (t, i) { var on = i === terms; return { label: t, cls: on ? 'on' : '', on: on, pick: function () { set({ terms: i }); } }; }),
      // Price list
      pq: pq, onPq: function (e) { set({ pq: e.target.value }); },
      cats: CATS.map(function (c, i) { var on = i === pcat; return { label: c, cls: on ? 'on' : '', on: on, pick: function () { set({ pcat: i }); } }; }),
      items: items, noItems: items.length === 0, selRows: selRows, hasSel: selRows.length > 0, noSel: selRows.length === 0,
      selCount: selRows.length + (selRows.length === 1 ? ' item' : ' items'), pSub: money(ptot),
      pbLabel: selRows.length ? 'Build quote from ' + selRows.length + (selRows.length === 1 ? ' item' : ' items') : 'Add items to start',
      emptyIc: ic('search', 'slate'), listIc: ic('list', 'slate')
    };
