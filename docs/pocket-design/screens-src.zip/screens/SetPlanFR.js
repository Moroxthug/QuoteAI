    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var failed = ST === 'paymentFailed', down = ST === 'downgraded', member = ST === 'member';
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('fr-CA'), total: total.toLocaleString('fr-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : '', sub: sub, subStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : 'color: var(--muted)' };
    };
    var meters = down ? [
      meter('Accès', 2, 2, 'L’accès de Luca Bianchi est en pause'),
      meter('Soumissions', 51, 60, 'Presque épuisé · remise à zéro le 1er oct.'),
      meter('Chantiers actifs', 3, 3, 'Terminez-en un pour en lancer un autre'),
      meter('Reçus numérisés', 38, 100, 'Remise à zéro le 1er oct.')
    ] : [
      meter('Accès', 3, 5, 'Marco, Luca et le bureau'),
      meter('Soumissions IA', 142, 500, 'Remise à zéro le 1er oct.'),
      meter('Textos', 412, 1000, 'Remise à zéro le 1er oct.'),
      meter('Reçus numérisés', 38, 200, 'Remise à zéro le 1er oct.')
    ];
    var B = ['Soumissions et chantiers illimités', 'Heures et liens d’équipe', 'Assistant', 'Analyses', 'Synchro QuickBooks et Wave', 'Synchro du calendrier', 'Paiement par carte', 'Envoi depuis Gmail'];
    var inc;
    if (down) {
      var P = ['60 soumissions par mois', 'Liste de prix et contrats', '3 chantiers actifs', 'Coûts et facturation', '2 accès'];
      var L = ['Heures et liens d’équipe', 'Assistant', 'Analyses', 'Synchro QuickBooks et Wave', 'Paiement par carte'];
      inc = P.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; })
        .concat(L.map(function (t) { return { t: t, ic: ic('lock', 'slate'), locked: true, style: 'color: var(--muted)' }; }));
    } else inc = B.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; });
    inc.forEach(function (f, i) { f.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
    var bn = failed ? { show: true, cls: 'b-bad', ic: ic('card', 'rose'), t: 'Votre dernier paiement n’est pas passé.', s: 'Mettez à jour votre mode de paiement sur quoteai.ca d’ici le 6 oct. Tout fonctionne jusque-là.' }
      : down ? { show: true, cls: 'b-info', ic: ic('tier2', 'azure'), t: 'Vous êtes sur Pro depuis le 14 sept.', s: 'Les fonctions Business sont en pause, pas supprimées. Les heures et rapports de l’équipe sont toujours là.' }
      : member ? { show: true, cls: 'b-info', ic: ic('lock', 'slate'), t: 'Utilisation seulement.', s: 'Votre rôle permet de voir l’utilisation du forfait.' }
      : { show: false, cls: '', ic: ic('dot', 'slate'), t: '', s: '' };
    var billRows = [
      failed ? stat(val('card', 'violet', 'Mode de paiement', 'Visa se terminant par 4242', ''), 'Refusé', 'st-bad si-x') : val('card', 'violet', 'Mode de paiement', 'Enregistré sur quoteai.ca', 'Visa ••4242', true),
      val('receipt', 'stone', 'Reçus', 'Envoyés à marco@rossireno.ca', 'Mensuels')
    ];
    return {
      roBanner: roBanner, bn: bn, member: member, canManage: !member,
      plan: down ? 'Pro' : 'Business', tierIc: down ? ic('tier2', 'azure') : ic('tier3', 'violet'),
      planSt: failed ? { w: 'Paiement dû le 6 oct.', cls: 'st-bad si-alert' } : down ? { w: 'Changé le 14 sept.', cls: 'st-mute si-check' } : { w: 'Actif', cls: 'st-ok si-live' },
      k1: failed ? { l: 'À régler d’ici le', v: '6 oct.', st: 'color: var(--bad)' } : { l: 'Renouvellement', v: '14 oct. 2026', st: '' },
      k2: { l: 'Accès', v: down ? '2 sur 2' : '3 sur 5' },
      meters: meters, incTitle: down ? 'Avec Pro' : 'Inclus avec Business', inc: inc,
      gBill: grp('Facturation', billRows, '', 190),
      webIc: ic('globe', 'violet')
    };
