    var tab = this.g('tab', 'period'), pi = this.g('pi', 1), exOpen = this.g('exOpen', false), exported = this.g('exported', '');
    var claim = this.g('claim', 'pending'), freq = this.g('freq', 1), preset = this.g('preset', 1);
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var whole = function (n) { return '$' + Math.round(n).toLocaleString('en-CA'); };
    var h = function (n) { return n.toFixed(1) + ' h'; };
    var PER = [
      { label: 'Aug 31 – Sep 13', sub: 'Every 2 weeks · paid Sep 18', status: 'Exported Sep 15', st: 'st-ok' },
      { label: 'Sep 14 – Sep 27', sub: 'Every 2 weeks · pay day Fri Oct 2', status: 'Ready to export', st: 'st-acc' },
      { label: 'Sep 28 – Oct 11', sub: 'Every 2 weeks · pay day Fri Oct 16', status: 'In progress · 2 days logged', st: 'st-mute' }
    ];
    var per = PER[pi];
    if (pi === 1 && exported) per = { label: per.label, sub: per.sub, status: 'Exported today', st: 'st-ok' };
    // name, ini, tint, role, rate, reg h, ot h, travel label, travel amt, flag
    var E = [
      ['Luca Bianchi', 'LB', 'tn1', 'Painter lead', 34, 80, 6, 'Travel · 4 days', 60, ''],
      ['Amara Okafor', 'AO', 'tn4', 'Drywall', 31, 80, 8, '', 0, ''],
      ['Dev Patel', 'DP', 'tn3', 'Carpenter', 33, 76, 0, 'Per diem · 3 days', 135, ''],
      ['Sofia Marin', 'SM', 'tn2', 'Apprentice', 21, 72.5, 0, '', 0, 'No payroll number']
    ];
    var gT = 0, vT = 0, trT = 0, hT = 0, otT = 0;
    var emps = E.map(function (e) {
      var reg = e[4] * e[5], ot = e[4] * 1.5 * e[6], vac = Math.round((reg + ot) * 0.04 * 100) / 100, gross = reg + ot + vac + e[8];
      gT += gross; vT += vac; trT += e[8]; hT += e[5] + e[6]; otT += e[6];
      var lines = [{ label: 'Regular', qty: h(e[5]) + ' × ' + money(e[4]), amt: money(reg) }];
      if (e[6]) lines.push({ label: 'Overtime', qty: h(e[6]) + ' × ' + money(e[4] * 1.5), amt: money(ot) });
      lines.push({ label: 'Vacation pay', qty: '4%', amt: money(vac) });
      if (e[8]) lines.push({ label: e[7].split(' · ')[0], qty: e[7].split(' · ')[1], amt: money(e[8]) });
      return { name: e[0], ini: e[1], tn: e[2], role: e[3] + ' · ' + money(e[4]) + '/h', gross: money(gross), hours: h(e[5] + e[6]), lines: lines, flag: e[9] };
    });
    var TG = [['CSV file', 'Any payroll or spreadsheet', 'doc', 'slate'], ['Wagepoint', 'Connected · 4 of 4 matched', 'sync', 'teal'], ['Payworks', 'Import file', 'export', 'azure'], ['QuickBooks Payroll', 'Connected', 'bank', 'sage']];
    // job, client, hours, ot, travel, icon
    var J = [['Basement finish', 'Tom & Lena Hart', 168.5, 10, 60, ['house', 'teal']], ['Hallway flooring', 'Okoye Condo', 78, 4, 135, ['building', 'violet']], ['Basement change order', 'Tom & Lena Hart', 52, 0, 0, ['doc', 'amber']], ['Shop and pick-ups', 'No job', 24, 0, 0, ['truck', 'slate']]];
    var AVG = 30.4;
    var jobs = J.map(function (j) {
      var st = (j[2] - j[3]) * AVG, prem = j[3] * AVG * 0.5 + j[3] * AVG, burden = (st + prem) * 0.18, cost = st + prem + burden + j[4];
      return { name: j[0], client: j[1], ic: ic(j[5][0], j[5][1]), c: cost, cost: whole(cost), cells: [
        { l: 'Hours', v: j[2].toFixed(1) }, { l: 'Overtime', v: j[3].toFixed(1) }, { l: 'Straight time', v: whole(st) },
        { l: 'Premium', v: whole(prem) }, { l: 'Burden', v: whole(burden) }, { l: 'Travel', v: whole(j[4]) }] };
    });
    var jT = jobs.reduce(function (a, j) { return a + j.c; }, 0);
    jobs.forEach(function (j) { j.bar = 'width: ' + (j.c / jT * 100).toFixed(1) + '%'; });
    var FQ = ['Weekly', 'Every 2 weeks', 'Twice a month'];
    var FN = ['Pay day every Friday', 'Pay day Friday after the period ends', 'Pay days on the 15th and the last day'];
    var PR = [['Ontario general', 'After 44 h a week', '1.5×', 'Not required'], ['Ontario construction', 'After 44 h a week', '1.5×', 'Sat and stat days at 1.5×'], ['Québec R-20', 'After 40 h a week', '1.5×', 'After 50 h at 2×'], ['BC', 'After 8 h a day', '1.5×', 'After 12 h a day at 2×']];
    var p = PR[preset];
    return {
      tabs: [['period', 'Pay period'], ['jobs', 'Labour by job'], ['rules', 'Rules and export']].map(function (t) { var on = t[0] === tab; return { label: t[1], on: on, cls: on ? 'on' : '', pick: function () { set({ tab: t[0], exOpen: false }); } }; }),
      isPeriod: tab === 'period', isJobs: tab === 'jobs', isRules: tab === 'rules',
      per: per,
      prevP: function () { if (pi > 0) set({ pi: pi - 1 }); }, nextP: function () { if (pi < 2) set({ pi: pi + 1 }); },
      prevStyle: pi === 0 ? 'opacity: .3' : '', nextStyle: pi === 2 ? 'opacity: .3' : '',
      exportOpen: exOpen, toggleExport: function () { set({ exOpen: !exOpen }); },
      exportLabel: exported ? 'Export again' : 'Export pay period',
      targets: TG.map(function (t, i) { return { label: t[0], sub: t[1], ic: ic(t[2], t[3]), last: i === 1, pick: function () { set({ exported: t[0], exOpen: false }); } }; }),
      exported: exported, okIc: ic('check', 'sage'), grossTotal: money(gT),
      warnings: [
        { title: '4 time entries to approve', sub: 'Luca, Amara and Dev · 31.5 h', tag: 'Review', st: 'st-warn', ic: ic('clock', 'amber'), href: 'Team.dc.html' },
        { title: '2 entries changed since export', sub: 'Edited Sep 28 after the last CSV', tag: 'Changed', st: 'st-warn', ic: ic('sync', 'clay'), href: '#' },
        { title: 'No payroll number for Sofia', sub: 'Wagepoint needs it to match her', tag: 'Missing', st: 'st-bad', ic: ic('user', 'rose'), href: 'Team.dc.html' },
        { title: 'Thanksgiving is Mon Oct 12', sub: 'Stat holiday in the next period', tag: 'Next', st: 'st-info', ic: ic('cal', 'azure'), href: '#' }
      ],
      totals: [
        { label: 'Gross pay', value: money(gT), sub: 'Before deductions', sep: '' },
        { label: 'Hours', value: hT.toFixed(1), sub: otT.toFixed(1) + ' overtime', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Vacation pay', value: money(vT), sub: '4% of earnings', sep: 'border-top: 1px solid var(--line)' },
        { label: 'Travel and per diem', value: money(trT), sub: claim === 'ok' ? '+ $97.98 mileage' : '1 claim waiting', sep: 'border-top: 1px solid var(--line); border-left: 1px solid var(--line)' }
      ],
      emps: emps,
      claimPending: claim === 'pending', claimCount: claim === 'pending' ? '1 to approve' : 'All done',
      claimWord: claim === 'pending' ? 'To approve' : claim === 'ok' ? 'Approved' : 'Rejected', claimSt: claim === 'pending' ? 'st-warn' : claim === 'ok' ? 'st-ok' : 'st-mute',
      approveClaim: function () { set({ claim: 'ok' }); }, rejectClaim: function () { set({ claim: 'no' }); },
      jobs: jobs, jobTotal: whole(jT),
      freqInd: 'width: calc((100% - 4px) / 3); transform: translateX(' + (freq * 100) + '%)',
      freqs: FQ.map(function (f, i) { var on = i === freq; return { label: f, on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ freq: i }); } }; }),
      freqNote: FN[freq],
      presets: PR.map(function (x, i) { var on = i === preset; return { label: x[0], on: on, cls: on ? 'on' : '', pick: function () { set({ preset: i }); } }; }),
      otRows: [{ l: 'Overtime starts', v: p[1] }, { l: 'Overtime rate', v: p[2] }, { l: 'Premium time', v: p[3] }],
      ruleRows: [
        { l: 'Stat holidays', sub: 'Ontario · next Thanksgiving, Oct 12', v: '9 a year', ic: ic('cal', 'azure') },
        { l: 'Vacation pay', sub: '6% after 5 years', v: '4%', ic: ic('sun', 'gold') },
        { l: 'Travel rate', sub: 'Personal vehicle', v: '$0.69/km', ic: ic('truck', 'teal') },
        { l: 'Per diem', sub: 'Jobs over 80 km away', v: '$45/day', ic: ic('pin', 'rose') }
      ],
      exportRows: [
        { l: 'Export to', sub: 'Wagepoint, every pay period', subCls: '', tag: '', st: '', ic: ic('export', 'violet') },
        { l: 'Earning codes', sub: 'REG · OT · VAC · TRV · PD', subCls: 'mono', tag: '', st: '', ic: ic('code', 'slate') },
        { l: 'Payroll numbers', sub: '3 of 4 employees', subCls: '', tag: '1 missing', st: 'st-warn', ic: ic('users', 'indigo') }
      ]
    };
