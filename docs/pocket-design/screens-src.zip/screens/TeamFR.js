    var ent = this.g('ent', {}), peek = this.g('peek', 'e1'), inv = this.g('inv', false), role = this.g('role', 0), email = this.g('email', '');
    var invited = this.g('invited', []), codes = this.g('codes', false);
    var d1 = function (n) { return n.toFixed(1).replace('.', ','); };
    var W = [
      ['Luca Bianchi', 'LB', 'tn1', 'Employé', 'Chef peintre', '34,00 $/h · charges 18 %', 148.5, 'Lien actif', 'st-ok si-live'],
      ['Amara Okafor', 'AO', 'tn4', 'Employée', 'Gypse', '31,00 $/h · charges 18 %', 152.0, 'Lien actif', 'st-ok si-live'],
      ['Dev Patel', 'DP', 'tn3', 'Employé', 'Menuisier', '33,00 $/h · charges 18 %', 139.0, 'Lien envoyé', 'st-info si-q1'],
      ['Sofia Marin', 'SM', 'tn2', 'Employée', 'Apprentie', '21,00 $/h · sans n° de paie', 128.5, 'Aucun lien', 'st-mute si-off'],
      ['Jonah Reyes', 'JR', 'tn5', 'Sous-traitant', 'Électricien', '85,00 $/h · sur facture', 44.0, 'Lien actif', 'st-ok si-live']
    ];
    // today, [week hours, week note], rate, cert, link  (row: title, sub, status, status class, button, amount)
    var WX = {
      'Luca Bianchi': { today: ['Harbourfront Dental', 'Arrivé à 8 h 02 · préparation et apprêt', 'Sur place', 'st-ok si-live'], week: ['38,5 h'], rate: ['34,00 $/h · charges 18 %', 'Visible par vous seulement · coût réel 40,12 $/h'], cert: ['SIMDUT', 'Valide jusqu’en juin 2027', 'Valide', 'st-ok si-check'], link: ['Lien d’équipe', 'Ouvert aujourd’hui à 8 h 02', 'Actif', 'st-ok si-live'] },
      'Amara Okafor': { today: ['Sous-sol Hart', 'Arrivée à 7 h 15 · 48 Galloway Rd', 'Sur place', 'st-ok si-live'], week: ['42,4 h'], rate: ['31,00 $/h · charges 18 %', 'Visible par vous seulement · coût réel 36,58 $/h'], cert: ['Travail en hauteur', 'IHSA · expire le 12 nov.', 'Expire bientôt', 'st-warn si-clock', 'Renouveler'], link: ['Lien d’équipe', 'Ouvert aujourd’hui à 7 h 15', 'Actif', 'st-ok si-live'] },
      'Dev Patel': { today: ['Gill Residence', 'Arrivé à 8 h · poteaux de clôture', 'Sur place', 'st-ok si-live'], week: ['30,5 h'], rate: ['33,00 $/h · charges 18 %', 'Visible par vous seulement · coût réel 38,94 $/h'], cert: ['Travail en hauteur', 'IHSA · expire le 14 oct.', 'Dans 15 jours', 'st-bad si-alert', 'Rappeler'], link: ['Lien d’équipe', 'Envoyé le 27 sept. · pas ouvert', 'Envoyé', 'st-info si-q1', 'Renvoyer'] },
      'Sofia Marin': { today: ['Sous-sol Hart', 'Arrivée à 7 h 30 · pointée par Amara', 'Sur place', 'st-ok si-live'], week: ['32,0 h'], rate: ['21,00 $/h · apprentie', 'Visible par vous seulement · pas encore de numéro de paie', 'Manquant', 'st-warn si-alert'], cert: ['SIMDUT', 'Valide jusqu’en mars 2027', 'Valide', 'st-ok si-check'], link: ['Lien d’équipe', 'Elle pointe par l’entremise d’Amara', 'Aucun lien', 'st-mute si-off', 'Envoyer le lien'] },
      'Jonah Reyes': { today: ['Sous-sol Hart à 10 h 30', 'Étiquettes du panneau · une heure', 'Réservé', 'st-info si-q1'], week: ['3,5 h'], rate: ['85,00 $/h · sous-traitant', 'Visible par vous seulement · sans charges, facture chaque mois'], cert: ['Licence ESA', 'Maître électricien · valide jusqu’en 2028', 'Valide', 'st-ok si-check'], link: ['Lien d’équipe', 'Ouvert le 25 sept.', 'Actif', 'st-ok si-live'] }
    };
    var E = [
      ['e1', 'Luca Bianchi', 'LB', 'tn1', 'lun. 28 sept.', '7 h 02 – 15 h 48', 'Finition du sous-sol · Tom & Lena Hart', 8.3, [['Saisi par le travailleur', 'st-mute si-dot']]],
      ['e2', 'Amara Okafor', 'AO', 'tn4', 'lun. 28 sept.', '7 h 15 – 18 h 10', 'Plancher du corridor · Okoye Condo', 10.4, [['Heures supp. 2,4 h', 'st-warn si-clock']]],
      ['e3', 'Dev Patel', 'DP', 'tn3', 'sam. 26 sept.', '8 h – 14 h 30', 'Plancher du corridor · Okoye Condo', 6.5, [['Hors chantier au pointage', 'st-bad si-alert'], ['Samedi', 'st-info si-dot']]],
      ['e4', 'Luca Bianchi', 'LB', 'tn1', 'sam. 26 sept.', '9 h – 15 h 18', 'Finition du sous-sol · Tom & Lena Hart', 6.3, [['Samedi', 'st-info si-dot']]]
    ];
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Appeler': 'Appelé', 'Texto': 'Envoyé', 'Rappeler': 'Rappel envoyé', 'Renouveler': 'Demandé', 'Renvoyer': 'Renvoyé', 'Envoyer le lien': 'Lien envoyé', 'Vérifier': 'Vérifié', 'Approuver': 'Approuvé' };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Terminé') : r[4], btnCls: d2 ? 'done' : '', act: r[6] || function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); } }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var upd = function (k, v) { var o = {}; for (var x in ent) o[x] = ent[x]; o[k] = v; set({ ent: o, peek: '' }); };
    var pend = E.filter(function (e) { return !ent[e[0]]; });
    var approvedN = E.filter(function (e) { return ent[e[0]] === 'ok'; }), rejectedN = E.filter(function (e) { return ent[e[0]] === 'no'; });
    var hrs = approvedN.reduce(function (a, e) { return a + e[7]; }, 0);
    var R = [['Bureau', 'Soumissions, factures, comptabilité · pas de paie'], ['Contremaître', 'Chantiers, équipe et heures · pas d’argent'], ['Chef d’équipe', 'Ses chantiers et ses tâches seulement']];
    var members = [
      { name: 'Marco Rossi', ini: 'MR', tn: 'tn5', sub: 'marco@rossireno.ca · vous', role: 'Propriétaire', st: 'st-acc' },
      { name: 'Luca Bianchi', ini: 'LB', tn: 'tn1', sub: 'Actif aujourd’hui', role: 'Contremaître', st: 'st-mute' },
      { name: 'office@rossireno.ca', ini: '@', tn: 'tn4', sub: 'Invitation du 24 sept. · en attente', role: 'Bureau', st: 'st-info' }
    ].concat(invited.map(function (i) { return { name: i.email, ini: '@', tn: 'tn2', sub: 'Invitation envoyée à l’instant', role: i.role, st: 'st-info' }; }));
    var used = members.length;
    var equip = [
      { name: 'Pulvérisateur sans air Graco', meta: '45 $/jour · 12 jours facturés', fin: '', charged: '540 $', kind: 'Propriété', st: 'st-mute', ic: ic('wave', 'violet'), n: 540 },
      { name: 'Plateforme élévatrice, 19 pi', meta: 'Sunbelt · 185 $/jour · retour le 2 oct.', fin: '', charged: '1 110 $', kind: 'Location', st: 'st-info', ic: ic('box', 'amber'), n: 1110 },
      { name: 'Ford Transit 2024', meta: '38 $/jour · 20 jours facturés', fin: 'RBC · 912 $/mois · 31 mois restants', charged: '760 $', kind: 'Financé', st: 'st-acc', ic: ic('truck', 'teal'), n: 760 }
    ];
    var eqT = equip.reduce(function (a, q) { return a + q.n; }, 0);
    var okEmail = /.+@.+\..+/.test(email);
    return {
      kpis: [
        { label: 'Équipe', value: '5', sub: '4 employés · 1 sous‑traitant', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Heures du mois', value: '612', sub: '↑ 8 % sur août', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'À approuver', value: String(pend.length), sub: pend.length ? d1(pend.reduce(function (a, e) { return a + e[7]; }, 0)) + ' h' : 'Tout est à jour', subStyle: pend.length ? 'color: var(--warn)' : 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'),
        bars: W.map(function (w) { return { name: w[0].split(' ')[0], h: d1(w[6]), w: 'width: ' + (w[6] / 160 * 100).toFixed(1) + '%' + (w[6] > 150 ? '; background: var(--warn-dot)' : '') }; }),
        rows: rowsOf('kpi', [
          ['Heures supp. ce mois-ci', 'Amara 6,4 h · Luca 2,0 h', 'Plus de 44 h par semaine', 'st-warn si-clock', 'Vérifier', '8,4 h'],
          ['Travail en hauteur · Dev', 'Carte IHSA, expire le 14 oct.', 'Dans 15 jours', 'st-warn si-clock', 'Rappeler'],
          ['Travail en hauteur · Amara', 'Carte IHSA, expire le 12 nov.', 'Dans 44 jours', 'st-mute si-clock']]) },
      workersOpen: W.some(function (w) { return xo === w[0]; }) ? 'has-open' : '',
      workers: W.map(function (w) {
        var mine = pend.filter(function (e) { return e[1] === w[0]; }), mh = mine.reduce(function (a, e) { return a + e[7]; }, 0);
        var x = WX[w[0]], id = w[0];
        var weekRow = mine.length
          ? ['7 derniers jours', mine.length + ' ' + (mine.length > 1 ? 'entrées' : 'entrée') + ' à approuver, ' + d1(mh) + ' h', '', '', 'Approuver', x.week[0], function () { var o = Object.assign({}, self.g('ent', {})); mine.forEach(function (e) { o[e[0]] = 'ok'; }); set({ ent: o, peek: '' }); }]
          : ['7 derniers jours', w[3] === 'Sous-traitant' ? 'Facture ses heures' : 'Toutes les entrées approuvées', '', '', '', x.week[0]];
        var rows = rowsOf(id, [x.today, weekRow, x.rate, x.cert, x.link]);
        if (!mine.length && E.some(function (e) { return e[1] === w[0] && ent[e[0]] === 'ok'; })) { rows[1].hasBtn = true; rows[1].btnLabel = 'Approuvé'; rows[1].btnCls = 'done'; rows[1].act = function () { var o = Object.assign({}, self.g('ent', {})); E.forEach(function (e) { if (e[1] === w[0]) delete o[e[0]]; }); set({ ent: o }); }; }
        var cd = !!xd[id + 'call'], td = !!xd[id + 'text'];
        return { name: w[0], ini: w[1], tn: w[2], type: w[3], trade: w[4], rate: w[5], hours: d1(w[6]) + ' h', link: w[7], st: w[8],
          open: xo === id, xcls: xo === id ? 'open' : '', toggle: toggleOf(id),
          x: { rows: rows, callLabel: cd ? 'Appelé' : 'Appeler', callCls: cd ? 'dn' : '', call: flip(id + 'call'), textLabel: td ? 'Envoyé' : 'Texto', textCls: td ? 'dn' : '', text: flip(id + 'text') } };
      }),
      hasPending: pend.length > 0, allDone: pend.length === 0,
      doneMsg: approvedN.length + (approvedN.length > 1 ? ' approuvées, ' : ' approuvée, ') + d1(hrs) + ' h' + (rejectedN.length ? ' · ' + rejectedN.length + (rejectedN.length > 1 ? ' refusées' : ' refusée') : ''),
      okIc: ic('check', 'sage'),
      approveAll: function () { var o = {}; for (var x in ent) o[x] = ent[x]; pend.forEach(function (e) { o[e[0]] = 'ok'; }); set({ ent: o, peek: '' }); },
      undoAll: function () { set({ ent: {}, peek: 'e1' }); },
      entries: pend.map(function (e, i) {
        return { name: e[1], ini: e[2], tn: e[3], day: e[4], span: e[5], job: e[6], hours: d1(e[7]) + ' h',
          flags: e[8].map(function (f) { return { label: f[0], st: f[1] }; }),
          sep: i ? 'border-top: 1px solid var(--line)' : '',
          shift: peek === e[0] ? 'transform: translateX(96px); box-shadow: -1px 0 0 var(--line)' : (peek === e[0] + 'r' ? 'transform: translateX(-96px)' : 'transform: translateX(0)'),
          peek: function () { set({ peek: peek === e[0] ? e[0] + 'r' : (peek === e[0] + 'r' ? '' : e[0]) }); },
          approve: function () { upd(e[0], 'ok'); }, reject: function () { upd(e[0], 'no'); } };
      }),
      equip: equip, equipTotal: eqT.toLocaleString('fr-CA').replace(/\s/g, ' ') + ' $',
      seatsUsed: used, seatBar: 'width: ' + (used / 5 * 100) + '%',
      inviteOpen: inv, toggleInvite: function () { set({ inv: !inv }); },
      invEmail: email, onInvEmail: function (e) { set({ email: e.target.value }); },
      roles: R.map(function (r, i) { var on = i === role; return { label: r[0], on: on, cls: on ? 'on' : '', pick: function () { set({ role: i }); } }; }),
      roleNote: R[role][1],
      sendStyle: okEmail && used < 5 ? '' : 'opacity: .4',
      sendInvite: function () { if (!okEmail || used >= 5) return; set({ invited: invited.concat([{ email: email, role: R[role][0] }]), email: '', inv: false }); },
      members: members,
      keyIc: ic('lock', 'indigo'),
      codeSub: codes ? '4 nouveaux · Chef d’équipe' : '2 actifs · Chef d’équipe',
      codeBtn: codes ? 'Terminé' : 'Créer des codes', makeCodes: function () { set({ codes: !codes }); },
      codesShown: codes, codes: [{ code: 'RSR-4K7Q' }, { code: 'RSR-9MP2' }, { code: 'RSR-T3XH' }, { code: 'RSR-6WDN' }]
    };
