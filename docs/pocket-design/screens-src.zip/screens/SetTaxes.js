    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var freq = self.g('freq', 1);
    var due = [['September', 'Due Oct 31'], ['Jul 1 – Sep 30', 'Due Oct 31'], ['2026', 'Due Mar 31']][freq];
    var collected = ['$2,071.60', '$6,214.80', '$24,907.35'][freq];
    var split = self.g('split', false);
    return {
      roBanner: roBanner, rate: '13%', taxName: 'HST', pctIc: ic('percent', 'violet'),
      gProv: grp('Where you work', [
        lnk('pin', 'clay', 'Province', 'Sets tax on every quote and invoice', 'Ontario', RO ? '' : '#'),
        val('receipt', 'violet', 'GST/HST number', 'Prints on your documents', '81234 5678 RT0001', true),
        sw('byJob', true, 'house', 'amber', 'Use the job’s province', 'For the odd job outside Ontario')
      ], '', 80),
      gEx: grp('Exempt clients', [
        lnk('user', 'teal', 'Gill Residence', 'New housing rebate assigned to you', 'Rebate', 'Client.dc.html'),
        lnk('user', 'sky', 'Chen Family', 'Exemption certificate on file', 'Exempt', 'Client.dc.html'),
        lnk('plus', 'slate', 'Add an exemption', 'Pick a client and the reason', '', '#')
      ].slice(0, RO ? 2 : 3), 'Their quotes and invoices go out without HST. Keep the paperwork for the CRA.', 130),
      gSplit: grp('Materials and labour', [
        sw('split', false, 'bricks', 'stone', 'Price materials and labour apart', split ? 'Each quote shows two subtotals' : 'Needed for jobs in BC and Quebec')
      ], 'BC: you pay 7% PST on materials yourself and don’t charge it on labour. Quebec: charge GST 5% and QST 9.975% on both.', 180),
      gDocs: grp('On your documents', [
        seg('show', 0, 'doc', 'azure', 'Show tax as', '', ['Separate line', 'Included in prices']),
        sw('perLine', false, 'list', 'lilac', 'Tax on each line', 'Clearer when some lines are exempt'),
        sw('showNum', true, 'receipt', 'violet', 'Show your GST/HST number', 'Clients need it to claim credits')
      ], '', 230),
      gFile: grp('Filing', [
        seg('freq', 1, 'cal', 'teal', 'Filing frequency', '', ['Monthly', 'Quarterly', 'Yearly']),
        stat(mk('clock', 'amber', 'Next return', due[0]), due[1], 'st-warn si-clock'),
        lnk('bank', 'sage', 'HST collected', 'Minus HST you paid on costs', collected, 'Books.dc.html', true)
      ], 'Match this to what the CRA has on file. We remind you two weeks before each return.', 280)
    };
