    var tab = this.g('tab', 0), copied = this.g('copied', false), invited = this.g('invited', false), reminded = this.g('reminded', false);
    var TABS = ['Quotes', 'Jobs', 'Invoices', 'Messages'];
    var sep = function (i) { return i ? 'border-top: 1px solid var(--line)' : ''; };
    return {
      acts: [
        { label: 'Call', ic: ic('phone', 'sage'), aria: 'Call Tom & Lena Hart' },
        { label: 'Text', ic: ic('chat', 'azure'), aria: 'Text Tom & Lena Hart' },
        { label: 'Email', ic: ic('mail', 'sky'), aria: 'Email Tom & Lena Hart' },
        { label: 'Map', ic: ic('pin', 'clay'), aria: 'Open 48 Galloway Rd in maps' }
      ],
      stats: [
        { label: 'Quotes won', value: '2 of 3', sub: '67% win rate', subStyle: 'color: var(--muted)', br: 'border-right: 1px solid var(--line); border-bottom: 1px solid var(--line)' },
        { label: 'Total value', value: '$42,355', sub: 'Since Aug 2026', subStyle: 'color: var(--muted)', br: 'border-bottom: 1px solid var(--line)' },
        { label: 'Owed', value: '$2,340', sub: '9 days overdue', subStyle: 'color: var(--bad)', br: 'border-right: 1px solid var(--line)' },
        { label: 'Jobs', value: '1', sub: 'Running, 64% done', subStyle: 'color: var(--ok)', br: '' }
      ],
      details: [
        { k: 'Address', v: '48 Galloway Rd, Scarborough', mono: false },
        { k: 'Phone', v: '(416) 555-0148', mono: true },
        { k: 'Email', v: 'lena.hart@gmail.com', mono: false },
        { k: 'GST/HST number', v: 'Not needed, household client', mono: false },
        { k: 'Business number', v: 'None', mono: false },
        { k: 'Tax on quotes', v: 'HST, Ontario 13%', mono: false }
      ].map(function (d, i) { return { k: d.k, v: d.v, sep: sep(i), cls: d.mono ? 'mono' : '' }; }),
      tabs: TABS.map(function (t, i) { var on = i === tab; return { label: t, cls: on ? 'on' : '', on: on, pick: function () { set({ tab: i }); } }; }),
      isQ: tab === 0, isJ: tab === 1, isI: tab === 2, isM: tab === 3,
      quotes: [
        ['Q-2026-114', 'Basement change order', 'Accepted Sep 19', '$3,955.00', 'Accepted', 'st-ok si-check'],
        ['Q-2026-107', 'Basement finish', 'Accepted Aug 28', '$38,400.00', 'Accepted', 'st-ok si-check'],
        ['Q-2026-092', 'Garage storage wall', 'Declined Jul 30', '$2,150.00', 'Declined', 'st-bad si-x']
      ].map(function (q, i) { return { no: q[0], title: q[1], when: q[2], amt: q[3], status: q[4], st: q[5], ic: ic('doc', i === 2 ? 'slate' : 'indigo') }; }),
      jobIc: ic('hammer', 'amber'),
      invoices: [
        ['INV-0412', 'Drywall milestone', 'Due Sep 20 · 9 days overdue', '$2,340.00', 'Overdue', 'st-bad si-alert'],
        ['INV-0405', 'Framing milestone', 'Paid Sep 18 · Interac', '$9,600.00', 'Paid', 'st-ok si-check'],
        ['INV-0398', 'Deposit, 30%', 'Paid Aug 28 · Card', '$11,520.00', 'Paid', 'st-ok si-check']
      ].map(function (v, i) { return { no: v[0], title: v[1], when: v[2], amt: v[3], status: v[4], st: v[5], ic: ic('receipt', i === 0 ? 'clay' : 'sage') }; }),
      msgs: [
        { who: 'Lena', text: 'Can Amara use the side door Thursday? We will be out until 5.', time: 'Mon 7:42 pm', mine: false },
        { who: 'You', text: 'Yes, she will lock up at 4. Drywall photos tonight.', time: 'Mon 7:50 pm', mine: true },
        { who: 'Lena', text: 'Perfect, thank you. The corner by the stairs looks great.', time: 'Yesterday 8:16 pm', mine: false }
      ].map(function (m) { return { text: m.text, time: m.time, wrap: m.mine ? 'align-items: flex-end' : 'align-items: flex-start', bubble: m.mine ? 'background: var(--inv); color: var(--on-inv); border-bottom-right-radius: 6px' : 'background: var(--card); color: var(--ink); box-shadow: 0 0 0 1px var(--ring); border-bottom-left-radius: 6px' }; }),
      portalIc: ic('globe', 'violet'),
      copyLabel: copied ? 'Link copied' : 'Copy link', copy: function () { set({ copied: true }); },
      inviteLabel: invited ? 'Invite sent to Tom' : 'Invite Tom', invite: function () { set({ invited: true }); },
      remindLabel: reminded ? 'Reminder sent' : 'Send reminder', remind: function () { set({ reminded: true }); }, remindDis: reminded,
      warnIc: ic('bell', 'clay')
    };
