    var lang = self.g('lang', 'en'), i = self.g('i', 0);
    var T = {
      en: { total: 'Total', amount: '$4,131.05', paid: 'Paid', paidAmt: '$2,340.00', create: 'Create an account', have: 'I have an account', crewQ: 'On a crew?', crewA: 'Join your team', tour: 'Watch the 60-second tour', prevL: 'Previous slide', nextL: 'Next slide',
        slides: [
          ['Quotes in minutes, from your phone', 'Describe the job out loud. quoteAI writes the itemized quote, with the right taxes for your province.'],
          ['Every job in one place', 'Schedule, crew, costs, photos and site reports, from the first visit to the final walkthrough.'],
          ['Get paid sooner', 'Invoices follow the payment schedule. Clients pay by card or Interac e-Transfer.']
        ] },
      fr: { total: 'Total', amount: '4 131,05 $', paid: 'Payée', paidAmt: '2 340,00 $', create: 'Créer un compte', have: 'J’ai déjà un compte', crewQ: 'Dans une équipe?', crewA: 'Rejoindre votre équipe', tour: 'Voir la visite de 60 secondes', prevL: 'Diapositive précédente', nextL: 'Diapositive suivante',
        slides: [
          ['Des soumissions en minutes, depuis votre téléphone', 'Décrivez le travail à voix haute. quoteAI rédige la soumission détaillée, avec les bonnes taxes pour votre province.'],
          ['Tous vos chantiers au même endroit', 'Horaire, équipe, coûts, photos et rapports, de la première visite à la visite finale.'],
          ['Soyez payé plus vite', 'Les factures suivent l’échéancier. Vos clients paient par carte ou virement Interac.']
        ] }
    };
    var t = T[lang];
    var go = function (n) { set({ i: Math.max(0, Math.min(2, n)) }); };
    return {
      t: t, i: { doc: ic('doc', 'violet'), mic: ic('mic', 'violet'), cal: ic('cal', 'azure'), house: ic('house', 'teal'), photo: ic('photo', 'sky'), receipt: ic('receipt', 'amber'), cone: ic('cone', 'amber'), users: ic('users', 'lilac'), check: ic('check', 'sage'), card: ic('card', 'indigo'), bank: ic('bank', 'sage') },
      cur: { title: t.slides[i][0], sub: t.slides[i][1] },
      tx: 'transform: translateX(' + (-i * 33.3333) + '%)',
      atStart: i === 0, atEnd: i === 2,
      next: function () { go(self.g('i', 0) + 1 > 2 ? 0 : self.g('i', 0) + 1); },
      prev: function () { go(self.g('i', 0) - 1); },
      dots: [0, 1, 2].map(function (n) { return { on: n === i, cls: n === i ? 'on' : '', w: 'width: ' + (n === i ? 22 : 8) + 'px', label: (lang === 'fr' ? 'Diapositive ' : 'Slide ') + (n + 1), pick: function () { go(n); } }; }),
      langInd: 'transform: translateX(' + (lang === 'fr' ? 100 : 0) + '%)',
      langs: [['en', 'EN', 'English'], ['fr', 'FR', 'Français']].map(function (l) { var on = l[0] === lang; return { code: l[1], name: l[2], on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ lang: l[0] }); } }; })
    };
