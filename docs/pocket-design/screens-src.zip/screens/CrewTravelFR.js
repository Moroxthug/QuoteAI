    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var kind = this.g('kind', mode === 'perDiem' ? 1 : 0);
    var km1 = this.g('km', 14), round = this.g('round', true), days = this.g('days', 2), night = this.g('night', true), hasPhoto = this.g('photo', kind === 1 || mode === 'perDiem');
    var dayI = this.g('day', 0), jobI = this.g('job', 0), mapUsed = this.g('map', false);
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var DAYS = ['Aujourd’hui, mar. 29 sept.', 'lun. 28 sept.', 'ven. 25 sept.', 'jeu. 24 sept.', 'mer. 23 sept.'];
    var JOBS = [['Sous-sol Hart', '48 Galloway Rd, Scarborough'], ['Harbourfront Dental', 'Queens Quay W'], ['Gill Residence', 'Gill Residence']];
    var total = round ? km1 * 2 : km1;
    var base = [
      { k: 'km', title: '22 km · aller-retour', sub: 'Home Depot, Warden Ave au sous-sol Hart', st: 'st-ok si-check', status: 'Approuvé', date: '22 sept.' },
      { k: 'diem', title: '2 jours loin', sub: 'Chantier au chalet Gill Residence · nuit sur place', st: 'st-ok si-check', status: 'Approuvé', date: '23 sept.' },
      { k: 'km', title: '48 km · aller-retour', sub: 'Achat de matériel pour Harbourfront Dental', st: 'st-warn si-clock', status: 'À approuver', date: '25 sept.' },
      { k: 'km', title: '116 km', sub: 'Luca demande : c’était pour quel chantier?', st: 'st-warn si-clock', status: 'Question', date: '24 sept.' }
    ];
    var added = this.g('added', []);
    var all = added.concat(base);
    var kmSum = all.filter(function (c) { return c.k === 'km'; }).reduce(function (a, c) { return a + (c.km || parseInt(c.title, 10)); }, 0);
    var daySum = all.filter(function (c) { return c.k === 'diem'; }).reduce(function (a, c) { return a + (c.d || parseInt(c.title, 10)); }, 0);
    var waiting = all.filter(function (c) { return c.status !== 'Approuvé'; }).length;
    var nt = sw(night), rt = sw(round);
    var justSent = this.g('justSent', false);
    return {
      offline: offline,
      kpis: [
        { label: 'Distance', value: kmSum + ' km', sub: 'cette période', sep: '' },
        { label: 'Jours loin', value: daySum + '', sub: 'indemnité', sep: 'border-left: 1px solid var(--line)' },
        { label: 'En attente', value: waiting + '', sub: 'de Luca', sep: 'border-left: 1px solid var(--line)' }
      ],
      kinds: ['Kilométrage', 'Indemnité'].map(function (l, i) { var on = i === kind; return { label: l, on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ kind: i }); } }; }),
      kindInd: 'transform: translateX(' + (kind * 100) + '%)', isKm: kind === 0, isDiem: kind === 1,
      calIc: ic('cal', 'azure'), jobIc: ic('house', 'clay'), cloudIc: ic('cloud', 'amber'), okIc: ic('check', 'sage'),
      dayLabel: DAYS[dayI], prevDay: function () { set({ day: (self.g('day', 0) + 1) % DAYS.length }); },
      job: JOBS[jobI][0], swapJob: function () { set({ job: (self.g('job', 0) + 1) % JOBS.length }); },
      from: this.g('from', 'Home Depot, Warden Ave'), to: this.g('to', JOBS[jobI][1]),
      onFrom: function (e) { set({ from: e.target.value }); }, onTo: function (e) { set({ to: e.target.value }); },
      km: total + '', tripWord: round ? 'aller-retour' : 'aller simple',
      kmMinus: function () { set({ km: Math.max(1, self.g('km', 14) - 1) }); }, kmPlus: function () { set({ km: self.g('km', 14) + 1 }); },
      useMap: function () { set({ km: 14, map: true }); }, mapLabel: mapUsed ? 'Distance de la carte · 14 km par trajet' : 'Utiliser la carte · 14 km par trajet',
      round: round, rTrack: rt.t, rKnob: rt.k, flipRound: function () { set({ round: !self.g('round', true) }); },
      days: days + '', daysWord: days === 1 ? 'jour' : 'jours',
      dMinus: function () { set({ days: Math.max(1, self.g('days', 2) - 1) }); }, dPlus: function () { set({ days: Math.min(14, self.g('days', 2) + 1) }); },
      night: night, nTrack: nt.t, nKnob: nt.k, flipNight: function () { set({ night: !self.g('night', true) }); },
      receiptTitle: kind === 0 ? 'Reçu de stationnement ou péage' : 'Reçu',
      hasPhoto: hasPhoto, togglePhoto: function () { set({ photo: !hasPhoto }); },
      note: this.g('note', ''), onNote: function (e) { set({ note: e.target.value }); },
      notePh: kind === 0 ? 'Ramassé du gypse pour le corridor' : 'Chantier au chalet, deux nuits à Barrie',
      submitLabel: (offline ? 'Enregistrer ' : 'Envoyer ') + (kind === 0 ? total + ' km' : days + (days === 1 ? ' jour' : ' jours')),
      submit: function () {
        var c = kind === 0
          ? { k: 'km', km: total, title: total + ' km' + (round ? ' · aller-retour' : ''), sub: self.g('from', 'Home Depot, Warden Ave') + ' à ' + JOBS[jobI][0] + (hasPhoto ? ' · reçu' : ''), date: DAYS[dayI].replace(/^.*?(\d+ sept\.)$/, '$1') }
          : { k: 'diem', d: days, title: days + (days === 1 ? ' jour' : ' jours') + ' loin', sub: JOBS[jobI][0] + (night ? ' · nuit sur place' : ''), date: DAYS[dayI].replace(/^.*?(\d+ sept\.)$/, '$1') };
        c.st = offline ? 'st-mute si-draft' : 'st-warn si-clock'; c.status = offline ? 'Sur le téléphone' : 'À approuver';
        set({ added: [c].concat(self.g('added', [])), justSent: true, note: '' });
      },
      justSent: justSent, sentMsg: offline ? 'Gardé sur votre téléphone.' : 'Envoyé à Luca.', sentSub: offline ? 'L’envoi se fera dès que vous aurez du réseau.' : 'Vous le verrez ici une fois vérifié.',
      undo: function () { set({ added: self.g('added', []).slice(1), justSent: false }); },
      claims: all.map(function (c) { return { title: c.title, sub: c.sub, st: c.st, status: c.status, date: c.date, ic: c.k === 'km' ? ic('truck', 'azure') : ic('house', 'amber') }; }),
      claimCount: all.length + ''
    };
