    var PS = { empty: ['', 'typing', 30, 4], typing: ['482', 'typing', 30, 4], wrong: ['482193', 'wrong', 30, 3], locked: ['', 'locked', 0, 0], verified: ['482913', 'ok', 30, 4] }[this.props.state || 'empty'];
    var code = self.g('code', PS[0]), st = self.g('st', PS[1]), sec = self.g('sec', PS[2]), tries = self.g('tries', PS[3]);
    if (!self._timer) { self._timer = setInterval(function () { var s = self.g('sec', 30); if (s > 0) self.setState({ sec: s - 1 }); }, 1000); }
    var RIGHT = '482913';
    var submit = function (c) {
      set({ code: c, st: 'checking' });
      setTimeout(function () {
        if (c === RIGHT) set({ st: 'ok' });
        else { var t = self.g('tries', 4) - 1; set(t <= 0 ? { st: 'locked', tries: 0 } : { st: 'wrong', tries: t, shakeN: (self.g('shakeN', 0) + 1) }); }
      }, 900);
    };
    var wrong = st === 'wrong', ok = st === 'ok', locked = st === 'locked', checking = st === 'checking';
    var boxes = [0, 1, 2, 3, 4, 5].map(function (n) {
      var cls = ok ? 'ok' : wrong ? 'bad' : locked ? 'off' : (!checking && n === code.length) ? 'act' : '';
      return { d: code[n] || '', cls: cls };
    });
    return {
      orbIc: ok ? ic('check', 'sage') : locked ? ic('lock', 'clay') : ic('mail', 'sky'), lockIc: ic('lock', 'clay'),
      title: ok ? 'Compte vérifié' : 'Vérifiez vos courriels',
      subA: ok ? 'Ensuite, quelques questions pour adapter les soumissions à ' : 'Entrez le code à 6 chiffres envoyé à ',
      subB: ok ? 'votre entreprise' : 'marco@rossireno.ca', subC: '.',
      boxA: boxes.slice(0, 3), boxB: boxes.slice(3),
      shake: wrong ? 'vf-shake' : '',
      code: code, inVal: (wrong || locked) ? '' : code, wrong: wrong, ok: ok, locked: locked, checking: checking, triesLeft: tries,
      onCode: function (e) {
        var c = (e.target.value || '').replace(/\D/g, '').slice(0, 6);
        if (c.length === 6) submit(c); else set({ code: c, st: 'typing' });
      },
      sec: sec, waiting: sec > 0 && !ok, canResend: sec === 0 && !ok,
      resend: function () { set({ sec: 30, code: '', st: 'typing', tries: 4 }); }
    };
