    var step = this.g('step', 1), open = this.g('open', 0);
    var STEPS = ['Review', 'Sign', 'Send', 'Customer signs'];
    var check = 'M5 12.5l4.5 4.5L19 7.5';
    var steps = STEPS.map(function (s, i) {
      var done = i < step, cur = i === step;
      return {
        label: s, n: (i + 1) + '', done: done, todo: !done,
        dot: done ? 'background: var(--inv); color: var(--on-inv)' : cur ? 'background: var(--card); color: var(--ink); box-shadow: 0 0 0 2px var(--ink)' : 'background: var(--sunk); color: var(--faint)',
        lab: done || cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
        line: i === 3 ? 'display: none' : (i < step ? 'background: var(--inv)' : 'background: var(--line2)')
      };
    });
    var secs = [
      ['Scope of work', true, 'Walls and ceilings in three bedrooms and the hallway, two coats. Bath ceiling cut out, patched, skim coated and stain-blocked before paint. Rossi Renovations supplies paint and sundries and protects floors daily.'],
      ['Price and payments', true, 'Contract price $4,131.05 including HST. 30% deposit ($1,239.32) on signing, balance on completion, due within 7 days by card or Interac e-Transfer.'],
      ['Schedule', true, 'Work starts Tue Oct 13, 2026 and takes about 6 working days, weather and access permitting. Hours are 8:00 am to 5:00 pm.'],
      ['Warranty', true, 'Workmanship is guaranteed for 1 year from completion. Peeling, cracking or stain bleed-through caused by our work is fixed at no charge.'],
      ['Changes to the work', false, 'Any change to the scope, price or schedule must be agreed in writing as a change order signed by both parties before the work is done.'],
      ['Holdback', false, 'The owner may hold back 10% of each payment for 60 days after substantial completion, as set out in the Construction Act (Ontario).'],
      ['Cancellation', false, 'Signed away from our place of business, so the owner may cancel within 10 days of receiving a copy, without reason or penalty.']
    ];
    var sections = secs.map(function (s, i) {
      var on = i === open;
      return {
        title: s[0], n: (i + 1) + '', ai: s[1], locked: !s[1], body: s[2], on: on, sep: i ? 'border-top: 1px solid var(--line)' : '',
        tag: s[1] ? 'Drafted by AI, editable' : 'Standard clause, locked',
        chev: on ? 'transform: rotate(180deg)' : 'transform: rotate(0deg)',
        toggle: function () { set({ open: self.g('open', 0) === i ? -1 : i }); }
      };
    });
    var signed = step >= 2, sent = step >= 3;
    var signers = [
      { name: 'Marco Rossi', role: 'Rossi Renovations, owner', ini: 'MR', tn: 'tn5', status: signed ? 'Signed' : 'Your turn', st: signed ? 'st-ok' : 'st-warn', sig: signed, meta: signed ? 'Today 9:34 am · ID verified' : 'Sign to send the contract' },
      { name: 'Dana Whitfield', role: 'Owner, 17 Castle Frank Cres', ini: 'DW', tn: 'tn1', status: sent ? 'Pending' : 'Not sent', st: sent ? 'st-info' : 'st-mute', sig: false, meta: sent ? 'Emailed today 9:36 am' : 'Gets the link after you sign' }
    ].map(function (s, i) { return Object.assign(s, { sep: i ? 'border-top: 1px solid var(--line)' : '' }); });
    var acts = [
      ['Today 9:12 am', 'Drafted with AI from Q-2026-119', 'orb', 'violet'],
      ['Today 9:20 am', 'You edited Schedule', 'pen', 'slate'],
      ['Today 9:21 am', 'Clauses checked for Ontario', 'shield', 'indigo']
    ];
    if (signed) acts.push(['Today 9:34 am', 'Signed by Marco Rossi', 'check', 'sage']);
    if (sent) acts.push(['Today 9:36 am', 'Sent to Dana by email', 'send', 'azure']);
    acts.reverse();
    var activity = acts.map(function (a, i) { return { time: a[0], text: a[1], ic: ic(a[2], a[3]), line: i === acts.length - 1 ? 'visibility: hidden' : '' }; });
    var labels = ['', 'Sign as Rossi Renovations', 'Send to Dana', 'Waiting for Dana'];
    return {
      steps: steps, sections: sections, signers: signers, activity: activity,
      statusLine: sent ? 'Sent · waiting for Dana' : signed ? 'Signed by you · ready to send' : 'Draft · reviewed, ready to sign',
      dotStyle: sent ? 'background: var(--info)' : signed ? 'background: var(--ok-dot)' : 'background: var(--warn-dot)',
      details: [
        ['Province', 'Ontario', ''], ['Language', 'English', ''], ['Subtotal', '$3,655.80', 'num'], ['HST, Ontario 13%', '$475.25', 'num'], ['Total', '$4,131.05', 'num'], ['Holdback, 10% for 60 days', '$413.11', 'num'], ['Start date', 'Tue Oct 13', ''], ['Warranty', '1 year', '']
      ].map(function (d, i) { return { k: d[0], v: d[1], cls: d[2], sep: i ? 'border-top: 1px solid var(--line)' : '', vs: d[0] === 'Total' ? 'font-weight: 600' : '' }; }),
      lockIc: ic('lock', 'slate'), aiIc: ic('orb', 'violet'),
      primary: labels[step], primaryStyle: sent ? 'background: var(--sunk); color: var(--muted); box-shadow: none' : '',
      act: function () { var s = self.g('step', 1); if (s < 3) set({ step: s + 1 }); }
    };
