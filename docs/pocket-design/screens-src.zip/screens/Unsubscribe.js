    var lang = this.g('lang', 'en'), fr = lang === 'fr';
    var state = this.g('state', null) || this.props.state || 'choose';
    var ch = this.g('ch', 'email'), pick = this.g('pick', 0);
    var EN = {
      from: 'From', title: 'Choose what to stop', channel: 'Channel', emails: 'Emails', texts: 'Texts',
      opts: [['Reminders', 'Quote follow-ups and visit reminders.'], ['News and offers', 'Seasonal tips and offers, a few times a year.'], ['All messages', 'Reminders, news and offers.']],
      short: ['reminders', 'news and offers', 'all messages'],
      stillTitle: 'Invoices still arrive.', still: 'So do receipts and documents to sign, while you have work with us.',
      unsub: 'Unsubscribe', doneEmail: 'No more {x} by email', doneText: 'No more {x} by text',
      doneSub: 'It can take up to a day to stop completely. Rossi Renovations can see this choice.', unsubbed: 'Unsubscribed',
      changed: 'Changed your mind?', resub: 'Resubscribe', resubbed: 'You’re subscribed again.',
      questions: 'Questions? Call Marco at', sentWith: 'Sent with quoteAI'
    };
    var FR = {
      from: 'De la part de', title: 'Choisissez quoi arrêter', channel: 'Canal', emails: 'Courriels', texts: 'Textos',
      opts: [['Rappels', 'Relances de soumission et rappels de visite.'], ['Nouvelles et offres', 'Conseils saisonniers et offres, quelques fois par année.'], ['Tous les messages', 'Rappels, nouvelles et offres.']],
      short: ['rappels', 'nouvelles et offres', 'messages'],
      stillTitle: 'Les factures arrivent toujours.', still: 'Tout comme les reçus et les documents à signer, tant que nous avons des travaux avec vous.',
      unsub: 'Me désabonner', doneEmail: 'Plus de {x} par courriel', doneText: 'Plus de {x} par texto',
      doneSub: 'L’arrêt peut prendre jusqu’à un jour. Rossi Renovations voit ce choix.', unsubbed: 'Désabonné',
      changed: 'Vous avez changé d’avis?', resub: 'Me réabonner', resubbed: 'Vous êtes de nouveau abonné.',
      questions: 'Des questions? Appelez Marco au', sentWith: 'Envoyé avec quoteAI'
    };
    var t = fr ? FR : EN;
    var isDone = state === 'done';
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      isChoose: !isDone, isDone: isDone, isResub: state === 'resubscribed',
      contact: ch === 'email' ? 'dana.whitfield@gmail.com' : '(416) 555-0198',
      chans: [['email', t.emails], ['text', t.texts]].map(function (c) { var o = c[0] === ch; return { label: c[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ ch: c[0] }); } }; }),
      chInd: 'transform: translateX(' + (ch === 'text' ? 100 : 0) + '%)',
      opts: t.opts.map(function (o, i) {
        var on = i === pick;
        return { name: o[0], desc: o[1], on: on,
          ring: on ? 'box-shadow: 0 0 0 2px var(--ink)' : 'box-shadow: 0 0 0 1px var(--ring)',
          radio: on ? 'background: var(--inv); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
          dot: on ? 'transform: scale(1)' : 'transform: scale(0)',
          pick: function () { set({ pick: i }); } };
      }),
      okIc: ic('check', 'sage'), docIc: ic('receipt', 'azure'),
      unsub: function () { set({ state: 'done' }); },
      resub: function () { set({ state: 'resubscribed' }); },
      doneTitle: (ch === 'email' ? t.doneEmail : t.doneText).replace('{x}', t.short[pick]),
      doneSub: t.doneSub
    };
