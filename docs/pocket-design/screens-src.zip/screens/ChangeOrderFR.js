    var ORDER = ['describe', 'review', 'sent', 'signed'];
    var LABELS = ['Description', 'Révision', 'Envoi', 'Signature'];
    var step = self.g('step', null) || (this.props.step || 'describe');
    var si = ORDER.indexOf(step); if (si < 0) { step = 'describe'; si = 0; }
    var mode = self.g('mode', 'talk'), rec = self.g('rec', 'done');
    var title = self.g('title', '4 encastrés, salle familiale');
    var transcript = self.g('text', 'Tom et Lena veulent quatre encastrés au plafond de la salle familiale, sur un gradateur près de l’escalier. Jonah peut les brancher jeudi, avant le tirage de joints. Environ une journée de travail.');
    var nPhotos = self.g('nPhotos', 2), bill = self.g('bill', 'next'), chan = self.g('chan', { email: true, text: true });
    var reminded = self.g('reminded', false), autoRem = self.g('autoRem', true), copied = self.g('copied', false);
    var go = function (s) { set({ step: s }); };
    var PH = [['co-p1', 'photo', 'azure', 'Plafond'], ['co-p2', 'camera', 'violet', 'Interrupteur'], ['co-p3', 'photo', 'amber', 'Solives']];
    var L = [
      ['Encastrés DEL minces 4 po', '4 × 42,00 $ · homologués IC, gradables', '168,00 $'],
      ['Gradateur et boîtier', 'Près de l’escalier', '46,00 $'],
      ['Électricien, Jonah Reyes', '5,5 h × 95,00 $', '522,50 $'],
      ['Découpe, réparation et retouches', 'Autour de chaque lumière, avant les joints', '165,00 $'],
      ['Avis à l’OSIE', 'Office de la sécurité des installations électriques', '89,65 $']
    ];
    var B = [['next', 'Ajouter à la prochaine facture d’étape', 'INV-0421 · étape 3, gypse'], ['own', 'Facture distincte', 'Envoyée à la fin des travaux'], ['sign', 'Payable à la signature', 'Carte ou virement Interac depuis le lien']];
    var tl = function (rows) { return rows.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], tStyle: a[3] ? '' : 'color: var(--muted)', dot: a[3] ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === rows.length - 1 ? 'display: none' : '' }; }); };
    var trackRows = [['Envoyé à Lena Hart', '10 h 42', 'Courriel et texto, avec le lien de signature', true]];
    if (reminded) trackRows.push(['Rappel envoyé', '10 h 58', 'Texto au 416 555 0148', true]);
    trackRows = trackRows.concat([['Ouvre le lien', 'En attente', 'Vous recevrez une notification', false], ['Signe', 'En attente', 'Budget, échéancier et facturation se mettent à jour automatiquement', false]]);
    return {
      stepNo: si + 1,
      steps: LABELS.map(function (l, i) { return { label: l, cls: (i <= si ? 'on' : '') + (i === si ? ' cur' : '') }; }),
      isDescribe: step === 'describe', isReview: step === 'review', isSent: step === 'sent', isSigned: step === 'signed',
      toReview: function () { go('review'); }, toDescribe: function () { go('describe'); }, toSent: function () { go('sent'); }, toSigned: function () { go('signed'); },
      isTalk: mode === 'talk', isType: mode === 'type',
      modeInd: mode === 'talk' ? 'transform: translateX(0)' : 'transform: translateX(100%)',
      talkStyle: mode === 'talk' ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
      typeStyle: mode === 'type' ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
      talk: function () { set({ mode: 'talk' }); }, type: function () { set({ mode: 'type' }); },
      listening: rec === 'live', notListening: rec !== 'live', hasText: rec === 'done',
      micCls: rec === 'live' ? 'live' : '', micLabel: rec === 'live' ? 'Arrêter l’enregistrement' : 'Commencer l’enregistrement',
      recTitle: rec === 'live' ? 'À l’écoute…' : (rec === 'done' ? 'C’est noté' : 'Touchez pour parler'),
      recSub: rec === 'done' ? 'Touchez le micro pour ajouter des détails' : 'Dites ce que le client a demandé',
      toggleRec: function () { set({ rec: self.g('rec', 'done') === 'live' ? 'done' : 'live' }); },
      transcript: transcript, onText: function (e) { set({ text: e.target.value }); },
      title: title, onTitle: function (e) { set({ title: e.target.value }); },
      photos: PH.slice(0, nPhotos).map(function (p) { return { cls: p[0], ic: ic(p[1], p[2]), cap: p[3] }; }),
      photoCount: nPhotos + (nPhotos > 1 ? ' ajoutées' : ' ajoutée'),
      addPhoto: function () { set({ nPhotos: Math.min(3, nPhotos + 1) }); },
      orbIc: ic('orb', 'violet'),
      lines: L.map(function (l, i) { return { name: l[0], detail: l[1], amt: l[2], sep: i ? 'border-top: 1px solid var(--line)' : '' }; }),
      sched: [
        { name: 'Encastrés et filage', sub: 'Jonah Reyes · nouvelle tâche', was: 'Nouveau', wasStyle: 'color: var(--acc-t); font-weight: 600', now: 'jeu. 1er oct.', ic: ic('bolt', 'gold') },
        { name: 'Fin de l’étape du gypse', sub: 'Les joints attendent un jour', was: '2 oct.', wasStyle: 'text-decoration: line-through; color: var(--faint)', now: '5 oct.', ic: ic('box', 'stone') },
        { name: 'Fin du chantier', sub: 'Peinture et plancher décalés aussi', was: '30 oct.', wasStyle: 'text-decoration: line-through; color: var(--faint)', now: '2 nov.', ic: ic('cal', 'sky') }
      ],
      bills: B.map(function (b) { var on = b[0] === bill; return { label: b[1], sub: b[2], on: on, dot: on ? 'border: 7px solid var(--inv)' : 'border: 1.6px solid var(--line2)', pick: function () { set({ bill: b[0] }); } }; }),
      chans: [['email', 'Courriel'], ['text', 'Texto']].map(function (c) { var on = !!chan[c[0]]; return { label: c[1], on: on, cls: on ? 'on' : '', flip: function () { var o = Object.assign({}, self.g('chan', { email: true, text: true })); o[c[0]] = !o[c[0]]; set({ chan: o }); } }; }),
      sentIc: ic('send', 'violet'), penIc: ic('pen', 'indigo'), okIc: ic('check', 'sage'), warnIc: ic('warn', 'amber'), linkIc: ic('link', 'azure'),
      doneIc: ic('check', 'sage'), crewIc: ic('bolt', 'gold'),
      reminded: reminded, remindLabel: reminded ? 'Rappel envoyé' : 'Relancer Lena',
      remind: function () { set({ reminded: true }); },
      track: tl(trackRows),
      autoRem: autoRem, autoSub: autoRem ? 'Demain à 9 h si ce n’est pas signé' : 'Désactivé · vous la relancerez vous-même',
      autoTrack: autoRem ? 'background: var(--acc)' : 'background: var(--track-off)', autoKnob: autoRem ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipAuto: function () { set({ autoRem: !self.g('autoRem', true) }); },
      copyLabel: copied ? 'Copié' : 'Copier le lien', copy: function () { set({ copied: true }); },
      updates: [
        { name: 'Valeur du contrat', sub: 'C-2026-014 avec CO-1 et CO-3', was: '42 355 $', now: '43 475 $', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('doc', 'indigo') },
        { name: 'Budget du chantier', sub: 'Lumières, gradateur, électricien et OSIE ajoutés aux coûts', was: '28 500 $', now: '29 326 $', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('bars', 'stone') },
        { name: 'Échéancier', sub: 'Encastrés le jeu. 1er oct., fin repoussée d’un jour ouvrable', was: '30 oct.', now: '2 nov.', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('cal', 'sky') },
        { name: 'Prochaine facture d’étape', sub: 'Ajouté comme ligne distincte sur INV-0421, étape 3', was: 'INV-0421', now: '+1 120,00 $', wasStyle: 'color: var(--muted)', ic: ic('receipt', 'teal') }
      ]
    };
