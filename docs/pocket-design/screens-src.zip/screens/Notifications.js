    var f = self.g('f', 'all'), read = self.g('read', {}), ask = self.g('ask', this.props.state === 'optin');
    var D = [
      ['brief', 'today', 'sun', 'gold', 'Your day', '3 visits booked · Luca, Amara and Sofia on site · 12°, rain after 3 pm', '6:30', '', '', 'SmartHome.dc.html'],
      ['viewed', 'today', 'eye', 'violet', 'Priya Nair opened your quote', 'Kitchen backsplash · Q-2026-118 · $1,865.10', '9:12', '', '', 'Quote.dc.html'],
      ['paid', 'today', 'card', 'sage', 'Payment received from Okoye Condo', '$2,210.00 by card · INV-0421, hallway flooring', '8:47', '', '', 'Invoice.dc.html'],
      ['etransfer', 'today', 'bank', 'amber', 'Chen Family sent an e-Transfer', '$1,650.00 for INV-0417. Check your bank, then confirm it here.', '8:05', 'Confirm', '#', '#'],
      ['hours', 'today', 'clock', 'teal', 'Crew hours to approve', 'Luca Bianchi and Amara Okafor · 31.5 h last week', '7:58', 'Review hours', '#', '#'],
      ['blocker', 'today', 'warn', 'clay', 'Blocker at 48 Galloway Rd', 'Amara: drywall delivery short 12 sheets. Hart basement is waiting.', '7:40', '', '', 'Job.dc.html'],
      ['signed', 'earlier', 'pen', 'sage', 'Tom & Lena Hart signed the change order', 'Basement change order · $3,955.00', 'Mon', '', '', 'Contract.dc.html'],
      ['budget', 'earlier', 'bars', 'amber', 'Hart basement is at 90% of budget', '$27,630 spent of $30,700 in costs · drywall phase', 'Mon', '', '', 'Job.dc.html'],
      ['overdue2', 'earlier', 'receipt', 'clay', 'INV-0419 is overdue', 'Harbourfront Dental · $780.00, due Sep 26', 'Sep 27', '', '', 'Invoice.dc.html'],
      ['overdue', 'earlier', 'receipt', 'clay', 'INV-0412 is overdue', 'Tom & Lena Hart · $2,340.00, due Sep 20', 'Sep 21', 'Send a reminder', '#', '#']
    ];
    var unreadIds = ['viewed', 'paid', 'etransfer', 'hours', 'blocker', 'brief'];
    var isUnread = function (d) { return unreadIds.indexOf(d[0]) >= 0 && !read[d[0]]; };
    var nUn = D.filter(isUnread).length;
    var rows = D.filter(function (d) { return f === 'all' || isUnread(d); });
    var groups = [['today', 'Today'], ['earlier', 'Earlier']].map(function (g) {
      return { title: g[1], rows: rows.filter(function (d) { return d[1] === g[0]; }).map(function (d) {
        var u = isUnread(d);
        return { ic: ic(d[2], d[3]), title: d[4], body: d[5], time: d[6], hasAct: !!d[7], act: d[7], href: d[8] || '#', bcls: u ? 'u' : '', dot: u ? '' : 'off', aria: (u ? 'Unread. ' : '') + d[4],
          open: function () { var r = Object.assign({}, self.g('read', {})); r[d[0]] = true; set({ read: r }); if (d[9] && d[9] !== '#' && !d[7]) setTimeout(function () { location.href = d[9]; }, 250); } };
      }) };
    }).filter(function (g) { return g.rows.length; });
    return {
      groups: groups, empty: groups.length === 0, bellIc: ic('bell', 'violet'), orbIc: ic('orb', 'violet'), orbIc2: ic('orb', 'violet'),
      noneUnread: nUn === 0,
      markAll: function () { var r = {}; D.forEach(function (d) { r[d[0]] = true; }); set({ read: r }); },
      showAll: function () { set({ f: 'all' }); },
      filters: [['all', 'All', D.length], ['unread', 'Unread', nUn]].map(function (x) { var on = x[0] === f; return { label: x[1], count: x[2], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      ask: ask, closeAsk: function () { set({ ask: false }); }
    };
