    var st = this.props.state || 'default', locked = st === 'locked';
    var scope = this.g('scope', 'all'), swOpen = this.g('sw', false), pb = this.g('pb', true), dup = this.g('dup', false), added = this.g('added', false);
    var money = function (n) { return '$' + Math.round(n).toLocaleString('en-CA'); };
    var C = {
      reno: { name: 'Rossi Renovations', sub: 'Toronto · residential · 5 crew', inv: 41870, cost: 28630, out: 3120, m: [38200, 36900, 41870], ic: ['building', 'violet'] },
      comm: { name: 'Rossi Commercial', sub: 'Mississauga · commercial · 3 crew', inv: 18450, cost: 13100, out: 6420, m: [12100, 15600, 18450], ic: ['building', 'teal'] }
    };
    var ELIM = 2400;
    var tot = scope === 'all'
      ? { inv: C.reno.inv + C.comm.inv - ELIM, cost: C.reno.cost + C.comm.cost - ELIM, out: C.reno.out + C.comm.out }
      : C[scope];
    var margin = (tot.inv - tot.cost) / tot.inv * 100;
    var MAX = 62000;
    var mn = ['Jul', 'Aug', 'Sep'];
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var s = sw(pb);
    var scopeName = scope === 'all' ? 'All companies' : C[scope].name;
    return {
      locked: locked, open: !locked,
      tierIc: ic('tier4', 'violet'), bldIc: ic('building', 'violet'), bld2Ic: ic('building', 'slate'), infoIc: ic('help', 'sky'),
      feats: [['Combined money across companies', 'bars', 'violet'], ['Crew hours on every crew', 'users', 'teal'], ['One shared price book', 'tag', 'amber'], ['One bill for all of them', 'receipt', 'sage']].map(function (f) { return { label: f[0], ic: ic(f[1], f[2]) }; }),
      scopeIc: ic(scope === 'all' ? 'grid' : 'building', scope === 'comm' ? 'teal' : 'violet'), scopeName: scopeName,
      swOpen: swOpen, chev: swOpen ? 'transform: rotate(180deg)' : '',
      toggleSw: function () { set({ sw: !swOpen }); },
      scopes: [['all', 'All companies', '2 companies · combined', 'grid', 'violet'], ['reno', 'Rossi Renovations', 'Toronto · residential', 'building', 'violet'], ['comm', 'Rossi Commercial', 'Mississauga · commercial', 'building', 'teal']].map(function (o) {
        return { label: o[1], sub: o[2], ic: ic(o[3], o[4]), on: o[0] === scope, pick: function () { set({ scope: o[0], sw: false }); } };
      }),
      elimNote: scope === 'all' ? money(ELIM) + ' between companies left out' : 'This company only',
      kpis: [
        { label: 'Invoiced', value: money(tot.inv), sub: '↑ 11% on Aug', subStyle: 'color: var(--ok)', sep: '' },
        { label: 'Costs', value: money(tot.cost), sub: 'Labour, materials, subs', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Margin', value: margin.toFixed(1) + '%', sub: money(tot.inv - tot.cost) + ' profit', subStyle: 'color: var(--ok)', sep: 'border-top: 1px solid var(--line)' },
        { label: 'Outstanding', value: money(tot.out), sub: scope === 'reno' ? '1 overdue' : '2 overdue', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line); border-top: 1px solid var(--line)' }
      ],
      months: mn.map(function (m, i) {
        var a = scope === 'comm' ? 0 : C.reno.m[i], b = scope === 'reno' ? 0 : C.comm.m[i];
        return { m: m, a: 'width: ' + (a / MAX * 100).toFixed(1) + '%; background: var(--inv); border-radius: 6px', b: 'width: ' + (b / MAX * 100).toFixed(1) + '%; background: var(--acc); border-radius: 6px', total: money(a + b) };
      }),
      companies: ['reno', 'comm'].map(function (k) {
        var c = C[k], mg = (c.inv - c.cost) / c.inv * 100;
        return { name: c.name, sub: c.sub, inv: money(c.inv), margin: mg.toFixed(1) + '% margin', mStyle: 'color: var(--muted)', ic: ic(c.ic[0], c.ic[1]), pick: function () { set({ scope: k, sw: false }); } };
      }),
      addLabel: added ? 'Invite sent to set up a company' : 'Add a company', addSub: added ? 'Check your email to finish on quoteai.ca' : 'Up to 3 on your plan',
      addCo: function () { set({ added: true }); },
      billIc: ic('receipt', 'sage'), pbIc: ic('tag', 'amber'), usersIc: ic('users', 'indigo'), linkIc: ic('link', 'azure'), okIc: ic('check', 'sage'),
      pbOn: pb, pbTrack: s.t, pbKnob: s.k, pbSub: pb ? '212 items used by both' : 'Each company keeps its own',
      flipPb: function () { set({ pb: !pb }); },
      dupOpen: !dup, dupDone: dup, linkDup: function () { set({ dup: true }); }
    };
