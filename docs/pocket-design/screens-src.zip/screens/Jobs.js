    var f = this.g('f', 'all');
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { maximumFractionDigits: 0 }); };
    var P = { AO: ['AO', 'tn3'], SM: ['SM', 'tn2'], LB: ['LB', 'tn1'], JR: ['JR', 'tn4'], DP: ['DP', 'tn5'] };
    var S = { setup: ['Review setup', 'st-acc si-q2'], planning: ['Planning', 'st-info si-q1'], active: ['Active', 'st-ok si-live'], hold: ['On hold', 'st-warn si-pause'], done: ['Completed', 'st-mute si-check'] };
    // [name, client, status, value, pct, meta, crew, crewNote, late]
    var data = [
      ['Hallway flooring', 'Okoye Condo', 'setup', 2210, 0, 'AI plan from Q-2026-112', [], ''],
      ['Basement finish', 'Tom & Lena Hart', 'active', 42355, 64, 'Next: finish drywall, Oct 2', ['AO', 'SM', 'LB'], '2 on site'],
      ['Clinic hallway refresh', 'Harbourfront Dental', 'active', 12850, 35, 'Next: prep and prime, Oct 1', ['LB'], 'Luca'],
      ['Fence and gate', 'Gill Residence', 'active', 5860, 40, 'Next: stain gate, Sep 30', ['DP', 'LB'], ''],
      ['Main floor repaint', 'Dana Whitfield', 'planning', 7900, 0, 'Starts Oct 13 · ends Oct 21', ['LB', 'SM'], ''],
      ['Back room shelving', 'Marchetti Bakery', 'hold', 4650, 20, 'Waiting on landlord sign-off', ['DP'], ''],
      ['Powder room', 'Priya Nair', 'done', 3120, 100, 'Finished Sep 11', ['AO', 'LB'], ''],
      ['Front porch rebuild', 'Chen Family', 'done', 9840, 100, 'Finished Aug 21', ['DP', 'JR'], '']
    ];
    var FIL = [['all', 'All', function (s) { return s !== 'done'; }, 'Open'], ['setup', 'Setup'], ['planning', 'Planning'], ['active', 'Active'], ['hold', 'On hold'], ['done', 'Completed']];
    var match = function (x, s) { return x[2] ? x[2](s) : s === x[0]; };
    var cur = FIL.filter(function (x) { return x[0] === f; })[0];
    var rows = data.filter(function (d) { return match(cur, d[2]); });
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { Order: 'Ordered', Review: 'Reviewed', Nudge: 'Nudged', Invoice: 'Invoiced', Fix: 'Fixed', Ask: 'Asked', Call: 'Calling' };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); } }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    var DET = {
      'Basement finish': { cap: 'Today on site', rows: [['Amara Okafor', 'Drywall · since 7:15', 'On site', 'st-ok si-live'], ['Sofia Marin', 'Taping · since 7:30', 'On site', 'st-ok si-live'], ['Next: finish drywall', 'Thu Oct 2 · then prime', 'On track', 'st-ok si-check'], ['Drywall ½″ short 12 sheets', 'Flagged by Amara at 9:12', 'Blocker', 'st-bad si-alert', 'Order']], stats: [['Invoiced', '46%'], ['Costs', '64%'], ['Margin', '32%']], second: 'Message crew' },
      'Clinic hallway refresh': { cap: 'Today', rows: [['Luca Bianchi', 'Prep and prime · from 9:00', 'On site', 'st-ok si-live'], ['Next: prep and prime', 'Wed Oct 1', 'On track', 'st-ok si-check'], ['Labour 18% over budget', '$3,960 of $5,400 spent at 35% done', 'Over budget', 'st-bad si-alert', 'Review']], stats: [['Invoiced', '30%'], ['Costs', '52%'], ['Margin', '21%']], second: 'Message Luca' },
      'Fence and gate': { cap: 'Today', rows: [['Dev Patel', 'Stain gate · from 8:00', 'On site', 'st-ok si-live'], ['Rain Thursday and Friday', 'Finish the stain by Wednesday', 'Weather', 'st-warn si-clock']], stats: [['Invoiced', '50%'], ['Costs', '20%'], ['Margin', '41%']], second: 'Message Dev' },
      'Main floor repaint': { cap: 'Before it starts', rows: [['Crew booked', 'Luca and Sofia · Oct 13 to 21'], ['Paint order', 'Dulux · 14 gal, 2 colours', 'To order', 'st-mute si-draft', 'Order'], ['Deposit', 'Paid Sep 26', 'Paid', 'st-ok si-check', '', '$2,370.00']], stats: [], second: 'Message Dana' },
      'Back room shelving': { cap: 'Why it’s waiting', rows: [['Landlord sign-off', 'Asked Sep 18 · no answer yet', 'Waiting', 'st-warn si-pause', 'Nudge']], stats: [['Invoiced', '20%'], ['Costs', '14%'], ['Margin', '—']], second: 'Call Marchetti' },
      'Powder room': { cap: 'After the job', rows: [['Warranty', 'Until Sep 2027', 'Covered', 'st-ok si-check'], ['Review', 'Not asked yet', '', '', 'Ask']], stats: [['Final', '$3,120'], ['Margin', '38%'], ['Days', '6']], second: 'Message Priya' },
      'Front porch rebuild': { cap: 'After the job', rows: [['Warranty', 'Until Aug 2027', 'Covered', 'st-ok si-check'], ['Review', '5 stars on Google', 'Received', 'st-ok si-check']], stats: [['Final', '$9,840'], ['Margin', '34%'], ['Days', '11']], second: 'Message Chen' }
    };
    var mk = function (d) {
      var st = d[2];
      return {
        hasBar: st !== 'planning', name: d[0], client: d[1], meta: d[5], value: money(d[3]), pct: d[4] + '%', pw: Math.max(d[4], 0) + '%',
        barStyle: st === 'done' ? 'background: var(--ok-dot)' : st === 'hold' ? 'background: var(--warn-dot)' : '',
        crew: d[6].map(function (c) { return { ini: P[c][0], tn: P[c][1] }; }), crewNote: d[7],
        status: S[st][0], st: S[st][1], href: 'Job.dc.html', ic: ic('list', 'violet'),
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { x = x || { rows: [], stats: [] }; return { cap: x.cap || '', hasCap: !!x.cap, rows: rowsOf(d[0], x.rows), stats: (x.stats || []).map(function (q) { return { l: q[0], v: q[1] }; }), hasStats: !!(x.stats && x.stats.length), second: x.second || 'Message client' }; })(DET[d[0]])
      };
    };
    var order = [['setup', 'Needs your review'], ['active', 'In progress'], ['planning', 'Planning'], ['hold', 'On hold'], ['done', 'Completed']];
    var groups = order.map(function (g) {
      var rs = rows.filter(function (d) { return d[2] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + d[3]; }, 0);
      return { title: g[1], total: rs.length && g[0] !== 'setup' ? money(tot) : '', setup: g[0] === 'setup', list: g[0] !== 'setup', rows: rs.map(mk), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '' };
    }).filter(function (g) { return g.has; });
    return {
      kpis: [
        { label: 'In progress', value: '$61,065', sub: '3 jobs', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'To invoice', value: '$7,680', sub: 'Hart, term 3', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'On site today', value: '4', sub: '1 clash', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[3] || x[1], count: data.filter(function (d) { return match(x, d[2]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), rows: rowsOf('kpi', [
        ['Basement finish', 'Hart · 64% done', '', '', '', '$42,355'], ['Clinic hallway refresh', 'Harbourfront · 35% done', '', '', '', '$12,850'], ['Fence and gate', 'Gill · 40% done', '', '', '', '$5,860'],
        ['Ready to invoice: Hart term 3', 'Drywall milestone reached', 'To invoice', 'st-warn si-clock', 'Invoice', '$7,680'],
        ['Luca is booked twice, 9 to 11', 'Hart basement and Clinic hallway', 'Clash', 'st-bad si-alert', 'Fix']]) },
      groups: groups, empty: groups.length === 0, emptyIc: ic('cone', 'amber'), rcIc: ic('receipt', 'amber')
    };
