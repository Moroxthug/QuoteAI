    var wa = self.g('wa', ST !== 'whatsappNotConnected');
    var usedUp = ST === 'textsUsedUp';
    var smsUsed = usedUp ? 1000 : 412;
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('en-CA'), total: total.toLocaleString('en-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : '', sub: full ? 'Used up · resets Oct 1' : sub, subStyle: full ? 'color: var(--bad)' : 'color: var(--muted)' };
    };
    var meters = [ meter('Texts this month', smsUsed, 1000, 'Resets Oct 1') ];
    if (wa) meters.push(meter('WhatsApp messages', 86, 500, 'Resets Oct 1'));
    var waRows;
    if (wa) waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', '(416) 555-0142 · verified Sep 2'), 'Connected', 'st-ok si-check'),
      sw('waPref', true, 'send', 'teal', 'Use it when clients prefer it', 'Otherwise we send a text'),
      btnRow('link', 'slate', 'Disconnect', 'Messages go back to text and email', 'Disconnect', function () { set({ wa: false }); }, 'btn-d')
    ];
    else waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', 'Clients get quotes and replies in WhatsApp'), 'Not connected', 'st-mute si-off'),
      btnRow('phone', 'violet', 'Connect your number', 'We send a 6-digit code to WhatsApp', 'Connect', function () { set({ wa: true }); }, 'btn-p')
    ];
    var logSt = function (r, w, c) { return stat(r, w, c); };
    return {
      roBanner: roBanner, usedUp: usedUp, waOn: wa, warnIc: ic('warn', 'rose'), phoneIc: ic('phone', 'violet'),
      numSt: usedUp ? { w: 'Paused', cls: 'st-warn si-pause' } : { w: 'Active', cls: 'st-ok si-live' },
      meters: meters,
      gSms: grp('Texts', [
        sw('sms', !usedUp, 'chat', 'sky', 'Text messages', usedUp ? 'Paused until Oct 1' : 'Quote and invoice links, reminders'),
        sw('leadFu', true, 'funnel', 'teal', 'Lead follow-ups', 'When a new lead waits for a reply'),
        sw('crewRem', true, 'users', 'amber', 'Crew reminders', 'Tomorrow’s site, the night before at 7 pm'),
        btnRow('send', 'indigo', 'Send a test', 'To your phone, (416) 555-0142', self.g('tested', false) ? 'Sent' : 'Send', function () { set({ tested: true }); })
      ], '', 80),
      gWa: grp('WhatsApp', waRows, wa ? '' : 'Needs a WhatsApp Business account on a number you own. Takes about 5 minutes.', 130),
      gTpl: grp('WhatsApp templates', [
        stat(lnk('doc', 'violet', 'Quote ready', 'Link to the quote', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('receipt', 'amber', 'Invoice reminder', 'Balance and pay link', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('truck', 'teal', 'On my way', 'Arrival time for the client', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('star', 'gold', 'Review request', 'Google and HomeStars links', '', '#'), 'In review', 'st-acc si-q2'),
        stat(lnk('funnel', 'rose', 'Lead follow-up', 'Too promotional. Edit and resend', '', '#'), 'Rejected', 'st-bad si-x')
      ], 'WhatsApp checks each template before you can use it, usually within a day.', 170),
      gQuiet: grp('Quiet hours', [
        sw('quiet', true, 'moon', 'indigo', 'Quiet hours', 'Messages wait until morning'),
        val('clock', 'slate', 'From', 'Every day', '9:00 pm', true),
        val('sun', 'amber', 'Until', 'Crew reminders too', '8:00 am', true)
      ], '', 210),
      gOpt: grp('Opt-outs', [
        val('shield', 'sage', 'Reply STOP to opt out', 'Added to each client’s first message', 'Always on'),
        lnk('users', 'stone', 'Opted out', 'They get email only', '3 clients', '#')
      ], 'Canada’s anti-spam law (CASL) needs consent and an easy way out. We handle both.', 250),
      gLog: grp('Recent messages', [
        logSt(mk('user', 'violet', 'Dana Whitfield', 'Quote link · 9:12 am'), 'Sent', 'st-info si-q1'),
        logSt(mk('user', 'teal', 'Harbourfront Dental', '“Can you start Monday?” · 8:40 am'), 'Received', 'st-acc si-dot'),
        logSt(mk('user', 'amber', 'Priya Nair', 'Follow-up · sends at 8:00 am'), 'Waiting', 'st-warn si-clock'),
        logSt(mk('user', 'rose', 'Tom & Lena Hart', 'Reminder INV-0412 · landline'), 'Failed', 'st-bad si-x')
      ], '', 290)
    };
