    var ST = this.props.state || 'default';
    var expired = ST === 'expired';
    var up = this.g('up_' + ST, ''); // '', 'busy', 'done'
    var J = function (a) { return a.join(' '); };
    var upload = function () {
      if (self.g('up_' + ST, '')) return;
      var o = {}; o['up_' + ST] = 'busy'; set(o);
      setTimeout(function () { var p = {}; p['up_' + ST] = 'done'; set(p); }, 1400);
    };
    var wsib = up === 'done'
      ? { w: 'In review', st: J(['st-acc', 'si-q2']), sub: 'New certificate · sent Sep 29', until: 'to Dec 31', bar: 100, btn: '', hasBtn: false }
      : expired
        ? { w: 'Expired', st: J(['st-bad', 'si-alert']), sub: 'Harbourfront Dental needs it before Oct 8', until: 'ended Sep 25', bar: 0, btn: up === 'busy' ? 'Uploading…' : 'Upload', hasBtn: true }
        : { w: 'Expires Oct 20', st: J(['st-warn', 'si-clock']), sub: 'Harbourfront Dental needs it before Oct 8', until: 'to Oct 20', bar: 8, btn: up === 'busy' ? 'Uploading…' : 'Upload', hasBtn: true };
    var doc = function (icn, tone, title, sub, w, st, until, bar, btn, hasBtn, act, primary) {
      return { ic: ic(icn, tone), title: title, sub: sub, w: w, st: st, hasExp: !!until, until: until,
        barStyle: 'width: ' + bar + '%; background: ' + (bar < 12 ? 'var(--bad)' : bar < 30 ? 'var(--warn-dot)' : 'var(--ok-dot)'),
        btn: btn, hasBtn: hasBtn, act: act || function () {}, busy: btn === 'Uploading…', btnCls: primary ? 'btn-p' : 'btn-s' };
    };
    var docs = [
      doc('shield', 'teal', 'WSIB clearance certificate', wsib.sub, wsib.w, wsib.st, wsib.until, wsib.bar, wsib.btn, wsib.hasBtn, upload, true),
      doc('file', 'azure', 'Liability insurance', '$2M general liability · Intact', 'Expires Nov 14', J(['st-warn', 'si-clock']), 'to Nov 14', 22, 'Upload', true, null, false),
      doc('bolt', 'gold', 'Electrical contractor licence', 'ECRA/ESA · #7012345', 'Valid', J(['st-ok', 'si-check']), 'to Mar 31, 2027', 78, 'Replace', true, null, false),
      doc('receipt', 'violet', 'HST number', '81234 5678 RT0001', 'On file', J(['st-ok', 'si-check']), '', 0, '', false, null, false)
    ];
    return {
      bannerWarn: !expired && up !== 'done', bannerBad: expired && up !== 'done', bannerOk: up === 'done',
      warnIc: ic('warn', 'amber'), badIc: ic('warn', 'rose'), okIc: ic('check', 'sage'),
      docMeta: up === 'done' ? '4 on file' : (expired ? '1 expired' : '2 expiring'),
      docs: docs,
      jobs: [
        { dow: 'Wed', day: '7', title: 'Hart basement', sub: 'Final electrical · devices and panel labels', time: '7:30', addr: '48 Galloway Rd', w: 'Scheduled', st: J(['st-info', 'si-q1']) },
        { dow: 'Thu', day: '8', title: 'Harbourfront Dental', sub: 'Pot lights, reception', time: '8:00', addr: 'Queens Quay W',
          w: up === 'done' ? 'Scheduled' : (expired ? 'On hold' : 'Needs WSIB'), st: up === 'done' ? J(['st-info', 'si-q1']) : (expired ? J(['st-warn', 'si-pause']) : J(['st-warn', 'si-clock'])) },
        { dow: 'Tue', day: '13', title: 'Marchetti Bakery', sub: 'Service call · breaker trips', time: '9:00', addr: 'Dundas St W', w: 'To confirm', st: J(['st-warn', 'si-clock']) }
      ],
      invoices: [
        { ic: ic('receipt', 'amber'), title: 'Hart basement, rough-in', id: 'RE-121', sub: 'pays Oct 2', amt: '$2,180.00', w: 'Approved', st: J(['st-ok', 'si-check']) },
        { ic: ic('receipt', 'violet'), title: 'Marchetti service call', id: 'RE-124', sub: 'sent Sep 27', amt: '$420.00', w: 'In review', st: J(['st-acc', 'si-q2']) },
        { ic: ic('receipt', 'sage'), title: 'Gill Residence, panel', id: 'RE-118', sub: 'Sep 18', amt: '$3,450.00', w: 'Paid', st: J(['st-ok', 'si-check']) }
      ]
    };
