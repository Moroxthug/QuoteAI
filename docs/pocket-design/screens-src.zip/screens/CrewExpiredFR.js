    var mode = this.props.state || 'expired';
    var online = this.g('online', mode !== 'offline');
    var retrying = this.g('retrying', false);
    var asking = this.g('asking', false), asked = this.g('asked', false);
    var code = this.g('code', ''), codeErr = this.g('codeErr', false), joining = this.g('joining', false);
    var T = {
      expired: ['Ce lien a expiré', 'Les liens cessent de fonctionner après un moment pour protéger les infos du chantier. Marco peut vous en envoyer un nouveau.', ['lock', 'slate']],
      replaced: ['Vous avez un lien plus récent', 'Marco a envoyé un nouveau lien sur votre téléphone, alors celui-ci ne fonctionne plus. Utilisez le dernier texto de Rossi Renovations.', ['sync', 'violet']],
      invalid: ['Ce lien ne fonctionne pas', 'Il manque peut-être une partie. Rouvrez-le depuis le texto ou demandez-en un nouveau à Marco.', ['warn', 'amber']],
      offline: ['Pas de connexion', 'Votre lien est bon. La page a besoin de réseau pour charger le travail du jour.', ['cloud', 'amber']]
    };
    var t = online && mode === 'offline' ? T.expired : T[mode] || T.expired;
    if (!online) t = T.offline;
    var digits = code.replace(/\D/g, '').slice(0, 6);
    var cells = [0, 1, 2, 3, 4, 5].map(function (i) { return { v: digits[i] || '', cls: i === digits.length ? 'on' : '' }; });
    return {
      title: t[0], sub: t[1], heroIc: ic(t[2][0], t[2][1]),
      offline: !online, online: online, retrying: retrying, retryLabel: retrying ? 'Nouvel essai…' : 'Réessayer',
      retry: function () { if (self.g('retrying', false)) return; set({ retrying: true }); setTimeout(function () { set({ retrying: false, online: true }); }, 1400); },
      notAsked: !asked, asked: asked, asking: asking, askLabel: asking ? 'Envoi…' : 'Demander un nouveau lien à Marco',
      ask: function () { if (self.g('asking', false)) return; set({ asking: true }); setTimeout(function () { set({ asking: false, asked: true }); }, 1200); },
      sentIc: ic('send', 'azure'), phoneIc: ic('phone', 'sage'),
      cells: cells, code: digits, codeErr: codeErr, codeCls: codeErr ? 'err' : '',
      onCode: function (e) { set({ code: e.target.value.replace(/\D/g, '').slice(0, 6), codeErr: false }); },
      joinLabel: joining ? 'Connexion…' : 'Entrer',
      join: function () {
        var d = self.g('code', '');
        if (d.length < 6 || d === '000000') { set({ codeErr: true }); return; }
        set({ joining: true });
        setTimeout(function () { window.location.href = 'CrewNow.dc.html'; }, 1100);
      }
    };
