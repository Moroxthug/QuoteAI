    var DEF_ORDER = ['quotes', 'visits', 'win', 'waiting', 'needs', 'weather', 'leads'];
    var DEF_ON = { quotes: true, visits: true, win: true, waiting: true, needs: false, weather: false, leads: false };
    var DEF_TABS = ['quotes', 'leads', 'clients'];
    var SEC = {
      quotes: ['Soumissions à rédiger', 'Brouillons et demandes', 'doc', 'violet'],
      visits: ['Visites de chantier', 'Aujourd’hui et demain', 'pin', 'rose'],
      win: ['Taux de réussite', '4 derniers mois', 'bars', 'indigo'],
      waiting: ['En attente des clients', 'Envoyées et consultées', 'clock', 'amber'],
      needs: ['À traiter', 'Approbations et réponses', 'bell', 'clay'],
      weather: ['Météo des chantiers', 'Alertes pluie et froid', 'sun', 'gold'],
      leads: ['Nouvelles demandes', 'De votre site Web et des appels', 'user', 'sage']
    };
    var order = this.g('order', DEF_ORDER), on = this.g('on', DEF_ON), lifted = this.g('lifted', ''), saved = this.g('saved', false);
    var dirty = function (o) { o.saved = false; set(o); };
    var move = function (i, d) {
      var a = self.g('order', DEF_ORDER).slice(), j = i + d;
      if (j < 0 || j >= a.length) return;
      var t = a[i]; a[i] = a[j]; a[j] = t; dirty({ order: a });
    };
    var rows = order.map(function (k, i) {
      var s = SEC[k], isOn = !!on[k], isL = lifted === k;
      return {
        name: s[0], sub: isOn ? s[1] : 'Masquée', ic: ic(s[2], s[3]),
        cls: (isL ? 'lift ' : '') + (isOn ? '' : 'off'), radius: i === 0 ? 'border-radius: 22px 22px 0 0' : (i === order.length - 1 ? 'border-radius: 0 0 22px 22px' : ''),
        lifted: isL, showSw: !isL, on: isOn, handleLabel: 'Déplacer : ' + s[0], swLabel: 'Afficher : ' + s[0],
        lift: function () { set({ lifted: self.g('lifted', '') === k ? '' : k }); },
        up: function () { move(i, -1); }, down: function () { move(i, 1); },
        upStyle: i === 0 ? 'opacity: .35' : '', downStyle: i === order.length - 1 ? 'opacity: .35' : '',
        track: isOn ? 'background: var(--acc)' : 'background: var(--track-off)',
        knob: isOn ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { var o = Object.assign({}, self.g('on', DEF_ON)); o[k] = !o[k]; dirty({ on: o }); }
      };
    });
    var shownN = order.filter(function (k) { return on[k]; }).length;

    var TABS = [
      ['quotes', 'Soumissions', 'doc', 'violet'], ['leads', 'Demandes', 'user', 'sage'], ['clients', 'Clients', 'users', 'azure'],
      ['jobs', 'Travaux', 'hammer', 'clay'], ['schedule', 'Horaire', 'cal', 'teal'], ['invoices', 'Factures', 'receipt', 'rose'],
      ['map', 'Carte', 'pin', 'amber'], ['docs', 'Documents', 'file', 'slate'], ['books', 'Comptabilité', 'bank', 'gold']
    ];
    var tabs = this.g('tabs', DEF_TABS), full = this.g('full', false);
    var tiles = TABS.map(function (t) {
      var idx = tabs.indexOf(t[0]), sel = idx >= 0, lock = t[0] === 'books';
      return {
        label: t[1], ic: ic(t[2], t[3]), on: sel, cls: sel ? 'on' : (lock ? 'lock' : ''), hasN: sel, n: String(idx + 2),
        aria: lock ? t[1] + ', hors de votre rôle' : t[1],
        pick: function () {
          if (lock) return;
          var a = self.g('tabs', DEF_TABS).slice(), p = a.indexOf(t[0]);
          if (p >= 0) { a.splice(p, 1); dirty({ tabs: a, full: false }); }
          else if (a.length >= 3) { set({ full: true }); }
          else { a.push(t[0]); dirty({ tabs: a, full: false }); }
        }
      };
    });
    var byKey = {}; TABS.forEach(function (t) { byKey[t[0]] = t; });
    var navPrev = [{ label: 'Accueil', ic: ic('house', 'violet'), cls: 'on' }];
    tabs.forEach(function (k) { var t = byKey[k]; navPrev.push({ label: t[1], ic: ic(t[2], t[3]), cls: '' }); });
    while (navPrev.length < 4) navPrev.push({ label: 'Vide', ic: ic('plus', 'slate'), cls: '' });

    var den = this.g('den', 0), compact = den === 1;
    var FIG = ['4', '62 %', '3', '18 640 $', '2'];
    var prevCards = FIG.map(function (f, i) {
      return { fig: f,
        style: compact ? 'height: 50px; padding: 8px 10px; margin-top: ' + (i ? 6 : 0) + 'px' : 'height: 78px; padding: 12px 14px; margin-top: ' + (i ? 10 : 0) + 'px',
        figStyle: compact ? 'font-size: 16px; margin-top: 4px' : 'font-size: 24px; margin-top: 8px',
        lineStyle: compact ? 'display: none' : '' };
    });
    return {
      saved: saved, okIc: ic('check', 'sage'),
      rows: rows, shownLabel: shownN + ' sur ' + order.length + ' affichées', lockIc: ic('lock', 'slate'),
      tiles: tiles, navPrev: navPrev, tabCount: (tabs.length + 1) + ' sur 4', full: full,
      dens: ['Confortable', 'Compacte'].map(function (l, i) { return { label: l, on: den === i, style: den === i ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { dirty({ den: i }); } }; }),
      denInd: 'transform: translateX(' + (den * 100) + '%)',
      prevCards: prevCards,
      denNote: compact ? 'Cartes plus petites. Environ 5 sections par écran.' : 'Chiffres plus grands. Environ 3 sections par écran.',
      reset: function () { set({ order: DEF_ORDER, on: DEF_ON, tabs: DEF_TABS, den: 0, lifted: '', full: false, saved: false }); },
      resetIc: ic('sync', 'slate'), rolesIc: ic('users', 'indigo'),
      save: function () { set({ saved: true, lifted: '' }); },
      saveLabel: saved ? 'Enregistré' : 'Enregistrer'
    };
