    return {
      remindIc: ic('bell', 'azure'), paidIc: ic('check', 'sage'),
      feats: [
        ['bell', 'amber', 'Needs you, on Home', 'Late invoices, unsigned quotes and crew questions, first thing when you open the app.'],
        ['list', 'violet', 'Swipe for quick actions', 'Swipe a quote or invoice left to follow up, send a reminder or mark it paid.'],
        ['camera', 'sage', 'Receipts from the camera', 'Snap a receipt. We read the total and the HST and file it to the job.'],
        ['eye', 'azure', 'Watch how', 'Short videos with captions on first-time screens and in Help.']
      ].map(function (f) { return { ic: ic(f[0], f[1]), title: f[2], text: f[3] }; })
    };
