    var mode = this.g('mode', this.props.state || 'connected');
    var fixed = this.g('fixed', false);
    var isErr = mode === 'error' && !fixed;
    var isOn = mode !== 'notConnected';
    var ret = this.g('ret', '');
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var master = this.g('master', true), ms = sw(master);
    var running = this.g('running', false), synced = this.g('synced', false);

    var SY = [
      ['inv', 'Factures', 'Les factures envoyées vont dans QuickBooks avec leurs codes de taxe', 'receipt', 'amber'],
      ['pay', 'Paiements', 'Dans les deux sens. Les paiements saisis dans QuickBooks reviennent ici', 'card', 'violet'],
      ['cli', 'Clients', 'Les nouveaux clients deviennent des clients QuickBooks', 'users', 'azure'],
      ['exp', 'Dépenses', 'Les coûts de chantier confirmés entrent comme dépenses', 'box', 'clay']
    ];
    var on = this.g('on', { inv: true, pay: true, cli: true, exp: false });
    var syncs = SY.map(function (s) {
      var o = on[s[0]] && master, x = sw(o);
      return { title: s[1], sub: s[2], ic: ic(s[3], s[4]), on: o, track: x.t, knob: x.k, flip: function () { var n = Object.assign({}, self.g('on', on)); n[s[0]] = !n[s[0]]; set({ on: n, master: true }); } };
    });

    var code = this.g('code', isErr ? '' : 'TVH ON');
    var MAPS = [
      ['TVH 13 %', 'Taxe · Ontario', code, 'tax'],
      ['TPS 5 %', 'Taxe · travaux hors province', 'TPS', ''],
      ['Exonéré', 'Taxe', 'Exonéré', ''],
      ['Revenus de chantier', 'Compte de revenus', 'Ventes · Rénovation', ''],
      ['Dépôts', 'Compte de dépôt', 'Fonds non déposés', ''],
      ['Matériaux', 'Compte de dépenses', 'Matériaux de chantier', '']
    ];
    var openPicker = function () { set({ picker: true, pick: self.g('pick', 'TVH ON') }); };
    var maps = MAPS.map(function (m, i) {
      var bad = m[3] === 'tax' && !m[2];
      return { from: m[0], kind: m[1], to: m[2], ok: !bad, bad: bad, sep: '', tap: m[3] === 'tax' ? openPicker : function () {} };
    });

    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var retried = this.g('retried', false);
    var LOG = [];
    if (isErr) {
      LOG.push({ k: 'inv', title: 'INV-0423 · Okoye Condo', sub: money(2210) + ' · aucun code QuickBooks pour la TVH 13 %', st: 'st-bad si-x', status: 'Échec', time: '8 h 12', fix: 'Associer le code', go: openPicker });
      LOG.push({ k: 'inv', title: 'INV-0422 · Priya Nair', sub: money(1865.10) + ' · même raison', st: 'st-bad si-x', status: 'Échec', time: '8 h 12' });
    }
    if (mode === 'error' && fixed) {
      LOG.push({ k: 'inv', title: 'INV-0423 · Okoye Condo', sub: money(2210) + ' · renvoyée avec TVH ON', st: 'st-ok si-check', status: 'Envoyée', time: 'à l’instant' });
      LOG.push({ k: 'inv', title: 'INV-0422 · Priya Nair', sub: money(1865.10) + ' · renvoyée avec TVH ON', st: 'st-ok si-check', status: 'Envoyée', time: 'à l’instant' });
    }
    LOG.push({ k: 'inv', title: 'INV-0421 · Gill Residence', sub: money(2980) + ' · avec TVH ON', st: 'st-ok si-check', status: 'Envoyée', time: '7 h 58' });
    LOG.push({ k: 'pay', title: 'Paiement · INV-0412', sub: 'Tom & Lena Hart · ' + money(2340) + ' · saisi dans QuickBooks', st: 'st-info si-q2', status: 'Revenu', time: '7 h 40' });
    if (!isErr && mode !== 'error') {
      LOG.push(retried
        ? { k: 'cli', title: 'Client · Marchetti Bakery', sub: 'Ajouté comme client', st: 'st-ok si-check', status: 'Envoyé', time: 'à l’instant' }
        : { k: 'cli', title: 'Client · Marchetti Bakery', sub: 'QuickBooks n’a pas répondu à temps', st: 'st-bad si-x', status: 'Échec', time: '7 h 31', fix: 'Réessayer', go: function () { set({ retried: true }); } });
    }
    LOG.push({ k: 'pay', title: 'Paiement · INV-0415', sub: 'Harbourfront Dental · ' + money(1450) + ' · carte', st: 'st-ok si-check', status: 'Envoyé', time: '6 h 02' });
    var LIC = { inv: ['receipt', 'amber'], pay: ['card', 'violet'], cli: ['user', 'azure'], exp: ['box', 'clay'] };
    var log = LOG.map(function (l, i) {
      var bad = l.status === 'Échec';
      return { title: l.title, sub: l.sub, st: l.st, status: l.status, time: l.time, ic: bad ? ic('warn', 'rose') : ic(LIC[l.k][0], LIC[l.k][1]), sep: '', canFix: !!l.fix, fixLabel: l.fix || '', fix: l.go || function () {} };
    });

    var pick = this.g('pick', 'TVH ON');
    var CODES = [['TVH ON', '13 % · Ontario'], ['TPS', '5 %'], ['TVH N.-É.', '14 % · Nouvelle-Écosse'], ['Exonéré', '0 %']];
    var codes = CODES.map(function (c, i) {
      var o = c[0] === pick;
      return { name: c[0], sub: c[1], on: o, sep: '', dot: o ? 'background: var(--inv); color: var(--on-inv)' : 'box-shadow: inset 0 0 0 1.6px var(--line2); color: transparent', chk: o ? 'opacity: 1' : 'opacity: 0', pick: function () { set({ pick: c[0] }); } };
    });

    var connecting = this.g('connecting', false);
    var bf = this.g('bf', 0);
    var RET = {
      fixed: ['b-ok', ['check', 'sage'], 'Code de taxe associé.', '2 factures envoyées à QuickBooks.'],
      connected: ['b-ok', ['check', 'sage'], 'Connecté à Rossi Renovations Inc.', 'Vérifiez les correspondances ci-dessous avant la première synchro.'],
      disconnected: ['b-info', ['sync', 'azure'], 'QuickBooks est déconnecté.', 'Rien n’a été modifié dans QuickBooks.'],
      cancelled: ['b-warn', ['warn', 'amber'], 'Connexion annulée.', 'Rien n’a été partagé. Réessayez quand vous serez prêt.']
    };
    var r = RET[ret];
    var stW = !isOn ? ['Non connecté', 'st-mute si-off'] : isErr ? ['Action requise', 'st-bad'] : !master ? ['En pause', 'st-warn si-pause'] : ['Connecté', 'st-ok'];
    var tries = this.g('tries', 0);
    return {
      appIc: ic('bars', 'sage'), errIc: ic('warn', 'rose'), backIc: ic('export', 'slate'), discIc: ic('warn', 'rose'),
      stWord: stW[0], stCls: stW[1],
      isOn: isOn, isOff: !isOn, isErr: isErr,
      returnMsg: !!r, retCls: r ? r[0] : '', retIc: r ? ic(r[1][0], r[1][1]) : ic('dot', 'slate'), retTitle: r ? r[2] : '', retSub: r ? r[3] : '',
      master: master, masterTrack: ms.t, masterKnob: ms.k, flipMaster: function () { set({ master: !master }); },
      syncSub: master ? 'Aux 15 minutes, et juste après un paiement' : 'En pause. Rien n’est envoyé avant la réactivation',
      lastSync: synced ? 'À l’instant' : 'Aujourd’hui, 8 h 12', running: running, runLabel: running ? 'Synchro…' : 'Lancer',
      runNow: function () { if (self.g('running', false)) return; set({ running: true }); setTimeout(function () { set({ running: false, synced: true }); }, 1500); },
      syncs: syncs, maps: maps, log: log, openPicker: openPicker,
      backSub: bf === 2 ? '38 envoyées · 1er janv. au 31 août' : '38 factures depuis le 1er janv.', backLabel: bf === 1 ? 'Envoi…' : bf === 2 ? 'Terminé' : 'Envoyer',
      backfill: function () { if (self.g('bf', 0)) return; set({ bf: 1 }); setTimeout(function () { set({ bf: 2 }); }, 1600); },
      pickerOpen: this.g('picker', false), discOpen: this.g('disc', false), codes: codes,
      closeSheets: function () { set({ picker: false, disc: false }); },
      saveCode: function () { set({ picker: false, code: self.g('pick', 'TVH ON'), fixed: true, ret: 'fixed' }); },
      askDisc: function () { set({ disc: true }); },
      disconnect: function () { set({ disc: false, mode: 'notConnected', ret: 'disconnected' }); },
      does: [
        { ic: ic('receipt', 'amber'), title: 'Les factures vont dans vos livres', sub: 'Avec le bon code de taxe, pour une TVH juste à la déclaration' },
        { ic: ic('card', 'violet'), title: 'Paiements dans les deux sens', sub: 'Marquez une facture payée d’un côté, l’autre le sait' },
        { ic: ic('box', 'clay'), title: 'Les coûts deviennent des dépenses', sub: 'Seulement ceux que vous confirmez, dans le compte choisi' }
      ],
      steps: [
        { n: '1', title: 'Connectez-vous à QuickBooks', sub: 'Sur la page d’Intuit' },
        { n: '2', title: 'Choisissez votre entreprise', sub: 'Si vous en avez plusieurs' },
        { n: '3', title: 'Associez codes de taxe et comptes', sub: 'Nous proposons une correspondance pour chacun' }
      ],
      perms: ['Lire vos codes de taxe et votre plan comptable', 'Ajouter des clients, factures et paiements', 'Ajouter des dépenses pour les coûts confirmés', 'Lire les paiements saisis dans QuickBooks'],
      nots: ['Voir vos accès bancaires ou faire la paie', 'Supprimer ou modifier des écritures passées'],
      connecting: connecting, connectLabel: connecting ? 'Ouverture de QuickBooks…' : 'Connecter QuickBooks',
      connect: function () {
        if (self.g('connecting', false)) return;
        set({ connecting: true, ret: '' });
        setTimeout(function () {
          var t = self.g('tries', 0);
          if (t === 0 && self.g('ret', '') === '' && self.props.state === 'notConnected') set({ connecting: false, ret: 'cancelled', tries: 1 });
          else set({ connecting: false, mode: 'connected', ret: 'connected', fixed: true, code: 'TVH ON' });
        }, 1500);
      }
    };
