    var na = this.g('na', {}), ls = this.g('ls', {}), bf = this.g('bf', 'open'), closed = this.g('closed', false);
    var money = function (n) { return (n < 0 ? '−$' : '+$') + Math.abs(n).toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var upd = function (key, obj, k, v) { var o = {}; for (var x in obj) o[x] = obj[x]; if (v === null) delete o[k]; else o[k] = v; var s = {}; s[key] = o; set(s); };
    // id, date, desc, amt, hint, match label, icon, tone, initial state
    var B = [
      ['b1', 'Sep 28', 'E-transfer deposit · L HART', 2340.00, 'Looks like INV-0412 · Tom & Lena Hart', 'Match', 'receipt', 'violet', ''],
      ['b2', 'Sep 26', 'Home Depot #7011 Toronto', -412.66, 'Matches a receipt Luca scanned Sep 26', 'Match', 'photo', 'amber', ''],
      ['b3', 'Sep 25', 'Sunbelt Rentals', -1110.00, 'Scissor lift, 6 days · no cost yet', 'Match…', 'truck', 'teal', ''],
      ['b4', 'Sep 24', 'Mobile cheque deposit', 780.00, 'Could be INV-0419 · Harbourfront Dental', 'Match', 'receipt', 'violet', ''],
      ['b5', 'Sep 22', 'RBC monthly fee', -12.95, 'No match found', 'Match…', 'search', 'slate', ''],
      ['b6', 'Sep 22', 'E-transfer deposit · OKOYE', 2497.30, 'INV-0418 · Okoye Condo', '', 'receipt', 'sage', 'match'],
      ['b7', 'Sep 16', 'E-transfer deposit · GILL', 1010.22, 'INV-0417 · Gill Residence', '', 'receipt', 'sage', 'match'],
      ['b8', 'Sep 18', 'Transfer to savings ••9020', -5000.00, 'Between your own accounts', '', 'bank', 'slate', 'ignore']
    ];
    var stateOf = function (b) { return ls[b[0]] !== undefined ? ls[b[0]] : b[8]; };
    var bucket = function (s) { return s === '' ? 'open' : s === 'ignore' ? 'ignored' : 'matched'; };
    var pending = B.filter(function (b) { return stateOf(b) === ''; }).length;
    var I = [
      ['bank', 'Bank lines not matched', 'To invoices, payments or costs', pending, '#'],
      ['pay', 'Payments not in the bank', 'Recorded, but no bank line yet', 2, 'Invoices.dc.html'],
      ['cost', 'Costs waiting', 'Receipts with no category', 3, '#'],
      ['claim', 'Claims with no receipt', 'Amara and Dev', 2, 'Team.dc.html'],
      ['tax', 'HST not split', 'Every cost has its tax split', 0, '#'],
      ['draft', 'Draft invoices not sent', 'INV-0422 and INV-0423', 2, 'Invoices.dc.html'],
      ['hours', 'Hours not approved', '4 time entries', 4, 'Team.dc.html'],
      ['qb', 'Not yet in QuickBooks', 'Everything synced at 7:40 am', 0, '#']
    ];
    var items = I.map(function (it) {
      var isNa = !!na[it[0]], open = it[3] > 0 && !isNa, done = !open;
      return {
        title: it[1], sub: isNa ? 'Marked not needed this month' : (it[3] > 0 ? it[2] : it[2]), count: it[3], href: it[4],
        open: open, closed: done, isNa: isNa,
        badge: open ? 'background: rgba(214,149,36,.14); color: var(--warn)' : 'background: var(--ok-soft); color: var(--ok)',
        fade: done ? '' : '',
        naLabel: 'Mark ' + it[1] + ' as not needed', openLabel: 'Open ' + it[1],
        na: function () { upd('na', na, it[0], true); }, undo: function () { upd('na', na, it[0], null); }
      };
    });
    var openCount = items.filter(function (i) { return i.open; }).length;
    var isClosed = closed && openCount === 0;
    var lines = B.filter(function (b) { return bucket(stateOf(b)) === bf; }).map(function (b, i) {
      var s = stateOf(b);
      var ST = { match: ['Matched', 'st-ok si-check'], cost: ['Recorded as a cost', 'st-info si-dot'], ignore: ['Ignored', 'st-mute si-off'] };
      return {
        date: b[1], desc: b[2], amt: money(b[3]), amtColor: b[3] > 0 ? 'color: var(--ok)' : '',
        hint: s === 'match' && b[8] === '' ? b[4].replace(/^(Looks like|Could be|Matches) /, '') : b[4], hintColor: s === '' ? 'color: var(--t2)' : 'color: var(--muted)',
        ic: ic(b[6], b[7]), matchLabel: b[5], sep: i ? 'border-top: 1px solid var(--line)' : '',
        pending: s === '', done: s !== '', status: s ? ST[s][0] : '', st: s ? ST[s][1] : '',
        match: function () { upd('ls', ls, b[0], 'match'); }, cost: function () { upd('ls', ls, b[0], 'cost'); }, ignore: function () { upd('ls', ls, b[0], 'ignore'); },
        undo: function () { upd('ls', ls, b[0], ''); }
      };
    });
    var cnt = function (k) { return B.filter(function (b) { return bucket(stateOf(b)) === k; }).length; };
    return {
      months: [['Jul', 'Closed'], ['Aug', 'Closed'], ['Sep', isClosed ? 'Closed' : 'Open']].map(function (m, i) { var on = i === 2; return { label: m[0], tag: m[1], on: on, cls: on ? 'on' : '' }; }),
      openCount: openCount, openWord: openCount === 1 ? 'open item' : 'open items', doneCount: items.length - openCount,
      monthWord: isClosed ? 'Closed' : 'Open', monthSt: isClosed ? 'st-ok' : 'st-warn',
      ticks: items.map(function (i) { return { bg: i.open ? 'background: var(--sunk)' : 'background: var(--ok-dot)' }; }),
      closeLabel: isClosed ? 'September is closed' : 'Close September',
      closeStyle: isClosed ? 'background: var(--ok-soft); color: var(--ok)' : (openCount > 0 ? 'opacity: .4' : ''),
      closeNote: isClosed ? 'Locked Sep 29 · reopen from ⋯' : (openCount > 0 ? 'Finish or mark N/A each open item first' : 'Locks September and sends it to QuickBooks'),
      closeMonth: function () { if (openCount === 0) set({ closed: true }); },
      checkLabel: (items.length - openCount) + ' of ' + items.length,
      items: items,
      bf: [['open', 'Not matched'], ['matched', 'Matched'], ['ignored', 'Ignored']].map(function (f) { var on = f[0] === bf; return { label: f[1], count: cnt(f[0]), on: on, cls: on ? 'on' : '', pick: function () { set({ bf: f[0] }); } }; }),
      lines: lines, noLines: lines.length === 0, bankIc: ic('bank', 'sage')
    };
