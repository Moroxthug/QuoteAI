    var P = this.props.state || 'default';
    var sel = self.g('sel', 0), remember = self.g('remember', true), opening = self.g('opening', P === 'opening');
    var removed = P === 'removed';
    var C = [
      ['Rossi Renovations', 'RR', 'Propriétaire', 'Toronto', 'tn2', 'tag-acc', 'Ouverte aujourd’hui à', '8 h 14'],
      ['Rossi Commercial', 'RC', 'Propriétaire', 'Toronto', 'tn4', 'tag-acc', 'Ouverte le', '21 sept.'],
      ['Harbourfront Builders', 'HB', 'Contremaître', 'Mississauga', 'tn3', '', removed ? 'Accès retiré le' : 'Ouverte le', removed ? '25 sept.' : '30 août']
    ];
    var cos = C.map(function (c, i) {
      var gone = removed && i === 2, on = !gone && i === sel;
      return { name: c[0], ini: c[1], role: c[2], city: c[3], last: c[6], when: c[7], tn: c[4], tagCls: c[5], on: on, ok: !gone, gone: gone, cls: (on ? 'on' : '') + (gone ? ' off' : ''), delay: 'animation-delay: ' + (60 + i * 40) + 'ms', pick: function () { if (!gone) set({ sel: i }); } };
    });
    return {
      loading: P === 'loading', ready: P !== 'loading', removed: removed, infoIc: ic('user', 'sky'),
      skels: [1, 2, 3], cos: cos, opening: opening,
      goLabel: opening ? 'Ouverture de ' + C[sel][0] + '…' : 'Continuer',
      go: function () { if (P === 'loading') return; set({ opening: true }); },
      remember: remember, flip: function () { set({ remember: !remember }); },
      track: remember ? 'background: var(--acc)' : 'background: var(--track-off)', knob: remember ? 'transform: translateX(20px)' : 'transform: translateX(0)'
    };
