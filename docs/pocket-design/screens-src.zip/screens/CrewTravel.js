    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var kind = this.g('kind', mode === 'perDiem' ? 1 : 0);
    var km1 = this.g('km', 14), round = this.g('round', true), days = this.g('days', 2), night = this.g('night', true), hasPhoto = this.g('photo', kind === 1 || mode === 'perDiem');
    var dayI = this.g('day', 0), jobI = this.g('job', 0), mapUsed = this.g('map', false);
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var DAYS = ['Today, Tue Sep 29', 'Mon, Sep 28', 'Fri, Sep 25', 'Thu, Sep 24', 'Wed, Sep 23'];
    var JOBS = [['Hart basement', '48 Galloway Rd, Scarborough'], ['Harbourfront Dental', 'Queens Quay W'], ['Gill Residence', 'Gill Residence']];
    var total = round ? km1 * 2 : km1;
    var base = [
      { k: 'km', title: '22 km · round trip', sub: 'Home Depot, Warden Ave to Hart basement', st: 'st-ok si-check', status: 'Approved', date: 'Sep 22' },
      { k: 'diem', title: '2 days away', sub: 'Gill Residence cottage job · overnight', st: 'st-ok si-check', status: 'Approved', date: 'Sep 23' },
      { k: 'km', title: '48 km · round trip', sub: 'Supply run for Harbourfront Dental', st: 'st-warn si-clock', status: 'To approve', date: 'Sep 25' },
      { k: 'km', title: '116 km', sub: 'Luca asked: which job was this for?', st: 'st-warn si-clock', status: 'Question', date: 'Sep 24' }
    ];
    var added = this.g('added', []);
    var all = added.concat(base);
    var kmSum = all.filter(function (c) { return c.k === 'km'; }).reduce(function (a, c) { return a + (c.km || parseInt(c.title, 10)); }, 0);
    var daySum = all.filter(function (c) { return c.k === 'diem'; }).reduce(function (a, c) { return a + (c.d || parseInt(c.title, 10)); }, 0);
    var waiting = all.filter(function (c) { return c.status !== 'Approved'; }).length;
    var nt = sw(night), rt = sw(round);
    var justSent = this.g('justSent', false);
    return {
      offline: offline,
      kpis: [
        { label: 'Distance', value: kmSum + ' km', sub: 'this period', sep: '' },
        { label: 'Days away', value: daySum + '', sub: 'per diem', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Waiting', value: waiting + '', sub: 'on Luca', sep: 'border-left: 1px solid var(--line)' }
      ],
      kinds: ['Mileage', 'Per diem'].map(function (l, i) { var on = i === kind; return { label: l, on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ kind: i }); } }; }),
      kindInd: 'transform: translateX(' + (kind * 100) + '%)', isKm: kind === 0, isDiem: kind === 1,
      calIc: ic('cal', 'azure'), jobIc: ic('house', 'clay'), cloudIc: ic('cloud', 'amber'), okIc: ic('check', 'sage'),
      dayLabel: DAYS[dayI], prevDay: function () { set({ day: (self.g('day', 0) + 1) % DAYS.length }); },
      job: JOBS[jobI][0], swapJob: function () { set({ job: (self.g('job', 0) + 1) % JOBS.length }); },
      from: this.g('from', 'Home Depot, Warden Ave'), to: this.g('to', JOBS[jobI][1]),
      onFrom: function (e) { set({ from: e.target.value }); }, onTo: function (e) { set({ to: e.target.value }); },
      km: total + '', tripWord: round ? 'there and back' : 'one way',
      kmMinus: function () { set({ km: Math.max(1, self.g('km', 14) - 1) }); }, kmPlus: function () { set({ km: self.g('km', 14) + 1 }); },
      useMap: function () { set({ km: 14, map: true }); }, mapLabel: mapUsed ? 'Map distance used · 14 km each way' : 'Use map distance · 14 km each way',
      round: round, rTrack: rt.t, rKnob: rt.k, flipRound: function () { set({ round: !self.g('round', true) }); },
      days: days + '', daysWord: days === 1 ? 'day' : 'days',
      dMinus: function () { set({ days: Math.max(1, self.g('days', 2) - 1) }); }, dPlus: function () { set({ days: Math.min(14, self.g('days', 2) + 1) }); },
      night: night, nTrack: nt.t, nKnob: nt.k, flipNight: function () { set({ night: !self.g('night', true) }); },
      receiptTitle: kind === 0 ? 'Parking or toll receipt' : 'Receipt',
      hasPhoto: hasPhoto, togglePhoto: function () { set({ photo: !hasPhoto }); },
      note: this.g('note', ''), onNote: function (e) { set({ note: e.target.value }); },
      notePh: kind === 0 ? 'Picked up board for the hallway' : 'Cottage job, two nights in Barrie',
      submitLabel: (offline ? 'Save ' : 'Send ') + (kind === 0 ? total + ' km' : days + (days === 1 ? ' day' : ' days')),
      submit: function () {
        var c = kind === 0
          ? { k: 'km', km: total, title: total + ' km' + (round ? ' · round trip' : ''), sub: self.g('from', 'Home Depot, Warden Ave') + ' to ' + JOBS[jobI][0] + (hasPhoto ? ' · receipt' : ''), date: DAYS[dayI].replace(/^.*?(Sep \d+)$/, '$1') }
          : { k: 'diem', d: days, title: days + (days === 1 ? ' day' : ' days') + ' away', sub: JOBS[jobI][0] + (night ? ' · overnight' : ''), date: DAYS[dayI].replace(/^.*?(Sep \d+)$/, '$1') };
        c.st = offline ? 'st-mute si-draft' : 'st-warn si-clock'; c.status = offline ? 'Saved on phone' : 'To approve';
        set({ added: [c].concat(self.g('added', [])), justSent: true, note: '' });
      },
      justSent: justSent, sentMsg: offline ? 'Saved on your phone.' : 'Sent to Luca.', sentSub: offline ? 'It sends when you have signal.' : 'You’ll see it here once he checks it.',
      undo: function () { set({ added: self.g('added', []).slice(1), justSent: false }); },
      claims: all.map(function (c) { return { title: c.title, sub: c.sub, st: c.st, status: c.status, date: c.date, ic: c.k === 'km' ? ic('truck', 'azure') : ic('house', 'amber') }; }),
      claimCount: all.length + ''
    };
