    var mode = this.props.state || 'default';
    var ro = mode === 'readOnly';
    var ORIG = 1865.10;
    var START = [
      { id: 'a', sec: 'Prep', name: 'Remove existing backsplash', qty: 32, unit: 'sq ft', rate: 4.50 },
      { id: 'b', sec: 'Prep', name: 'Cement board and waterproofing', qty: 32, unit: 'sq ft', rate: 6.25 },
      { id: 'c', sec: 'Tile', name: 'Tile install, herringbone', qty: 32, unit: 'sq ft', rate: 18.50 },
      { id: 'd', sec: 'Tile', name: 'Tile, grout and trim supply', qty: 37, unit: 'sq ft', rate: 13.69 },
      { id: 'e', sec: 'Finish', name: 'Outlet extenders and cover plates', qty: 4, unit: 'each', rate: 22.00 },
      { id: 'f', sec: 'Finish', name: 'Silicone, sealing and cleanup', qty: 1, unit: 'lot', rate: 120.00 }
    ];
    var lines = this.g('lines', START);
    var title = this.g('title', 'Kitchen backsplash');
    var bookOpen = this.g('book', false), exDraft = this.g('exDraft', '');
    var excl = this.g('excl', ['Moving or reconnecting appliances', 'Drywall repair behind the old tile beyond 2 sq ft', 'Electrical work past swapping cover plates']);
    var optsOn = this.g('opts', true), rec = this.g('rec', 1);
    var dep = this.g('dep', 30), mile = this.g('mile', 30), holdOn = this.g('hold', true);
    var sent = this.g('sent', false);
    var FLAGS = this.g('flags', { a: 'Low', d: 'High', f: 'Low' });

    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var money = function (n) { var s = Math.abs(n).toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); return (n < 0 ? '−$' : '$') + s; };
    var parse = function (s) { var n = parseFloat(String(s).replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    var upd = function (id, k, v) { set({ sent: false, lines: self.g('lines', START).map(function (l) { if (l.id !== id) return l; var n = Object.assign({}, l); n[k] = v; return n; }) }); };

    var SECS = ['Prep', 'Tile', 'Finish'];
    var sub = 0;
    var sections = SECS.map(function (sn, si) {
      var ls = lines.filter(function (l) { return l.sec === sn; });
      var ss = 0;
      var out = ls.map(function (l, i) {
        var amt = r2(l.qty * l.rate); ss += amt;
        var f = FLAGS[l.id];
        return { name: l.name, unit: l.unit, amt: money(amt), qty: String(l.qty), rate: l.rate.toFixed(2), qid: 'q-' + l.id, rid: 'r-' + l.id,
          sep: i ? 'border-top: 1px solid var(--line)' : '', canEdit: !ro,
          onQty: function (e) { upd(l.id, 'qty', parse(e.target.value)); },
          onRate: function (e) { upd(l.id, 'rate', parse(e.target.value)); },
          upLabel: 'Move ' + l.name + ' up',
          up: function () { var all = self.g('lines', START).slice(); var idx = all.findIndex(function (x) { return x.id === l.id; }); var j = idx - 1; while (j >= 0 && all[j].sec !== l.sec) j--; if (j < 0) return; var t = all[j]; all[j] = all[idx]; all[idx] = t; set({ lines: all }); },
          flag: !!f, flagWord: f || '', flagCls: f === 'Low' ? 'st-warn si-alert' : 'st-info si-alert' };
      });
      sub += ss;
      return { name: sn, sub: money(r2(ss)), lines: out, sep: si ? 'border-top: 1px solid var(--line)' : '' };
    });
    sub = r2(sub);
    var tax = r2(sub * 0.13), total = r2(sub + tax);
    var tm = money(total);
    var delta = r2(total - ORIG);
    var nFlags = Object.keys(FLAGS).length;

    var book = [
      ['Grout sealer, 2 coats', '$1.40', 'per sq ft', 'drop', 'teal', 32, 'sq ft', 1.40],
      ['Under-cabinet LED strip', '$145.00', 'per run', 'bolt', 'amber', 1, 'run', 145],
      ['Schluter edge trim', '$9.50', 'per lin ft', 'ruler', 'slate', 8, 'lin ft', 9.50],
      ['Paint touch-up above tile', '$85.00', 'fixed', 'brush', 'rose', 1, 'lot', 85]
    ].map(function (b, i) { return { name: b[0], rate: b[1], unit: b[2], sub: 'Used on 6 jobs this year', ic: ic(b[3], b[4]),
      add: function () { set({ book: false, sent: false, lines: self.g('lines', START).concat([{ id: 'n' + Date.now() + i, sec: 'Finish', name: b[0], qty: b[5], unit: b[6], rate: b[7] }]) }); } }; });

    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var os = sw(optsOn), hs = sw(holdOn);

    var TIERS = [
      ['Good', 'Ceramic 3×6, straight lay', ic('tier1', 'slate'), total - 396.63, [['Standard white ceramic subway', 1], ['Straight lay, same prep and waterproofing', 1], ['No edge trim, caulked ends', 0]]],
      ['Better', 'Zellige-look 3×12, herringbone', ic('tier2', 'violet'), total, [['The tile Priya picked', 1], ['Herringbone to the underside of the uppers', 1], ['Metal edge trim at the ends', 1]]],
      ['Best', 'Better, plus lighting and sealer', ic('tier3', 'gold'), total + 369.93, [['Everything in Better', 1], ['Under-cabinet LED strip, 2 runs', 1], ['Grout sealed twice, 1-year touch-up visit', 1]]]
    ];
    var tiers = TIERS.map(function (t, i) {
      var isRec = i === rec;
      return { name: t[0], sub: t[1], ic: t[2], price: money(r2(t[3])), rec: isRec, cls: isRec ? 'on' : '',
        recLbl: isRec ? 'Recommended' : 'Recommend', recBtnCls: isRec ? 'btn-p' : 'btn-s', editLbl: i === 1 ? 'Lines above' : 'Edit',
        pickRec: function () { if (!ro) set({ rec: i }); },
        incl: t[4].map(function (x) { return { text: x[0], path: x[1] ? 'm5 12.5 4.5 4.5L19 7.5' : 'M6 6l12 12M18 6 6 18', col: x[1] ? '' : 'color: var(--faint)' }; }) };
    });

    // payment schedule: last payable row takes the cents so it always adds up
    var hold = holdOn ? 10 : 0;
    var rest = 100 - dep - mile - hold;
    var bad = rest < 0;
    var cents = Math.round(total * 100);
    var dC = Math.round(cents * dep / 100), mC = Math.round(cents * mile / 100), hC = holdOn ? Math.round(cents * hold / 100) : 0;
    var cC = cents - dC - mC - hC;
    var COL = ['var(--acc)', 'var(--info)', 'var(--ok-dot)', 'var(--warn-dot)'];
    var stepper = function (key, cur, min, max) {
      return { dec: function () { if (!ro) set({ [key]: Math.max(min, cur - 5), sent: false }); }, inc: function () { if (!ro) set({ [key]: Math.min(max, cur + 5), sent: false }); } };
    };
    var ds = stepper('dep', dep, 0, 60), ms = stepper('mile', mile, 0, 80);
    var terms = [
      { label: 'Deposit', when: 'On signing', pct: dep + '%', amt: money(dC / 100), step: !ro, auto: ro, dec: ds.dec, inc: ds.inc, decLbl: 'Lower deposit', incLbl: 'Raise deposit', sw: 'background: ' + COL[0] },
      { label: 'Tile set', when: 'Tile on the wall', pct: mile + '%', amt: money(mC / 100), step: !ro, auto: ro, dec: ms.dec, inc: ms.inc, decLbl: 'Lower milestone', incLbl: 'Raise milestone', sw: 'background: ' + COL[1] },
      { label: 'On completion', when: 'Whatever is left, to the cent', pct: (rest < 0 ? '−' + (-rest) : rest) + '%', amt: money(cC / 100), step: false, auto: true, sw: 'background: ' + COL[2], pctCol: bad ? 'color: var(--bad)' : '', amtCol: bad ? 'color: var(--bad)' : '' }
    ];
    if (holdOn) terms.push({ label: 'Holdback', when: '60 days after completion', pct: '10%', amt: money(hC / 100), step: false, auto: true, sw: 'background: ' + COL[3] });
    var segs = [dep, mile, Math.max(0, rest), hold].map(function (p, i) { return { style: 'width: ' + p + '%; background: ' + COL[i] + (p ? '' : '; display: none') }; });

    return {
      ro: ro, roAttr: ro, roCls: ro ? 'qe-ro' : '', canEdit: !ro,
      title: title, onTitle: function (e) { set({ title: e.target.value }); },
      lockIc: ic('lock', 'slate'), syncIc: ic('sync', 'violet'), pcIc: ic('percent', 'teal'), warnIc: ic('warn', 'clay'), cardIc: ic('card', 'azure'),
      docIc: ic('doc', 'violet'), layIc: ic('file', 'stone'), aiIc: ic('orb', 'violet'),
      pcSub: nFlags ? 'Against 14 past jobs' : 'Every line in range',
      pcWord: nFlags ? nFlags + ' to check' : 'In range', pcCls: nFlags ? 'st-warn si-alert' : 'st-ok si-check',
      sections: sections, itemCount: lines.length + ' items',
      bookOpen: bookOpen, toggleBook: function () { set({ book: !self.g('book', false) }); }, book: book,
      addBlank: function () { set({ sent: false, lines: self.g('lines', START).concat([{ id: 'n' + Date.now(), sec: 'Finish', name: 'New line', qty: 1, unit: 'each', rate: 0 }]) }); },
      subtotal: money(sub), tax: money(tax), totalWhole: tm.slice(0, -3), totalCents: tm.slice(-3),
      totalDelta: Math.abs(delta) < 0.005 ? 'Same as version 1' : (delta > 0 ? '+' : '') + money(delta) + ' vs version 1',
      excl: excl.map(function (x, i) { return { text: x, canEdit: !ro, aria: 'Remove: ' + x, del: function () { set({ excl: excl.filter(function (_, j) { return j !== i; }) }); } }; }),
      exCount: String(excl.length), exDraft: exDraft, onEx: function (e) { set({ exDraft: e.target.value }); },
      addEx: function () { var v = String(self.g('exDraft', '')).trim(); if (!v) return; set({ excl: excl.concat([v]), exDraft: '' }); },
      optsOn: optsOn, optsOff: !optsOn, optTrack: os.t, optKnob: os.k, toggleOpts: function () { if (!ro) set({ opts: !optsOn }); },
      tiers: tiers,
      segs: segs, terms: terms, payTotal: money((dC + mC + Math.max(0, cC) + hC) / 100),
      payWord: bad ? 'Over 100%' : 'Adds up', payCls: bad ? 'st-bad si-alert' : 'st-ok si-check', payErr: bad, overBy: (-rest) + '%',
      holdOn: holdOn, holdTrack: hs.t, holdKnob: hs.k, toggleHold: function () { if (!ro) set({ hold: !holdOn }); },
      send: function () { if (!bad) set({ sent: true }); },
      sendLabel: bad ? 'Fix the schedule' : sent ? 'Sent to Priya' : 'Send ' + tm,
      sendStyle: bad ? 'opacity: .4' : sent ? 'background: var(--ok-dot); color: #ffffff' : ''
    };
