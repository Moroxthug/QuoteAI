    var mode = this.props.state || 'default';
    var acct = mode === 'accountant', empty = mode === 'empty', canEdit = !acct && !empty;
    var filed = self.g('filed', {}), proof = self.g('proof', {}), rem = self.g('rem', { hst: true }), sel = self.g('sel', 'van'), flt = self.g('flt', 'all');
    var emptyVals = self.g('ev', {});
    // id, title, needed, date, day offset, kind (overdue|due|later|filed), amount, glyph, tone, done label
    var D = [
      ['van', 'Van plate renewal', 'Ford Transit · renew on ServiceOntario, then add the receipt', 'Sep 26', -3, 'overdue', '', 'truck', 'clay', 'Mark renewed'],
      ['pay9', 'Payroll remittance, September', 'Source deductions for 5 people, from Pay', 'Oct 15', 16, 'due', '$4,386.20', 'bank', 'sage', 'Mark paid'],
      ['wsib', 'WSIB clearance certificate', 'Expires Oct 20. Harbourfront Dental asked for a copy.', 'Oct 20', 21, 'due', '', 'shield', 'teal', 'Mark renewed'],
      ['hst', 'HST return, Q3', 'Jul 1 – Sep 30 · worksheet is ready', 'Oct 31', 32, 'due', '$6,212.00', 'percent', 'violet', 'Mark filed'],
      ['ins', 'Liability insurance', '$2M general liability · add the new certificate', 'Nov 14', 46, 'due', '', 'shield', 'azure', 'Mark renewed'],
      ['pay10', 'Payroll remittance, October', 'Source deductions, from Pay', 'Nov 16', 48, 'due', '', 'bank', 'sage', 'Mark paid'],
      ['pay11', 'Payroll remittance, November', 'Source deductions, from Pay', 'Dec 15', 77, 'due', '', 'bank', 'sage', 'Mark paid'],
      ['t4a', 'T4A slips for subs', 'Jonah Reyes and 2 others paid $500 or more in 2026', 'Feb 28', 152, 'later', '', 'users', 'indigo', 'Mark filed'],
      ['lic', 'Contractor licence', 'City of Toronto renovator licence · renew online', 'Mar 31', 183, 'later', '', 'doc', 'amber', 'Mark renewed'],
      ['hstq2', 'HST return, Q2', 'Filed Jul 28 · confirmation 4471 0092', 'Jul 31', -60, 'filed', '$5,140.75', 'percent', 'violet', ''],
      ['pay8', 'Payroll remittance, August', 'Paid Sep 14 from RBC business chequing', 'Sep 15', -14, 'filed', '$4,212.60', 'bank', 'sage', '']
    ];
    var kindOf = function (d) { return filed[d[0]] ? 'filedNow' : d[5]; };
    var ST = { overdue: 'st-bad si-alert', due: 'st-warn si-clock', later: 'st-mute si-clock', filed: 'st-ok si-check', filedNow: 'st-ok si-check' };
    var word = function (d, k) {
      if (k === 'overdue') return (0 - d[4]) + ' days late';
      if (k === 'filed') return 'Filed';
      if (k === 'filedNow') return d[9] === 'Mark paid' ? 'Paid today' : (d[9] === 'Mark renewed' ? 'Renewed today' : 'Filed today');
      if (k === 'later') return 'Due ' + d[3];
      return (d[0] === 'wsib' ? 'Expires ' : (d[0] === 'ins' ? 'Renews ' : 'Due ')) + d[3];
    };
    var flip = function (key, id) { var o = Object.assign({}, self.g(key, key === 'rem' ? { hst: true } : {})); o[id] = !o[id]; var p = {}; p[key] = o; set(p); };
    var item = function (d) {
      var k = kindOf(d), isF = k === 'filed' || k === 'filedNow';
      return {
        id: d[0], title: d[1], sub: k === 'filedNow' ? 'Today · ' + (proof[d[0]] ? 'proof added' : 'add proof for your records') : d[2], amt: d[6], amtStyle: d[6] ? '' : 'display: none',
        ic: ic(d[7], d[8]), st: ST[k], word: word(d, k), selCls: sel === d[0] ? 'sel' : '',
        open: sel === d[0], pick: function () { set({ sel: d[0] }); },
        acts: canEdit && !isF && sel === d[0], undo: canEdit && k === 'filedNow' && sel === d[0], dl: acct && sel === d[0] && (isF || d[0] === 'hst' || d[0] === 'pay9'),
        dlLabel: isF ? 'Download proof' : 'Download worksheet',
        doneLabel: d[9], file: function () { flip('filed', d[0]); },
        upLabel: proof[d[0]] ? 'Proof added' : 'Upload proof', upStyle: proof[d[0]] ? 'color: var(--ok)' : '', upload: function () { flip('proof', d[0]); },
        remLabel: rem[d[0]] ? 'Reminding you' : 'Remind me', remStyle: rem[d[0]] ? 'color: var(--acc-t)' : '', remind: function () { flip('rem', d[0]); }
      };
    };
    var all = D.map(function (d) { return { d: d, k: kindOf(d) }; });
    var pick = function (ks) { return all.filter(function (x) { return ks.indexOf(x.k) > -1; }).map(function (x) { return item(x.d); }); };
    var late = pick(['overdue']), soon = pick(['due']), later = pick(['later']), done = pick(['filedNow', 'filed']);
    var G = [];
    if (flt === 'all' || flt === 'overdue') G.push({ title: 'Late', sub: late.length ? '1 needs you' : '', items: late });
    if (flt === 'all' || flt === 'due') G.push({ title: 'Next 90 days', sub: soon.length + ' deadlines', items: soon });
    if (flt === 'all' || flt === 'due') G.push({ title: 'Later', sub: '', items: later });
    if (flt === 'all' || flt === 'filed') G.push({ title: 'Filed', sub: 'Most recent', items: done });
    G = G.filter(function (g) { return g.items.length; });
    var marks = D.filter(function (d) { return d[4] <= 90 && (d[5] === 'overdue' || d[5] === 'due'); }).map(function (d, i) {
      var k = kindOf(d), pct = Math.max(3.5, Math.min(96, d[4] / 90 * 100));
      var col = k === 'overdue' ? 'var(--bad)' : (k === 'filedNow' ? 'var(--ok-dot)' : 'var(--warn-dot)');
      return { left: pct.toFixed(1) + '%', date: d[3], lane: i % 2 ? 'cp-dn' : 'cp-up', dot: 'background: ' + col, cls: sel === d[0] ? 'on' : '', aria: d[1] + ', ' + d[3], pick: function () { set({ sel: d[0] }); } };
    });
    var sd = D.filter(function (d) { return d[0] === sel; })[0] || D[2];
    var sk = kindOf(sd);
    var hstK = kindOf(D[3]);
    var nOver = late.length, nSoon = all.filter(function (x) { return x.k === 'due' && x.d[4] <= 30; }).length;
    var EV = [['GST/HST filing', ['Quarterly', 'Monthly', 'Yearly'], 'percent', 'violet'], ['Fiscal year end', ['Dec 31', 'Mar 31', 'Jun 30'], 'cal', 'sky'], ['Payroll remittances', ['Monthly', 'Quarterly', 'No payroll'], 'bank', 'sage'], ['Income tax instalments', ['Quarterly', 'None'], 'receipt', 'amber'], ['WSIB clearance', ['Track it', 'Not needed'], 'shield', 'teal'], ['Subcontractor slips', ['T4A and T5018', 'T5018 only', 'Off'], 'users', 'indigo']];
    return {
      isAcct: acct, isEmpty: empty, hasData: !empty, canEdit: canEdit,
      eyeIc: ic('eye', 'sky'), hstIc: ic('percent', 'violet'), okIc: ic('check', 'sage'), calIc: ic('cal', 'sky'),
      kpis: [
        { label: 'Late', value: String(nOver), sub: nOver ? 'Van plate' : 'All clear', style: nOver ? 'color: var(--bad)' : '' },
        { label: 'Next 30 days', value: String(nSoon), sub: 'Payroll, WSIB', style: '' },
        { label: 'Filed in 2026', value: String(11 + Object.keys(filed).filter(function (k) { return filed[k]; }).length), sub: 'On time', style: '' }
      ],
      hst: { st: ST[hstK], word: word(D[3], hstK), btn: filed.hst ? 'Undo filed' : 'Mark filed', toggle: function () { flip('filed', 'hst'); }, ws: acct ? 'Download worksheet' : 'Open worksheet' },
      marks: marks,
      selItem: { title: sd[1], when: sd[3] + (sd[4] >= 0 ? ' · in ' + sd[4] + ' days' : ' · ' + (0 - sd[4]) + ' days ago'), st: ST[sk], word: word(sd, sk) },
      filters: [['all', 'All', D.length], ['due', 'Coming up', soon.length + later.length], ['overdue', 'Late', late.length], ['filed', 'Filed', done.length]].map(function (f) { var on = f[0] === flt; return { label: f[1], count: f[2], on: on, cls: on ? 'on' : '', pick: function () { set({ flt: f[0] }); } }; }),
      groups: G, noMatch: G.length === 0,
      setupRows: [['GST/HST filing', 'Quarterly', 'percent', 'violet'], ['Fiscal year end', 'Dec 31', 'cal', 'sky'], ['Payroll remittances', 'Monthly', 'bank', 'sage'], ['Reminders', '14 and 3 days before', 'bell', 'amber']].map(function (r) { return { label: r[0], value: r[1], ic: ic(r[2], r[3]) }; }),
      emptyRows: EV.map(function (r, i) { var v = emptyVals[i] || 0; return { label: r[0], value: r[1][v], ic: ic(r[2], r[3]), cycle: function () { var o = Object.assign({}, self.g('ev', {})); o[i] = ((o[i] || 0) + 1) % r[1].length; set({ ev: o }); } }; })
    };
