    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { overdue: 'st-bad', viewed: 'st-acc', sent: 'st-info', partial: 'st-warn si-q3', draft: 'st-mute', scheduled: 'st-info', paid: 'st-ok' };
    var tints = { 'Tom & Lena Hart': 'tn1', 'Harbourfront Dental': 'tn4', 'Marchetti Bakery': 'tn3', 'Priya Nair': 'tn2', 'Dana Whitfield': 'tn5', 'Okoye Condo': 'tn3', 'Gill Residence': 'tn1', 'Chen Family': 'tn4' };
    // no, type, client, amount, balance, kind, statusWord, dates, group
    var data = [
      ['INV-0412', 'Progress 2 of 4', 'Tom & Lena Hart', 2340.00, 2340.00, 'overdue', '9 days late', 'Issued Sep 5 · Due Sep 20', 'overdue'],
      ['INV-0419', 'Final', 'Harbourfront Dental', 780.00, 780.00, 'overdue', '3 days late', 'Issued Aug 27 · Due Sep 26', 'overdue'],
      ['INV-0391', 'Change order', 'Marchetti Bakery', 640.00, 640.00, 'overdue', '47 days late', 'Issued Jul 29 · Due Aug 13', 'overdue'],
      ['INV-0420', 'Change order', 'Tom & Lena Hart', 4469.15, 2234.58, 'partial', 'Partly paid', 'Issued Sep 19 · Due Oct 3', 'open'],
      ['INV-0421', 'Deposit', 'Priya Nair', 559.53, 559.53, 'viewed', 'Viewed', 'Issued Sep 25 · Due Oct 9', 'open'],
      ['INV-0423', 'Progress 3 of 4', 'Tom & Lena Hart', 4339.20, 0, 'draft', 'Draft', 'Created today · Due in 15 days', 'draft'],
      ['INV-0422', 'Deposit', 'Dana Whitfield', 1239.32, 0, 'draft', 'Draft', 'Created Sep 28 · Due on receipt', 'draft'],
      ['INV-0424', 'Holdback release', 'Tom & Lena Hart', 3840.00, 0, 'scheduled', 'Sends Nov 14', 'Held 10% · Due Nov 28', 'draft'],
      ['INV-0418', 'Final', 'Okoye Condo', 2497.30, 0, 'paid', 'Paid', 'Issued Sep 8 · Paid Sep 22', 'paid'],
      ['INV-0417', 'Deposit', 'Gill Residence', 1010.22, 0, 'paid', 'Paid', 'Issued Sep 14 · Paid Sep 16', 'paid'],
      ['INV-0415', 'Final', 'Chen Family', 3729.00, 0, 'paid', 'Paid', 'Issued Aug 25 · Paid Sep 8', 'paid'],
      ['INV-0414', 'Progress 1 of 2', 'Harbourfront Dental', 1695.00, 0, 'paid', 'Paid', 'Issued Aug 20 · Paid Sep 3', 'paid'],
      ['INV-0410', 'Final', 'Priya Nair', 675.91, 0, 'paid', 'Paid', 'Issued Aug 18 · Paid Sep 2', 'paid']
    ];
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var whole = function (n) { return '$' + Math.round(n).toLocaleString('en-CA'); };
    var FIL = [
      ['all', 'All', function () { return true; }],
      ['overdue', 'Overdue', function (d) { return d[5] === 'overdue'; }],
      ['unpaid', 'Unpaid', function (d) { return d[4] > 0; }],
      ['draft', 'Drafts', function (d) { return d[5] === 'draft'; }],
      ['scheduled', 'Scheduled', function (d) { return d[5] === 'scheduled'; }],
      ['paid', 'Paid', function (d) { return d[5] === 'paid'; }]
    ];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d) && (!ql || (d[0] + ' ' + d[1] + ' ' + d[2]).toLowerCase().indexOf(ql) >= 0); });
    var acted = this.g('acted', {});
    var mkActs = function (no, list) { return list.map(function (a) { return { label: a[0], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); if (!a[4]) return; var n = Object.assign({}, self.g('acted', {})); n[no] = [a[4], a[5]]; set({ acted: n }); } }; }); };
    var IA = {
      overdue: [['Remind', 'bell', 'azure', 'info', 'Reminder sent', 'st-info si-q1'], ['Got paid', 'bank', 'sage', 'ok', 'Paid', 'st-ok si-check']],
      draft: [['Send', 'send', 'azure', 'info', 'Sent', 'st-info si-q1'], ['Delete', 'warn', 'rose', 'bad', 'Deleted', 'st-mute si-off']],
      scheduled: [['Send now', 'send', 'azure', 'info', 'Sent', 'st-info si-q1'], ['Edit', 'pen', 'slate', 'mute']],
      paid: [['Send receipt', 'receipt', 'amber', 'mute', 'Receipt sent', 'st-ok si-check'], ['Archive', 'box', 'stone', 'mute', 'Archived', 'st-mute si-off']]
    };
    IA.viewed = IA.overdue; IA.sent = IA.overdue; IA.partial = IA.overdue;
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Remind': 'Reminded', 'Record payment': 'Payment recorded', 'Send': 'Sent', 'Send now': 'Sent', 'Send receipt': 'Receipt sent', 'Resend receipt': 'Receipt sent', 'Receipt': 'Sent', 'Call': 'Calling', 'Reply': 'Replied', 'Final notice': 'Notice sent', 'Remind all 3': 'Reminded 3', 'Edit date': 'Edited' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); var sw = el && el.closest('.swr'); if (sw) sw.scrollLeft = 0; var go = function () { var c = el.closest('.xc'); if (c && c.classList.contains('open')) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }; if (cur !== id && el) { setTimeout(go, 120); setTimeout(go, 520); } }; };
    var paid = function (sent, how, when, amt, rc) { return { main: rc ? 'Resend receipt' : 'Send receipt', rows: [['Sent ' + sent, 'By email', 'Delivered', 'st-ok si-check'], ['Paid in full', how + ' · ' + when, 'Paid', 'st-ok si-check', '', amt], rc ? ['Receipt', 'Sent automatically ' + when, 'Sent', 'st-ok si-check'] : ['Receipt', 'Not sent yet', 'To send', 'st-mute si-draft']] }; };
    // per invoice: rows [title, context, status, statusCls, btn, amount], stats, primary action
    var DET = {
      'INV-0412': { main: 'Remind', rows: [['Sent Sep 5', 'Email to Tom and Lena', 'Delivered', 'st-ok si-check'], ['Viewed 3 times', 'Last on Sep 22'], ['2 reminders', 'Sep 21 and Sep 25 · no reply', 'No reply', 'st-warn si-clock', 'Call'], ['Payments', 'None yet', '', '', '', '$0.00']], stats: [['Balance', '$2,340'], ['Late', '9 days'], ['Job', '64% done']] },
      'INV-0419': { main: 'Remind', rows: [['Sent Aug 27', 'To accounts payable', 'Delivered', 'st-ok si-check'], ['1 reminder', 'Sep 27, sent automatically', 'Sent', 'st-info si-q1'], ['Asked for a PO number', 'Accounts payable · Sep 28', 'Needs reply', 'st-warn si-clock', 'Reply'], ['Payments', 'None yet', '', '', '', '$0.00']], stats: [['Balance', '$780'], ['Late', '3 days'], ['Pays in', '14 days']] },
      'INV-0391': { main: 'Remind', rows: [['Sent Jul 29', 'By email', 'Delivered', 'st-ok si-check'], ['3 reminders', 'Aug 14, Aug 28, Sep 15 · no reply', 'No reply', 'st-bad si-alert', 'Final notice'], ['Job on hold', 'Back room shelving · landlord sign-off', 'On hold', 'st-warn si-pause', 'Call'], ['Payments', 'None yet', '', '', '', '$0.00']], stats: [['Balance', '$640'], ['Late', '47 days'], ['Reminders', '3']] },
      'INV-0420': { main: 'Record payment', rows: [['Sent Sep 19', 'For the egress window change order', 'Delivered', 'st-ok si-check'], ['Payment 1', 'e-Transfer · Sep 24', 'Received', 'st-ok si-check', 'Receipt', '$2,234.57'], ['Balance', 'Due Fri Oct 3', 'Partly paid', 'st-warn si-q3', '', '$2,234.58']], stats: [['Paid', '50%'], ['Due in', '4 days'], ['Reminders', '0']] },
      'INV-0421': { main: 'Record payment', rows: [['Sent Sep 25', 'By email and text', 'Delivered', 'st-ok si-check'], ['Viewed', 'Today, 7:50 am', 'Viewed', 'st-acc si-q2'], ['Deposit, 30%', 'Of Q-2026-118, kitchen backsplash'], ['Payments', 'None yet · due Oct 9', '', '', '', '$0.00']] },
      'INV-0423': { main: 'Send', rows: [['Created today', 'Drywall milestone reached on Basement finish', 'Draft', 'st-mute si-draft'], ['Progress 3 of 4', 'Term 2 is still unpaid (INV-0412)', '1 late', 'st-bad si-alert'], ['Due', '15 days after you send it']] },
      'INV-0422': { main: 'Send', rows: [['Created Sep 28', 'Deposit, 30% of Q-2026-119', 'Draft', 'st-mute si-draft'], ['Waiting on the quote', 'Q-2026-119 is not sent yet', 'Not sent', 'st-mute si-draft'], ['Due on receipt', 'Card or e-Transfer']] },
      'INV-0424': { main: 'Send now', rows: [['Holdback, 10%', 'Of Basement finish, $38,400', '', '', '', '$3,840.00'], ['Sends Nov 14', '45 days after substantial completion', 'Scheduled', 'st-info si-clock', 'Edit date'], ['Due Nov 28', '14 days after sending']] },
      'INV-0418': paid('Sep 8', 'e-Transfer', 'Sep 22', '$2,497.30', false),
      'INV-0417': paid('Sep 14', 'Credit card', 'Sep 16', '$1,010.22', true),
      'INV-0415': paid('Aug 25', 'Cheque', 'Sep 8', '$3,729.00', false),
      'INV-0414': paid('Aug 20', 'Bank transfer', 'Sep 3', '$1,695.00', true),
      'INV-0410': paid('Aug 18', 'e-Transfer', 'Sep 2', '$675.91', true)
    };
    var mk = function (d) {
      var ini = d[2].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var ac = acted[d[0]]; return { no: d[0], type: d[1], client: d[2], amt: money(d[3]), status: ac ? ac[0] : d[6], st: ac ? ac[1] : S[d[5]], dates: d[7], ini: ini, tn: tints[d[2]] || 'tn5', acts: mkActs(d[0], IA[d[5]]),
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { var k2 = d[0] + 'm', dn = !!xd[k2]; return { rows: rowsOf(d[0], x.rows), stats: (x.stats || []).map(function (q2) { return { l: q2[0], v: q2[1] }; }), hasStats: !!(x.stats && x.stats.length), main: dn ? (DONE[x.main] || 'Done') : x.main, mainCls: dn ? 'done' : '', mainAct: flip(k2) }; })(DET[d[0]]) };
    };
    var groups = [['overdue', 'Overdue', 4], ['open', 'Waiting on payment', 4], ['draft', 'Drafts and scheduled', 3], ['paid', 'Paid this month', 3]].map(function (g) {
      var rs = rows.filter(function (d) { return d[8] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + (g[2] === 4 ? d[4] : d[3]); }, 0);
      return { title: g[1], total: rs.length ? money(tot) : '', rows: rs.map(mk), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '', first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;

    var out = data.reduce(function (a, d) { return a + d[4]; }, 0);
    var overdue = data.filter(function (d) { return d[5] === 'overdue'; }).reduce(function (a, d) { return a + d[4]; }, 0);
    var AG = [
      ['Not yet due', 2794.11, 'background: var(--ok-dot)'],
      ['1–30 days', 3120.00, 'background: var(--warn-dot)'],
      ['31–60 days', 640.00, 'background: var(--bad)'],
      ['61–90 days', 0, 'background: var(--bad); filter: brightness(.78)'],
      ['90+ days', 0, 'background: var(--bad); filter: brightness(.58)']
    ];
    var ow = money(out).split('.');
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      outWhole: ow[0], outCents: '.' + ow[1], overdueAmt: whole(overdue),
      agingLabel: 'Aging: ' + AG.map(function (a) { return a[0] + ' ' + whole(a[1]); }).join(', '),
      aging: AG.filter(function (a) { return a[1] > 0; }).map(function (a) { return { seg: 'flex: ' + a[1].toFixed(0) + ' 1 0; min-width: 10px; ' + a[2] }; }),
      agingAll: AG.map(function (a) { return { label: a[0], amt: whole(a[1]), dot: a[2], fade: a[1] > 0 ? '' : 'opacity: .5' }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), cap: 'Who owes you, oldest first',
        main: xd.kpim ? 'Reminded 3' : 'Remind all 3 late', mainCls: xd.kpim ? 'done' : '', mainAct: flip('kpim'),
        rows: rowsOf('kpi', [
          ['Marchetti Bakery', 'INV-0391 · 31–60 days', '47 days late', 'st-bad si-alert', 'Remind', '$640.00'],
          ['Tom & Lena Hart', 'INV-0412 · 1–30 days', '9 days late', 'st-bad si-alert', 'Remind', '$2,340.00'],
          ['Harbourfront Dental', 'INV-0419 · 1–30 days', '3 days late', 'st-bad si-alert', 'Remind', '$780.00'],
          ['Tom & Lena Hart', 'INV-0420 · half paid, due Oct 3', 'Not yet due', 'st-ok si-check', '', '$2,234.58'],
          ['Priya Nair', 'INV-0421 · viewed, due Oct 9', 'Not yet due', 'st-ok si-check', '', '$559.53']]),
        stats: [{ l: 'Avg. days', v: '14' }, { l: 'On time', v: '78%' }, { l: 'Late', v: '3' }] },
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(x[2]).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
