    var lang = this.props.lang || 'en', fr = lang === 'fr';
    var wa = (this.props.channel || 'sms') === 'whatsapp';
    var money = function (n) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return fr ? s + ' $' : '$' + s;
    };
    var EN = {
      back: 'Back to messages', call: 'Call Rossi Renovations', verified: 'Verified business', send: 'Send',
      sms: 'Text message · (416) 555-0142', waLine: 'WhatsApp · business account',
      prevTitle: 'Fence and deck staining', arrives: 'Arrives about', mins: '14 min away', onWay: 'On the way',
      unsubbed: 'Unsubscribed from texts', manage: 'Manage what you get', composerSms: 'Text message', composerWa: 'Message',
      d1: 'Tue, Sep 8', d2: 'Sun, Sep 13', d3: 'Mon, Sep 14', d4: 'Tue, Sep 22', d5: 'Thu, Sep 24',
      quote: 'Hi Harpreet, it’s Marco from Rossi Renovations. Your quote for the fence and deck staining is ready:',
      bilingual: 'Répondez FR pour nos textos en français.', stop: 'Reply STOP to opt out.', stopWa: 'Reply STOP to opt out.',
      accept: 'Looks great. We’ll accept it tonight.',
      remind: 'Reminder: we start tomorrow, Mon Sep 14, between 7:30 and 8 AM. Please move the patio furniture off the deck.', replyC: 'Reply C to confirm.',
      c: 'C', confirmed: 'Thanks, you’re confirmed. See you tomorrow.',
      onway: 'Morning Harpreet. Luca is on the way, about 14 min out.',
      paid: 'Payment received: {amt} for invoice INV-0409. Thank you. Your receipt:', paidWa: 'Payment received: {amt} for invoice INV-0409. Thank you.',
      review: 'Thanks again for choosing us, Harpreet. If you have a minute, a Google review would mean a lot:',
      stopMsg: 'STOP', stopped: 'You won’t get more texts from Rossi Renovations. Invoices and receipts still come by email. Reply START to resubscribe.',
      qView: 'View quote', qConfirm: 'Confirm', qCall: 'Call Marco', qReceipt: 'View receipt', qReview: 'Leave a review'
    };
    var FR = {
      back: 'Retour aux messages', call: 'Appeler Rossi Renovations', verified: 'Entreprise vérifiée', send: 'Envoyer',
      sms: 'Texto · (416) 555-0142', waLine: 'WhatsApp · compte entreprise',
      prevTitle: 'Teinture de clôture et terrasse', arrives: 'Arrivée vers', mins: 'à 14 min', onWay: 'En route',
      unsubbed: 'Désabonné des textos', manage: 'Gérer ce que vous recevez', composerSms: 'Texto', composerWa: 'Message',
      d1: 'mar. 8 sept.', d2: 'dim. 13 sept.', d3: 'lun. 14 sept.', d4: 'mar. 22 sept.', d5: 'jeu. 24 sept.',
      quote: 'Bonjour Harpreet, ici Marco de Rossi Renovations. Votre soumission pour la teinture de la clôture et de la terrasse est prête :',
      bilingual: 'Reply EN for texts in English.', stop: 'Répondez STOP pour vous désabonner.', stopWa: 'Répondez STOP pour vous désabonner.',
      accept: 'Parfait. On l’accepte ce soir.',
      remind: 'Rappel : nous commençons demain, lundi 14 sept., entre 7 h 30 et 8 h. Merci de retirer les meubles de la terrasse.', replyC: 'Répondez C pour confirmer.',
      c: 'C', confirmed: 'Merci, c’est confirmé. À demain.',
      onway: 'Bonjour Harpreet. Luca est en route, à environ 14 min.',
      paid: 'Paiement reçu : {amt} pour la facture INV-0409. Merci. Votre reçu :', paidWa: 'Paiement reçu : {amt} pour la facture INV-0409. Merci.',
      review: 'Merci encore de nous avoir choisis, Harpreet. Si vous avez une minute, un avis Google nous aiderait beaucoup :',
      stopMsg: 'STOP', stopped: 'Vous ne recevrez plus de textos de Rossi Renovations. Les factures et reçus arrivent toujours par courriel. Répondez START pour vous réabonner.',
      qView: 'Voir la soumission', qConfirm: 'Confirmer', qCall: 'Appeler Marco', qReceipt: 'Voir le reçu', qReview: 'Laisser un avis'
    };
    var t = fr ? FR : EN;
    var tf = function (hm) { var p = hm.split(':'), h = +p[0]; if (fr) return h + ' h ' + p[1]; return ((h + 11) % 12 + 1) + ':' + p[1] + (h < 12 ? ' AM' : ' PM'); };
    var list = [];
    var day = function (d, tm) { list.push({ isDay: true, isMsg: false, day: d, dayTime: tf(tm) }); };
    var prevIn = null;
    var msg = function (o) {
      var inb = !o.out;
      var m = {
        isDay: false, isMsg: true, side: inb ? 'in' : 'out',
        cls: 'tm-' + (inb ? 'in' : 'out') + '-' + (wa ? 'wa' : 'sms'),
        text: o.text, hasLink: !!o.link, link: o.link || '',
        hasPrev: !!o.prev, hasEta: !!o.eta, etaIc: ic('truck', 'teal'), hasTail: !!o.tail, tail: o.tail || '',
        hasQr: wa && !!o.qr, qr: (o.qr || []).map(function (q) { return { label: q[0], href: q[1] }; }),
        hasTime: !!o.time, time: o.time ? tf(o.time) : '',
        gap: list.length && !list[list.length - 1].isDay && list[list.length - 1].side === (inb ? 'in' : 'out') ? '4px' : '10px'
      };
      list.push(m);
    };
    day(t.d1, '10:02');
    msg({ text: t.quote, link: wa ? '' : 'rossireno.quoteai.ca/p/7Kq2', prev: true, tail: t.bilingual + ' ' + (wa ? t.stopWa : t.stop), qr: [[t.qView, 'ClientQuote.dc.html']], time: '10:02' });
    msg({ out: true, text: t.accept, time: '10:40' });
    day(t.d2, '18:00');
    msg({ text: t.remind + (wa ? '' : ' ' + t.replyC), qr: [[t.qConfirm, '#'], [t.qCall, 'tel:+14165550142']], time: '18:00' });
    msg({ out: true, text: wa ? t.qConfirm : t.c, time: '18:04' });
    msg({ text: t.confirmed, time: '18:04' });
    day(t.d3, '7:31');
    msg({ text: t.onway, eta: true, time: '7:31' });
    day(t.d4, '16:10');
    msg({ text: (wa ? t.paidWa : t.paid).replace('{amt}', money(1740.20)), link: wa ? '' : 'rossireno.quoteai.ca/r/9Fz1', qr: [[t.qReceipt, '#']], time: '16:10' });
    day(t.d5, '11:00');
    msg({ text: t.review, link: wa ? '' : 'g.page/r/rossireno', tail: wa ? t.stopWa : t.stop, qr: [[t.qReview, '#']], time: '11:00' });
    msg({ out: true, text: t.stopMsg, time: '11:06' });
    msg({ text: t.stopped, time: '11:06' });
    return {
      t: t, isWa: wa, thread: list,
      chanLine: wa ? t.waLine : t.sms,
      composer: wa ? t.composerWa : t.composerSms,
      prevTotal: money(2486)
    };
