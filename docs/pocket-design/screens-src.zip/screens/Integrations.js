    var mode = this.props.state || 'default';
    var firstTime = mode === 'firstTime', readOnly = mode === 'readOnly';
    var cat = this.g('cat', 'all'), q = this.g('q', ''), added = this.g('added', {}), busy = this.g('busy', ''), toast = this.g('toast', '');
    var CATS = [['all', 'All'], ['acct', 'Accounting'], ['pay', 'Payments'], ['msg', 'Messaging'], ['cal', 'Calendar'], ['store', 'Storage'], ['supp', 'Suppliers'], ['lead', 'Lead sources']];
    // id, name, cat, glyph, tone, desc, state, connected line
    var APPS = [
      ['qbo', 'QuickBooks Online', 'acct', 'bars', 'sage', 'Invoices, payments and costs go to your books with tax codes', 'attention', '2 invoices didn’t sync · 8:12 am', 'Integration.dc.html'],
      ['xero', 'Xero', 'acct', 'orb', 'sky', 'Send invoices and payments to Xero', 'none', '', ''],
      ['wave', 'Wave', 'acct', 'wave', 'teal', 'Paid invoices and costs go to Wave', 'none', '', ''],
      ['stripe', 'Stripe', 'pay', 'card', 'violet', 'Clients pay invoices and deposits by card', 'connected', 'Payouts daily to TD ••4410', ''],
      ['gcal', 'Google Calendar', 'cal', 'cal', 'azure', 'Jobs and site visits on the calendar you choose', 'connected', 'Jobs and visits to “Rossi jobs”', ''],
      ['outlook', 'Outlook', 'cal', 'cal', 'indigo', 'Jobs and visits in your Outlook calendar', 'soon', '', ''],
      ['wa', 'WhatsApp Business', 'msg', 'chat', 'sage', 'Send quotes and reminders where clients already reply', 'connected', '3 of 5 message templates approved', ''],
      ['drive', 'Google Drive', 'store', 'cloud', 'amber', 'Back up job photos and signed PDFs', 'paused', 'Paused Sep 21 · photos not backing up', ''],
      ['jobber', 'Jobber import', 'store', 'export', 'slate', 'Bring clients, jobs and quotes over from Jobber', 'none', '', 'Imports.dc.html'],
      ['hd', 'Home Depot Pro', 'supp', 'hammer', 'clay', 'Your Pro prices in the price book, receipts into costs', 'none', '', ''],
      ['hs', 'HomeStars', 'lead', 'star', 'gold', 'Your review link on quotes and invoices', 'none', '', ''],
      ['gbp', 'Google Business Profile', 'lead', 'pin', 'rose', 'Leads and messages from your Google listing', 'locked', '', '']
    ];
    var ST = { connected: ['Connected', 'st-ok'], attention: ['Needs attention', 'st-bad'], paused: ['Paused', 'st-warn si-pause'], none: ['Not connected', 'st-mute si-off'] };
    var stateOf = function (a) {
      if (added[a[0]]) return 'connected';
      if (firstTime && a[6] !== 'soon' && a[6] !== 'locked') return 'none';
      return a[6];
    };
    var ql = q.trim().toLowerCase();
    var match = function (a) { return (cat === 'all' || a[2] === cat) && (!ql || (a[1] + ' ' + a[5]).toLowerCase().indexOf(ql) >= 0); };
    var isOn = function (s) { return s === 'connected' || s === 'attention' || s === 'paused'; };

    var SUG = { qbo: 'Invoices and payments to your books', stripe: 'Card payments on invoices', gcal: 'Jobs and visits on your calendar' };
    var sugOn = firstTime && !ql && !APPS.some(function (a) { return isOn(stateOf(a)); });
    var LINES = { xero: 'First sync tonight', wave: 'First sync tonight', jobber: 'Import ready to review', hd: 'Pro prices update weekly', hs: 'Review link on quotes' };
    var top = APPS.filter(function (a) { return isOn(stateOf(a)) && match(a); }).map(function (a) {
      var s = stateOf(a);
      return { name: a[1], line: added[a[0]] ? (LINES[a[0]] || 'Connected just now') : a[7], status: ST[s][0], st: ST[s][1], ic: ic(a[3], a[4]), href: a[8] || 'Integration.dc.html' };
    });
    // first-time: suggestions on top
    if (sugOn) {
      top = APPS.filter(function (a) { return ['qbo', 'stripe', 'gcal'].indexOf(a[0]) >= 0 && (cat === 'all' || a[2] === cat); }).map(function (a) {
        var s = stateOf(a);
        return { name: a[1], line: SUG[a[0]], status: ST[s][0], st: ST[s][1], ic: ic(a[3], a[4]), href: 'Integration.dc.html' };
      });
    }
    var catName = {}; CATS.forEach(function (c) { catName[c[0]] = c[1]; });
    var rank = function (a) { var s = stateOf(a); return s === 'soon' ? 1 : s === 'locked' ? 2 : 0; };
    var dir = APPS.filter(function (a) { return !isOn(stateOf(a)) && match(a) && !(sugOn && SUG[a[0]]); });
    dir = dir.map(function (a, i) { return [a, i]; }).sort(function (x, y) { return rank(x[0]) - rank(y[0]) || x[1] - y[1]; }).map(function (x) { return x[0]; });
    var tiles = dir.map(function (a) {
      var s = stateOf(a), b = busy === a[0];
      return {
        name: a[1], desc: a[5], cat: cat === 'all' ? catName[a[2]] : '', ic: ic(a[3], a[4]), plan: 'Included in Elite',
        canConnect: s === 'none' && !b && !readOnly, busy: b, soon: s === 'soon', locked: s === 'locked', ro: s === 'none' && readOnly,
        locked0: s === 'locked',
        connect: function () {
          if (a[8]) { window.location.href = a[8]; return; }
          set({ busy: a[0] });
          setTimeout(function () { var n = Object.assign({}, self.g('added', {})); n[a[0]] = true; set({ busy: '', added: n, toast: a[0] }); }, 1400);
        }
      };
    });
    var suggested = this.g('suggested', false);
    var nOn = APPS.filter(function (a) { return isOn(stateOf(a)); }).length;
    var nAtt = APPS.filter(function (a) { return stateOf(a) === 'attention'; }).length;
    var summary = firstTime && !nOn ? 'Nothing connected yet' : nOn + ' connected' + (nAtt ? ' · ' + nAtt + ' needs attention' : '');
    var tApp = APPS.filter(function (a) { return a[0] === toast; })[0];
    return {
      summary: summary, readOnly: readOnly, firstTime: firstTime && nOn === 0,
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', cat: 'all' }); },
      chips: CATS.map(function (c) { var on = c[0] === cat; return { label: c[1], count: c[0] === 'all' ? APPS.length : APPS.filter(function (a) { return a[2] === c[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ cat: c[0] }); } }; }),
      top: top, hasTop: top.length > 0, topTitle: firstTime && nOn === 0 ? 'Good places to start' : 'Connected', topCount: top.length + '',
      tiles: tiles, hasTiles: tiles.length > 0 || !ql, dirTitle: cat === 'all' ? 'More apps' : catName[cat], dirCount: tiles.length + '',
      showSuggest: !ql && !readOnly, sugTitle: suggested ? 'Thanks, noted' : 'Missing an app?', sugSub: suggested ? 'We’ll email Marco if we add it' : 'Tell us which one you use',
      suggest: function () { set({ suggested: true }); },
      empty: !top.length && !tiles.length && !!ql,
      showLocked: tiles.some(function (t) { return t.locked; }),
      toast: !!tApp, toastName: tApp ? tApp[1] : '', toastSub: tApp ? (LINES[tApp[0]] || '') + '.' : '',
      okIc: ic('check', 'sage'), lockIc: ic('lock', 'azure'), heroIc: ic('sync', 'violet'), emptyIc: ic('search', 'slate')
    };
