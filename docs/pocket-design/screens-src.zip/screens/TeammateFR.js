    var st = this.props.state || 'default';
    var ro = st === 'readonly';
    var role = this.g('role', 'crew'), link = this.g('link', st === 'nolink' ? 'off' : 'on'), copied = this.g('copied', false), resent = this.g('resent', false);
    var inactive = this.g('inactive', st === 'deactivated'), sheet = this.g('sheet', false), renew = this.g('renew', false);
    var perms = this.g('perms', { pay: false, margins: false, approve: false, tasks: true });
    var fore = role === 'foreman';
    var sw = function (on) { return { track: on ? 'background: var(--acc)' : 'background: var(--track-off)', knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var linkOn = link === 'on' && !inactive;
    var P = [
      ['tasks', 'Ajouter des tâches sur place', 'Pour l’équipe et les contremaîtres', 'list', 'violet', false],
      ['pay', 'Voir sa propre paie', 'Taux et heures sur son lien', 'card', 'sage', false],
      ['margins', 'Voir les marges', 'Coûts et profits de ses chantiers', 'percent', 'amber', !fore],
      ['approve', 'Approuver les heures', fore ? 'Heures de son équipe sur ses chantiers' : 'Contremaîtres seulement', 'check', 'teal', !fore]
    ];
    var lock = ro || inactive;
    return {
      readonly: ro, inactive: inactive, roLock: lock, linkOff: !linkOn,
      eyeIc: ic('eye', 'azure'), pauseIc: ic('lock', 'amber'), linkIc: ic('link', 'azure'), clockIc: ic('clock', 'amber'),
      roleName: fore ? 'Contremaître' : 'Équipe', roleTagCls: fore ? 'tag-acc' : '',
      roleHint: fore ? 'Promue aujourd’hui' : 'Depuis mars 2024',
      linkWord: inactive ? 'Lien coupé' : linkOn ? 'Lien actif' : 'Aucun lien', linkSt: inactive || !linkOn ? 'st-mute si-off' : 'st-ok si-live',
      linkTitle: linkOn ? 'quoteai.ca/t/amara-7K2' : 'Aucun lien personnel',
      linkSub: linkOn ? (resent ? 'Renvoyé par texto à l’instant' : 'Ouvert aujourd’hui à 7 h 15') : 'Elle ne peut pas pointer tant que vous n’en envoyez pas',
      quick: [
        { label: 'Appeler', ic: ic('phone', 'sage'), href: '#' },
        { label: 'Message', ic: ic('chat', 'violet'), href: '#' },
        { label: 'Heures', ic: ic('clock', 'teal'), href: 'CrewHours.dc.html' }
      ],
      roles: [['crew', 'Équipe', 'Pointe, voit ses tâches, envoie des photos'], ['foreman', 'Contremaître', 'Dirige un chantier, approuve les heures']].map(function (r) {
        var on = r[0] === role;
        return { label: r[1], sub: r[2], on: on, cls: on ? 'on' : '', dis: lock, pick: function () { var n = Object.assign({}, perms); if (r[0] === 'foreman') n.approve = true; else { n.approve = false; n.margins = false; } set({ role: r[0], perms: n }); } };
      }),
      jobs: [
        { name: 'Finition du sous-sol', sub: 'Tom & Lena Hart · gypse', hours: '46,0 h', status: 'Sur place', st: 'st-ok si-live', ic: ic('house', 'violet'), href: 'Job.dc.html' },
        { name: 'Plancher du corridor', sub: 'Okoye Condo · ragréage', hours: '28,5 h', status: 'En cours', st: 'st-ok si-live', ic: ic('bricks', 'amber'), href: 'Job.dc.html' },
        { name: 'Peinture de la réception', sub: 'Harbourfront Dental · 13 oct.', hours: '8,0 h', status: 'Prévu', st: 'st-info si-q1', ic: ic('brush', 'teal'), href: 'Job.dc.html' }
      ],
      certs: [
        { name: 'Travail en hauteur', sub: 'IHSA · carte WAH-448120', status: renew ? 'Renouvellement demandé' : 'Expire le 12 nov.', st: renew ? 'st-info si-q1' : 'st-warn si-clock', ic: ic('shield', 'amber') },
        { name: 'SIMDUT', sub: 'Valide jusqu’au 4 mars 2027', status: 'Valide', st: 'st-ok si-check', ic: ic('shield', 'teal') }
      ],
      renewLabel: renew ? 'Demandé' : 'Demander', askRenew: function () { if (!lock) set({ renew: true }); },
      copyLabel: copied ? 'Copié' : 'Copier', copy: function () { set({ copied: true }); },
      resendLabel: linkOn ? (resent ? 'Envoyé' : 'Renvoyer') : 'Envoyer', resend: function () { set({ link: 'on', resent: true }); },
      revokeLabel: 'Révoquer', revoke: function () { set({ link: 'off', resent: false, copied: false }); },
      perms: P.map(function (p) {
        var on = !!perms[p[0]], s = sw(on && !p[5]);
        return { label: p[1], sub: p[2], ic: ic(p[3], p[4]), on: on && !p[5], dis: p[5] || lock, track: s.track, knob: s.knob, flip: function () { var n = Object.assign({}, perms); n[p[0]] = !on; set({ perms: n }); } };
      }),
      canDeactivate: !inactive && !ro,
      sheet: sheet, askDeact: function () { set({ sheet: true }); }, closeAll: function () { set({ sheet: false }); },
      deactivate: function () { set({ sheet: false, inactive: true }); },
      reactivate: function () { set({ inactive: false }); }
    };
