    var mode = this.props.state || 'default';
    var ro = mode === 'readOnly';
    var ORIG = 1865.10;
    var START = [
      { id: 'a', sec: 'Préparation', name: 'Retrait du dosseret existant', qty: 32, unit: 'pi²', rate: 4.50 },
      { id: 'b', sec: 'Préparation', name: 'Panneau de ciment et imperméabilisation', qty: 32, unit: 'pi²', rate: 6.25 },
      { id: 'c', sec: 'Carrelage', name: 'Pose de tuiles en chevrons', qty: 32, unit: 'pi²', rate: 18.50 },
      { id: 'd', sec: 'Carrelage', name: 'Fourniture de tuiles, coulis et moulures', qty: 37, unit: 'pi²', rate: 13.69 },
      { id: 'e', sec: 'Finition', name: 'Rallonges de prises et plaques', qty: 4, unit: 'unité', rate: 22.00 },
      { id: 'f', sec: 'Finition', name: 'Silicone, scellement et nettoyage', qty: 1, unit: 'forfait', rate: 120.00 }
    ];
    var lines = this.g('lines', START);
    var title = this.g('title', 'Dosseret de cuisine');
    var bookOpen = this.g('book', false), exDraft = this.g('exDraft', '');
    var excl = this.g('excl', ['Déplacer ou rebrancher les électroménagers', 'Réparer le gypse derrière l’ancienne tuile au-delà de 2 pi²', 'Travaux électriques autres que le remplacement des plaques']);
    var optsOn = this.g('opts', true), rec = this.g('rec', 1);
    var dep = this.g('dep', 30), mile = this.g('mile', 30), holdOn = this.g('hold', true);
    var sent = this.g('sent', false);
    var FLAGS = this.g('flags', { a: 'Low', d: 'High', f: 'Low' });

    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var money = function (n) { var s = Math.abs(n).toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' '); return (n < 0 ? '−' : '') + s + ' $'; };
    var parse = function (s) { var n = parseFloat(String(s).replace(',', '.').replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    var upd = function (id, k, v) { set({ sent: false, lines: self.g('lines', START).map(function (l) { if (l.id !== id) return l; var n = Object.assign({}, l); n[k] = v; return n; }) }); };

    var SECS = ['Préparation', 'Carrelage', 'Finition'];
    var sub = 0;
    var sections = SECS.map(function (sn, si) {
      var ls = lines.filter(function (l) { return l.sec === sn; });
      var ss = 0;
      var out = ls.map(function (l, i) {
        var amt = r2(l.qty * l.rate); ss += amt;
        var f = FLAGS[l.id];
        return { name: l.name, unit: l.unit, amt: money(amt), qty: String(l.qty), rate: l.rate.toFixed(2).replace('.', ','), qid: 'q-' + l.id, rid: 'r-' + l.id,
          sep: i ? 'border-top: 1px solid var(--line)' : '', canEdit: !ro,
          onQty: function (e) { upd(l.id, 'qty', parse(e.target.value)); },
          onRate: function (e) { upd(l.id, 'rate', parse(e.target.value)); },
          upLabel: 'Monter « ' + l.name + ' »',
          up: function () { var all = self.g('lines', START).slice(); var idx = all.findIndex(function (x) { return x.id === l.id; }); var j = idx - 1; while (j >= 0 && all[j].sec !== l.sec) j--; if (j < 0) return; var t = all[j]; all[j] = all[idx]; all[idx] = t; set({ lines: all }); },
          flag: !!f, flagWord: f === 'Low' ? 'Bas' : f === 'High' ? 'Élevé' : '', flagCls: f === 'Low' ? 'st-warn si-alert' : 'st-info si-alert' };
      });
      sub += ss;
      return { name: sn, sub: money(r2(ss)), lines: out, sep: si ? 'border-top: 1px solid var(--line)' : '' };
    });
    sub = r2(sub);
    var tax = r2(sub * 0.13), total = r2(sub + tax);
    var tm = money(total);
    var delta = r2(total - ORIG);
    var nFlags = Object.keys(FLAGS).length;

    var book = [
      ['Scellant à coulis, 2 couches', '1,40 $', 'le pi²', 'drop', 'teal', 32, 'pi²', 1.40],
      ['Bande DEL sous les armoires', '145,00 $', 'la longueur', 'bolt', 'amber', 1, 'longueur', 145],
      ['Moulure de finition Schluter', '9,50 $', 'le pi lin.', 'ruler', 'slate', 8, 'pi lin.', 9.50],
      ['Retouches de peinture au-dessus des tuiles', '85,00 $', 'forfait', 'brush', 'rose', 1, 'forfait', 85]
    ].map(function (b, i) { return { name: b[0], rate: b[1], unit: b[2], sub: 'Utilisé sur 6 chantiers cette année', ic: ic(b[3], b[4]),
      add: function () { set({ book: false, sent: false, lines: self.g('lines', START).concat([{ id: 'n' + Date.now() + i, sec: 'Finition', name: b[0], qty: b[5], unit: b[6], rate: b[7] }]) }); } }; });

    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var os = sw(optsOn), hs = sw(holdOn);

    var TIERS = [
      ['Bon', 'Céramique 3×6, pose droite', ic('tier1', 'slate'), total - 396.63, [['Tuile métro en céramique blanche standard', 1], ['Pose droite, même préparation et imperméabilisation', 1], ['Sans moulure de finition, extrémités calfeutrées', 0]]],
      ['Meilleur', 'Style zellige 3×12, en chevrons', ic('tier2', 'violet'), total, [['La tuile choisie par Priya', 1], ['En chevrons jusque sous les armoires du haut', 1], ['Moulure métallique aux extrémités', 1]]],
      ['Excellent', 'Meilleur, plus éclairage et scellant', ic('tier3', 'gold'), total + 369.93, [['Tout ce qui est dans Meilleur', 1], ['Bande DEL sous les armoires, 2 longueurs', 1], ['Coulis scellé deux fois, retouches après 1 an', 1]]]
    ];
    var tiers = TIERS.map(function (t, i) {
      var isRec = i === rec;
      return { name: t[0], sub: t[1], ic: t[2], price: money(r2(t[3])), rec: isRec, cls: isRec ? 'on' : '',
        recLbl: isRec ? 'Recommandé' : 'Recommander', recBtnCls: isRec ? 'btn-p' : 'btn-s', editLbl: i === 1 ? 'Lignes ci-dessus' : 'Modifier',
        pickRec: function () { if (!ro) set({ rec: i }); },
        incl: t[4].map(function (x) { return { text: x[0], path: x[1] ? 'm5 12.5 4.5 4.5L19 7.5' : 'M6 6l12 12M18 6 6 18', col: x[1] ? '' : 'color: var(--faint)' }; }) };
    });

    // payment schedule: last payable row takes the cents so it always adds up
    var hold = holdOn ? 10 : 0;
    var rest = 100 - dep - mile - hold;
    var bad = rest < 0;
    var cents = Math.round(total * 100);
    var dC = Math.round(cents * dep / 100), mC = Math.round(cents * mile / 100), hC = holdOn ? Math.round(cents * hold / 100) : 0;
    var cC = cents - dC - mC - hC;
    var COL = ['var(--acc)', 'var(--info)', 'var(--ok-dot)', 'var(--warn-dot)'];
    var stepper = function (key, cur, min, max) {
      return { dec: function () { if (!ro) set({ [key]: Math.max(min, cur - 5), sent: false }); }, inc: function () { if (!ro) set({ [key]: Math.min(max, cur + 5), sent: false }); } };
    };
    var ds = stepper('dep', dep, 0, 60), ms = stepper('mile', mile, 0, 80);
    var terms = [
      { label: 'Dépôt', when: 'À la signature', pct: dep + ' %', amt: money(dC / 100), step: !ro, auto: ro, dec: ds.dec, inc: ds.inc, decLbl: 'Réduire le dépôt', incLbl: 'Augmenter le dépôt', sw: 'background: ' + COL[0] },
      { label: 'Pose', when: 'Tuiles au mur', pct: mile + ' %', amt: money(mC / 100), step: !ro, auto: ro, dec: ms.dec, inc: ms.inc, decLbl: 'Réduire l’étape', incLbl: 'Augmenter l’étape', sw: 'background: ' + COL[1] },
      { label: 'À la fin des travaux', when: 'Le reste, au cent près', pct: (rest < 0 ? '−' + (-rest) : rest) + ' %', amt: money(cC / 100), step: false, auto: true, sw: 'background: ' + COL[2], pctCol: bad ? 'color: var(--bad)' : '', amtCol: bad ? 'color: var(--bad)' : '' }
    ];
    if (holdOn) terms.push({ label: 'Retenue', when: '60 jours après la fin', pct: '10 %', amt: money(hC / 100), step: false, auto: true, sw: 'background: ' + COL[3] });
    var segs = [dep, mile, Math.max(0, rest), hold].map(function (p, i) { return { style: 'width: ' + p + '%; background: ' + COL[i] + (p ? '' : '; display: none') }; });

    return {
      ro: ro, roAttr: ro, roCls: ro ? 'qe-ro' : '', canEdit: !ro,
      title: title, onTitle: function (e) { set({ title: e.target.value }); },
      lockIc: ic('lock', 'slate'), syncIc: ic('sync', 'violet'), pcIc: ic('percent', 'teal'), warnIc: ic('warn', 'clay'), cardIc: ic('card', 'azure'),
      docIc: ic('doc', 'violet'), layIc: ic('file', 'stone'), aiIc: ic('orb', 'violet'),
      pcSub: nFlags ? 'Selon 14 chantiers passés' : 'Toutes les lignes dans la norme',
      pcWord: nFlags ? nFlags + ' à vérifier' : 'Dans la norme', pcCls: nFlags ? 'st-warn si-alert' : 'st-ok si-check',
      sections: sections, itemCount: lines.length + ' lignes',
      bookOpen: bookOpen, toggleBook: function () { set({ book: !self.g('book', false) }); }, book: book,
      addBlank: function () { set({ sent: false, lines: self.g('lines', START).concat([{ id: 'n' + Date.now(), sec: 'Finition', name: 'Nouvelle ligne', qty: 1, unit: 'unité', rate: 0 }]) }); },
      subtotal: money(sub), tax: money(tax), totalWhole: tm.slice(0, -5), totalCents: tm.slice(-5),
      totalDelta: Math.abs(delta) < 0.005 ? 'Identique à la version 1' : (delta > 0 ? '+' : '') + money(delta) + ' par rapport à la version 1',
      excl: excl.map(function (x, i) { return { text: x, canEdit: !ro, aria: 'Retirer : ' + x, del: function () { set({ excl: excl.filter(function (_, j) { return j !== i; }) }); } }; }),
      exCount: String(excl.length), exDraft: exDraft, onEx: function (e) { set({ exDraft: e.target.value }); },
      addEx: function () { var v = String(self.g('exDraft', '')).trim(); if (!v) return; set({ excl: excl.concat([v]), exDraft: '' }); },
      optsOn: optsOn, optsOff: !optsOn, optTrack: os.t, optKnob: os.k, toggleOpts: function () { if (!ro) set({ opts: !optsOn }); },
      tiers: tiers,
      segs: segs, terms: terms, payTotal: money((dC + mC + Math.max(0, cC) + hC) / 100),
      payWord: bad ? 'Plus de 100 %' : 'Équilibré', payCls: bad ? 'st-bad si-alert' : 'st-ok si-check', payErr: bad, overBy: (-rest) + ' %',
      holdOn: holdOn, holdTrack: hs.t, holdKnob: hs.k, toggleHold: function () { if (!ro) set({ hold: !holdOn }); },
      send: function () { if (!bad) set({ sent: true }); },
      sendLabel: bad ? 'Corriger les paiements' : sent ? 'Envoyée à Priya' : 'Envoyer ' + tm,
      sendStyle: bad ? 'opacity: .4' : sent ? 'background: var(--ok-dot); color: #ffffff' : ''
    };
