    var ORDER = ['describe', 'check', 'send', 'done'];
    var step = self.g('step', null) || this.props.step || 'describe';
    var idx = ORDER.indexOf(step); if (idx < 0) { idx = 0; step = 'describe'; }
    var SAMPLE = 'Repaint a 12×14 bedroom, two coats. Walls only, patch a few nail holes, light colour over beige.';
    var txt = self.g('txt', ''), writing = self.g('writing', false), listening = self.g('listening', false);
    var sending = self.g('sending', false), dest = self.g('dest', 'me'), notif = self.g('notif', false);
    var S = [['Describe the job', 'By voice or text'], ['Check the price', 'Change any line before it goes out'], ['Send it', 'To yourself first, if you like']];
    var steps = S.map(function (s, i) {
      var done = i < idx, now = i === idx;
      return { n: i + 1, name: s[0], sub: s[1], done: done, open: !done, now: now, cls: done ? 'done' : now ? 'now' : 'later', sr: done ? 'Done' : now ? 'Current step' : 'Next' };
    });
    var T = { describe: ['Your first quote', 'Three short steps. About two minutes.'], check: ['Check the price', 'Built from your trade and Ontario prices.'], send: ['Send it', 'Send it to yourself to see what clients get.'] }[step] || ['', ''];
    return {
      title: T[0], sub: T[1], steps: steps,
      isDescribe: step === 'describe', isCheck: step === 'check', isSend: step === 'send', isDone: step === 'done', notDone: step !== 'done',
      canBack: idx === 1 || idx === 2, noBack: !(idx === 1 || idx === 2),
      back: function () { set({ step: ORDER[Math.max(0, idx - 1)] }); },
      txt: txt, onTxt: function (e) { set({ txt: e.target.value }); },
      hint: listening ? 'Listening…' : txt ? txt.length + ' characters' : 'Tap the mic and talk',
      mic: function () { set({ listening: true }); setTimeout(function () { set({ listening: false, txt: SAMPLE }); }, 1300); },
      showTry: !txt, useTry: function () { set({ txt: SAMPLE }); },
      brushIc: ic('brush', 'violet'),
      cantWrite: !txt.trim() || writing, writing: writing, writeLabel: writing ? 'Writing your quote…' : 'Write my quote',
      write: function () { set({ writing: true }); setTimeout(function () { set({ writing: false, step: 'check' }); }, 1500); },
      lines: [
        { name: 'Prep and protect', sub: 'Fill nail holes, sand, cover floors', amt: '$160.00' },
        { name: 'Walls, two coats', sub: '416 sq ft at $1.35', amt: '$561.60' },
        { name: 'Paint and supplies', sub: 'Eggshell, two gallons, tape, rollers', amt: '$145.00' }
      ],
      checkIc: ic('check', 'sage'),
      toSend: function () { set({ step: 'send' }); },
      to: [['me', 'Me first', 'marco@rossireno.ca', 'user', 'violet'], ['client', 'A client', 'Pick from your contacts', 'users', 'teal']].map(function (o) {
        return { name: o[1], sub: o[2], ic: ic(o[3], o[4]), on: dest === o[0], cls: dest === o[0] ? 'on' : '', pick: function () { set({ dest: o[0] }); } };
      }),
      docIc: ic('doc', 'indigo'),
      sending: sending, sendLabel: sending ? 'Sending…' : dest === 'me' ? 'Send to me' : 'Choose a client',
      send: function () { set({ sending: true }); setTimeout(function () { set({ sending: false, step: 'done' }); }, 1200); },
      sentIc: ic('send', 'sage'), bellIc: ic('bell', 'amber'),
      notif: notif, notifOff: !notif, notifOn: function () { set({ notif: true }); }
    };
