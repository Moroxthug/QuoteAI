    var ROLE = this.props.role || 'estimator';
    var done = this.g('done', {});
    var row = function (key, icn, tone, t, s, w, st, btn, doneWord, doneSt) {
      var d = done[key];
      return { hasIc: true, hasAv: false, ic: ic(icn, tone), t: t, s: s, hasSt: !!w, w: d ? doneWord : w, st: d ? doneSt : st,
        hasVal: false, val: '', hasBtn: !!btn && !d, btn: btn || '', tn: '', ini: '',
        act: function () { var o = Object.assign({}, self.g('done', {})); o[key] = true; set({ done: o }); } };
    };
    var vrow = function (icn, tone, t, s, v) { return { hasIc: true, hasAv: false, ic: ic(icn, tone), t: t, s: s, hasSt: false, w: '', st: '', hasVal: true, val: v, hasBtn: false, btn: '', act: function () {}, tn: '', ini: '' }; };
    var arow = function (key, ini, tn, t, s, w, st, btn, doneWord, doneSt) { var r = row(key, 'dot', 'slate', t, s, w, st, btn, doneWord, doneSt); r.hasIc = false; r.hasAv = true; r.ini = ini; r.tn = tn; return r; };
    var mi = function (t, v, vStyle) { return { t: t, v: v, isNum: true, isSt: false, st: '', vStyle: vStyle || '', style: '' }; };
    var ms = function (t, v, st) { return { t: t, v: v, isNum: false, isSt: true, st: st, vStyle: '', style: '' }; };
    var OK = 'color: var(--ok)', BAD = 'color: var(--bad)', WARN = 'color: var(--warn)', MUT = 'color: var(--muted)';
    var sec = function (o) {
      return Object.assign({ title: '', link: '', href: '#', hasLink: false, isHero: false, isBars: false, isList: false, isKpis: false, isProg: false,
        label: '', meta: '', fig: '', figSub: '', figSubStyle: MUT, hasBar: false, barStyle: '', hasMini: false, mini: [], hasFoot: false, foot: '',
        bars: [], rows: [], kpis: [], prog: [] }, o, { cardHref: o.cardHref || o.href, hasLink: !!o.link, hasMini: !!(o.mini && o.mini.length), hasFoot: !!o.foot });
    };
    var bars = function (vals, labels, hi) {
      var mx = Math.max.apply(null, vals);
      return vals.map(function (v, i) { return { label: labels[i], style: 'height: ' + Math.round(v / mx * 52) + 'px; animation-delay: ' + (i * 70) + 'ms; background: ' + (i === hi ? 'var(--acc)' : 'var(--sunk)') }; });
    };
    var kp = function (l, v, sub, subStyle) { return { l: l, v: v, sub: sub, subStyle: subStyle || MUT }; };
    var pr = function (name, pct, phase, note, noteStyle) { return { name: name, pct: pct + ' %', style: 'width: ' + pct + '%', phase: phase, note: note, noteStyle: noteStyle || '' }; };

    var R = {
      officeManager: { name: 'Carla Mendes', role: 'Gestionnaire de bureau', tabs: 'Accueil, Soumissions, Factures, Clients', sections: [
        sec({ title: 'À traiter', link: 'Tout voir', href: 'Notifications.dc.html', isList: true, rows: [
          arow('om1', 'AO', 'tn3', 'Amara Okafor, 12,5 h', 'Sous-sol Hart · 21–27 sept.', 'À approuver', 'st-warn', 'Approuver', 'Approuvé', 'st-ok si-check'),
          row('om2', 'receipt', 'rose', 'INV-0412 · Hart', '2 340 $ · envoyée le 11 sept.', '9 j de retard', 'st-bad', 'Relancer', 'Rappel envoyé', 'st-info'),
          row('om3', 'user', 'violet', 'Demande · Chen Family', 'Cuisine · via votre site Web', 'Nouvelle', 'st-acc si-dot', 'Appeler', 'Appelé', 'st-ok') ] }),
        sec({ title: 'Argent', link: 'Comptabilité', href: 'Books.dc.html', isHero: true, label: 'Encaissé en septembre', meta: '6 factures ouvertes', fig: '48 230 $', figSub: '↑ 12 %', figSubStyle: OK,
          mini: [mi('À recevoir', '9 870 $'), mi('En retard', '3 120 $', BAD)] }),
        sec({ title: 'Aujourd’hui', link: 'Horaire', href: 'Schedule.dc.html', isList: true, rows: [
          vrow('cal', 'azure', 'Estimation · Priya Nair', 'Ben · 212 Dovercourt Rd', '11 h'),
          vrow('pin', 'rose', 'Visite de chantier · Chen Family', 'Ben · cuisine', '14 h 30'),
          vrow('truck', 'clay', 'Livraison · sous-sol Hart', 'Gypse, 24 feuilles', '16 h') ] }),
        sec({ title: 'Cette semaine', isKpis: true, kpis: [kp('Soumissions', '7', '2 consultées'), kp('Facturé', '14 380 $', '5 factures'), kp('Messages', '3', 'non lus', WARN)] }) ] },

      estimator: { name: 'Ben Walsh', role: 'Estimateur', tabs: 'Accueil, Soumissions, Demandes, Clients', sections: [
        sec({ title: 'Soumissions à rédiger', link: 'Soumissions', href: 'Quotes.dc.html', isHero: true, label: 'Brouillons et demandes', meta: 'Cette semaine', fig: '4', figSub: '2 pour aujourd’hui', figSubStyle: WARN, cardHref: 'NewQuote.dc.html',
          mini: [ms('Chen Family · cuisine', 'Aujourd’hui', 'st-warn si-clock'), ms('Marchetti Bakery · comptoir', 'Aujourd’hui', 'st-warn si-clock'), ms('Okoye Condo · salle de bain', 'Pour jeu.', 'st-warn si-clock')] }),
        sec({ title: 'Visites de chantier', link: 'Horaire', href: 'Schedule.dc.html', isList: true, rows: [
          row('es1', 'pin', 'rose', '11 h · Priya Nair', '212 Dovercourt Rd · dosseret', '', '', 'Itinéraire', '', ''),
          row('es2', 'pin', 'amber', '14 h 30 · Chen Family', '88 Brookside Dr · cuisine', '', '', 'Itinéraire', '', '') ] }),
        sec({ title: 'Taux de réussite', link: 'Analyses', href: 'Analytics.dc.html', isBars: true, label: 'Soumissions gagnées, 4 derniers mois', meta: '38 envoyées', fig: '62 %', figSub: '↑ 4 points', figSubStyle: OK,
          bars: bars([48, 55, 58, 62], ['juin', 'juil.', 'août', 'sept.'], 3) }),
        sec({ title: 'En attente des clients', isList: true, rows: [
          row('ew1', 'building', 'azure', 'Harbourfront Dental', 'Q-2026-114 · 18 640 $', 'Consultée', 'st-acc si-q2', 'Relancer', 'Relancée', 'st-info'),
          row('ew2', 'house', 'sage', 'Okoye Condo', 'Q-2026-117 · 9 200 $', 'Expire ven.', 'st-warn si-clock', '', '', ''),
          row('ew3', 'house', 'clay', 'Gill Residence', 'Ordre de changement · 1 180 $', 'Envoyé', 'st-info si-q1', '', '', '') ] }) ] },

      projectManager: { name: 'Hannah Kim', role: 'Gestionnaire de projet', tabs: 'Accueil, Travaux, Horaire, Clients', sections: [
        sec({ title: 'À risque', link: 'Travaux', href: 'Jobs.dc.html', isList: true, rows: [
          row('pm1', 'warn', 'amber', 'Sous-sol Hart', 'Gypse : 2 j de retard', 'Bloqué', 'st-bad si-alert', 'Ouvrir', 'Ouvert', 'st-acc si-q2'),
          row('pm2', 'doc', 'violet', 'Harbourfront Dental', 'Ordre en attente · 1 180 $', 'En attente', 'st-warn si-clock', 'Relancer', 'Relancé', 'st-info') ] }),
        sec({ title: 'Chantiers actifs', link: '5 actifs', href: 'Jobs.dc.html', isProg: true, prog: [
          pr('Sous-sol Hart', 64, 'Gypse', '2 jours de retard', BAD), pr('Gill Residence', 85, 'Peinture et moulures', 'Dans les temps', OK),
          pr('Harbourfront Dental', 30, 'Charpente', 'Dans les temps', OK), pr('Okoye Condo', 10, 'Démolition', 'Début jeu.') ] }),
        sec({ title: 'Budget et réel', isKpis: true, kpis: [kp('Dans le budget', '3 sur 5', 'chantiers'), kp('Coûts, sept.', '21 460 $', 'sur 24 900 $'), kp('Dépassement', '1 240 $', 'Sous-sol Hart', BAD)] }),
        sec({ title: 'Ordres de changement', link: 'Tous', href: 'ChangeOrder.dc.html', isList: true, rows: [
          row('pc1', 'doc', 'violet', 'CO-07 · Sous-sol Hart', 'Prises supplémentaires · 640 $', 'Signé', 'st-ok si-check', '', '', ''),
          row('pc2', 'doc', 'violet', 'CO-08 · Harbourfront Dental', 'Soffite de la réception · 1 180 $', 'Envoyé', 'st-info si-q1', '', '', '') ] }) ] },

      dispatcher: { name: 'Omar Haddad', role: 'Répartiteur', tabs: 'Accueil, Horaire, Travaux, Carte', sections: [
        sec({ title: 'Équipe en ce moment', link: 'Carte', href: 'CrewMap.dc.html', isHero: true, label: 'Position partagée', meta: '1 en congé', fig: '4 en direct', figSub: '3 sur place', figSubStyle: OK, cardHref: 'CrewMap.dc.html',
          mini: [mi('Jonah, en route vers le sous-sol Hart', '14 min', 'color: var(--acc-t)'), ms('Luca et Amara · sous-sol Hart', 'Sur place', 'st-ok si-live'), ms('Dev · Gill Residence', 'Sur place', 'st-ok si-live')] }),
        sec({ title: 'Non assignés', isList: true, rows: [
          row('dp1', 'hammer', 'amber', 'Harbourfront Dental · jeu.', 'Réparation · 1 plâtrier requis', 'Ouvert', 'st-warn si-dot', 'Assigner', 'Amara', 'st-ok'),
          row('dp2', 'bolt', 'gold', 'Marchetti Bakery · dépannage', 'Disjoncteur · cette semaine', 'Ouvert', 'st-warn si-dot', 'Assigner', 'Jonah', 'st-ok') ] }),
        sec({ title: 'Demain', link: 'Horaire', href: 'Schedule.dc.html', isList: true, rows: [
          vrow('house', 'clay', 'Sous-sol Hart', 'Luca, Amara, Sofia · deuxième couche', '7 h'),
          vrow('house', 'sage', 'Gill Residence', 'Dev · moulures', '7 h 30'),
          vrow('truck', 'azure', 'Harbourfront Dental', 'Livraison · montants d’acier', '10 h') ] }),
        sec({ title: 'Cette semaine', isKpis: true, kpis: [kp('Réservées', '186 h', 'sur 200'), kp('Heures sup.', '6 h', 'Luca', WARN), kp('Pluie', 'jeu.', 'travaux ext. à reporter', MUT)] }) ] },

      bookkeeper: { name: 'Rosa Lima', role: 'Commis comptable', tabs: 'Accueil, Factures, Comptabilité, Paie', sections: [
        sec({ title: 'À rapprocher', link: 'Comptabilité', href: 'Books.dc.html', isHero: true, label: 'Lignes bancaires, septembre', meta: 'Compte chèques RBC', fig: '18', figSub: 'à associer', figSubStyle: WARN, cardHref: 'Books.dc.html',
          hasBar: true, barStyle: 'width: 89%', foot: '142 sur 160 associées · synchro à 8 h 12' }),
        sec({ title: 'Reçus', link: 'Tous', href: 'Books.dc.html', isList: true, rows: [
          row('bk1', 'receipt', 'rose', 'Home Depot · Warden Ave', '412,66 $ · doublon possible', 'Question', 'st-warn si-clock', 'Vérifier', 'Vérifié', 'st-ok'),
          row('bk2', 'receipt', 'clay', 'Rona · sous-sol Hart', '86,20 $ · chantier non défini', 'À confirmer', 'st-warn si-clock', 'Vérifier', 'Vérifié', 'st-ok'),
          row('bk3', 'receipt', 'azure', 'Esso · camionnette', '74,10 $ · essence', 'À confirmer', 'st-warn si-clock', 'Vérifier', 'Vérifié', 'st-ok') ] }),
        sec({ title: 'TVH', link: 'Conformité', href: 'Compliance.dc.html', isHero: true, label: 'T3 · 1er juil. au 30 sept.', meta: 'Trimestrielle', fig: '6 212,00 $', figSub: 'dû le 31 oct.', figSubStyle: WARN, cardHref: 'Compliance.dc.html',
          mini: [mi('TVH perçue', '9 868,40 $'), mi('Crédits de taxe sur les intrants', '−3 656,40 $')] }),
        sec({ title: 'À venir', isList: true, rows: [
          row('bc1', 'bank', 'sage', 'Versement de paie, sept.', '4 386,20 $ · ARC', 'Dû le 15 oct.', 'st-warn si-clock', '', '', ''),
          row('bc2', 'shield', 'teal', 'Prime WSIB, T3', '1 912,40 $', 'Dû le 30 oct.', 'st-warn si-clock', '', '', '') ] }) ] },

      safety: { name: 'Kevin Tran', role: 'Coordonnateur SST', tabs: 'Accueil, Travaux, Équipe, Documents', sections: [
        sec({ title: 'Certificats à renouveler', link: 'Conformité', href: 'Compliance.dc.html', isList: true, rows: [
          arow('sf1', 'DP', 'tn2', 'Dev Patel', 'Secourisme · échu le 12 sept.', 'Expiré', ['st-bad', 'si-alert'].join(' '), 'Demander', 'Demandé', 'st-info'),
          arow('sf2', 'JR', 'tn4', 'Jonah Reyes', 'WSIB · sous-traitant', 'Expire le 20 oct.', 'st-warn si-clock', 'Demander', 'Demandé', 'st-info'),
          arow('sf3', 'SM', 'tn5', 'Sofia Marin', 'Travail en hauteur', 'Expire le 3 nov.', 'st-warn si-clock', '', '', '') ] }),
        sec({ title: 'Incidents', link: 'Registre', href: '#', isKpis: true, kpis: [kp('Sans arrêt', '142 j', 'record : 210'), kp('Quasi-accidents', '2', 'en septembre', WARN), kp('Ouverts', '1', 'échelle, Hart', BAD)] }),
        sec({ title: 'Causeries sécurité', link: 'Toutes', href: 'Documents.dc.html', isList: true, rows: [
          row('st1', 'chat', 'violet', 'Sécurité des échelles', 'jeu. 7 h · sous-sol Hart', '3 sur 5 signées', 'st-warn si-q3', 'Relancer', 'Relancé', 'st-info'),
          row('st2', 'chat', 'teal', 'Poussière de silice et sablage', '22 sept. · tous les chantiers', 'Signée', 'st-ok si-check', '', '', '') ] }),
        sec({ title: 'Inspections de chantier', isList: true, rows: [
          row('si1', 'house', 'clay', 'Sous-sol Hart', 'Tournée hebdomadaire', 'Pour ven.', 'st-warn si-clock', '', '', ''),
          row('si2', 'house', 'sage', 'Gill Residence', '24 sept. · Kevin', 'Réussie', 'st-ok si-check', '', '', '') ] }) ] }
    };
    var P = R[ROLE] || R.estimator;
    P.sections.forEach(function (s, i) { s.delay = 'animation-delay: ' + (60 + i * 50) + 'ms'; });
    var parts = P.name.split(' ');
    var bannerText = ROLE === 'bookkeeper' ? 'Vous voyez l’argent, mais pas les marges. Demandez à Marco de changer ça.' : (ROLE === 'estimator' ? 'Les taux de salaire sont masqués pour votre rôle.' : '');
    return {
      first: parts[0], ini: parts[0][0] + parts[1][0], roleName: P.role,
      hasBanner: false, bannerText: bannerText, bannerIc: ic('lock', 'slate'),
      sections: P.sections,
      custIc: ic('grid', 'violet'), custSub: 'Onglets : ' + P.tabs
    };
