    var lang = this.g('lang', 'en'), opt = this.g('opt', 1), name = this.g('name', ''), accepted = this.g('accepted', false), rate = this.g('rate', 0);
    var fr = lang === 'fr';
    var money = function (n) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return fr ? s + ' $' : '$' + s;
    };
    var EN = {
      from: 'From', quote: 'Quote', issued: 'Sep 29, 2026', title: 'Bedrooms and bath ceiling', for: 'For', valid: 'Valid until Oct 29',
      open: 'Open', acceptedSt: 'Accepted', totalWith: 'Total with HST', deposit: '30% deposit on acceptance',
      choose: 'Choose your option', pickOne: 'Pick one', recommended: 'Recommended', included: "What's included",
      subtotal: 'Subtotal', hst: 'HST, Ontario 13%', total: 'Total', owner: 'Owner, Rossi Renovations',
      note: 'Thanks for walking me through the house, Dana. We can start Tuesday Oct 13 and finish in four working days. We move furniture, cover floors and leave the rooms clean every evening.',
      rebates: 'Rebates and incentives', rebatesSub: 'None apply to paint or drywall work. We checked federal, Ontario and Toronto programs.', none: 'Checked',
      financing: 'Financing with Financeit', est: 'Estimate', perMonth: '/month over 60 months, on approval', check: 'Check rate', checking: 'Checking…', approved: 'Pre-approved',
      acceptTitle: 'Accept this quote', fullName: 'Full name', legal: 'Typing your name counts as your signature. You agree to the scope and payment terms above.',
      accept: 'Accept quote', next: 'Next step', payDeposit: 'Pay the deposit', payHow: 'Card or Interac e-Transfer', payBtn: 'Pay deposit',
      pdf: 'Download PDF', questions: 'Questions? Call Marco at', sentWith: 'Sent with quoteAI', notified: 'Rossi Renovations has been told. A copy is on its way to your email.',
      confirmed: 'Confirmed by', on: 'on Sep 29',
      opts: [['Good', 'Walls two coats, ceilings one coat. Contractor-grade paint.'], ['Better', 'Two coats everywhere. Benjamin Moore Regal Select.'], ['Best', 'Better, plus trim and doors. Benjamin Moore Aura, 3-year warranty.']],
      ch: ['Bedrooms and hallway', 'Bath ceiling', 'Materials and site'],
      ln: {
        paint: ['Painting, 3 bedrooms and hallway', '1,120 sq ft · '], trim: ['Trim and doors', '3 bedrooms, 6 doors, semi-gloss'], repair: ['Water-damage repair', 'Cut out, board, tape and skim'],
        primer: ['Stain-blocking primer', '48 sq ft · one coat'], sundries: ['Paint and sundries', 'Supplied by Rossi Renovations'], protect: ['Floor protection and cleanup', 'Drop sheets, daily sweep, final clean']
      },
      coats: ['walls 2 coats, ceilings 1', 'two coats', 'two coats']
    };
    var FR = {
      from: 'De la part de', quote: 'Soumission', issued: '29 sept. 2026', title: 'Chambres et plafond de salle de bain', for: 'Pour', valid: "Valide jusqu'au 29 oct.",
      open: 'Ouverte', acceptedSt: 'Acceptée', totalWith: 'Total avec TVH', deposit: "Dépôt de 30 % à l'acceptation",
      choose: 'Choisissez votre option', pickOne: 'Une seule', recommended: 'Recommandée', included: 'Ce qui est inclus',
      subtotal: 'Sous-total', hst: 'TVH, Ontario 13 %', total: 'Total', owner: 'Propriétaire, Rossi Renovations',
      note: "Merci de m'avoir fait visiter la maison, Dana. Nous pouvons commencer le mardi 13 octobre et terminer en quatre jours ouvrables. Nous déplaçons les meubles, protégeons les planchers et laissons les pièces propres chaque soir.",
      rebates: 'Remises et subventions', rebatesSub: "Aucune ne s'applique à la peinture ou aux cloisons sèches. Nous avons vérifié les programmes fédéraux, ontariens et torontois.", none: 'Vérifié',
      financing: 'Financement avec Financeit', est: 'Estimation', perMonth: '/mois sur 60 mois, sous réserve d\'approbation', check: 'Voir mon taux', checking: 'Vérification…', approved: 'Préapprouvé',
      acceptTitle: 'Accepter cette soumission', fullName: 'Nom complet', legal: 'Taper votre nom vaut signature. Vous acceptez les travaux et les modalités de paiement ci-dessus.',
      accept: 'Accepter la soumission', next: 'Prochaine étape', payDeposit: 'Payer le dépôt', payHow: 'Carte ou virement Interac', payBtn: 'Payer le dépôt',
      pdf: 'Télécharger le PDF', questions: 'Des questions? Appelez Marco au', sentWith: 'Envoyé avec quoteAI', notified: 'Rossi Renovations a été avisé. Une copie est envoyée à votre courriel.',
      confirmed: 'Confirmée par', on: 'le 29 sept.',
      opts: [['Bon', 'Murs deux couches, plafonds une couche. Peinture standard.'], ['Mieux', 'Deux couches partout. Benjamin Moore Regal Select.'], ['Optimal', 'Mieux, plus boiseries et portes. Benjamin Moore Aura, garantie 3 ans.']],
      ch: ['Chambres et couloir', 'Plafond de salle de bain', 'Matériaux et chantier'],
      ln: {
        paint: ['Peinture, 3 chambres et couloir', '1 120 pi² · '], trim: ['Boiseries et portes', '3 chambres, 6 portes, semi-lustré'], repair: ["Réparation de dégât d'eau", 'Découpe, gypse, ruban et enduit'],
        primer: ['Apprêt anti-taches', '48 pi² · une couche'], sundries: ['Peinture et fournitures', 'Fournies par Rossi Renovations'], protect: ['Protection des planchers et nettoyage', 'Bâches, balayage quotidien, nettoyage final']
      },
      coats: ['murs 2 couches, plafonds 1', 'deux couches', 'deux couches']
    };
    var t = fr ? FR : EN;
    var OPT = [
      { rate: 1.80, sundries: 295, trim: 0 },
      { rate: 2.10, sundries: 395, trim: 0 },
      { rate: 2.10, sundries: 615, trim: 420 }
    ];
    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var calc = function (o) {
      var paint = r2(1120 * o.rate), c1 = paint + o.trim, c2 = 640 + 88.80, c3 = o.sundries + 180;
      var sub = r2(c1 + c2 + c3), tax = r2(sub * 0.13);
      return { paint: paint, c1: r2(c1), c2: r2(c2), c3: r2(c3), sub: sub, tax: tax, total: r2(sub + tax) };
    };
    var cur = calc(OPT[opt]);
    var base = calc(OPT[1]).total;
    var L = t.ln;
    var chLines = [
      [[L.paint[0], L.paint[1] + t.coats[opt], cur.paint]].concat(OPT[opt].trim ? [[L.trim[0], L.trim[1], OPT[opt].trim]] : []),
      [[L.repair[0], L.repair[1], 640], [L.primer[0], L.primer[1], 88.80]],
      [[L.sundries[0], L.sundries[1], OPT[opt].sundries], [L.protect[0], L.protect[1], 180]]
    ];
    var chSubs = [cur.c1, cur.c2, cur.c3];
    var chapters = t.ch.map(function (n, i) {
      return { name: n, sub: money(chSubs[i]), sep: i ? 'border-top: 1px solid var(--line2)' : '', lines: chLines[i].map(function (l) { return { name: l[0], detail: l[1], amt: money(l[2]) }; }) };
    });
    var options = OPT.map(function (o, i) {
      var c = calc(o), on = i === opt, d = r2(c.total - base);
      return {
        name: t.opts[i][0], desc: t.opts[i][1], total: money(c.total), rec: i === 1, on: on,
        diff: d === 0 ? (fr ? 'Prix de base' : 'Base price') : (d > 0 ? '+' : '−') + money(Math.abs(d)),
        ring: (on ? 'box-shadow: 0 0 0 2px var(--ink)' : 'box-shadow: 0 0 0 1px var(--ring)') + (accepted && !on ? '; opacity: .5' : ''),
        radio: on ? 'background: var(--inv); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
        dot: on ? 'transform: scale(1)' : 'transform: scale(0)',
        pick: function () { if (!self.g('accepted', false)) self.setState({ opt: i }); }
      };
    });
    var r = 0.1499 / 12, n = 60;
    var monthly = Math.round(cur.total * r / (1 - Math.pow(1 + r, -n)));
    var totalStr = money(cur.total);
    var first = (name.trim().split(/\s+/)[0]) || 'Dana';
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      accepted: accepted, open: !accepted,
      acceptedTitle: t.confirmed + ' ' + first + ' ' + t.on,
      status: accepted ? t.acceptedSt : t.open, statusSt: accepted ? 'st-ok' : 'st-info',
      total: totalStr, totalWhole: fr ? totalStr : totalStr.slice(0, -3), totalCents: fr ? '' : totalStr.slice(-3),
      deposit: money(r2(cur.total * 0.3)),
      options: options, optName: t.opts[opt][0], chapters: chapters,
      subtotal: money(cur.sub), tax: money(cur.tax),
      okIc: ic('check', 'sage'), giftIc: ic('gift', 'rose'), bankIc: ic('bank', 'indigo'), cardIc: ic('card', 'violet'),
      monthly: money(monthly).replace(/[.,]00/, ''),
      rateStyle: rate === 2 ? 'background: var(--ok-soft); color: var(--ok)' : '',
      chooseTitle: accepted ? (fr ? 'Votre option' : 'Your option') : t.choose, pickOne: accepted ? '' : t.pickOne,
      rateLabel: rate === 0 ? t.check : (rate === 1 ? t.checking : t.approved),
      checkRate: function () { if (self.g('rate', 0)) return; self.setState({ rate: 1 }); setTimeout(function () { self.setState({ rate: 2 }); }, 1400); },
      acceptSub: t.opts[opt][0] + ' · ' + totalStr,
      name: name, onName: function (e) { self.setState({ name: e.target.value }); },
      noName: name.trim().length < 3,
      acceptBtn: t.accept + ' · ' + totalStr,
      accept: function () { if (self.g('name', '').trim().length >= 3) self.setState({ accepted: true }); }
    };
