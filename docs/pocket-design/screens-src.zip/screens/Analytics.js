    var mode = this.props.state || 'default';
    var per = self.g('per', 'm');
    var P = {
      m: { label: 'September 2026', revBy: 'By month', revLabel: 'Invoiced in September', rev: '$48,230', revSub: 'Up 12% on August', revCap: 'Your best month this year.', win: '42%', winOf: '14 won of 33 quotes decided', avg: '$6,840', avgSub: 'Up from $4,920 in April', q2c: '23', d1: '6 d', d2: '9 d', d3: '8 d', n: [6, 9, 8], util: '78%',
        bars: [['Apr', 31.2], ['May', 36.8], ['Jun', 44.1], ['Jul', 39.6], ['Aug', 43.1], ['Sep', 48.2]],
        k: [['Invoiced', '$48,230', 'Up 12%', 1], ['Collected', '$41,870', '87% of invoiced', 0], ['Costs', '$30,910', 'Materials, labour, subs', 0], ['Margin', '36%', '$17,320 kept', 1], ['Outstanding', '$12,480', '$3,120 overdue', 2], ['To invoice', '$18,760', 'Next 30 days', 0]] },
      q: { label: 'Q3 2026, Jul to Sep', revBy: 'By quarter', revLabel: 'Invoiced in Q3', rev: '$130,930', revSub: 'Up 17% on Q2', revCap: 'Your best quarter so far.', win: '39%', winOf: '41 won of 105 quotes decided', avg: '$6,480', avgSub: 'Up from $5,210 in Q2', q2c: '26', d1: '7 d', d2: '10 d', d3: '9 d', n: [7, 10, 9], util: '81%',
        bars: [['Q4 ’25', 88.4], ['Q1', 71.9], ['Q2', 112.1], ['Q3', 130.9]],
        k: [['Invoiced', '$130,930', 'Up 17%', 1], ['Collected', '$121,480', '93% of invoiced', 0], ['Costs', '$86,410', 'Materials, labour, subs', 0], ['Margin', '34%', '$44,520 kept', 1], ['Outstanding', '$12,480', '$3,120 overdue', 2], ['To invoice', '$18,760', 'Next 30 days', 0]] },
      y: { label: '2026 so far', revBy: 'By year', revLabel: 'Invoiced in 2026 so far', rev: '$314,900', revSub: 'On pace for about $420,000', revCap: 'Almost as much as all of 2025, with a quarter to go.', win: '38%', winOf: '96 won of 252 quotes decided', avg: '$5,960', avgSub: 'Up from $4,870 in 2025', q2c: '29', d1: '8 d', d2: '11 d', d3: '10 d', n: [8, 11, 10], util: '80%',
        bars: [['2023', 212.4], ['2024', 268.7], ['2025', 331.5], ['2026', 314.9]],
        k: [['Invoiced', '$314,900', 'Up 24% on this time last year', 1], ['Collected', '$298,640', '95% of invoiced', 0], ['Costs', '$212,560', 'Materials, labour, subs', 0], ['Margin', '32%', '$102,340 kept', 1], ['Outstanding', '$12,480', '$3,120 overdue', 2], ['To invoice', '$18,760', 'Next 30 days', 0]] }
    };
    var p = P[per];
    var max = Math.max.apply(null, p.bars.map(function (b) { return b[1]; }));
    var fmtK = function (v) { return v >= 100 ? '$' + Math.round(v) + 'k' : '$' + v.toFixed(1) + 'k'; };
    var tot = p.n[0] + p.n[1] + p.n[2];
    var hb = function (rows, hi) { return rows.map(function (r, i) { return { name: r[0], v: r[1] + '%', w: 'width: ' + r[1] + '%' + (i === hi ? '; background: var(--ok-dot)' : ''), share: r[2] ? r[2] + '%' : '', wonStyle: i === hi ? 'color: var(--ok)' : '' }; }); };
    var sixBars = P.m.bars;
    return {
      isLoading: mode === 'loading', isLocked: mode === 'locked', isData: mode === 'default', notLocked: mode !== 'locked',
      p: Object.assign({}, p, { revAria: 'Invoiced ' + p.bars.map(function (b) { return b[0] + ' ' + fmtK(b[1]); }).join(', '), q2cAria: p.d1 + ' to accept, ' + p.d2 + ' to invoice, ' + p.d3 + ' to get paid' }),
      periods: [['m', 'Month'], ['q', 'Quarter'], ['y', 'Year']].map(function (c) { var on = c[0] === per; return { label: c[1], on: on, cls: on ? 'on' : '', pick: function () { set({ per: c[0] }); } }; }),
      kpis: p.k.map(function (k) { return { label: k[0], value: k[1], sub: k[2], subStyle: k[3] === 1 ? 'color: var(--ok)' : (k[3] === 2 ? 'color: var(--bad)' : 'color: var(--muted)') }; }),
      revBars: p.bars.map(function (b, i) { var last = i === p.bars.length - 1; return { m: b[0], v: last ? fmtK(b[1]) : '', cls: last ? 'on' : '', h: 'height: ' + Math.max(6, b[1] / max * 82).toFixed(1) + '%; animation-delay: ' + (i * 60) + 'ms' }; }),
      ghostBars: sixBars.map(function (b, i) { return { m: b[0], cls: i === 5 ? 'on' : '', h: 'height: ' + (b[1] / 48.2 * 82).toFixed(1) + '%' }; }),
      risk: [
        { name: 'Okoye Condo', sub: 'Flooring · 108% of budget', word: 'Over budget', st: 'st-bad si-alert', ic: ic('bars', 'clay'), href: 'Job.dc.html' },
        { name: 'Gill Residence', sub: 'Deck · $2,980 not billed', word: 'To invoice', st: 'st-warn si-clock', ic: ic('receipt', 'amber'), href: 'Job.dc.html' },
        { name: 'Harbourfront Dental', sub: 'INV-0419 · $780', word: '3 days late', st: 'st-bad si-alert', ic: ic('doc', 'azure'), href: 'Invoice.dc.html' }
      ],
      winBy: hb([['Decks', 61], ['Painting', 48], ['Basements', 40], ['Kitchens', 33], ['Bathrooms', 22]], 0),
      q2c: { a: 'flex: ' + p.n[0] + ' 1 0; background: var(--acc)', b: 'flex: ' + p.n[1] + ' 1 0; background: var(--warn-dot)', c: 'flex: ' + p.n[2] + ' 1 0; background: var(--ok-dot)' },
      margin: hb([['Painting', 38], ['Decks', 34], ['Drywall', 29], ['Basements', 24], ['Bathrooms', 17]], 0),
      clients: [['TL', 'tn1', 'Tom & Lena Hart', 'Basement finish · 2 change orders', '$42,355', '13%'], ['HD', 'tn4', 'Harbourfront Dental', 'Reception and 3 operatories', '$18,920', '6%'], ['OC', 'tn2', 'Okoye Condo', 'Hallway flooring and paint', '$9,640', '3%']].map(function (c) { return { ini: c[0], tn: c[1], name: c[2], sub: c[3], amt: c[4], share: c[5] + ' of 2026' }; }),
      crew: hb([['Amara Okafor', 91], ['Dev Patel', 84], ['Sofia Marin', 76], ['Luca Bianchi', 64]], -1),
      leads: hb([['Referrals', 58, 41], ['Website form', 31, 24], ['Google', 27, 18], ['HomeStars', 22, 11], ['Other', 15, 6]], 0).map(function (r, i) { r.w = 'width: ' + [41, 24, 18, 11, 6][i] / 41 * 100 + '%' + (i === 0 ? '; background: var(--ok-dot)' : ''); return r; }),
      skKpis: [1, 2, 3, 4, 5, 6],
      skCards: [0, 1, 2].map(function () { return { bars: [42, 55, 70, 60, 68, 82].map(function (h) { return { h: 'height: ' + h + '%' }; }) }; }),
      lockIc: ic('bars', 'azure'),
      lockFeats: [['Revenue, costs and margin by month', 'bars', 'azure'], ['Win rate and average quote', 'star', 'gold'], ['Margin by job type', 'percent', 'violet'], ['Crew time and lead sources', 'users', 'teal']].map(function (f) { return { label: f[0], ic: ic(f[1], f[2]) }; })
    };
