    var mode = this.props.state || 'expired';
    var online = this.g('online', mode !== 'offline');
    var retrying = this.g('retrying', false);
    var asking = this.g('asking', false), asked = this.g('asked', false);
    var code = this.g('code', ''), codeErr = this.g('codeErr', false), joining = this.g('joining', false);
    var T = {
      expired: ['This link has expired', 'Links stop working after a while to keep the site details safe. Marco can send you a new one.', ['lock', 'slate']],
      replaced: ['You have a newer link', 'Marco sent a new link to your phone, so this one stopped working. Use the latest text from Rossi Renovations.', ['sync', 'violet']],
      invalid: ['This link doesn’t work', 'Part of it may be missing. Open it again from the text, or ask Marco for a new one.', ['warn', 'amber']],
      offline: ['No connection', 'Your link is fine. The page needs signal to load today’s work.', ['cloud', 'amber']]
    };
    var t = online && mode === 'offline' ? T.expired : T[mode] || T.expired;
    if (!online) t = T.offline;
    var digits = code.replace(/\D/g, '').slice(0, 6);
    var cells = [0, 1, 2, 3, 4, 5].map(function (i) { return { v: digits[i] || '', cls: i === digits.length ? 'on' : '' }; });
    return {
      title: t[0], sub: t[1], heroIc: ic(t[2][0], t[2][1]),
      offline: !online, online: online, retrying: retrying, retryLabel: retrying ? 'Trying again…' : 'Try again',
      retry: function () { if (self.g('retrying', false)) return; set({ retrying: true }); setTimeout(function () { set({ retrying: false, online: true }); }, 1400); },
      notAsked: !asked, asked: asked, asking: asking, askLabel: asking ? 'Sending…' : 'Ask Marco for a new link',
      ask: function () { if (self.g('asking', false)) return; set({ asking: true }); setTimeout(function () { set({ asking: false, asked: true }); }, 1200); },
      sentIc: ic('send', 'azure'), phoneIc: ic('phone', 'sage'),
      cells: cells, code: digits, codeErr: codeErr, codeCls: codeErr ? 'err' : '',
      onCode: function (e) { set({ code: e.target.value.replace(/\D/g, '').slice(0, 6), codeErr: false }); },
      joinLabel: joining ? 'Joining…' : 'Join',
      join: function () {
        var d = self.g('code', '');
        if (d.length < 6 || d === '000000') { set({ codeErr: true }); return; }
        set({ joining: true });
        setTimeout(function () { window.location.href = 'CrewNow.dc.html'; }, 1100);
      }
    };
