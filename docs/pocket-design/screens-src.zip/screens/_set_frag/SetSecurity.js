    var ts = self.g('ts', ST !== 'twoStepOff');
    var sched = self.g('sched', ST === 'deleteScheduled');
    var chromeOn = self.g('chrome', true), ipadOn = self.g('ipad', true);
    var exp = self.g('exp', 'idle');
    var signRows = [
      lnk('key', 'violet', 'Password', 'Last changed May 12', 'Change', 'ForgotPassword.dc.html'),
      sw('face', true, 'face', 'slate', 'Face ID', 'Sign in and unlock after 5 minutes away'),
      sw('ts', ST !== 'twoStepOff', 'shield', 'indigo', 'Two-step verification', ts ? 'A code by text to (416) 555-0142' : 'Off. A code on top of your password')
    ];
    if (ts) {
      signRows.push(seg('tsBy', 0, 'chat', 'sky', 'Send codes by', '', ['Text', 'Authenticator app']));
      signRows.push(lnk('list', 'stone', 'Backup codes', 'For when you lose your phone', '8 left', 'TwoStep.dc.html'));
    } else {
      signRows.push(lnk('shield', 'amber', 'Set up two-step', 'Takes about a minute', '', 'TwoStep.dc.html'));
    }
    var sess = [ stat(mk('phone', 'violet', 'This iPhone', 'iPhone 15 Pro · Toronto'), 'Active now', 'st-ok si-live') ];
    if (chromeOn) sess.push(btnRow('globe', 'azure', 'Chrome on Windows', 'Toronto · 2 hours ago', 'Sign out', function () { set({ chrome: false, lastOut: 'Chrome on Windows' }); }));
    if (ipadOn) sess.push(btnRow('photo', 'teal', 'Safari on iPad', 'Mississauga · Sep 21', 'Sign out', function () { set({ ipad: false, lastOut: 'Safari on iPad' }); }));
    var others = (chromeOn ? 1 : 0) + (ipadOn ? 1 : 0);
    var lastOut = self.g('lastOut', '');
    var expRow;
    if (exp === 'idle') expRow = lnk('export', 'stone', 'Export my data', 'Quotes, clients, invoices and photos', '', '');
    else if (exp === 'prep') expRow = stat(mk('export', 'stone', 'Export my data', 'Preparing your files. We’ll email you too.'), 'Preparing', 'st-info si-q1');
    else expRow = btnRow('export', 'sage', 'Your export is ready', '214 MB · link works until Oct 6', 'Download', function () {}, 'btn-p');
    if (exp === 'idle') { expRow.isA = false; expRow.notA = true; expRow.isLink = false; expRow.isBtn = true; expRow.btn = 'Export'; expRow.act = function () { set({ exp: 'prep' }); setTimeout(function () { set({ exp: 'ready' }); }, 1800); }; }
    var typed = self.g('typed', '');
    var delOpen = self.g('delOpen', false) && !sched;
    return {
      roBanner: roBanner, sched: sched, cancelled: self.g('cancelled', false), tsOffBanner: !ts,
      warnIc: ic('warn', 'rose'), okIc: ic('check', 'sage'), shieldWarn: ic('shield', 'amber'),
      gSign: grp('Sign in', signRows, '', 60),
      gSessions: grp('Where you’re signed in', sess, lastOut ? 'Signed out of ' + lastOut + '.' : 'Don’t recognise one? Sign it out and change your password.', 120),
      signOutAll: function () { set({ chrome: false, ipad: false, lastOut: 'every other device' }); },
      onlyThis: others === 0, allStyle: others === 0 ? 'opacity: .45' : '',
      allLabel: others === 0 ? 'Only this phone is signed in' : 'Sign out everywhere else',
      gActivity: grp('Recent activity', [
        val('globe', 'azure', 'New sign-in', 'Chrome on Windows · Toronto', 'Sep 27', true),
        val('shield', 'indigo', ST === 'twoStepOff' ? 'Two-step turned off' : 'Two-step turned on', 'On this iPhone', 'Sep 2', true),
        val('key', 'violet', 'Password changed', 'On this iPhone', 'May 12', true)
      ], '', 180),
      gData: grp('Your data', [expRow], 'Keep records for 6 years for the CRA. An export is the easiest way.', 240),
      grace: [
        { ic: ic('clock', 'amber'), t: '30 days to change your mind', s: 'Sign in any time before Oct 29 to cancel. Nothing is lost.' },
        { ic: ic('lock', 'slate'), t: 'Client links stop working', s: 'Open quotes, invoices and the portal close on day 30.' },
        { ic: ic('warn', 'rose'), t: 'Then it’s erased for good', s: 'Quotes, clients, invoices, photos and crew hours.' }
      ],
      showDelBtn: !delOpen && !sched, delOpen: delOpen, typed: typed,
      openDelete: function () { set({ delOpen: true }); }, closeDelete: function () { set({ delOpen: false, typed: '' }); },
      onType: function (e) { set({ typed: e.target.value }); },
      delDisabled: typed.trim().toUpperCase() !== 'DELETE', delBtnStyle: typed.trim().toUpperCase() !== 'DELETE' ? 'opacity: .45' : '',
      confirmDelete: function () { if (self.g('typed', '').trim().toUpperCase() !== 'DELETE') return; set({ sched: true, delOpen: false, cancelled: false }); },
      cancelDelete: function () { set({ sched: false, cancelled: true }); }
    };
