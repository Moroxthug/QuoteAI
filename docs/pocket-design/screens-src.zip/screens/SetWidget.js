    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var seen = ST !== 'notInstalled';
    var SW = [['Brand colour, harbour blue', '#1F4F86'], ['Violet', '#6A2FBF'], ['Forest', '#1F7A45'], ['Brick', '#B4462B'], ['Teal', '#1E7F80'], ['Charcoal', '#2B2B30']];
    var bi = self.g('wc', 0), brand = SW[bi][1];
    var theme = self.g('wTheme', 0);
    var darkW = theme === 1;
    var F = [['fPhone', 'Phone'], ['fEmail', 'Email'], ['fPostal', 'Postal code']];
    var wFields = ['Your name'].concat(F.filter(function (f) { return self.g(f[0], f[0] !== 'fEmail' || true); }).map(function (f) { return f[1]; }));
    var copied = self.g('copied', false), mailed = self.g('mailed', false);
    var statusRows = seen ? [
      stat(mk('globe', 'azure', 'rossireno.ca/contact', 'Last seen 12 minutes ago'), 'Live', 'st-ok'),
      lnk('funnel', 'teal', 'Leads from your site', 'This month', '18', 'Leads.dc.html', true)
    ] : [
      stat(mk('globe', 'azure', 'rossireno.ca', 'Not seen on any page yet'), 'Not installed', 'st-mute'),
      lnk('eye', 'indigo', 'Open the test page', 'Try the form as a client would', '', '#')
    ];
    return {
      roBanner: roBanner, notSeen: !seen, warnIc: ic('warn', 'amber'),
      brandBg: 'background: ' + brand, brushIc: ic('brush', 'lilac'), swName: bi === 0 ? 'Matches your brand colour' : SW[bi][0],
      wSurface: darkW ? 'background: #1b1b1f; color: #f3f2ef' : 'background: #ffffff; color: #141416',
      wInput: darkW ? 'background: #2a2a30; color: #9d9ca4' : 'background: #f3f2ef; color: #8a8a90',
      kinds: ['Kitchen', 'Bathroom', 'Basement'].map(function (t, i) { return { t: t, style: i === 2 ? 'color: #ffffff; background: ' + brand : (darkW ? 'background: #2a2a30; color: #d0cfd5' : 'background: #f3f2ef; color: #3c3c43') }; }),
      wFields: wFields.slice(0, 3), btnText: self.g('instant', true) ? 'See my estimate' : 'Send request',
      gStatus: grp('', statusRows, '', 80),
      swatches: SW.map(function (s, i) { var on = i === bi; return { name: s[0], on: on, style: 'background: ' + s[1] + '; ' + (on ? 'box-shadow: 0 0 0 2px var(--card), 0 0 0 4px ' + s[1] + '; transform: scale(1.04)' : 'box-shadow: 0 0 0 1px var(--line2)'), pick: function () { set({ wc: i }); } }; }),
      gLook: (function (g) { g.rows[0].sep = 'border-top: 1px solid var(--line)'; return g; })(grp('Look', [
        seg('wTheme', 0, 'moon', 'slate', 'Background', '', ['Light', 'Dark', 'Match site']),
        seg('wStyle', 0, 'grid', 'lilac', 'Shows as', '', ['Form on the page', 'Floating button'])
      ], '', 130)),
      gFields: grp('What it asks', [
        val('user', 'violet', 'Name', 'Always asked', 'Required'),
        sw('fPhone', true, 'phone', 'sage', 'Phone', 'Needed for text follow-ups'),
        sw('fEmail', true, 'mail', 'sky', 'Email', ''),
        sw('fPostal', true, 'pin', 'clay', 'Postal code', 'Skips jobs outside your area'),
        sw('fPhotos', false, 'camera', 'amber', 'Photos', 'Up to 5 from their phone'),
        sw('fBudget', false, 'bars', 'teal', 'Budget range', ''),
        sw('instant', true, 'spark', 'violet', 'Instant estimate', 'A price range from your price book')
      ], '', 180),
      code: '<script src="https://quoteai.ca/w.js" data-key="wk_7Hq2LmR9" async><\/script>',
      copyLabel: copied ? 'Copied' : 'Copy code', copy: function () { set({ copied: true }); setTimeout(function () { set({ copied: false }); }, 1800); },
      mailLabel: mailed ? 'Sent' : 'Email to web person', mail: function () { set({ mailed: true }); },
      gCode: { rows: (function () { var r = [ val('key', 'violet', 'Widget key', 'Only works on rossireno.ca', 'wk_7Hq2LmR9', true), lnk('eye', 'indigo', 'Test page', 'Try the form as a client would', '', '#') ]; r[0].sep = 'border-top: 1px solid var(--line)'; r[1].sep = 'border-top: 1px solid var(--line)'; return r; })() },
      gLeads: grp('Where leads go', [
        lnk('funnel', 'teal', 'Leads', 'Tagged “Website”', 'Open', 'Leads.dc.html'),
        lnk('user', 'violet', 'Assign to', 'Who follows up first', 'Marco Rossi', '#'),
        sw('notify', true, 'bell', 'amber', 'Notify me', 'On this phone, right away'),
        sw('autoReply', true, 'chat', 'sky', 'Auto-reply', 'Texts the lead within a minute')
      ], '', 260)
    };
