#!/bin/bash
# build my screens: NAME TITLE H PROPS
S=/tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad
b(){ DC_PROPS="$4" python3 $S/kit/assemble.py $1 "$2" $S/screens/$1.body.html $S/screens/$1.js $3 >/dev/null && python3 $S/kit/normalize.py $S/screens/$1.body.html $S/screens/$1.js >/dev/null && DC_PROPS="$4" python3 $S/kit/assemble.py $1 "$2" $S/screens/$1.body.html $S/screens/$1.js $3 && cp $S/design/project/$1.dc.html $S/prev/ && sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/prev/$1.dc.html > $S/prev/$1_D.dc.html; }
for n in "$@"; do case $n in
Feedback) b Feedback "Send feedback" 844 '"state":{"editor":"enum","options":["compose","sending","sent","offline"],"default":"compose"},';;
HelpCentre) b HelpCentre "Help" ${HCH:-1700} '"state":{"editor":"enum","options":["default","search","noresults","offline"],"default":"default"},';;
VideoPlayer) b VideoPlayer "Video player" 844 '"video":{"editor":"enum","options":["quotes","overview"],"default":"quotes"},"state":{"editor":"enum","options":["playing","paused","buffering","offline"],"default":"playing"},';;
WhatsNew) b WhatsNew "What’s new" 844 '';;
CompanyPicker) b CompanyPicker "Choose company" 844 '"state":{"editor":"enum","options":["default","loading","opening","removed"],"default":"default"},';;
Dunning) b Dunning "Subscription payment" ${DUH:-1800} '"role":{"editor":"enum","options":["owner","teammate"],"default":"owner"},';;
esac; done
