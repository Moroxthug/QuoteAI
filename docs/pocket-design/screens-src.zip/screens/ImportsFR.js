    var step = this.g('step', this.props.step || 'source');
    var kind = this.g('kind', 0), prog = this.g('prog', 92), maps = this.g('maps', null), rev = this.g('rev', {}), errs = this.g('errs', {});
    var KINDS = ['Clients', 'Prix', 'Chantiers'];
    var FIELDS = ['Nom du client', 'Téléphone', 'Courriel', 'Adresse', 'Notes', 'Ne pas importer'];
    var COLS = [['Nom', 'Dana Whitfield', 0], ['Tél.', '416-555-0187', 1], ['Courriel', 'dana.w@rogers.com', 2], ['Rue', '17 Castle Frank Cres', 3], ['Commentaires', 'Porte de côté, chien gentil', 4], ['Solde', '0,00 $', 5]];
    var cur = maps || COLS.map(function (c) { return c[2]; });
    var segStyle = function (on) { return on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)'; };
    var go = function (s, extra) { return function () { set(Object.assign({ step: s }, extra || {})); }; };
    var pct = Math.min(100, Math.round(prog / 148 * 100));
    var R = [
      ['m1', 'Dana Whitfield', 'DW', 'tn1', 'Même courriel que votre client'],
      ['m2', 'Priya Nair', 'PN', 'tn2', 'Même téléphone · adresse changée'],
      ['m3', 'T. Hart', 'TH', 'tn4', 'Ressemble à Tom & Lena Hart']
    ];
    var E = [
      ['e1', 'Ligne 41', 'Sans nom', 'Ni nom ni courriel', 'Ignorer'],
      ['e2', 'Ligne 77', 'Marchetti Bakery', 'Téléphone 416-55 trop court', 'Corriger'],
      ['e3', 'Ligne 102', 'Gill Residence', 'En double · premier gardé', 'Ajouter']
    ];
    var revLeft = R.filter(function (r) { return !rev[r[0]]; }).length;
    var errLeft = E.filter(function (e) { return !errs[e[0]]; }).length;
    var kept = R.filter(function (r) { return rev[r[0]] === 'no'; }).length;
    return {
      isSource: step === 'source', notSource: step !== 'source', isMap: step === 'mapping', isRun: step === 'importing', isDone: step === 'done',
      hdrTitle: step === 'source' ? '' : 'Importer des ' + KINDS[kind].toLowerCase(),
      back: go(step === 'done' ? 'source' : step === 'importing' ? 'mapping' : 'source'),
      s1: 'on', s2: step === 'importing' || step === 'done' ? 'on' : '', s3: step === 'done' ? 'on' : '',
      kindInd: 'transform: translateX(' + (kind * 100) + '%)',
      kinds: KINDS.map(function (k, i) { return { label: k, on: i === kind, style: segStyle(i === kind), pick: function () { set({ kind: i }); } }; }),
      sources: [
        ['Fichier CSV ou Excel', 'Tout tableur, on associe les colonnes', 'file', 'azure', '', '', go('mapping', { prog: 92, maps: null })],
        ['QuickBooks Online', 'Dernière synchro le 27 sept.', 'bank', 'sage', 'Connecté', 'st-ok', go('mapping', { prog: 92, maps: null })],
        ['Jobber', 'Clients, soumissions et chantiers', 'sync', 'teal', 'Non connecté', 'st-mute si-off', function () {}],
        ['Anciennes soumissions PDF', 'L’IA lit les clients et les prix', 'doc', 'violet', '', '', function () {}]
      ].map(function (s) { return { label: s[0], sub: s[1], ic: ic(s[2], s[3]), status: s[4], st: s[5], hasSt: !!s[4], go: s[6] }; }),
      history: [
        ['Prix · soumission Chen.pdf', '18 sept. · 11 ajoutés', 'Terminé', 'st-mute si-check', 'doc', 'violet'],
        ['Clients · QuickBooks', '30 août · 62 ajoutés · 4 fusionnés', 'Terminé', 'st-mute si-check', 'bank', 'sage'],
        ['Chantiers · old-jobs.xlsx', '12 août · arrêté à la ligne 18', 'Échec', 'st-bad si-x', 'file', 'rose']
      ].map(function (h) { return { label: h[0], sub: h[1], status: h[2], st: h[3], ic: ic(h[4], h[5]) }; }),
      maps: COLS.map(function (c, i) {
        var to = FIELDS[cur[i]];
        return { col: c[0], ex: c[1], to: to, cls: cur[i] === 5 ? 'skip' : '', aria: c[0] + ' va dans ' + to,
          cycle: function () { var n = cur.slice(); n[i] = (n[i] + 1) % FIELDS.length; set({ maps: n }); } };
      }),
      preview: [
        { a: 'Dana Whitfield', b: '416-555-0187', c: '17 Castle Frank Cres' },
        { a: 'Okoye Condo', b: '647-555-0122', c: '88 Harbour St, app. 2104' },
        { a: 'Chen Family', b: '905-555-0164', c: '9 Thornhill Woods Dr' }
      ],
      syncIc: ic('users', 'sky'),
      importLabel: 'Importer 148 ' + KINDS[kind].toLowerCase(),
      start: go('importing', { prog: 92 }),
      pct: pct + ' %', doneN: String(Math.min(prog, 148)), ringOff: 'stroke-dashoffset: ' + (389.6 * (1 - pct / 100)).toFixed(1),
      runSteps: [
        { label: 'Lecture du fichier', sub: '148 lignes, 6 colonnes', status: 'Terminé', st: 'st-mute si-check', ic: ic('file', 'azure') },
        { label: 'Recherche de doublons', sub: '3 doublons possibles', status: prog >= 148 ? 'Terminé' : 'En cours', st: prog >= 148 ? 'st-mute si-check' : 'st-ok si-live', ic: ic('users', 'violet') },
        { label: 'Ajout des clients', sub: prog >= 148 ? '142 ajoutés' : 'En attente de la vérification', status: prog >= 148 ? 'Terminé' : 'En attente', st: prog >= 148 ? 'st-mute si-check' : 'st-warn si-clock', ic: ic('plus', 'sage') }
      ],
      tick: function () { if (prog >= 148) set({ step: 'done' }); else set({ prog: Math.min(148, prog + 56) }); },
      okBigIc: ic('check', 'sage'), doneTitle: '142 clients ajoutés',
      sum: [
        { label: 'Ajoutés', value: String(142 + kept), style: 'color: var(--ok)', sep: '' },
        { label: 'À vérifier', value: String(revLeft), style: revLeft ? 'color: var(--warn)' : '', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Ignorés', value: String(errLeft), style: errLeft ? 'color: var(--bad)' : '', sep: 'border-left: 1px solid var(--line)' }
      ],
      hasReview: true, reviewLeft: revLeft ? revLeft + ' restants' : 'Tout est fait',
      review: R.map(function (r, i) {
        var d = rev[r[0]];
        return { name: r[1], ini: r[2], tn: r[3], sub: d === 'yes' ? 'Fusionné avec votre client existant' : d === 'no' ? 'Ajouté comme nouveau client' : r[4],
          status: d === 'yes' ? 'Fusionné' : d === 'no' ? 'Nouveau client' : 'Semblable', st: d === 'yes' ? 'st-ok si-check' : d === 'no' ? 'st-info si-dot' : 'st-acc si-q2',
          open: !d, sep: i ? 'border-top: 1px solid var(--line)' : '',
          yes: function () { var n = Object.assign({}, rev); n[r[0]] = 'yes'; set({ rev: n }); },
          no: function () { var n = Object.assign({}, rev); n[r[0]] = 'no'; set({ rev: n }); } };
      }),
      errLeft: errLeft ? errLeft + ' lignes' : 'Aucune restante',
      errors: E.map(function (e) {
        var f = !!errs[e[0]];
        return { row: e[1], name: e[2], why: f ? (e[4] === 'Ignorer' ? 'Ignorée pour de bon' : 'Corrigée et ajoutée') : e[3], subStyle: f ? '' : 'color: var(--bad)', action: e[4], open: !f, fixed: f && e[4] !== 'Ignorer',
          fix: function () { var n = Object.assign({}, errs); n[e[0]] = true; set({ errs: n }); } };
      }),
      restart: go('source', { rev: {}, errs: {}, maps: null, prog: 92 })
    };
