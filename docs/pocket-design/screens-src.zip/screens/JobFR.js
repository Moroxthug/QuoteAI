    var t = this.g('t', 'overview');
    var money = function (n) { return n.toLocaleString('fr-CA', { maximumFractionDigits: 0 }).replace(/\s/g, ' ') + ' $'; };
    var money2 = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var TABS = [['overview', 'Aperçu'], ['schedule', 'Horaire'], ['co', 'Ordres de changement'], ['costs', 'Coûts'], ['inv', 'Factures'], ['team', 'Équipe'], ['photos', 'Photos'], ['msg', 'Messages'], ['docs', 'Documents'], ['ask', 'Assistant']];
    // blockers
    var sorted = this.g('sorted', {});
    var BL = [
      ['b1', 'AO', 'tn3', 'Amara Okafor', 'il y a 2 h', 'Question', 'st-warn si-clock', 'La boîte électrique derrière le bar est à 2 po du plan. On la déplace, ou on pose le gypse autour?'],
      ['b2', 'SM', 'tn2', 'Sofia Marin', 'Hier', 'Matériel', 'st-info si-dot', 'Il nous faut 6 feuilles de plus de gypse hydrofuge ½ po pour le mur de la salle de bain.']
    ];
    var blocks = BL.filter(function (b) { return !sorted[b[0]]; }).map(function (b) {
      return { ini: b[1], tn: b[2], who: b[3], when: b[4], kind: b[5], st: b[6], text: b[7], sort: function () { var o = Object.assign({}, sorted); o[b[0]] = true; set({ sorted: o }); } };
    });
    // budget
    var BUD = [['Matériaux', 6840, 9200], ['Main-d’œuvre', 7420, 11800], ['Sous-traitants', 2700, 5400], ['Permis et frais', 850, 850], ['Équipement', 410, 600], ['Divers', 160, 650]];
    var budget = BUD.map(function (b) {
      var r = b[1] / b[2];
      return { name: b[0], spent: money(b[1]), bud: money(b[2]), w: Math.min(100, Math.round(r * 100)) + '%', fill: r > 1 ? 'background: var(--bad)' : (r > 0.85 && b[0] !== 'Permis et frais') ? 'background: var(--warn-dot)' : '' };
    });
    // permits
    var added = this.g('permitAdded', false);
    var PER = [
      ['Permis de construction', 'Ville de Toronto · 26 148220 BLD', 'Délivré', 'st-info si-q1', 'shield', 'azure'],
      ['Permis d’électricité', 'ESA · déposé par Jonah Reyes', 'Délivré', 'st-info si-q1', 'shield', 'azure'],
      ['Inspection de l’isolation', 'Réussie le 24 sept. · inspecteur D. Moore', 'Réussie', 'st-ok si-check', 'check', 'sage'],
      ['Inspection finale', 'Réserver 48 h d’avance · après la peinture', 'Non réservée', 'st-warn si-clock', 'cal', 'amber']
    ];
    if (added) PER.push(['Permis de plomberie', 'Ville de Toronto · évier du bar', 'À demander', 'st-mute si-draft', 'shield', 'slate']);
    // tasks
    var td = this.g('td', { t1: true, t2: true, t3: true, t4: true, t5: false, t6: false });
    var TK = [['t1', 'Poser le gypse, salle familiale et chambre', ''], ['t2', 'Poser le gypse, salle de bain (hydrofuge)', ''], ['t3', 'Joints et 1re couche', ''], ['t4', 'Coins métalliques à la niche du bar', 'Du chantier · Amara'], ['t5', '2e couche, salle familiale', ''], ['t6', 'Sabler et apprêter', 'Du chantier · Sofia']];
    var tasks = TK.map(function (k) {
      var on = !!td[k[0]];
      return { name: k[1], site: k[2], on: on, cls: on ? 'on' : '', style: on ? 'color: var(--muted); text-decoration: line-through' : '', tog: function () { var o = Object.assign({}, td); o[k[0]] = !on; set({ td: o }); } };
    });
    var nDone = TK.filter(function (k) { return td[k[0]]; }).length;
    var MI = [
      ['Démolition et charpente', '8 – 12 sept.', '5 tâches sur 5', 'done'],
      ['Électricité et plomberie brutes', '14 – 18 sept.', '6 tâches sur 6', 'done'],
      ['Isolation et pare-vapeur', '21 – 24 sept.', '4 tâches sur 4', 'done'],
      ['Gypse', '25 sept. – 2 oct.', nDone + ' tâches sur 6', 'cur'],
      ['Peinture et moulures', '5 – 16 oct.', '7 tâches', 'up'],
      ['Plancher, bar et nettoyage final', '19 – 30 oct.', '8 tâches', 'up']
    ];
    var miles = MI.map(function (m, i) {
      var s = m[3];
      return {
        title: m[0], dates: m[1], tasks: m[2], done: s === 'done', open: s === 'cur',
        dot: s === 'done' ? 'dn' : s === 'cur' ? 'cu' : 'up',
        st: s === 'done' ? 'st-mute si-check' : s === 'cur' ? 'st-ok si-live' : 'st-mute', status: s === 'done' ? 'Terminée' : s === 'cur' ? 'En cours' : 'À venir',
        titleStyle: s === 'up' ? 'color: var(--t2)' : '', lnStyle: i === MI.length - 1 ? 'visibility: hidden' : s === 'done' ? 'background: var(--ok-dot)' : ''
      };
    });
    // crew weeks: j = this job, o = other, x = clash, '' = free
    var W = { AO: 'jjjjjjjjjjooooooo...', SM: 'jjjjjjjjj.jjjjjjjjjj', LB: 'oooo.xjjjjjjjjjooooo', JR: '..j.......o....jj...' };
    var TN = { AO: 'tn3', SM: 'tn2', LB: 'tn1', JR: 'tn4' };
    var crewWeeks = Object.keys(W).map(function (k) {
      var weeks = [0, 1, 2, 3].map(function (w) { return { days: W[k].slice(w * 5, w * 5 + 5).split('').map(function (c) { return { c: c === '.' ? '' : c }; }) }; });
      return { ini: k, tn: TN[k], weeks: weeks };
    });
    // costs
    var conf = this.g('conf', {});
    var RV = [['r1', 'Home Depot', 'Matériaux · sûr à 96 %', 412.18, 'receipt', 'amber'], ['r2', 'RONA', 'Matériaux · sûr à 91 %', 143.62, 'receipt', 'amber'], ['r3', 'Ace Tool Rental', 'Équipement · sûr à 88 %', 56.60, 'receipt', 'slate']];
    var review = RV.filter(function (r) { return !conf[r[0]]; }).map(function (r) {
      return { vendor: r[1], meta: r[2], amt: money2(r[3]), ic: ic(r[4], r[5]), ok: function () { var o = Object.assign({}, conf); o[r[0]] = true; set({ conf: o }); } };
    });
    var EN = [
      ['Gypse ½ po, 48 feuilles', 'Matériaux · Reçu · 23 sept.', 1248.00, 'box', 'amber'],
      ['Amara Okafor, 32 h', 'Main-d’œuvre · Temps · cette semaine', 1120.00, 'clock', 'teal'],
      ['Jonah Reyes, installation brute', 'Sous-traitants · Relevé bancaire · 18 sept.', 2700.00, 'bank', 'clay'],
      ['Permis de construction', 'Permis et frais · Manuel · 2 sept.', 850.00, 'shield', 'azure'],
      ['Monte-panneaux, 1 semaine', 'Équipement · Utilisation · 25 sept.', 210.00, 'truck', 'slate'],
      ['Trajets au chantier, 146 km', 'Divers · Déplacements · septembre', 97.00, 'pin', 'stone']
    ];
    // invoices
    var made = this.g('made', false), reminded = this.g('reminded', false);
    var terms = [
      ['Étape 1 · Dépôt', '20 % · INV-0388 · payée le 31 août', 7680, 'Payée', 'st-ok si-check'],
      ['Étape 2 · Installation brute faite', '25 % · INV-0401 · payée le 21 sept.', 9600, 'Payée', 'st-ok si-check'],
      ['Ordre de changement CO-01', 'INV-0412 · due le 20 sept.', 2340, '9 j de retard', 'st-bad'],
      ['Étape 3 · Gypse terminé', made ? '20 % · INV-0421 brouillon' : '20 % · due à la fin de l’étape', 7680, made ? 'Brouillon' : '', made ? 'st-mute' : '', !made],
      ['Étape 4 · Peinture et moulures', '20 % · 16 oct.', 7680, 'Ouverte', 'st-mute si-dot'],
      ['Étape 5 · Fin des travaux', '15 % · 30 oct. · moins la retenue de 10 %', 5760, 'Ouverte', 'st-mute si-dot'],
      ['Libération de la retenue', '10 % · 14 déc., après la période d’hypothèque légale', 3840, 'Retenue', 'st-warn si-pause']
    ].map(function (x) {
      return { name: x[0], meta: x[1], amt: money(x[2]), status: x[3], st: x[4], action: !!x[5], noAction: !x[5], actLabel: 'Créer', act: function () { set({ made: true }); } };
    });
    // team
    var appr = this.g('appr', {});
    var HR = [['h1', 'AO', 'tn3', 'Amara Okafor', '8,0 h', 'lun. 28 sept. · 7 h 31 – 15 h 34 · sur place', ''], ['h2', 'SM', 'tn2', 'Sofia Marin', '7,5 h', 'lun. 28 sept. · 8 h 02 – 15 h 40 · sur place', ''], ['h3', 'AO', 'tn3', 'Amara Okafor', '4,0 h', 'sam. 26 sept. · à 180 m du chantier', 'color: var(--warn)']];
    var hours = HR.map(function (h) {
      var d = !!appr[h[0]];
      return { ini: h[1], tn: h[2], name: h[3], hrs: h[4], meta: h[5], metaStyle: h[6], pending: !d, done: d, ok: function () { var o = Object.assign({}, appr); o[h[0]] = true; set({ appr: o }); } };
    });
    var crew = [['AO', 'tn3', 'Amara Okafor', 'Gypse · responsable de ce chantier', '96 h'], ['SM', 'tn2', 'Sofia Marin', 'Apprentie', '71,5 h'], ['DP', 'tn5', 'Dev Patel', 'Menuisier · charpente terminée', '48 h'], ['JR', 'tn4', 'Jonah Reyes', 'Électricien · sous-traitant', '22 h'], ['LB', 'tn1', 'Luca Bianchi', 'Chef peintre · dès le 5 oct.', '0 h']].map(function (c) { return { ini: c[0], tn: c[1], name: c[2], role: c[3], hrs: c[4] }; });
    // photos
    var sel = this.g('sel', [1, 4, 5]);
    var PH = [['28 sept.', 'photo', 'violet', 'p3'], ['28 sept.', 'house', 'stone', 'p0'], ['28 sept.', 'ruler', 'azure', 'p1'], ['25 sept.', 'hammer', 'clay', 'p5'], ['25 sept.', 'photo', 'sage', 'p4'], ['24 sept.', 'check', 'teal', 'p4'], ['22 sept.', 'cone', 'amber', 'p5'], ['18 sept.', 'bars', 'indigo', 'p1'], ['18 sept.', 'photo', 'slate', 'p2'], ['12 sept.', 'box', 'gold', 'p0'], ['10 sept.', 'house', 'sky', 'p1'], ['8 sept.', 'photo', 'rose', 'p3']];
    var photos = PH.map(function (p, i) {
      var on = sel.indexOf(i) >= 0;
      return { cap: p[0], ic: ic(p[1], p[2]), on: on, cls: p[3] + (on ? ' sel' : ''), label: 'Photo du ' + p[0], tog: function () { set({ sel: on ? sel.filter(function (x) { return x !== i; }) : sel.concat([i]) }); } };
    });
    var docs = [['Contrat C-2026-014', 'Signé par Tom et Lena · 28 août', 'doc', 'violet'], ['Ordre de changement CO-01', 'Signé le 19 sept.', 'pen', 'indigo'], ['Soumission Q-2026-107', 'Acceptée le 28 août', 'file', 'slate'], ['Factures', '3 envoyées · 1 brouillon', 'card', 'teal'], ['Reçus', '24 fichiers', 'receipt', 'amber'], ['Permis de construction', 'PDF · Ville de Toronto', 'shield', 'azure']].map(function (d) { return { name: d[0], meta: d[1], ic: ic(d[2], d[3]) }; });
    var PRI = { overview: 'Noter l’avancement', schedule: 'Noter l’avancement', co: 'Nouvel ordre de changement', costs: 'Numériser un reçu', inv: made ? 'Envoyer INV-0421' : 'Facturer l’étape 3', team: 'Saisir des heures', photos: sel.length ? 'Partager ' + sel.length + ' avec le client' : 'Prendre une photo', msg: 'Écrire au client', docs: 'Partager un document', ask: 'Demander à l’assistant' };
    var omwSent = this.g('omw', false);
    return {
      tabs: TABS.map(function (x) { var on = x[0] === t; return { label: x[1], cls: on ? 'on' : '', cur: on ? 'page' : 'false', pick: function () { set({ t: x[0] }); } }; }),
      tOverview: t === 'overview', tSchedule: t === 'schedule', tCO: t === 'co', tCosts: t === 'costs', tInv: t === 'inv', tTeam: t === 'team', tPhotos: t === 'photos', tMsg: t === 'msg', tDocs: t === 'docs', tAsk: t === 'ask',
      omw: function () { set({ omw: !omwSent }); }, omwLabel: omwSent ? 'Heure envoyée' : 'En route',
      omwIc: ic('send', 'teal'), camIc: ic('camera', 'indigo'), micIc: ic('mic', 'violet'),
      blocks: blocks, hasBlocks: blocks.length > 0, noBlocks: blocks.length === 0, blockCount: blocks.length ? blocks.length + (blocks.length > 1 ? ' ouverts' : ' ouvert') : 'Tout est réglé', okIc: ic('check', 'sage'),
      today: [
        { ini: 'AO', tn: 'tn3', name: 'Amara Okafor', what: 'Gypse · 2e couche', time: '7 h 30 – 15 h 30', status: 'Sur place', st: 'st-ok' },
        { ini: 'SM', tn: 'tn2', name: 'Sofia Marin', what: 'Gypse · sablage, chambre', time: '8 h – 16 h', status: 'Sur place', st: 'st-ok' },
        { ini: 'JR', tn: 'tn4', name: 'Jonah Reyes', what: 'Étiquettes du panneau · 1 h', time: 'Arrivée 10 h 40', status: 'En route', st: 'st-info' }
      ],
      nextIc: ic('hammer', 'violet'), budget: budget,
      permits: PER.map(function (p) { return { name: p[0], meta: p[1], status: p[2], st: p[3], ic: ic(p[4], p[5]) }; }),
      suggest: !added, addPermit: function () { set({ permitAdded: true }); }, orbIc: ic('orb', 'violet'),
      notes: [
        { text: 'La niche du bar sera 6 po plus profonde. Confirmé avec Tom sur place.', meta: 'Tapé · Marco · 22 sept.', ic: ic('pen', 'slate') },
        { text: 'Laisser une trappe d’accès pour le regard de nettoyage sous l’escalier.', meta: 'Dicté · Amara · hier', ic: ic('mic', 'violet') },
        { text: 'Tableau du panneau : les circuits 14 et 16 alimentent le sous-sol.', meta: 'D’après une photo · Jonah · 18 sept.', ic: ic('camera', 'indigo') }
      ],
      miles: miles, tasks: tasks, crewWeeks: crewWeeks, warnIc: ic('warn', 'rose'),
      cos: [
        { no: 'CO-01', title: 'Bar : installation brute et niche', meta: '+3 jours · signé le 19 sept.', amt: '3 955 $', status: 'Signé', st: 'st-ok' },
        { no: 'CO-02', title: 'Plafond insonorisé, salle familiale', meta: '+2 jours · envoyé le 27 sept.', amt: '1 840 $', status: 'En attente', st: 'st-info' },
        { no: 'CO-3', title: 'Spots, salle de séjour', meta: '+1 jour · envoyé le 29 sept.', amt: '1 120 $', status: 'À signer', st: 'st-warn si-clock' }
      ],
      scanIc: ic('camera', 'amber'), review: review, hasReview: review.length > 0, noReview: review.length === 0, reviewCount: review.length ? review.length + (review.length > 1 ? ' reçus' : ' reçu') : 'Terminé',
      entries: EN.map(function (e) { return { name: e[0], meta: e[1], amt: money2(e[2]), ic: ic(e[3], e[4]) }; }),
      terms: terms, remind: function () { set({ reminded: true }); }, remindLabel: reminded ? 'Envoyé' : 'Relancer',
      hours: hours, approveAll: function () { set({ appr: { h1: true, h2: true, h3: true } }); }, crew: crew, pinIc: ic('pin', 'rose'),
      photos: photos, hasSel: sel.length > 0, photoHead: sel.length ? sel.length + ' sur 12 sélectionnées' : '12 photos', selLabel: sel.length ? 'Effacer' : 'Sélectionner', clearSel: function () { set({ sel: sel.length ? [] : [0] }); },
      photoIc: ic('photo', 'sky'), syncIc: ic('sync', 'azure'),
      globeIc: ic('globe', 'azure'), copy: function () { set({ copied: true }); }, copyLabel: this.g('copied', false) ? 'Copié' : 'Copier le lien',
      docs: docs, primary: PRI[t]
    };
