    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var clockedIn = this.g('clock', mode !== 'clockedOut');
    var justClocked = this.g('justClocked', false);
    var sorted = this.g('sorted', {}), done = this.g('done', { t1: true, t2: true });
    var appr = this.g('appr', { amara: true }), sent = this.g('sent', false), nudged = this.g('nudged', false);
    var rsorted = this.g('rsorted', {}), ask = this.g('ask', '');
    var markSorted = function (k) { var n = Object.assign({}, self.g('sorted', {})); n[k] = true; set({ sorted: n }); };
    var cls = function (t, s) { return 'st-' + t + ' si-' + s; };

    var blockers = [
      ['b1', 'Il manque 6 feuilles de gypse ½ po', 'Amara · Galloway Rd · le plafond de la chambre 2 attend leur arrivée', ic('bricks', 'clay')],
      ['b2', 'Le spot au-dessus de l’escalier touche une solive', 'Jonah · Galloway Rd · décision requise pour le déplacer de 8 po', ic('bolt', 'amber')]
    ];
    var openB = 0;
    var bl = blockers.map(function (b, i) {
      var isS = !!sorted[b[0]]; if (!isS) openB++;
      return { title: b[1], sub: b[2], ic: b[3], open: !isS, word: isS ? 'Réglé' : 'Blocage', cls: isS ? cls('mute', 'check') : cls('bad', 'alert'),
        strike: isS ? 'color: var(--muted); text-decoration: line-through' : '', sep: i ? 'border-top: 1px solid var(--line)' : '',
        answer: function () { set({ ask: 'Re : ' + b[1] + ' · ' }); }, sort: function () { markSorted(b[0]); } };
    });

    var crew = [
      ['AO', 'Amara Okafor', 'Gypse · Galloway Rd', 'Sur place', cls('ok', 'live'), 'depuis 7 h 05', 'tn1', 'var(--ok-dot)'],
      ['SM', 'Sofia Marin', 'Apprentie · Galloway Rd', 'Sur place', cls('ok', 'live'), 'depuis 7 h 20', 'tn2', 'var(--ok-dot)'],
      ['DP', 'Dev Patel', 'Menuisier · Okoye Condo', 'Ailleurs', cls('info', 'q1'), 'depuis 7 h 40', 'tn4', 'var(--info)'],
      ['JR', 'Jonah Reyes', 'Électricien, sous-traitant · Galloway Rd', 'Plus tard', cls('warn', 'clock'), 'dès 13 h', 'tn3', 'var(--warn-dot)']
    ].map(function (c) { return { ini: c[0], name: c[1], sub: c[2], word: c[3], cls: c[4], time: c[5], tn: c[6], dot: 'background: ' + c[7] }; });

    var TASKS = [
      ['t1', 'Poser le plafond, chambre 1', 'Amara, Sofia'],
      ['t2', 'Coupe-feu autour du panneau', 'Amara · photo requise'],
      ['t3', 'Poser le plafond, chambre 2', 'Amara · attend 6 feuilles'],
      ['t4', 'Inspection de l’électricité brute', 'Ville de Toronto · 14 h'],
      ['t5', 'Rapport du jour et photos', 'Vous · avant 15 h 30']
    ];
    var nDone = 0;
    var tasks = TASKS.map(function (t) {
      var d = !!done[t[0]]; if (d) nDone++;
      return { title: t[1], sub: t[2], done: d, aria: 'Fait : ' + t[1], late: t[0] === 't3' && !d,
        strike: d ? 'color: var(--muted); text-decoration: line-through' : '',
        tickStyle: d ? 'background: var(--ok-dot); color: #ffffff' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
        svgStyle: d ? '' : 'opacity: 0',
        tog: function () { var n = Object.assign({}, self.g('done', { t1: true, t2: true })); n[t[0]] = !n[t[0]]; set({ done: n }); } };
    });

    var waits = [
      ['Ordre de changement : 2 spots de plus', 'Demandé par les Hart dimanche · Marco doit chiffrer et envoyer', 'En attente', cls('warn', 'clock'), ic('doc', 'violet')],
      ['Livraison de gypse en appoint', '6 feuilles ½ po, 2 boîtes de vis · pour jeudi matin', 'À confirmer', cls('warn', 'clock'), ic('truck', 'azure')],
      ['Couleur de peinture pour Harbourfront', 'Murs de la réception · choix du client d’ici mer.', 'En attente', cls('warn', 'clock'), ic('brush', 'rose')]
    ].map(function (w) { return { title: w[0], sub: w[1], word: w[2], cls: w[3], ic: w[4] }; });

    var HRS = [
      ['amara', 'AO', 'Amara Okafor', 'lun. 8,0 · mar. 2,8 jusqu’ici', 10.8, 'tn1'],
      ['sofia', 'SM', 'Sofia Marin', 'lun. 8,0 · mar. 2,5 jusqu’ici', 10.5, 'tn2'],
      ['dev', 'DP', 'Dev Patel', 'lun. 9,5 · 1,5 h de plus', 12.1, 'tn4'],
      ['jonah', 'JR', 'Jonah Reyes', 'lun. 4,0 · sous-traitant, sur facture', 4.0, 'tn3']
    ];
    var nAppr = 0, tot = 0;
    var hours = HRS.map(function (h) {
      var a = !!appr[h[0]]; if (a) nAppr++; tot += h[4];
      var over = h[0] === 'dev';
      var st = sent ? ['Envoyées', cls('info', 'q1')] : a ? ['Approuvées', cls('ok', 'check')] : over ? ['Temps supp.', cls('warn', 'clock')] : ['À approuver', cls('warn', 'clock')];
      var setA = function (v) { return function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); var n = Object.assign({}, self.g('appr', { amara: true })); n[h[0]] = v; set({ appr: n }); }; };
      return { ini: h[1], name: h[2], sub: h[3], hrs: h[4].toFixed(1).replace('.', ',') + ' h', tn: h[5], word: st[0], cls: st[1],
        acts: a ? [{ label: 'Annuler', ic: ic('sync', 'slate'), cls: 'sw-mute', go: setA(false) }, { label: 'Modifier', ic: ic('pen', 'violet'), cls: 'sw-acc', go: function () {} }]
                : [{ label: 'Approuver', ic: ic('check', 'sage'), cls: 'sw-ok', go: setA(true) }, { label: 'Question', ic: ic('chat', 'amber'), cls: 'sw-warn', go: setA(false) }] };
    });
    var allA = nAppr === HRS.length;

    var reports = [
      ['r1', 'AO', 'Amara Okafor', 'Galloway Rd', '8 h 02', 'Tache d’eau sur le mur nord derrière la fournaise. C’est sec, mais je ne veux pas poser le gypse sans que quelqu’un vérifie.', ['4', ''], 'tn1'],
      ['r2', 'DP', 'Dev Patel', 'Okoye Condo', '8 h 40', 'Le sous-plancher descend d’environ ¼ po près du placard. On le nivelle avant les planches, une demi-journée de plus.', ['2', ''], 'tn4']
    ];
    var nOpenR = 0;
    var reps = reports.map(function (r) {
      var s = rsorted[r[0]], cost = r[0] === 'r2';
      if (!s) nOpenR++;
      var st = s ? ['Réglé', cls('mute', 'check')] : cost ? ['Coûts à revoir', cls('acc', 'q2')] : ['Nouveau', cls('info', 'dot')];
      return { ini: r[1], name: r[2], where: r[3], when: r[4], text: r[5], tn: r[7], word: st[0], cls: st[1], open: !s,
        photos: [{ ic: ic('photo', 'sky'), n: '1/' + r[6][0] }, { ic: ic('photo', 'teal'), n: '2/' + r[6][0] }],
        sort: function () { var n = Object.assign({}, self.g('rsorted', {})); n[r[0]] = true; set({ rsorted: n }); } };
    });

    var sites = [
      ['Finition du sous-sol · Hart', 'Étape du gypse · ensuite : joints le 2 oct.', 64, 'Sur place', cls('ok', 'live')],
      ['Plancher du corridor · Okoye Condo', 'Préparation du sous-plancher · ensuite : planches le 1er oct.', 30, 'Sur place', cls('ok', 'live')],
      ['Repeinture de la réception · Harbourfront', 'Préparation et apprêt · Luca, Sofia', 0, 'Début jeu.', cls('warn', 'clock')]
    ].map(function (s, i) { return { name: s[0], sub: s[1], pct: s[2] + ' %', bar: 'width: ' + Math.max(s[2], 2) + '%; background: ' + (s[2] ? 'var(--ok-dot)' : 'var(--line2)'), word: s[3], cls: s[4], sep: i ? 'border-top: 1px solid var(--line)' : '' }; });

    var next = [
      ['14 h', 'Inspection brute', 'Galloway Rd · soyez sur place'],
      ['15 h 30', 'Rapport du jour dû', 'Photos du plafond de la chambre 1'],
      ['mer.', 'Visite chez Harbourfront', 'Queens Quay W · 7 h 30'],
      ['jeu.', 'Livraison de gypse en appoint', 'Galloway Rd · 8 h–10 h'],
      ['ven.', 'Envoyer les heures au bureau', 'Semaine du 28 sept.']
    ].map(function (n) { return { when: n[0], title: n[1], sub: n[2] }; });

    var toggleClock = function () { set({ clock: !self.g('clock', mode !== 'clockedOut'), justClocked: true }); };
    return {
      offline: offline, pending: offline ? 2 + (justClocked ? 1 : 0) : 0, cloudIc: ic('cloud', 'amber'),
      askPh: offline ? 'Signalez, l’envoi se fera plus tard' : 'Demander ou signaler', ask: ask, onAsk: function (e) { set({ ask: e.target.value }); },
      clockWord: clockedIn ? 'Sur place' : 'Pas pointé', clockCls: clockedIn ? cls('ok', 'live') : cls('mute', 'off'),
      timer: clockedIn ? (justClocked && mode === 'clockedOut' ? '0 h 00' : '2 h 41') : (justClocked ? '2 h 41' : '0 h 00'),
      timerStyle: clockedIn ? '' : 'color: var(--faint)',
      clockSub: clockedIn ? (justClocked && mode === 'clockedOut' ? 'Arrivée pointée · 48 Galloway Rd' : 'Depuis 7 h 12 · Galloway Rd') : (justClocked ? 'Départ pointé' : 'Équipe arrivée à 7 h 05 à Galloway Rd'),
      clockBtn: clockedIn ? 'Pointer le départ' : 'Pointer l’arrivée', clockBtnCls: clockedIn ? 'btn-s' : 'btn-p', toggleClock: toggleClock,
      clockSaved: offline && justClocked,
      blockers: bl, blockLbl: openB ? openB + (openB > 1 ? ' ouverts' : ' ouvert') : 'Tout est réglé',
      quick: [
        { label: 'Horaire', ic: ic('cal', 'violet'), href: 'Schedule.dc.html' },
        { label: 'Travaux', ic: ic('hammer', 'clay'), href: 'Jobs.dc.html' },
        { label: 'Heures', ic: ic('clock', 'teal'), href: 'CrewHours.dc.html' },
        { label: 'Équipe', ic: ic('users', 'azure'), href: 'CrewNow.dc.html' }
      ],
      crew: crew, crewLbl: '3 sur place · 1 plus tard',
      tasks: tasks, taskLbl: nDone + ' sur ' + TASKS.length + ' faites',
      waits: waits, waitCount: '3', nudge: function () { set({ nudged: true }); }, nudgeLbl: nudged ? (offline ? 'Relance gardée, envoi plus tard' : 'Marco relancé') : 'Relancer Marco',
      hours: hours, hrsTotal: tot.toFixed(1).replace('.', ',') + ' h',
      approveAll: function () { set({ appr: { amara: true, sofia: true, dev: true, jonah: true } }); },
      approveAllStyle: allA || sent ? 'display: none' : '',
      sendHours: function () { if (allA) set({ sent: true }); },
      sendLbl: sent ? (offline ? 'En file' : 'Envoyées au bureau') : 'Envoyer',
      sendStyle: sent ? 'background: var(--ok-soft); color: var(--ok)' : allA ? '' : 'opacity: .4',
      reports: reps, fieldLbl: nOpenR ? nOpenR + (nOpenR > 1 ? ' ouverts' : ' ouvert') : 'Tout est réglé',
      sites: sites, next: next
    };
