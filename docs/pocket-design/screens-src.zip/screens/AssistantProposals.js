    var st = this.props.state || 'default';
    var offline = st === 'offline', ro = st === 'readonly', locked = st === 'locked', emptySt = st === 'empty';
    var dec = this.g('dec', {}), edits = this.g('edits', {}), editing = this.g('editing', null), toast = this.g('toast', null);
    var P = [
      { id: 'hart', gl: 'bell', tone: 'amber', kind: 'msg', title: 'Send a reminder to Tom & Lena Hart', meta: 'INV-0412 · $2,340.00 · 9 days overdue', doLabel: 'It will text', channel: 'SMS to Tom Hart',
        draft: 'Hi Tom and Lena, a quick reminder that invoice INV-0412 for $2,340.00 was due Sep 20. You can pay by card or e-Transfer here: pay.quoteai.ca/r/0412. Thanks, Marco',
        why: 'It’s 9 days late. The Harts paid the last two invoices within a day of a nudge.', done: 'Reminder sent to the Harts', word: 'Sent', cls: 'st-info si-q1', editLabel: 'Text to Tom Hart' },
      { id: 'drywall', gl: 'truck', tone: 'clay', kind: 'order', title: 'Reorder drywall for the Hart basement', meta: 'Home Depot Pro · delivery Thu 7 am', doLabel: 'It will order', channel: 'Supplier order',
        items: [['30 × drywall 1/2 in, 4 × 8 ft', '$441.00'], ['2 × drywall screws, 5 lb', '$45.20'], ['Delivery to 48 Galloway Rd', '$0.00']], totLabel: 'Total before HST', total: '$486.20',
        why: 'Amara logged 6 sheets left and the ceiling needs 36 on Thursday. It’s over your $300 order limit, so it asked.', done: 'Drywall ordered for Thursday', word: 'Ordered', cls: 'st-info si-q1', editHref: 'Supplier.dc.html' },
      { id: 'gill', gl: 'cal', tone: 'sky', kind: 'move', title: 'Move the Gill deck stain to Wednesday', meta: 'Gill Residence · deck refinish', doLabel: 'It will move', channel: 'Schedule',
        from: 'Thu Oct 1', fromSub: '80% rain after 10 am', to: 'Wed Sep 30', toSub: 'Dry, 16°', note: 'Luca and Sofia are free Wednesday. It texts them the new day and emails the Gills.',
        why: 'Stain needs 24 dry hours to cure. Thursday’s forecast turned wet overnight.', done: 'Deck stain moved to Wed Sep 30', word: 'Moved', cls: 'st-ok si-check', editHref: 'Schedule.dc.html' },
      { id: 'priya', gl: 'mail', tone: 'violet', kind: 'msg', title: 'Draft a follow-up for Priya Nair', meta: 'Q-2026-118 · kitchen backsplash · $1,865.10', doLabel: 'It will email', channel: 'Email to Priya',
        subj: 'Your backsplash quote', draft: 'Hi Priya, just checking in on the backsplash quote. Happy to walk through the tile options or adjust the layout. We can start the week of Oct 12 if that works. Marco',
        why: 'She opened the quote three times since Friday and hasn’t replied. It expires Oct 8.', done: 'Follow-up sent to Priya', word: 'Sent', cls: 'st-info si-q1', editLabel: 'Email to Priya' }
    ];
    if (emptySt || locked) P = [];
    var showToast = function (b, s, ids) {
      var tid = Date.now();
      set({ toast: { b: b, s: s, ids: ids, id: tid } });
      setTimeout(function () { var t = self.g('toast', null); if (t && t.id === tid) set({ toast: null }); }, 10000);
    };
    var decide = function (ids, how, extra) {
      var n = Object.assign({}, self.g('dec', {}));
      ids.forEach(function (id) { n[id] = how; });
      var o = Object.assign({ dec: n, editing: null }, extra || {});
      set(o);
    };
    var undo = function (ids) { var n = Object.assign({}, self.g('dec', {})); ids.forEach(function (id) { delete n[id]; }); set({ dec: n, toast: null }); };
    var props = P.map(function (p) {
      var d = dec[p.id], isEd = editing === p.id;
      if (d === 'dismissed') return null;
      var draft = edits[p.id] || p.draft;
      var approved = d === 'approved';
      return {
        title: p.title, meta: p.meta, ic: ic(p.gl, p.tone), open: !approved, closed: approved,
        doLabel: p.doLabel, channel: p.channel, isMsg: p.kind === 'msg', isOrder: p.kind === 'order', isMove: p.kind === 'move',
        hasSubj: !!p.subj, subj: p.subj || '', draft: draft, showDo: !isEd,
        items: (p.items || []).map(function (x) { return { name: x[0], amt: x[1] }; }), totLabel: p.totLabel || '', total: p.total || '',
        from: p.from || '', fromSub: p.fromSub || '', to: p.to || '', toSub: p.toSub || '', note: p.note || '',
        why: p.why, editing: isEd, notEditing: !isEd, editInline: p.kind === 'msg', editLink: p.kind !== 'msg', editHref: p.editHref || '#',
        fid: 'ed-' + p.id, editLabel: p.editLabel || '',
        onEdit: function (e) { var n = Object.assign({}, self.g('edits', {})); n[p.id] = e.target.value; set({ edits: n }); },
        edit: function () { set({ editing: p.id }); },
        cancelEdit: function () { set({ editing: null }); },
        saveEdit: function () { decide([p.id], 'approved'); showToast(offline ? 'Saved.' : 'Approved.', offline ? 'Sends when you’re back online.' : p.done + '.', [p.id]); },
        approve: function () { decide([p.id], 'approved'); showToast(offline ? 'Saved.' : 'Approved.', offline ? 'Sends when you’re back online.' : p.done + '.', [p.id]); },
        dismiss: function () { decide([p.id], 'dismissed'); showToast('Dismissed.', 'It won’t suggest this again for this job.', [p.id]); },
        undo: function () { undo([p.id]); },
        doneText: offline ? p.title : p.done, doneWord: offline ? 'Sends when online' : p.word, doneSt: offline ? 'st-warn si-clock' : p.cls
      };
    }).filter(Boolean);
    var pending = P.filter(function (p) { return !dec[p.id]; });
    var n = pending.length;
    var words = ['Nothing', 'One thing', 'Two things', 'Three things', 'Four things'];
    var title = locked ? 'Your assistant' : (n ? words[n] + ' to approve' : 'All caught up');
    var sub = locked ? 'Proposals from the assistant show up here once it’s on your plan.' : (n ? 'Nothing goes out until you say yes.' : 'Nothing is waiting on you right now.');
    var R = [
      ['receipt', 'amber', '$212.40 cost added to Hart', 'Home Depot receipt · 10:12 am', 'Approved', 'st-ok si-check'],
      ['doc', 'indigo', 'Okoye change order draft', 'Hallway trim · 9:30 am', 'Dismissed', 'st-mute' + ' si-x'],
      ['bank', 'gold', 'Chen e-Transfer, $1,200.00', 'No match for INV-0415 · 8:31 am', 'Failed', 'st-bad si-x'],
      ['receipt', 'violet', 'Harbourfront invoice draft', 'INV-0421 · $3,210.00 · 7:05 am', '', '', 'Open', 'Invoice.dc.html']
    ];
    var recent = R.map(function (r) { return { ic: ic(r[0], r[1]), t: r[2], s: r[3], word: r[4], st: r[5], hasSt: !!r[4] && r[4] !== 'Failed', hasBtn: !!r[6] || r[4] === 'Failed', btn: r[6] || 'Retry', href: r[7] || '#' }; });
    return {
      title: title, sub: sub, offline: offline, readonly: ro, locked: locked, ro: ro,
      pendingCount: String(n), hasCount: !locked && n > 0,
      listTitle: n ? 'Waiting for you' : 'Just approved', hasPending: props.length > 0, props: props, canBatch: n > 1 && !ro,
      approveAllLabel: 'Approve all ' + n,
      approveAll: function () { var ids = pending.map(function (p) { return p.id; }); decide(ids, 'approved'); showToast(ids.length + ' approved.', offline ? 'They send when you’re back online.' : 'Reminders, order and schedule change are on their way.', ids); },
      allClear: !locked && props.length === 0,
      showRecent: !locked && !emptySt, recent: recent,
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '', toastUndo: function () { var t = self.g('toast', null); if (t) undo(t.ids); },
      cloudIc: ic('cloud', 'amber'), eyeIc: ic('eye', 'sky'), lockIc: ic('lock', 'violet'), checkIc: ic('check', 'sage')
    };
