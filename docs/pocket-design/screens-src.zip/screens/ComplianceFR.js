    var mode = this.props.state || 'default';
    var acct = mode === 'accountant', empty = mode === 'empty', canEdit = !acct && !empty;
    var filed = self.g('filed', {}), proof = self.g('proof', {}), rem = self.g('rem', { hst: true }), sel = self.g('sel', 'van'), flt = self.g('flt', 'all');
    var emptyVals = self.g('ev', {});
    // id, title, needed, date, day offset, kind (overdue|due|later|filed), amount, glyph, tone, done label
    var D = [
      ['van', 'Plaque du fourgon', 'Ford Transit · renouveler sur ServiceOntario, puis ajouter le reçu', '26 sept.', -3, 'overdue', '', 'truck', 'clay', 'Marquer renouvelé'],
      ['pay9', 'Remise de paie, septembre', 'Retenues à la source de 5 personnes', '15 oct.', 16, 'due', '4 386,20 $', 'bank', 'sage', 'Marquer payé'],
      ['wsib', 'Attestation WSIB', 'Expire le 20 oct. Harbourfront Dental veut une copie.', '20 oct.', 21, 'due', '', 'shield', 'teal', 'Marquer renouvelé'],
      ['hst', 'Déclaration TVH, T3', '1er juil. au 30 sept. · feuille de calcul prête', '31 oct.', 32, 'due', '6 212,00 $', 'percent', 'violet', 'Marquer produite'],
      ['ins', 'Assurance RC', 'Responsabilité civile de 2 M$ · ajouter le nouveau certificat', '14 nov.', 46, 'due', '', 'shield', 'azure', 'Marquer renouvelé'],
      ['pay10', 'Remise de paie, octobre', 'Retenues à la source, depuis Paie', '16 nov.', 48, 'due', '', 'bank', 'sage', 'Marquer payé'],
      ['pay11', 'Remise de paie, novembre', 'Retenues à la source, depuis Paie', '15 déc.', 77, 'due', '', 'bank', 'sage', 'Marquer payé'],
      ['t4a', 'T4A des sous-traitants', 'Jonah Reyes et 2 autres payés 500 $ ou plus en 2026', '28 févr.', 152, 'later', '', 'users', 'indigo', 'Marquer produite'],
      ['lic', 'Permis d’entrepreneur', 'Permis de rénovateur de la Ville de Toronto · renouveler en ligne', '31 mars', 183, 'later', '', 'doc', 'amber', 'Marquer renouvelé'],
      ['hstq2', 'Déclaration TVH, T2', 'Produite le 28 juil. · confirmation 4471 0092', '31 juil.', -60, 'filed', '5 140,75 $', 'percent', 'violet', ''],
      ['pay8', 'Remise de paie, août', 'Payée le 14 sept. depuis le compte d’entreprise RBC', '15 sept.', -14, 'filed', '4 212,60 $', 'bank', 'sage', '']
    ];
    var kindOf = function (d) { return filed[d[0]] ? 'filedNow' : d[5]; };
    var ST = { overdue: 'st-bad si-alert', due: 'st-warn si-clock', later: 'st-mute si-clock', filed: 'st-ok si-check', filedNow: 'st-ok si-check' };
    var word = function (d, k) {
      if (k === 'overdue') return (0 - d[4]) + ' j de retard';
      if (k === 'filed') return 'Produite';
      if (k === 'filedNow') return d[9] === 'Marquer payé' ? 'Payé aujourd’hui' : (d[9] === 'Marquer renouvelé' ? 'Renouvelé auj.' : 'Produite auj.');
      if (k === 'later') return 'Dû le ' + d[3];
      return (d[0] === 'wsib' ? 'Expire le ' : (d[0] === 'ins' ? 'Renouv. le ' : 'Dû le ')) + d[3];
    };
    var flip = function (key, id) { var o = Object.assign({}, self.g(key, key === 'rem' ? { hst: true } : {})); o[id] = !o[id]; var p = {}; p[key] = o; set(p); };
    var item = function (d) {
      var k = kindOf(d), isF = k === 'filed' || k === 'filedNow';
      return {
        id: d[0], title: d[1], sub: k === 'filedNow' ? 'Aujourd’hui · ' + (proof[d[0]] ? 'preuve ajoutée' : 'ajoutez une preuve pour vos dossiers') : d[2], amt: d[6], amtStyle: d[6] ? '' : 'display: none',
        ic: ic(d[7], d[8]), st: ST[k], word: word(d, k), selCls: sel === d[0] ? 'sel' : '',
        open: sel === d[0], pick: function () { set({ sel: d[0] }); },
        acts: canEdit && !isF && sel === d[0], undo: canEdit && k === 'filedNow' && sel === d[0], dl: acct && sel === d[0] && (isF || d[0] === 'hst' || d[0] === 'pay9'),
        dlLabel: isF ? 'Télécharger la preuve' : 'Télécharger la feuille',
        doneLabel: d[9], file: function () { flip('filed', d[0]); },
        upLabel: proof[d[0]] ? 'Preuve ajoutée' : 'Joindre une preuve', upStyle: proof[d[0]] ? 'color: var(--ok)' : '', upload: function () { flip('proof', d[0]); },
        remLabel: rem[d[0]] ? 'Rappel actif' : 'Me le rappeler', remStyle: rem[d[0]] ? 'color: var(--acc-t)' : '', remind: function () { flip('rem', d[0]); }
      };
    };
    var all = D.map(function (d) { return { d: d, k: kindOf(d) }; });
    var pick = function (ks) { return all.filter(function (x) { return ks.indexOf(x.k) > -1; }).map(function (x) { return item(x.d); }); };
    var late = pick(['overdue']), soon = pick(['due']), later = pick(['later']), done = pick(['filedNow', 'filed']);
    var G = [];
    if (flt === 'all' || flt === 'overdue') G.push({ title: 'En retard', sub: late.length ? '1 à traiter' : '', items: late });
    if (flt === 'all' || flt === 'due') G.push({ title: '90 prochains jours', sub: soon.length + ' échéances', items: soon });
    if (flt === 'all' || flt === 'due') G.push({ title: 'Plus tard', sub: '', items: later });
    if (flt === 'all' || flt === 'filed') G.push({ title: 'Réglées', sub: 'Les plus récentes', items: done });
    G = G.filter(function (g) { return g.items.length; });
    var marks = D.filter(function (d) { return d[4] <= 90 && (d[5] === 'overdue' || d[5] === 'due'); }).map(function (d, i) {
      var k = kindOf(d), pct = Math.max(3.5, Math.min(96, d[4] / 90 * 100));
      var col = k === 'overdue' ? 'var(--bad)' : (k === 'filedNow' ? 'var(--ok-dot)' : 'var(--warn-dot)');
      return { left: pct.toFixed(1) + '%', date: d[3], lane: i % 2 ? 'cp-dn' : 'cp-up', dot: 'background: ' + col, cls: sel === d[0] ? 'on' : '', aria: d[1] + ', ' + d[3], pick: function () { set({ sel: d[0] }); } };
    });
    var sd = D.filter(function (d) { return d[0] === sel; })[0] || D[2];
    var sk = kindOf(sd);
    var hstK = kindOf(D[3]);
    var nOver = late.length, nSoon = all.filter(function (x) { return x.k === 'due' && x.d[4] <= 30; }).length;
    var EV = [['Déclaration TPS/TVH', ['Trimestrielle', 'Mensuelle', 'Annuelle'], 'percent', 'violet'], ['Fin d’exercice', ['31 déc.', '31 mars', '30 juin'], 'cal', 'sky'], ['Remises de paie', ['Mensuelles', 'Trimestrielles', 'Aucune paie'], 'bank', 'sage'], ['Acomptes provisionnels', ['Trimestriels', 'Aucun'], 'receipt', 'amber'], ['Attestation WSIB', ['Suivre', 'Non requise'], 'shield', 'teal'], ['Feuillets sous-traitants', ['T4A et T5018', 'T5018 seul', 'Désactivé'], 'users', 'indigo']];
    return {
      isAcct: acct, isEmpty: empty, hasData: !empty, canEdit: canEdit,
      eyeIc: ic('eye', 'sky'), hstIc: ic('percent', 'violet'), okIc: ic('check', 'sage'), calIc: ic('cal', 'sky'),
      kpis: [
        { label: 'En retard', value: String(nOver), sub: nOver ? 'Plaque du fourgon' : 'Tout est à jour', style: nOver ? 'color: var(--bad)' : '' },
        { label: '30 prochains jours', value: String(nSoon), sub: 'Paie, WSIB', style: '' },
        { label: 'Réglées en 2026', value: String(11 + Object.keys(filed).filter(function (k) { return filed[k]; }).length), sub: 'Dans les délais', style: '' }
      ],
      hst: { st: ST[hstK], word: word(D[3], hstK), btn: filed.hst ? 'Annuler' : 'Marquer produite', toggle: function () { flip('filed', 'hst'); }, ws: acct ? 'Télécharger la feuille' : 'Ouvrir la feuille' },
      marks: marks,
      selItem: { title: sd[1], when: sd[3] + (sd[4] >= 0 ? ' · dans ' + sd[4] + '\xa0jours' : ' · il y a ' + (0 - sd[4]) + '\xa0jours'), st: ST[sk], word: word(sd, sk) },
      filters: [['all', 'Toutes', D.length], ['due', 'À venir', soon.length + later.length], ['overdue', 'En retard', late.length], ['filed', 'Réglées', done.length]].map(function (f) { var on = f[0] === flt; return { label: f[1], count: f[2], on: on, cls: on ? 'on' : '', pick: function () { set({ flt: f[0] }); } }; }),
      groups: G, noMatch: G.length === 0,
      setupRows: [['Déclaration TPS/TVH', 'Trimestrielle', 'percent', 'violet'], ['Fin d’exercice', '31 déc.', 'cal', 'sky'], ['Remises de paie', 'Mensuelles', 'bank', 'sage'], ['Rappels', '14 et 3 jours avant', 'bell', 'amber']].map(function (r) { return { label: r[0], value: r[1], ic: ic(r[2], r[3]) }; }),
      emptyRows: EV.map(function (r, i) { var v = emptyVals[i] || 0; return { label: r[0], value: r[1][v], ic: ic(r[2], r[3]), cycle: function () { var o = Object.assign({}, self.g('ev', {})); o[i] = ((o[i] || 0) + 1) % r[1].length; set({ ev: o }); } }; })
    };
