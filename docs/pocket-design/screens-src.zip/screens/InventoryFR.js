    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var loc = this.g('loc', 0), sheet = this.g('sheet', null), orders = this.g('orders', {});
    var sq = this.g('sq', 0), ss = this.g('ss', 0), sd = this.g('sd', 0);
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    // id, name, unit, shop, truck, site(label,n), par, reserved(n, job), icon, tone, suggested qty, suppliers [name, price, sub]
    var L = [
      { id: 'dw', name: 'Gypse 1/2 po 4×8', unit: 'feuilles', shop: 8, truck: 0, site: null, par: 30, res: [24, 'Sous-sol Hart'], ic: ['bricks', 'clay'], sugg: 40,
        sups: [['Home Depot Pro', 19.95, 'Livraison demain · Net 30', 'Hausse de 8 % depuis avril'], ['CanWel Building Supply', 19.40, 'Livraison jeu. · Net 45', 'Meilleur prix'], ['Lumber Plus', 20.25, 'Cueillette aujourd’hui', '']] },
      { id: 'jc', name: 'Composé à joints 17 L', unit: 'seaux', shop: 2, truck: 0, site: ['Hart', 0], par: 6, res: null, ic: ['bricks', 'stone'], sugg: 8,
        sups: [['Home Depot Pro', 26.48, 'Livraison demain · Net 30', 'Dernier prix'], ['CanWel Building Supply', 27.10, 'Livraison jeu. · Net 45', '']] },
      { id: 'pt', name: 'Ruban de peintre 1,88 po', unit: 'rouleaux', shop: 1, truck: 3, site: null, par: 12, res: null, ic: ['brush', 'amber'], sugg: 24,
        sups: [['Dulux Paints Queen St', 8.49, 'Cueillette aujourd’hui · Net 30', 'Dernier prix'], ['Home Depot Pro', 8.97, 'Livraison demain', '']] },
      { id: 'cw', name: 'Blanc plafond 18,9 L', unit: 'seaux', shop: 1, truck: 0, site: null, par: 3, res: null, ic: ['brush', 'violet'], sugg: 4,
        sups: [['Dulux Paints Queen St', 176.40, 'Cueillette aujourd’hui · Net 30', 'Dernier prix'], ['Home Depot Pro', 182.00, 'Livraison demain', '']] }
    ];
    var OK = [
      { name: 'Montant SPF 2×4×8', unit: 'montants', shop: 46, truck: 0, site: ['Chantier Hart', 20], par: 40, res: [20, 'Sous-sol Hart'], ic: ['ruler', 'sage'] },
      { name: 'Vis à gypse 1 5/8 po, 5 lb', unit: 'boîtes', shop: 5, truck: 2, site: null, par: 4, res: null, ic: ['hammer', 'slate'] },
      { name: 'Apprêt intérieur 18,9 L', unit: 'seaux', shop: 3, truck: 0, site: ['Chantier Whitfield', 2], par: 3, res: [2, 'Chambres Whitfield'], ic: ['drop', 'azure'] },
      { name: 'Plancher de chêne d’ingénierie', unit: 'boîtes', shop: 3, truck: 0, site: null, par: 2, res: [2, 'appel de service Okoye Condo'], ic: ['grid', 'amber'] },
      { name: 'Pare-vapeur 6 mil', unit: 'rouleaux', shop: 2, truck: 0, site: ['Chantier Hart', 1], par: 2, res: null, ic: ['shield', 'teal'] },
      { name: 'Toiles de protection', unit: 'toiles', shop: 0, truck: 6, site: null, par: 6, res: null, ic: ['box', 'stone'] }
    ];
    var un = function (u, n) { return n === 1 ? u.replace(/[sx]$/, '') : u; };
    var qtyAt = function (it) { var s = it.site ? it.site[1] : 0; return [it.shop + it.truck + s, it.shop, it.truck, s][loc]; };
    var locsOf = function (it) { var a = []; if (it.shop) a.push({ name: 'Atelier', n: it.shop }); if (it.truck) a.push({ name: 'Camion', n: it.truck }); if (it.site && it.site[1]) a.push({ name: it.site[0], n: it.site[1] }); if (!a.length) a.push({ name: 'Nulle part', n: 0 }); return a; };
    var low = L.map(function (it, i) {
      var tot = it.shop + it.truck + (it.site ? it.site[1] : 0), o = orders[it.id];
      var st = o ? ['Commandé', 'st-info'] : (it.res && tot < it.res[0] ? ['Manque', 'st-bad'] : ['Bas', 'st-warn' + ' si-alert']);
      return { name: it.name, unit: un(it.unit, tot), qty: tot, par: it.par, ic: ic(it.ic[0], it.ic[1]), status: st[0], st: st[1], sep: i ? 'border-top: 1px solid var(--line)' : '',
        sugg: o ? o.qty + ' ' + it.unit + ' chez ' + o.sup : it.sugg + ' ' + it.unit + ' chez ' + it.sups[0][0].replace(' Paints', ''),
        suggSub: o ? 'À la commande · ' + o.dest : (it.res && tot < it.res[0] ? it.res[0] + ' requis cette semaine pour ' + it.res[1] : money(it.sups[0][1]) + ' l’unité · dernier prix'),
        canOrder: !o && !RO, ordered: !!o && !RO,
        open: function () { set({ sheet: i, sq: o ? o.qty : it.sugg, ss: o ? o.si : 0, sd: o ? o.di : 0 }); } };
    });
    var all = L.concat(OK);
    var stock = all.map(function (it) {
      var q = qtyAt(it), tot = it.shop + it.truck + (it.site ? it.site[1] : 0), isLow = L.indexOf(it) >= 0;
      return { name: it.name, unit: un(it.unit, q), qty: q, ic: ic(it.ic[0], it.ic[1]), locs: locsOf(it), hasRes: !!it.res, res: it.res ? it.res[0] + ' ' + it.unit : '', resJob: it.res ? it.res[1] : '',
        bar: 'width: ' + Math.min(100, tot / (it.par * 2) * 100).toFixed(0) + '%; background: ' + (isLow ? 'var(--warn-dot)' : 'var(--ok-dot)'), show: q > 0 };
    }).filter(function (s) { return s.show; });
    stock.forEach(function (s, i) { s.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
    var LOCS = ['Tout', 'Atelier', 'Camion', 'Chantiers'];
    var cur = sheet === null ? null : L[sheet];
    var sh = { name: '', qtyNow: 0, why: '', qty: 0, sups: [], dests: [], total: '' };
    if (cur) {
      var DEST = ['Atelier', 'Chantier Hart', 'Cueillette'];
      sh = { name: cur.name, qtyNow: cur.shop + cur.truck + (cur.site ? cur.site[1] : 0), qty: sq,
        why: sq === cur.sugg ? 'Suggéré selon les 8 dernières semaines' : 'Suggéré : ' + cur.sugg,
        sups: cur.sups.map(function (s, j) { var on = j === ss; return { name: s[0], sub: s[2], price: money(s[1]), tag: s[3], tagStyle: s[3] === 'Meilleur prix' ? 'color: var(--ok)' : s[3].indexOf('Hausse') === 0 ? 'color: var(--warn)' : 'color: var(--muted)', on: on,
          radio: on ? 'box-shadow: inset 0 0 0 7px var(--inv)' : 'box-shadow: inset 0 0 0 1.5px var(--line2)', pick: function () { set({ ss: j }); } }; }),
        dests: DEST.map(function (d, j) { var on = j === sd; return { label: d, on: on, cls: on ? 'on' : '', pick: function () { set({ sd: j }); } }; }),
        total: money(sq * cur.sups[ss][1]) };
    }
    var nOrd = Object.keys(orders).length;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'Vous êtes hors ligne.', 'Quantités de 7 h 40. Les changements partiront à votre retour.'],
      readOnly: ['b-info', 'eye', 'sky', 'Consultation seulement.', 'Votre rôle peut voir le stock, mais pas commander ni modifier les quantités.']
    };
    var b = B[ST];
    var hasData = ['loading', 'empty', 'locked'].indexOf(ST) < 0;
    return {
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      locked: ST === 'locked', loading: ST === 'loading', isEmpty: ST === 'empty', hasData: hasData, ghost: [1, 2, 3, 4],
      lockIc: ic('lock', 'violet'), emptyIc: ic('box', 'amber'), boxIc: ic('box', 'slate'),
      kpis: [
        { label: 'Articles suivis', value: '48', sub: '3 emplacements', style: '', sep: '' },
        { label: 'Stock bas', value: String(4 - nOrd), sub: nOrd ? nOrd + ' commandé(s)' : '1 en manque', style: 4 - nOrd ? 'color: var(--warn)' : '', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Réservé', value: '2 190 $', sub: 'Pour 3 chantiers', style: '', sep: 'border-left: 1px solid var(--line)' }
      ],
      segInd: 'width: calc((100% - 4px) / 4); transform: translateX(' + (loc * 100) + '%)',
      locs: LOCS.map(function (l, i) { return { label: l, on: i === loc, style: i === loc ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ loc: i }); } }; }),
      hasLow: loc === 0, low: low, lowCount: (4 - nOrd) + ' sur 48',
      stockTitle: loc === 0 ? 'Tout le stock' : ['', 'À l’atelier', 'Dans le camion', 'Sur les chantiers'][loc], stockSub: stock.length + ' articles',
      stock: stock, noStock: stock.length === 0,
      showFab: hasData && !RO, fabHref: nOrd ? 'Supplier.dc.html' : '#', fabLabel: nOrd ? 'Revoir la commande · ' + nOrd : 'Compter le stock',
      sheetOpen: !!cur, sh: sh, close: function () { set({ sheet: null }); },
      dec: function () { set({ sq: Math.max(1, sq - (cur && cur.sugg >= 20 ? 5 : 1)) }); }, inc: function () { set({ sq: sq + (cur && cur.sugg >= 20 ? 5 : 1) }); },
      addOrder: function () { var n = Object.assign({}, orders); n[L[sheet].id] = { qty: sq, sup: L[sheet].sups[ss][0], si: ss, di: sd, dest: ['à l’atelier', 'au chantier Hart', 'cueillette'][sd] }; set({ orders: n, sheet: null }); }
    };
