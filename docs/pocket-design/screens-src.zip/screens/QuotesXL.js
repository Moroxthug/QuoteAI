    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { draft: ['Draft', 'st-mute si-draft'], sent: ['Sent', 'st-info si-q1'], viewed: ['Viewed', 'st-acc si-q2'], accepted: ['Accepted', 'st-ok si-check'], declined: ['Declined', 'st-bad si-x'], expired: ['Expired', 'st-mute si-off'], expiring: ['Expires Fri', 'st-warn si-clock'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    var data = [
      ['Q-2026-119', 'Dana Whitfield', 'Bedrooms and bath ceiling', 4131.05, 'draft', 'week', 'Today'],
      ['Q-2026-118', 'Priya Nair', 'Kitchen backsplash', 1865.10, 'viewed', 'week', 'Viewed 2 h ago'],
      ['Q-2026-117', 'Harbourfront Dental', 'Reception repaint', 6420.00, 'expiring', 'week', 'Sent Sep 24'],
      ['Q-2026-116', 'Gill Residence', 'Deck refinish', 2980.00, 'sent', 'week', 'Sent Mon'],
      ['Q-2026-114', 'Tom & Lena Hart', 'Basement change order', 3955.00, 'accepted', 'earlier', 'Accepted Sep 19'],
      ['Q-2026-112', 'Okoye Condo', 'Hallway flooring', 2210.00, 'accepted', 'earlier', 'Accepted Sep 15'],
      ['Q-2026-110', 'Marchetti Bakery', 'Storefront trim', 1480.00, 'declined', 'earlier', 'Declined Sep 12'],
      ['Q-2026-108', 'Chen Family', 'Laundry room refresh', 3300.00, 'expired', 'earlier', 'Expired Sep 9'],
      ['Q-2026-107', 'Tom & Lena Hart', 'Basement finish', 38400.00, 'accepted', 'earlier', 'Accepted Aug 28']
    ];
    var FIL = [['all', 'All', function () { return true; }], ['draft', 'Draft', function (s) { return s === 'draft'; }], ['waiting', 'Waiting', function (s) { return s === 'sent' || s === 'viewed' || s === 'expiring'; }], ['accepted', 'Accepted', function (s) { return s === 'accepted'; }], ['closed', 'Closed', function (s) { return s === 'declined' || s === 'expired'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[0]).toLowerCase().indexOf(ql) >= 0); });
    var acted = this.g('acted', {});
    var mkActs = function (no, list) { return list.map(function (a) { return { label: a[0], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); if (!a[4]) return; var n = Object.assign({}, self.g('acted', {})); n[no] = [a[4], a[5]]; set({ acted: n }); } }; }); };
    var QA = {
      draft: [['Send', 'send', 'azure', 'info', 'Sent', 'st-info si-q1'], ['Duplicate', 'doc', 'slate', 'mute']],
      sent: [['Follow up', 'chat', 'violet', 'acc', 'Followed up', 'st-info si-q1'], ['Mark won', 'check', 'sage', 'ok', 'Accepted', 'st-ok si-check']],
      accepted: [['Invoice deposit', 'receipt', 'amber', 'warn', 'Deposit sent', 'st-info si-q1'], ['Start job', 'cone', 'amber', 'ok', 'Job started', 'st-ok si-live']],
      declined: [['Revive', 'sync', 'indigo', 'acc', 'Draft', 'st-mute si-draft'], ['Archive', 'box', 'stone', 'mute', 'Archived', 'st-mute si-off']]
    };
    QA.viewed = QA.sent; QA.expiring = QA.sent; QA.expired = QA.declined;
    var mk = function (d, i) { var ini = d[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); var ac = acted[d[0]]; return { no: d[0], client: d[1], job: d[6] + ' · ' + d[2], amt: money(d[3]), status: ac ? ac[0] : S[d[4]][0], st: ac ? ac[1] : S[d[4]][1], ini: ini, tn: tints[i % tints.length], acts: mkActs(d[0], QA[d[4]]) }; };
    var groups = [['week', 'This week'], ['earlier', 'Earlier']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + d[3]; }, 0);
      return { title: g[1], total: rs.length ? money(tot) : '', rows: rs.map(function (d) { return mk(d, data.indexOf(d)); }), has: rs.length > 0, first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Waiting', value: '$15,396', sub: '4 quotes', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Won this month', value: '$6,165', sub: '2 accepted', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Win rate', value: '62%', sub: '↑ 4 pts', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
