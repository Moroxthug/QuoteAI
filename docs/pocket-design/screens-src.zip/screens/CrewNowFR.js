    if (!self._t0) self._t0 = Date.now() - (2 * 3600 + 41 * 60 + 8) * 1000;
    if (!self._iv) self._iv = setInterval(function () { if (self.g('on', true)) self.setState({ tick: Date.now() }); }, 1000);
    var on = this.g('on', true), phase = this.g('phase', ''), start = this.g('start', self._t0), accum = this.g('accum', 0);
    var inAt = this.g('inAt', '7 h 02'), outAt = this.g('outAt', '');
    var locating = phase === 'locating';
    var now = Date.now();
    var worked = accum + (on ? now - start : 0);
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var sec = Math.floor(worked / 1000);
    var timer = Math.floor(sec / 3600) + ':' + pad(Math.floor(sec / 60) % 60) + ':' + pad(sec % 60);
    var hm = function (d) { var h = d.getHours(), m = d.getMinutes(); return h + ' h ' + pad(m); };
    var dur = Math.floor(sec / 3600) + ' h ' + pad(Math.floor(sec / 60) % 60);

    var toggleClock = function () {
      if (self.g('phase', '') === 'locating') return;
      self.setState({ phase: 'locating' });
      setTimeout(function () {
        var t = Date.now();
        if (self.g('on', true)) {
          self.setState({ on: false, phase: 'done', accum: self.g('accum', 0) + (t - self.g('start', self._t0)), outAt: hm(new Date(t)) });
        } else {
          self.setState({ on: true, phase: 'done', start: t, inAt: hm(new Date(t)) });
        }
        setTimeout(function () { self.setState({ phase: '' }); }, 1800);
      }, 1600);
    };

    var clockBtn, clockBtnSub, clockBtnStyle, clockDiscStyle;
    var isDone = phase === 'done';
    if (isDone) {
      clockBtn = on ? 'Arrivée pointée' : 'Départ pointé'; clockBtnSub = (on ? inAt : outAt) + ' · position confirmée';
      clockBtnStyle = 'background: var(--ok-soft); color: var(--ok)'; clockDiscStyle = 'background: var(--ok-dot); color: #ffffff';
    } else if (locating) {
      clockBtn = 'Localisation…'; clockBtnSub = 'On vérifie que vous êtes au 48 Galloway Rd';
      clockBtnStyle = 'background: var(--sunk); color: var(--ink)'; clockDiscStyle = 'background: var(--card); color: var(--acc-t); box-shadow: 0 0 0 1px var(--ring)';
    } else if (on) {
      clockBtn = 'Pointer le départ'; clockBtnSub = 'Appuyez en quittant le chantier';
      clockBtnStyle = 'background: var(--sunk); color: var(--ink)'; clockDiscStyle = 'background: var(--bad-soft); color: var(--bad)';
    } else {
      clockBtn = 'Pointer l’arrivée'; clockBtnSub = 'Au sous-sol Hart · 48 Galloway Rd';
      clockBtnStyle = 'background: var(--inv); color: var(--on-inv); box-shadow: 0 12px 28px -12px var(--shadow)'; clockDiscStyle = 'background: var(--ok-dot); color: #ffffff';
    }

    var taskDone = this.g('tasks', [true, false, false, false]);
    var TASKS = [
      ['Poser le gypse, mur du fond', 'Fait à 8 h 40', false],
      ['Joints et 1re couche, chambre', 'Prenez le composé à prise rapide, 45 min', false],
      ['Coins métalliques, corridor', 'Ajouté par Luca ce matin', true],
      ['Sabler et balayer avant de partir', 'L’aspirateur est dans la salle de la fournaise', false]
    ];
    var doneN = taskDone.filter(Boolean).length;
    var tasks = TASKS.map(function (t, i) {
      var d = taskDone[i];
      return {
        title: t[0], sub: d && i !== 0 ? 'Fait' : t[1], done: d, isNew: t[2] && !d, sep: i ? 'border-top: 1px solid var(--line)' : '',
        tickStyle: d ? 'background: var(--ok-dot); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
        checkStyle: d ? 'opacity: 1' : 'opacity: 0',
        textStyle: d ? 'color: var(--muted)' : 'color: var(--ink)',
        toggle: function () { var a = self.g('tasks', [true, false, false, false]).slice(); a[i] = !a[i]; self.setState({ tasks: a }); }
      };
    });

    var kind = this.g('kind', 0), sheetOpen = this.g('sheet', false), hasPhoto = this.g('photo', true), repText = this.g('repText', '');
    var KINDS = [['Suivi', 'Qu’avez-vous fait?', 'Mur du fond posé, je commence les joints dans la chambre', 'Envoyer le suivi'], ['Blocage', 'Qu’est-ce qui vous bloque?', 'Il manque 4 feuilles de gypse ½ po pour le corridor', 'Envoyer le blocage'], ['Matériaux', 'Autre chose à noter?', 'Acheté au Home Depot, Warden Ave', 'Envoyer les matériaux']];
    var kinds = KINDS.map(function (k, i) { var o = i === kind; return { label: k[0], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ kind: i }); } }; });

    var reports = this.g('reports', [
      { k: 'blocker', title: 'Blocage · manque de gypse', sub: 'Luca : feuilles en plus à 11 h', st: 'st-ok', status: 'Répondu', time: '7 h 48' },
      { k: 'photo', title: 'Photo · mur du fond posé', sub: 'Gardée sur votre téléphone, part dès qu’il y a du réseau', st: 'st-warn', status: 'À synchroniser', time: '8 h 42' },
      { k: 'materials', title: 'Matériaux · ruban treillis', sub: 'Pas envoyé. Touchez pour réessayer', st: 'st-bad', status: 'Échec', time: '9 h 05' }
    ]);
    var RIC = { blocker: ['warn', 'amber'], photo: ['camera', 'azure'], materials: ['box', 'clay'], update: ['chat', 'violet'] };
    var reportRows = reports.map(function (r, i) {
      return {
        title: r.title, sub: r.sub, st: r.st, status: r.status, time: r.time, ic: ic(RIC[r.k][0], RIC[r.k][1]), sep: i ? 'border-top: 1px solid var(--line)' : '',
        tap: function () {
          if (r.status !== 'Échec') return;
          var a = self.g('reports', reports).slice(); a[i] = Object.assign({}, r, { st: 'st-mute', status: 'Envoi', sub: 'Envoi en cours' }); self.setState({ reports: a });
          setTimeout(function () { var b = self.g('reports', a).slice(); b[i] = Object.assign({}, r, { st: 'st-ok', status: 'Envoyé', sub: 'Luca le verra à sa prochaine vérification' }); self.setState({ reports: b }); }, 1300);
        }
      };
    });

    var changesOpen = this.g('chOpen', false);
    return {
      greet: 'Bonjour Amara',
      showChanges: !this.g('gotIt', false), changesOpen: changesOpen,
      chevRot: changesOpen ? 'transform: rotate(180deg)' : 'transform: rotate(0deg)',
      toggleChanges: function () { self.setState({ chOpen: !self.g('chOpen', false) }); },
      gotIt: function () { self.setState({ gotIt: true }); },
      changes: [
        { ic: ic('cal', 'azure'), title: 'Jeudi déplacé à 8 h', sub: 'Harbourfront Dental, murs de la réception. C’était 7 h.' },
        { ic: ic('list', 'violet'), title: 'Nouvelle tâche aujourd’hui', sub: 'Coins métalliques dans le corridor, ajoutée par Luca' },
        { ic: ic('chat', 'sage'), title: 'Luca a répondu à votre blocage', sub: 'Feuilles en plus à 11 h' }
      ],
      clockSt: locating ? 'st-info' : (on ? 'st-ok' : 'st-mute'),
      clockLabel: locating ? 'Vérification de la position' : (on ? 'En quart' : 'Hors quart'),
      timer: timer,
      timerStyle: on ? 'color: var(--ink)' : 'color: var(--muted)',
      timerSub: on ? 'Depuis ' + inAt + ' · sur place' : 'Départ pointé à ' + outAt + ' · ' + dur + ' aujourd’hui',
      locating: locating, isDone: isDone, showPower: !locating && !isDone,
      toggleClock: toggleClock, clockBtn: clockBtn, clockBtnSub: clockBtnSub, clockBtnStyle: clockBtnStyle, clockDiscStyle: clockDiscStyle,
      jobIc: ic('house', 'clay'), pinIc: ic('pin', 'rose'), phoneIc: ic('phone', 'sage'), jobIc2: ic('house', 'clay'),
      gate: this.g('showCode', true) ? '4417 #' : '•••• #', gateSub: 'Boîte à clé, porte de côté',
      toggleCode: function () { self.setState({ showCode: !self.g('showCode', true) }); },
      tasks: tasks, taskCount: doneN + ' sur ' + TASKS.length, allDone: doneN === TASKS.length, doneIc: ic('check', 'sage'),
      upcoming: [
        { dow: 'mer.', day: '30', job: 'Sous-sol Hart', time: '7 h–15 h 30', what: 'Gypse, 2e couche', hasTag: false, tag: '', tagSt: '' },
        { dow: 'jeu.', day: '1', job: 'Harbourfront Dental', time: '8 h–16 h', what: 'Réparer les murs de la réception', hasTag: true, tag: 'Déplacé', tagSt: 'st-acc' },
        { dow: 'ven.', day: '2', job: 'Sous-sol Hart', time: '7 h–15 h 30', what: 'Sabler et apprêter', hasTag: false, tag: '', tagSt: '' },
        { dow: 'lun.', day: '5', job: 'Gill Residence', time: '7 h 30–12 h', what: 'Réparation du plafond, demi-journée', hasTag: false, tag: '', tagSt: '' }
      ],
      reports: reportRows,
      openReport: function () { self.setState({ sheet: true }); },
      closeReport: function () { self.setState({ sheet: false }); },
      sheetOpen: sheetOpen, kinds: kinds, kindInd: 'transform: translateX(' + (kind * 100) + '%)',
      isBlocker: kind === 1, isMaterials: kind === 2,
      textLabel: KINDS[kind][1], textPh: KINDS[kind][2], sendLabel: KINDS[kind][3],
      repText: repText, onRepText: function (e) { self.setState({ repText: e.target.value }); },
      hasPhoto: hasPhoto, togglePhoto: function () { self.setState({ photo: !self.g('photo', true) }); },
      warnIc: ic('warn', 'amber'),
      sendReport: function () {
        var k = ['update', 'blocker', 'materials'][self.g('kind', 0)];
        var txt = (self.g('repText', '') || KINDS[self.g('kind', 0)][2]);
        var t = hm(new Date()).replace(/ (am|pm)$/, '');
        var nr = { k: k, title: KINDS[self.g('kind', 0)][0] + ' · ' + (txt.length > 26 ? txt.slice(0, 26) + '…' : txt), sub: k === 'blocker' ? 'Envoyé à Luca et Marco' : 'Envoyé au bureau', st: 'st-ok', status: 'Envoyé', time: t };
        self.setState({ sheet: false, repText: '', reports: [nr].concat(self.g('reports', reports)) });
      }
    };
