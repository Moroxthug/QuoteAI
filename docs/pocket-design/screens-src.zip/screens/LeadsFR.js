    var stage = this.g('stage', 0), moved = this.g('moved', {}), chan = this.g('chan', {}), form = this.g('form', false), fch = this.g('fch', 0), toast = this.g('toast', null), nm = this.g('nm', '');
    var STAGES = ['Nouvelles', 'Contactées', 'En soumission', 'Gagnées', 'Perdues'];
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // id, name, source, when, ask, channel(0 text,1 email), follow-up, due tone, stage
    var base = [
      ['am', 'Aaron Mitchell', 'Formulaire du site', 'il y a 2 h', 'Repeindre la cuisine et le corridor, environ 400 pi². Aimerait finir avant l’Action de grâce.', 0, 'Aujourd’hui, 16 h', 'due', 0],
      ['so', 'Sam Oduya', 'Google Services locaux', 'il y a 5 h', 'Coin humide au sous-sol. Veut une soumission pour l’imperméabilisation.', 0, 'Aujourd’hui, 17 h 30', 'due', 0],
      ['rt', 'Rebecca Tran', 'Instagram', 'Hier', 'Teinture du patio et de deux garde-corps à Etobicoke.', 1, 'Demain, 9 h', '', 0],
      ['jp', 'Jordan Price', 'Ajoutée par vous', '24 sept.', 'Céramique de la salle de bain des maîtres, douche à l’italienne. A demandé des photos de travaux passés.', 0, 'Hier, manqué', 'late', 1],
      ['ml', 'Mei Lin', 'Facebook', '25 sept.', 'Deux chambres et une cage d’escalier, couleurs foncées à couvrir.', 1, 'jeu. 1er oct.', '', 1],
      ['cd', 'Claire Dubois', 'Formulaire du site', '26 sept.', 'Plinthes et moulures de condo, 900 pi².', 0, 'ven. 2 oct.', '', 1],
      ['ha', 'Hassan Ali', 'Liste importée', '21 sept.', 'Reconstruction du patio au printemps, veut un prix cet automne.', 1, 'sam. 3 oct.', '', 1],
      ['dw', 'Dana Whitfield', 'Recommandée par Priya Nair', '27 sept.', 'Chambres et plafond de salle de bain · Q‑2026‑119, 4 131,05 $', 0, 'Aujourd’hui, après 18 h', 'due', 2],
      ['gr', 'Gill Residence', 'Formulaire du site', '22 sept.', 'Remise à neuf du patio · Q‑2026‑116, 2 980,00 $', 1, 'jeu. 1er oct.', '', 2],
      ['hd', 'Harbourfront Dental', 'Google Services locaux', '18 sept.', 'Peinture de la réception · Q‑2026‑117, expire ven.', 1, 'mer. 30 sept.', '', 2],
      ['oc', 'Okoye Condo', 'Instagram', '10 sept.', 'Plancher du corridor · gagnée, 2 210,00 $', 0, 'Demande d’avis, 20 oct.', '', 3],
      ['th', 'Tom & Lena Hart', 'Recommandation', '14 août', 'Finition du sous-sol · gagnée, 38 400,00 $', 1, 'Chantier en cours', '', 3]
    ];
    var leads = base.map(function (d) { return { id: d[0], name: d[1], src: d[2], when: d[3], ask: d[4], ch: chan[d[0]] !== undefined ? chan[d[0]] : d[5], follow: d[6], tone: d[7], stage: moved[d[0]] !== undefined ? moved[d[0]] : d[8], i: base.indexOf(d) }; });
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    var de = function (n) { return /^[AEIOUYÉÈ]/i.test(n) ? 'd’' + n : 'de ' + n; };
    // full request, photos, plan after the next follow-up, drafted reply
    var DET = {
      am: ['Murs et plafonds, les moulures restent blanches. L’Action de grâce tombe le 12 oct., donc la peinture doit être sèche le 10. À la maison en semaine après 15 h.', '4 photos · cuisine, corridor', 'Puis jeu. et lun. sans réponse', 'Bonjour Aaron, ici Marco de Rossi Renovations. Merci pour les photos. Je peux passer jeudi à 16 h pour mesurer et vous envoyer un prix vendredi. Est-ce que ça vous convient ?'],
      so: ['Mur nord, près de la salle de lavage. Dépôt blanc sur les blocs et odeur de moisi après la pluie. Veut savoir si c’est urgent.', '2 photos · coin du sous-sol', 'Puis jeu. sans réponse', 'Bonjour Sam, ici Marco de Rossi Renovations. Les coins humides sont fréquents après autant de pluie. Je peux venir voir mercredi à 9 h et vous dire ce qu’il faut faire.'],
      rt: ['Environ 220 pi², dernière teinture en 2021. Semi-transparente, même ton de cèdre. Veut que ce soit fait avant les grands froids.', '3 photos · patio, garde-corps', 'Puis lun. sans réponse', 'Bonjour Rebecca, merci de nous avoir écrit. Un patio de cette taille avec deux garde-corps nous prend environ deux jours. Envoyez-moi une photo de l’escalier et je vous fais la soumission à partir de vos photos.'],
      jp: ['Environ 60 pi² avec une douche sans seuil et une niche. Veut voir des salles de bain déjà réalisées avant de réserver une visite.', '', 'Manqué hier · réessayer aujourd’hui', 'Bonjour Jordan, désolé de vous avoir manqué hier. Voici trois salles de bain qu’on a faites cette année. Je peux passer cette semaine pour mesurer.'],
      ml: ['Marine et vert forêt à recouvrir en blanc chaud. Deux couches, plus un apprêt au besoin. La cage d’escalier fait deux étages.', '5 photos · chambres, cage d’escalier', 'Puis lun. 5 oct.', 'Bonjour Mei, je fais un suivi pour les chambres et la cage d’escalier. J’ai le 8 oct. de libre pour une visite. Est-ce que le matin vous irait ?'],
      cd: ['L’immeuble exige un certificat d’assurance et une réservation de l’ascenseur. Semi-lustré, blanc.', '1 photo · moulures du salon', 'Puis mar. 6 oct.', 'Bonjour Claire, notre certificat d’assurance est prêt pour votre immeuble. Dès que l’ascenseur est réservé, je peux prendre les mesures en 30 minutes.'],
      ha: ['Environ 300 pi². Veut le bois traité et le composite chiffrés côte à côte pour planifier son budget.', '', 'Puis chaque mois jusqu’en mars', 'Bonjour Hassan, avec plaisir pour chiffrer les deux options. Une courte visite ce mois-ci me permet de garantir les prix du bois de cette année.'],
      dw: ['Q‑2026‑119 préparée aujourd’hui après la visite du 28 sept. Deux chambres plus le plafond de la salle de bain, peinture à faible COV.', '6 photos · de la visite', 'Puis jeu. si non ouverte', 'Bonjour Dana, votre soumission pour les chambres et le plafond de la salle de bain est prête. J’ai gardé les dates demandées. Dites-moi s’il y a quelque chose à changer.'],
      gr: ['Q‑2026‑116 envoyée lundi par courriel, pas encore ouverte. Début de préférence une fin de semaine.', '3 photos · patio', 'Puis lun. 5 oct.', 'Bonjour, je voulais m’assurer que la soumission pour le patio vous est bien parvenue. Je peux la passer en revue avec vous par téléphone cette semaine.'],
      hd: ['Q‑2026‑117 envoyée le 24 sept. à la directrice du bureau. En dehors des heures seulement, patients sur place le jour.', '4 photos · réception', 'Dernier rappel jeu. avant l’expiration', 'Bonjour, petit rappel : la soumission pour la peinture de la réception expire vendredi. On peut commencer la semaine du 19 oct., en soirée seulement.'],
      oc: ['Acceptée le 15 sept. Le plan des travaux est préparé à partir de Q‑2026‑112 et attend votre révision.', '2 photos · corridor', 'Demande d’avis le 20 oct.', 'Bonjour, merci encore d’avoir choisi Rossi Renovations. On commence le corridor le 5 oct. et on vous enverra un rappel la veille.'],
      th: ['Acceptée le 28 août. Le chantier est terminé à 64 %, étape du gypse, avec un ordre de changement de 3 955,00 $.', '8 photos · sous-sol', 'Demande d’avis après le chantier', 'Bonjour Lena, petite mise à jour : le gypse se termine jeudi, puis l’apprêt. Je vous envoie des photos en fin de journée.']
    };
    var srcIc = { 'Formulaire du site': ['globe', 'azure'], 'Google Services locaux': ['search', 'sage'], 'Instagram': ['camera', 'rose'], 'Facebook': ['users', 'indigo'], 'Ajoutée par vous': ['pen', 'slate'], 'Liste importée': ['file', 'stone'] };
    var cards = leads.filter(function (l) { return l.stage === stage; }).map(function (l) {
      var ini = l.name.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var si = srcIc[l.src] || ['star', 'gold'];
      var open = stage < 3;
      return {
        name: l.name, ini: ini, tn: tints[l.i % 5], src: l.src, when: l.when, ask: l.ask, follow: l.follow, srcIc: ic(si[0], si[1]),
        followStyle: l.tone === 'late' ? 'color: var(--bad)' : l.tone === 'due' ? 'color: var(--warn)' : 'color: var(--ink)',
        open: open, won: l.stage === 3,
        chans: ['Texto', 'Courriel'].map(function (c, ci) { var on = ci === l.ch; return { label: c, on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { var o = Object.assign({}, self.g('chan', {})); o[l.id] = ci; set({ chan: o }); } }; }),
        ind: 'width: calc((100% - 4px) / 2); transform: translateX(' + (l.ch * 100) + '%)',
        send: function () { var o = Object.assign({}, self.g('moved', {})); var mv = l.stage === 0; if (mv) o[l.id] = 1; set({ moved: o, xo: mv ? null : self.g('xo', null), toast: { id: l.id, name: l.name, from: l.stage, to: mv ? 'Contactées' : null, via: l.ch ? 'courriel' : 'texto' } }); },
        sendLabel: l.ch ? 'Envoyer le courriel' : 'Envoyer le texto',
        isOpen: xo === l.id, xcls: xo === l.id ? 'open' : '', toggle: toggleOf(l.id),
        x: (function (x) {
          var st = l.stage, sk = l.id + ':sec', sd = !!xd[sk];
          var sec = st < 2 ? ['Fixer une visite', 'Visite fixée'] : st === 2 ? ['Appeler', 'Appel en cours'] : st === 3 ? ['Demander un avis', 'Avis demandé'] : ['Réactiver', 'Réactivée'];
          var main = st < 2 ? ['Soumissionner', 'NewQuoteFR.dc.html'] : st === 2 ? ['Voir la soumission', 'Quote.dc.html'] : st === 3 ? ['Voir le client', 'Client.dc.html'] : ['Soumissionner', 'NewQuoteFR.dc.html'];
          var tone = l.tone === 'late' ? ['Manqué', 'st-bad si-alert'] : l.tone === 'due' ? ['Aujourd’hui', 'st-warn si-clock'] : ['Planifié', 'st-info si-q1'];
          var rows = [];
          rows.push({ t: x[1] ? 'Photos' : 'Pas encore de photos', s: x[1] || 'Demandez-en quelques-unes dans la réponse', hasS: true, hasSt: false, hasBtn: !x[1], btnLabel: xd[l.id + ':ph'] ? 'Demandées' : 'Demander', btnCls: xd[l.id + ':ph'] ? 'done' : '', act: flip(l.id + ':ph'), hasSeg: false });
          rows.push({ t: 'Provenance', s: l.src + ' · ' + l.when, hasS: true, hasSt: false, hasBtn: false, hasSeg: false });
          if (st < 3) rows.push({ t: 'Plan de suivi', s: x[2], hasS: true, st: tone[0], stCls: tone[1], hasSt: true, hasBtn: false, hasSeg: true });
          else rows.push({ t: st === 4 ? 'Marquée perdue' : l.follow, s: st === 4 ? 'À relancer la saison prochaine' : x[2], hasS: true, hasSt: false, hasBtn: false, hasSeg: false });
          return {
            full: x[0], cap: st < 3 ? 'Demande ' + de(l.name.split(' ')[0]) : 'Détails', reply: x[3], via: l.ch ? 'par courriel' : 'par texto', rows: rows,
            second: sd ? sec[1] : sec[0], secCls: sd ? 'done' : '',
            secAct: st === 4 ? function () { var o = Object.assign({}, self.g('moved', {})); o[l.id] = base[l.i][8]; set({ moved: o, xo: null, toast: null }); } : flip(sk),
            main: main[0], href: main[1], canLose: st < 3, loseLabel: 'Marquer comme perdue',
            lose: function () { var o = Object.assign({}, self.g('moved', {})); o[l.id] = 4; set({ moved: o, xo: null, toast: { id: l.id, name: l.name, from: l.stage, to: 'Perdues', lost: true } }); }
          };
        })(DET[l.id])
      };
    });
    var counts = STAGES.map(function (s, i) { return leads.filter(function (l) { return l.stage === i; }).length; });
    var nOpen = counts[0] + counts[1] + counts[2];
    return {
      tabs: STAGES.map(function (s, i) { var on = i === stage; return { label: s, count: counts[i], cls: on ? 'on' : '', on: on, pick: function () { set({ stage: i, toast: null, xo: null }); } }; }),
      openCls: cards.some(function (c) { return c.isOpen; }) ? 'has-open' : '',
      cards: cards, has: cards.length > 0, empty: cards.length === 0, isNew: stage === 0,
      emptyIc: ic('users', 'slate'), plugIc: ic('funnel', 'violet'),
      dueLine: nOpen + (nOpen > 1 ? ' pistes ouvertes' : ' piste ouverte') + ' · 3 suivis aujourd’hui',
      form: form, openForm: function () { set({ form: !self.g('form', false) }); }, closeForm: function () { set({ form: false }); },
      onName: function (e) { set({ nm: e.target.value }); }, nm: nm,
      fchans: ['Texto', 'Courriel'].map(function (c, ci) { var on = ci === fch; return { label: c, on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ fch: ci }); } }; }),
      find: 'width: calc((100% - 4px) / 2); transform: translateX(' + (fch * 100) + '%)',
      save: function () { set({ form: false, stage: 0, toast: { id: null, name: (self.g('nm', '') || 'Nouvelle piste'), to: 'Nouvelles', saved: true } }); },
      toast: !!toast, toastText: toast ? (toast.lost ? toast.name + ' : piste déplacée dans Perdues.' : toast.saved ? toast.name + ' : piste ajoutée aux Nouvelles. Premier suivi demain à 9 h.' : toast.to ? 'Envoyé par ' + toast.via + '. ' + toast.name + ' passe à Contactées.' : 'Suivi envoyé à ' + toast.name + ' par ' + toast.via + '.') : '',
      undoShow: !!(toast && !toast.saved && toast.to),
      undo: function () { var t = self.g('toast', null); if (!t) return; var o = Object.assign({}, self.g('moved', {})); o[t.id] = t.from; set({ moved: o, toast: null }); },
      okIc: ic('check', 'sage')
    };
