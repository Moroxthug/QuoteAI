    var ST = this.props.state || 'default';
    var f = this.g('f', 'all'), q = this.g('q', ''), acted = this.g('acted', {});
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    // id, name, rep, role, account, spend, last order, category, icon, tone, group
    var data = [
      ['hd', 'Home Depot Pro', 'Rachel Kim', 'Pro desk', 'Acct 4410-2291 · Net 30', 3284.60, 'Last order Sep 27', 'building', 'house', 'amber', 'acct'],
      ['dx', 'Dulux Paints Queen St', 'Marc Tremblay', 'store manager', 'Acct DX-88213 · Net 30', 1412.35, 'Last order Sep 25', 'paint', 'brush', 'violet', 'acct'],
      ['cw', 'CanWel Building Supply', 'Sandra Li', 'inside sales', 'Acct CW-10457 · Net 45', 1146.20, 'Last order Sep 18', 'building', 'bricks', 'clay', 'acct'],
      ['lp', 'Lumber Plus', 'Greg Watts', 'yard', 'Acct LP-3390 · Net 30', 684.00, 'Last order Sep 22', 'lumber', 'ruler', 'sage', 'acct'],
      ['ct', 'Canadian Tire', 'Danforth Ave store', '', 'No account · company card', 315.14, 'Last order Sep 12', 'tools', 'hammer', 'rose', 'counter']
    ];
    var FIL = [['all', 'All'], ['building', 'Building'], ['paint', 'Paint'], ['lumber', 'Lumber'], ['tools', 'Tools']];
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return (f === 'all' || d[7] === f) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[4]).toLowerCase().indexOf(ql) >= 0); });
    var mkActs = function (d) {
      return [['Call', 'phone', 'sage', 'ok', 'Called just now', 'st-ok'], ['Email', 'mail', 'azure', 'info', 'Email drafted', 'st-info']].map(function (a) {
        return { label: a[0], aria: a[0] + ' ' + d[1], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); var n = Object.assign({}, self.g('acted', {})); n[d[0]] = [a[4], a[5]]; set({ acted: n }); } };
      });
    };
    var mk = function (d) { var ac = acted[d[0]]; return { name: d[1], contact: d[2] + (d[3] ? ', ' + d[3] : ''), acct: d[4], spend: money(d[5]), last: d[6], ic: ic(d[8], d[9]), acted: !!ac, notActed: !ac, stWord: ac ? ac[0] : '', stCls: ac ? ac[1] : '', acts: mkActs(d) }; };
    var groups = [['acct', 'Accounts', 'Billed monthly'], ['counter', 'Pay at the counter', 'Receipts only']].map(function (g) {
      var rs = rows.filter(function (d) { return d[10] === g[0]; });
      return { title: g[1], sub: g[2], rows: rs.map(mk), has: rs.length > 0, first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'You’re offline.', 'Showing suppliers saved on this phone. Calls still work.'],
      readOnly: ['b-info', 'eye', 'sky', 'View only.', 'Your role can see suppliers but not change them.']
    };
    var b = B[ST];
    var hasData = ST !== 'loading' && ST !== 'empty';
    return {
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      canEdit: ST !== 'readOnly' && ST !== 'loading',
      loading: ST === 'loading', skels: [1, 2, 3, 4, 5], hasData: hasData, isEmpty: ST === 'empty',
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Spend this month', value: '$6,842', sub: '14 orders', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Owing', value: '$5,843', sub: 'Next due Oct 15', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Price changes', value: '4', sub: '3 went up', subStyle: 'color: var(--warn)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[0] === 'all' || d[7] === x[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, noMatch: hasData && groups.length === 0, showTip: hasData && groups.length > 0 && !ql && f === 'all',
      searchIc: ic('search', 'slate'), boxIc: ic('box', 'amber'), emptyIc: ic('truck', 'amber')
    };
