    var stripe = ST !== 'stripeNotConnected';
    var terms = self.g('terms', 1), termsW = ['On receipt', 'Net 15', 'Net 30'][terms];
    var r1 = self.g('r1', true), r2 = self.g('r2', true), r3 = self.g('r3', true);
    var dot = function (on) { return on ? 'background: var(--acc)' : 'background: var(--card); box-shadow: inset 0 0 0 2px var(--line2)'; };
    var late = self.g('late', true), hold = self.g('hold', true), auto = self.g('auto', true);
    var dayFmt = function (x) { return x === 0 ? 'Same day' : x + (x === 1 ? ' day' : ' days'); };
    var pay = [
      sw('etr', true, 'bank', 'sage', 'Interac e-Transfer', 'To pay@rossireno.ca · autodeposit on')
    ];
    if (stripe) pay.push(stat(lnk('card', 'violet', 'Card, through Stripe', 'Payouts in 2 business days', '', 'Integration.dc.html'), 'Connected', 'st-ok si-check'));
    else pay.push(btnRow('card', 'violet', 'Card, through Stripe', 'Not connected yet', 'Connect', function () {}, 'btn-p'));
    pay.push(sw('chq', true, 'receipt', 'stone', 'Cheque', 'Payable to Rossi Renovations Inc.'));
    var dep = [ step('dep', 30, 5, 0, 50, '%', 'percent', 'amber', 'Default deposit', 'Asked when a quote is accepted'),
      sw('hold', true, 'lock', 'indigo', 'Holdback', hold ? '10% kept on progress invoices' : 'Off. Turn on for Ontario Construction Act jobs') ];
    if (hold) dep.push(val('cal', 'teal', 'Holdback release', 'Invoiced when the lien period ends', '60 days after'));
    var lateRows = [ sw('late', true, 'warn', 'rose', 'Charge a late fee', 'Printed on every invoice') ];
    if (late) { lateRows.push(step('rate', 2, 0.5, 0.5, 5, function (x) { return x + '%/mo'; }, 'percent', 'clay', 'Rate', 'Per month on the balance')); lateRows.push(step('after', 30, 5, 0, 60, dayFmt, 'clock', 'amber', 'Starts after', 'Past the due date')); }
    return {
      roBanner: roBanner, noStripe: !stripe, cardWarn: ic('card', 'amber'), invIc: ic('receipt', 'violet'),
      nextNo: 'INV-0' + self.g('nextN', 425), termsTag: termsW,
      gNum: grp('Numbering and terms', [
        lnk('tag', 'lilac', 'Number format', 'Prefix, then 4 digits', 'INV-0425', RO ? '' : '#', true),
        seg('terms', 1, 'cal', 'teal', 'Payment terms', 'Due date on new invoices', ['On receipt', 'Net 15', 'Net 30']),
        sw('auto', true, 'send', 'sky', 'Send on schedule', auto ? 'From each job’s payment schedule' : 'Off. You send each invoice'),
      ].concat(auto ? [step('delay', 1, 1, 0, 7, dayFmt, 'clock', 'stone', 'Wait before sending', 'After the milestone is done')] : []), '', 80),
      tl: [
        { lbl: '3 days before', pos: 'left: 0; align-items: flex-start', dot: dot(r1), lblStyle: r1 ? 'color: var(--ink)' : 'color: var(--faint)' },
        { lbl: 'Due date', pos: 'left: 50%; transform: translateX(-50%); align-items: center', dot: dot(r2), lblStyle: r2 ? 'color: var(--ink)' : 'color: var(--faint)' },
        { lbl: '7 days after', pos: 'right: 0; align-items: flex-end', dot: dot(r3), lblStyle: r3 ? 'color: var(--ink)' : 'color: var(--faint)' }
      ],
      gRem: (function (g) { g.rows[0].sep = 'border-top: 1px solid var(--line)'; return g; })(grp('Reminders', [
        sw('r1', true, 'bell', 'amber', '3 days before', 'A friendly heads-up with the pay link'),
        sw('r2', true, 'cal', 'teal', 'On the due date', 'Balance and how to pay'),
        sw('r3', true, 'warn', 'rose', '7 days after', late ? 'Firmer, mentions the late fee' : 'Firmer, asks for a date'),
        seg('remBy', 2, 'chat', 'sky', 'Send by', '', ['Email', 'Text', 'Both'])
      ], 'Reminders stop as soon as a payment comes in, or when you mark it paid.', 130)),
      gPay: grp('How clients pay', pay, '', 180),
      gDep: grp('Deposits and holdback', dep, '', 230),
      gLate: grp('Late fees', lateRows, late ? 'Invoices also show the yearly rate, as the Interest Act asks.' : '', 280)
    };
