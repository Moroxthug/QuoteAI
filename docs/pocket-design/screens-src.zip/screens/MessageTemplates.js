    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly' || ST === 'locked';
    var f = this.g('f', 'all'), sel = this.g('sel', 'f1'), lang = this.g('lang', 'en'), chan = this.g('chan', 1);
    var edits = this.g('edits', {}), saved = this.g('saved', {}), autoMap = this.g('auto', {}), menuOpen = this.g('menu', false), tested = this.g('tested', false);
    var V = {
      first: ['client first name', 'prénom du client'], link: ['quote link', 'lien de la soumission'], job: ['job name', 'nom du projet'],
      amount: ['amount', 'montant'], due: ['due date', 'échéance'], inv: ['invoice link', 'lien de la facture'], me: ['your name', 'votre nom'],
      co: ['company', 'entreprise'], eta: ['arrival time', 'heure d’arrivée'], review: ['review link', 'lien d’avis'], sign: ['signing link', 'lien de signature']
    };
    var SAMPLE = {
      dana: { en: { first: 'Dana', link: 'quoteai.ca/q/7KD2', job: 'bedrooms and bath ceiling', me: 'Marco', co: 'Rossi Renovations', amount: '$4,131.05', due: 'Oct 29', inv: 'quoteai.ca/i/7KD2', eta: '10:40 am', review: 'g.page/rossireno', sign: 'quoteai.ca/s/7KD2' },
              fr: { first: 'Dana', link: 'quoteai.ca/q/7KD2', job: 'chambres et plafond de salle de bain', me: 'Marco', co: 'Rossi Renovations', amount: '4 131,05 $', due: '29 oct.', inv: 'quoteai.ca/i/7KD2', eta: '10 h 40', review: 'g.page/rossireno', sign: 'quoteai.ca/s/7KD2' } },
      hart: { en: { first: 'Lena', link: 'quoteai.ca/q/H48G', job: 'basement finish', me: 'Marco', co: 'Rossi Renovations', amount: '$2,340.00', due: 'Sep 20', inv: 'quoteai.ca/i/0412', eta: '7:50 am', review: 'g.page/rossireno', sign: 'quoteai.ca/s/H48G' },
              fr: { first: 'Lena', link: 'quoteai.ca/q/H48G', job: 'finition du sous-sol', me: 'Marco', co: 'Rossi Renovations', amount: '2 340,00 $', due: '20 sept.', inv: 'quoteai.ca/i/0412', eta: '7 h 50', review: 'g.page/rossireno', sign: 'quoteai.ca/s/H48G' } },
      okoye: { en: { first: 'Grace', link: '', job: 'hallway flooring', me: 'Marco', co: 'Rossi Renovations', amount: '', due: '', inv: '', eta: '8:30 am', review: 'g.page/rossireno', sign: '' },
               fr: { first: 'Grace', link: '', job: 'plancher du corridor', me: 'Marco', co: 'Rossi Renovations', amount: '', due: '', inv: '', eta: '8 h 30', review: 'g.page/rossireno', sign: '' } }
    };
    var T = [
      { id: 'f1', cat: 'follow', name: 'Quote follow-up 1', when: '3 days after sending', auto: '3 days after the quote, at 9 am', ic: ['chat', 'violet'], who: 'dana', client: 'Dana Whitfield', defCh: 1, vars: ['first', 'job', 'link', 'me', 'co'],
        subj: { en: 'Your quote from {co}', fr: 'Votre soumission de {co}' },
        en: 'Hi {first}, just checking you got the quote for the {job}: {link} Happy to walk through it on a call. {me}, {co}',
        fr: 'Bonjour {first}, avez-vous bien reçu la soumission pour {job}? La voici : {link} Je peux vous l’expliquer au téléphone. {me}, {co}' },
      { id: 'f2', cat: 'follow', name: 'Quote follow-up 2', when: '7 days after sending', auto: '7 days after the quote, at 9 am', ic: ['chat', 'violet'], who: 'dana', client: 'Dana Whitfield', defCh: 1, vars: ['first', 'job', 'link', 'me'],
        subj: { en: 'Any questions about the {job}?', fr: 'Des questions sur {job}?' },
        en: 'Hi {first}, the quote for the {job} is still open: {link} If the timing or scope needs a change, reply and I’ll adjust it. {me}',
        fr: 'Bonjour {first}, la soumission pour {job} est toujours valide : {link} Si l’échéancier ou les travaux doivent changer, répondez-moi. {me}' },
      { id: 'f3', cat: 'follow', name: 'Quote follow-up 3', when: '14 days after, the last one', auto: '14 days after the quote, then stops', ic: ['chat', 'violet'], who: 'dana', client: 'Dana Whitfield', defCh: 0, vars: ['first', 'job', 'link', 'me', 'co'],
        subj: { en: 'Your quote expires soon', fr: 'Votre soumission expire bientôt' },
        en: 'Hi {first}, a last note on the {job} quote. It expires soon and our fall schedule is filling up. {link} {me}, {co}',
        fr: 'Bonjour {first}, un dernier mot sur la soumission pour {job}. Elle expire bientôt et notre horaire d’automne se remplit. {link} {me}, {co}' },
      { id: 'r1', cat: 'remind', name: 'Invoice due soon', when: '3 days before the due date', auto: '3 days before the due date, at 9 am', ic: ['bell', 'amber'], who: 'hart', client: 'Lena Hart', defCh: 0, vars: ['first', 'amount', 'job', 'due', 'inv', 'co'],
        subj: { en: 'Invoice for the {job}, due {due}', fr: 'Facture pour {job}, due le {due}' },
        en: 'Hi {first}, a reminder that {amount} for the {job} is due {due}. Pay by card or e-Transfer here: {inv} Thanks, {co}',
        fr: 'Bonjour {first}, un rappel : {amount} pour {job} est dû le {due}. Payez par carte ou virement Interac ici : {inv} Merci, {co}' },
      { id: 'r2', cat: 'remind', name: 'Invoice overdue', when: '7 and 14 days late', auto: '7 and 14 days after the due date', ic: ['bell', 'rose'], who: 'hart', client: 'Lena Hart', defCh: 1, vars: ['first', 'job', 'amount', 'due', 'inv', 'co'],
        subj: { en: 'Your invoice is past due', fr: 'Votre facture est en retard' },
        en: 'Hi {first}, the invoice for the {job} ({amount}) was due {due}. You can pay here: {inv} If it’s already sent, thank you. {co}',
        fr: 'Bonjour {first}, la facture pour {job} ({amount}) était due le {due}. Vous pouvez payer ici : {inv} Si c’est déjà fait, merci. {co}' },
      { id: 'r3', cat: 'remind', name: 'Signature reminder', when: '2 days after sending a contract', auto: '2 days after the contract, at 9 am', ic: ['pen', 'indigo'], who: 'hart', client: 'Lena Hart', defCh: 0, vars: ['first', 'job', 'sign', 'me'],
        subj: { en: 'Your contract is ready to sign', fr: 'Votre contrat est prêt à signer' },
        en: 'Hi {first}, the contract for the {job} is ready to sign: {sign} It takes about a minute. {me}',
        fr: 'Bonjour {first}, le contrat pour {job} est prêt à signer : {sign} Ça prend environ une minute. {me}' },
      { id: 'rv', cat: 'review', name: 'Review request', when: '2 days after a job is done', auto: '2 days after the job is marked done', ic: ['star', 'gold'], who: 'okoye', client: 'Grace Okoye', defCh: 1, vars: ['first', 'job', 'review', 'me', 'co'],
        subj: { en: 'How did we do?', fr: 'Comment avons-nous fait?' },
        en: 'Hi {first}, thanks for having us for the {job}. If you’re happy with the work, a short review helps a small crew like ours: {review} {me}, {co}',
        fr: 'Bonjour {first}, merci de nous avoir confié {job}. Si vous êtes satisfaite, un court avis aide beaucoup une petite équipe comme la nôtre : {review} {me}, {co}' },
      { id: 'ow', cat: 'way', name: 'On my way', when: 'When the crew starts driving', auto: 'When the crew taps On my way', ic: ['truck', 'teal'], who: 'okoye', client: 'Grace Okoye', defCh: 1, vars: ['first', 'me', 'co', 'eta'],
        subj: { en: '{co} is on the way', fr: '{co} est en route' },
        en: 'Hi {first}, {me} from {co} is on the way. Arriving around {eta}.',
        fr: 'Bonjour {first}, {me} de {co} est en route. Arrivée vers {eta}.' }
    ];
    var cur = T.filter(function (x) { return x.id === sel; })[0] || T[0];
    var li = lang === 'en' ? 0 : 1, key = cur.id + '_' + lang;
    var text = edits[key] !== undefined ? edits[key] : cur[lang];
    var dirty = edits[key] !== undefined && edits[key] !== (saved[key] !== undefined ? saved[key] : cur[lang]);
    var parse = function (s) { var out = [], re = /\{(\w+)\}/g, m, last = 0, vi = 0; while ((m = re.exec(s))) { if (m.index > last) out.push({ t: s.slice(last, m.index) }); out.push({ v: m[1], i: vi++ }); last = re.lastIndex; } if (last < s.length) out.push({ t: s.slice(last) }); return out; };
    var sample = SAMPLE[cur.who][lang];
    var fill = function (s) { return s.replace(/\{(\w+)\}/g, function (a, k) { return sample[k] || ''; }); };
    var removeAt = function (n) { var c = 0; var s2 = text.replace(/\s?\{(\w+)\}/g, function (a) { return c++ === n ? '' : a; }); var e = Object.assign({}, self.g('edits', {})); e[key] = s2; set({ edits: e }); };
    var body = parse(text).map(function (p) { return p.v ? { isVar: true, isText: false, label: V[p.v] ? V[p.v][li] : p.v, aria: 'Remove ' + (V[p.v] ? V[p.v][li] : p.v), canRemove: !RO, remove: function () { if (!RO) removeAt(p.i); } } : { isVar: false, isText: true, text: p.t, label: '', aria: '', canRemove: false, remove: function () {} }; });
    var subj = parse(cur.subj[lang]).map(function (p) { return p.v ? { isVar: true, isText: false, label: V[p.v][li], text: '' } : { isVar: false, isText: true, label: '', text: p.t }; });
    var pv = fill(text).replace(/\s+/g, ' ').trim();
    var CH = ['Email', 'SMS', 'WhatsApp'];
    var segs = Math.ceil(pv.length / 160);
    var FIL = [['all', 'All'], ['follow', 'Follow-ups'], ['remind', 'Reminders'], ['review', 'Reviews'], ['way', 'On the way']];
    var shown = T.filter(function (x) { return f === 'all' || x.cat === f; });
    var UI = { en: { subject: 'Subject', message: 'Message', insert: 'Tap to add', preview: 'Preview' }, fr: { subject: 'Objet', message: 'Message', insert: 'Touchez pour ajouter', preview: 'Aperçu' } };
    var autoOn = autoMap[cur.id] !== undefined ? autoMap[cur.id] : true;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'You’re offline.', 'Edits save on this phone and sync when you’re back.'],
      readOnly: ['b-info', 'eye', 'sky', 'View only.', 'Your role can read templates but not change them.'],
      locked: ['b-acc', 'lock', 'violet', 'Editing templates is included in Business.', 'Clients get the standard wording until then. Plans can’t be changed in the app.']
    };
    var b = B[ST];
    var closeMenu = function () { set({ menu: false }); };
    var isEdited = function (x) { return ['en', 'fr'].some(function (l) { var k = x.id + '_' + l; return saved[k] !== undefined && saved[k] !== x[l]; }); };
    return {
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      canEdit: !RO, ui: UI[lang],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: T.filter(function (t) { return x[0] === 'all' || t.cat === x[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      list: shown.map(function (x) { var on = x.id === cur.id, ed = isEdited(x) || x.id === 'f1'; return { name: x.name, when: x.when + ' · ' + CH[x.defCh], ic: ic(x.ic[0], x.ic[1]), on: on, cls: on ? 'on' : '', tag: ed ? 'Edited' : 'Default', tagCls: ed ? 'tag-acc' : '', pick: function () { set({ sel: x.id, chan: x.defCh }); } }; }),
      cur: { name: cur.name, when: 'EN and FR', auto: cur.auto },
      langInd: 'width: calc((100% - 4px) / 2); transform: translateX(' + (li * 100) + '%)',
      langs: [['en', 'English'], ['fr', 'Français']].map(function (l) { var on = l[0] === lang; return { label: l[1], on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ lang: l[0] }); } }; }),
      chInd: 'width: calc((100% - 4px) / 3); transform: translateX(' + (chan * 100) + '%)',
      chans: [['Email', 'Email'], ['SMS', 'Text message'], ['WhatsApp', 'WhatsApp']].map(function (c, j) { var on = j === chan; return { label: c[0], aria: c[1], on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ chan: j }); } }; }),
      isEmail: chan === 0, isText: chan > 0, isWa: chan === 2, waIc: ic('chat', 'sage'),
      waWord: lang === 'en' ? 'Approved' : 'In review', waSt: lang === 'en' ? 'st-ok si-check' : 'st-acc si-q2',
      subj: subj, body: body,
      vars: cur.vars.map(function (k) { return { label: V[k][li], add: function () { var e = Object.assign({}, self.g('edits', {})); e[key] = text.replace(/\s+$/, '') + ' {' + k + '}'; set({ edits: e }); } }; }),
      countLine: chan === 0 ? pv.split(' ').length + ' words' : pv.length + ' characters',
      countSub: chan === 1 ? (segs > 1 ? segs + ' texts each time' : '1 text') : chan === 2 ? '1 WhatsApp message' : 'Your logo and signature are added',
      countStyle: chan === 1 && segs > 1 ? 'color: var(--warn)' : '',
      previewFor: cur.client, pvSubject: fill(cur.subj[lang]), pvText: pv, pvTime: lang === 'en' ? 'Today 9:00 am' : 'Aujourd’hui 9 h 00',
      pvFrom: chan === 1 ? 'From (416) 555-0199' : 'From Rossi Renovations on WhatsApp', bubCls: chan === 2 ? 'wa' : '',
      autoIc: ic('clock', 'teal'), testIc: ic('send', 'violet'), autoOn: autoOn,
      autoTrack: (autoOn ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45' : ''), autoKnob: autoOn ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      toggleAuto: function () { if (RO) return; var a = Object.assign({}, autoMap); a[cur.id] = !autoOn; set({ auto: a }); },
      testLabel: tested ? 'Test sent to you' : 'Send me a test', test: function () { set({ tested: true }); },
      saveLabel: dirty ? 'Save changes' : 'Saved', saveStyle: dirty ? '' : 'opacity: .45;',
      save: function () { if (!dirty) return; var s = Object.assign({}, saved); s[key] = text; set({ saved: s }); },
      menuOpen: menuOpen, openMenu: function () { set({ menu: true }); }, closeMenu: closeMenu,
      menu: [
        { label: 'Reset to default', sub: 'Our standard wording, ' + (lang === 'en' ? 'English' : 'French'), ic: ic('sync', 'indigo'), go: function () { var e = Object.assign({}, edits); e[key] = cur[lang]; var s = Object.assign({}, saved); s[key] = cur[lang]; set({ edits: e, saved: s, menu: false }); } },
        { label: 'Copy to the other language', sub: 'Then translate the text', ic: ic('globe', 'azure'), go: closeMenu },
        { label: 'Duplicate', sub: 'Start a new template from this one', ic: ic('doc', 'slate'), go: closeMenu },
        { label: 'Where it’s used', sub: 'Quotes, Settings, automations', ic: ic('link', 'teal'), go: closeMenu }
      ]
    };
