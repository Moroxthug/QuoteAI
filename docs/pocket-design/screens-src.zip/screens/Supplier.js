    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var menuOpen = this.g('menu', false), called = this.g('called', false), priceDone = this.g('priceDone', false), matched = this.g('matched', null);
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var spark = function (vals) {
      var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), rg = mx - mn || 1;
      var pts = vals.map(function (v, i) { return [2 + i * (60 / (vals.length - 1)), mx === mn ? 14 : 24 - (v - mn) / rg * 20]; });
      return { pts: pts.map(function (p) { return p[0].toFixed(1) + ',' + p[1].toFixed(1); }).join(' '), ex: pts[pts.length - 1][0].toFixed(1), ey: pts[pts.length - 1][1].toFixed(1) };
    };
    var P = [
      ['Drywall 1/2" 4×8', 'per sheet', [18.40, 18.40, 18.95, 19.25, 19.60, 19.95], 'Sep 15'],
      ['Joint compound 17 L', 'per pail', [24.97, 24.97, 25.48, 25.48, 26.48, 26.48], 'Aug 30'],
      ['SPF stud 2×4×8', 'per stud', [5.98, 5.98, 5.79, 5.62, 5.49, 5.49], 'Aug 12'],
      ['Drywall screws 1-5/8", 5 lb', 'per box', [38.97, 38.97, 38.97, 38.97, 38.97, 38.97], 'No change']
    ];
    var prices = P.map(function (p) {
      var a = p[2][0], b = p[2][p[2].length - 1], d = (b - a) / a * 100, s = spark(p[2]);
      return { name: p[0], unit: p[1], from: money(a), to: money(b), pts: s.pts, ex: s.ex, ey: s.ey, when: p[3],
        delta: Math.abs(d) < 0.05 ? '0%' : (d > 0 ? '+' : '−') + Math.abs(d).toFixed(1) + '%',
        color: d > 0.05 ? 'color: var(--warn)' : d < -0.05 ? 'color: var(--ok)' : 'color: var(--faint)' };
    });
    var orders = [
      ['Hart basement · Sep 27', 'Drywall, 64 sheets', '', 1842.10, 'Delivered', 'st-ok', 'si-check', 'truck', 'amber'],
      ['Hart basement · for Thu', 'Compound and tape', '', 312.44, 'Ready for pickup', 'st-ok', 'si-check', 'box', 'amber'],
      ['Whitfield bedrooms · Sep 22', 'Primer, rollers, poly', '', 486.06, 'Picked up', 'st-mute', 'si-check', 'box', 'stone'],
      ['Okoye Condo service · Sep 28', 'Flooring nails, shims', '', 64.00, 'Backordered', 'st-warn', 'si-clock', 'clock', 'slate']
    ].map(function (o) { return { no: o[0], job: o[1], meta: o[2], amt: money(o[3]), status: o[4], st: o[5] + ' ' + o[6], ic: ic(o[7], o[8]) }; });
    var R = [
      ['r1', 'Sep 27 · drywall order', 1842.10, 'Matched to Hart basement', false],
      ['r2', 'Sep 22 · paint supplies', 486.06, 'Matched to Whitfield bedrooms', false],
      ['r3', 'Sep 24 · counter purchase', 57.23, 'Photo from Luca, no job yet', true]
    ];
    var receipts = R.map(function (r) {
      var needs = r[4] && !matched;
      return { title: r[1] + (needs ? '' : ''), meta: needs ? money(r[2]) + ' · ' + r[3] : (r[4] ? 'Matched to ' + matched : r[3]),
        amt: money(r[2]), needs: needs && !RO, done: !needs || RO, status: needs ? 'To match' : 'Matched', st: needs ? 'st-warn si-clock' : 'st-ok si-check',
        ic: ic('receipt', needs ? 'amber' : 'sage'), match: function () { set({ matched: 'Okoye Condo service' }); } };
    });
    var nMatched = receipts.filter(function (r) { return r.status === 'Matched'; }).length;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'You’re offline.', 'Prices and orders are from this morning. Calls still work.'],
      readOnly: ['b-info', 'eye', 'sky', 'View only.', 'Your role can see this supplier but not change it.']
    };
    var b = B[ST];
    var closeAll = function () { set({ menu: false }); };
    return {
      hdIc: ic('house', 'amber'), warnIc: ic('warn', 'amber'), okIc: ic('check', 'sage'),
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      call: function () { set({ called: true }); }, callLabel: called ? 'Calling…' : 'Call supplier',
      prices: prices,
      showNudge: !priceDone && !RO, priceDone: priceDone && !RO,
      updatePrice: function () { set({ priceDone: true }); }, undoPrice: function () { set({ priceDone: false }); },
      orders: orders, receipts: receipts, rcSummary: nMatched + ' of 3 matched',
      menuOpen: menuOpen, openMenu: function () { set({ menu: true }); }, closeAll: closeAll,
      menu: [
        { label: 'Edit supplier', sub: 'Contacts, account and terms', ic: ic('pen', 'indigo'), style: RO ? 'opacity: .45' : '' },
        { label: 'Share order list', sub: 'Text or email what you need', ic: ic('list', 'azure'), style: '' },
        { label: 'Statement', sub: 'September · PDF', ic: ic('doc', 'azure'), style: '' },
        { label: 'Add a contact', sub: 'Another rep or the yard', ic: ic('user', 'sage'), style: RO ? 'opacity: .45' : '' },
        { label: 'Archive supplier', sub: 'Keeps past orders and receipts', ic: ic('box', 'stone'), style: RO ? 'opacity: .45' : 'color: var(--bad)' }
      ]
    };
