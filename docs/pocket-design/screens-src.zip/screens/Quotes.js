    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { draft: ['Draft', 'st-mute si-draft'], sent: ['Sent', 'st-info si-q1'], viewed: ['Viewed', 'st-acc si-q2'], accepted: ['Accepted', 'st-ok si-check'], declined: ['Declined', 'st-bad si-x'], expired: ['Expired', 'st-mute si-off'], expiring: ['Expires Fri', 'st-warn si-clock'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    var data = [
      ['Q-2026-119', 'Dana Whitfield', 'Bedrooms and bath ceiling', 4131.05, 'draft', 'week', 'Today'],
      ['Q-2026-118', 'Priya Nair', 'Kitchen backsplash', 1865.10, 'viewed', 'week', 'Viewed 2 h ago'],
      ['Q-2026-117', 'Harbourfront Dental', 'Reception repaint', 6420.00, 'expiring', 'week', 'Sent Sep 24'],
      ['Q-2026-116', 'Gill Residence', 'Deck refinish', 2980.00, 'sent', 'week', 'Sent Mon'],
      ['Q-2026-114', 'Tom & Lena Hart', 'Basement change order', 3955.00, 'accepted', 'earlier', 'Accepted Sep 19'],
      ['Q-2026-112', 'Okoye Condo', 'Hallway flooring', 2210.00, 'accepted', 'earlier', 'Accepted Sep 15'],
      ['Q-2026-110', 'Marchetti Bakery', 'Storefront trim', 1480.00, 'declined', 'earlier', 'Declined Sep 12'],
      ['Q-2026-108', 'Chen Family', 'Laundry room refresh', 3300.00, 'expired', 'earlier', 'Expired Sep 9'],
      ['Q-2026-107', 'Tom & Lena Hart', 'Basement finish', 38400.00, 'accepted', 'earlier', 'Accepted Aug 28']
    ];
    var FIL = [['all', 'All', function () { return true; }], ['draft', 'Draft', function (s) { return s === 'draft'; }], ['waiting', 'Waiting', function (s) { return s === 'sent' || s === 'viewed' || s === 'expiring'; }], ['accepted', 'Accepted', function (s) { return s === 'accepted'; }], ['closed', 'Closed', function (s) { return s === 'declined' || s === 'expired'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[0]).toLowerCase().indexOf(ql) >= 0); });
    var acted = this.g('acted', {});
    var mkActs = function (no, list) { return list.map(function (a) { return { label: a[0], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); if (!a[4]) return; var n = Object.assign({}, self.g('acted', {})); n[no] = [a[4], a[5]]; set({ acted: n }); } }; }); };
    var QA = {
      draft: [['Send', 'send', 'azure', 'info', 'Sent', 'st-info si-q1'], ['Duplicate', 'doc', 'slate', 'mute']],
      sent: [['Follow up', 'chat', 'violet', 'acc', 'Followed up', 'st-info si-q1'], ['Mark won', 'check', 'sage', 'ok', 'Accepted', 'st-ok si-check']],
      accepted: [['Invoice deposit', 'receipt', 'amber', 'warn', 'Deposit sent', 'st-info si-q1'], ['Start job', 'cone', 'amber', 'ok', 'Job started', 'st-ok si-live']],
      declined: [['Revive', 'sync', 'indigo', 'acc', 'Draft', 'st-mute si-draft'], ['Archive', 'box', 'stone', 'mute', 'Archived', 'st-mute si-off']]
    };
    QA.viewed = QA.sent; QA.expiring = QA.sent; QA.expired = QA.declined;
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Follow up': 'Followed up', 'Mark won': 'Marked won', 'Send': 'Sent', 'Invoice deposit': 'Deposit invoiced', 'Revive': 'Revived', 'Start job': 'Job started', 'Extend': 'Extended', 'Call': 'Calling', 'Review': 'Reviewed', 'Schedule': 'Scheduled', 'Invoice term 3': 'Invoiced', 'Ask why': 'Asked', 'Renew': 'Renewed' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); var sw = el && el.closest('.swr'); if (sw) sw.scrollLeft = 0; var go = function () { var c = el.closest('.xc'); if (c && c.classList.contains('open')) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }; if (cur !== id && el) { setTimeout(go, 120); setTimeout(go, 520); } }; };
    // per quote: caption (scope), rows [title, context, status, statusCls, btn, amount], primary action
    var DET = {
      'Q-2026-119': { cap: 'Two bedrooms and the bath ceiling, 2 coats', main: 'Send', rows: [['Drafted today', 'From your site notes, 9:40', 'Not sent', 'st-mute si-draft'], ['Two bedrooms', 'Walls and trim, patch and paint', '', '', '', '$2,685.25'], ['Bath ceiling', 'Mould-resistant primer and paint', '', '', '', '$1,445.80'], ['Valid for 30 days', 'Starts counting when you send it']] },
      'Q-2026-118': { cap: 'Subway tile backsplash, 28 sq ft', main: 'Follow up', rows: [['Sent Sep 25', 'By email and text', 'Delivered', 'st-ok si-check'], ['Viewed twice', 'Yesterday 8:14 pm and 2 h ago', 'Viewed', 'st-acc si-q2', 'Call'], ['2 options', 'Standard white or handmade (+$620.00)'], ['Valid until Oct 25', '26 days left']] },
      'Q-2026-117': { cap: 'Reception repaint, after hours over 2 weekends', main: 'Follow up', rows: [['Sent Sep 24', 'To the office manager', 'Delivered', 'st-ok si-check'], ['Opened once', 'Sep 24, 4:02 pm · no reply since', 'Viewed', 'st-acc si-q2'], ['Labour and materials', '2 painters, 4 evenings · Benjamin Moore', '', '', '', '$6,420.00'], ['Expires Fri Oct 2', '3 days left', 'Expires Fri', 'st-warn si-clock', 'Extend']] },
      'Q-2026-116': { cap: 'Strip, stain and seal, 320 sq ft deck', main: 'Follow up', rows: [['Sent Mon Sep 28', 'By email', 'Delivered', 'st-ok si-check'], ['Not opened yet', 'Sent 1 day ago', 'Not opened', 'st-mute si-off'], ['Said yes by phone?', 'Mark it won to start the job', '', '', 'Mark won'], ['Valid until Oct 28', '29 days left']] },
      'Q-2026-114': { cap: 'Egress window and extra pot lights', main: 'Schedule', rows: [['Accepted Sep 19', 'Signed by Lena Hart', 'Accepted', 'st-ok si-check'], ['Invoiced', 'INV-0420 · half paid Sep 24', 'Partly paid', 'st-warn si-q3'], ['Added to Basement finish', 'Adds 3 days to the plan']] },
      'Q-2026-112': { cap: 'Luxury vinyl plank, 240 sq ft hallway', main: 'Start job', rows: [['Accepted Sep 15', 'Signed online', 'Accepted', 'st-ok si-check'], ['Job drafted', 'Hallway flooring · plan to review', 'Review setup', 'st-acc si-q2', 'Review'], ['Invoiced in full', 'INV-0418 · paid Sep 22', 'Paid', 'st-ok si-check', '', '$2,497.30']] },
      'Q-2026-110': { cap: 'Storefront trim, scrape and repaint', main: 'Revive', rows: [['Declined Sep 12', 'Viewed 3 times before', 'Declined', 'st-bad si-x'], ['No reason given', 'A short note often reopens it', '', '', 'Ask why']] },
      'Q-2026-108': { cap: 'Laundry room paint and new shelving', main: 'Renew', rows: [['Sent Aug 10', 'Viewed once, Aug 11', 'Viewed', 'st-acc si-q2'], ['Expired Sep 9', 'No reply after 1 follow-up', 'Expired', 'st-mute si-off'], ['Renew with today’s prices', 'Materials up about 2% since August']] },
      'Q-2026-107': { cap: 'Full basement finish, 850 sq ft', main: 'Invoice term 3', rows: [['Accepted Aug 28', 'Signed by Tom and Lena', 'Accepted', 'st-ok si-check'], ['Basement finish', '64% done · drywall phase', 'Active', 'st-ok si-live'], ['Progress invoices', '2 of 4 sent · INV-0412 is 9 days late', '1 late', 'st-bad si-alert'], ['Holdback 10%', 'Released Nov 14', 'Scheduled', 'st-info si-clock', '', '$3,840.00']] }
    };
    var mk = function (d, i) { var ini = d[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); var ac = acted[d[0]]; return { no: d[0], client: d[1], job: d[6] + ' · ' + d[2], amt: money(d[3]), status: ac ? ac[0] : S[d[4]][0], st: ac ? ac[1] : S[d[4]][1], ini: ini, tn: tints[i % tints.length], acts: mkActs(d[0], QA[d[4]]),
      open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
      x: (function (x) { var mk2 = d[0] + 'm', dn = !!xd[mk2]; return { cap: x.cap, rows: rowsOf(d[0], x.rows), main: dn ? (DONE[x.main] || 'Done') : x.main, mainCls: dn ? 'done' : '', mainAct: flip(mk2) }; })(DET[d[0]]) }; };
    var groups = [['week', 'This week'], ['earlier', 'Earlier']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + d[3]; }, 0);
      return { title: g[1], total: rs.length ? money(tot) : '', rows: rs.map(function (d) { return mk(d, data.indexOf(d)); }), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '', first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Waiting', value: '$15,396', sub: '4 quotes', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Won this month', value: '$6,165', sub: '2 accepted', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Win rate', value: '62%', sub: '↑ 4 pts', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), cap: 'Waiting longest first', rows: rowsOf('kpi', [
        ['Harbourfront Dental', 'Reception repaint · sent Sep 24', 'Expires Fri', 'st-warn si-clock', 'Follow up', '$6,420.00'],
        ['Priya Nair', 'Kitchen backsplash · viewed twice', 'Viewed', 'st-acc si-q2', 'Follow up', '$1,865.10'],
        ['Gill Residence', 'Deck refinish · not opened', 'Sent', 'st-info si-q1', 'Follow up', '$2,980.00'],
        ['Dana Whitfield', 'Bedrooms and bath ceiling · draft', 'Not sent', 'st-mute si-draft', 'Send', '$4,131.05'],
        ['Won in September', 'Hart change order, Okoye flooring', 'Accepted', 'st-ok si-check', '', '$6,165.00']]),
        stats: [{ l: 'Sent in Sep', v: '8' }, { l: 'Avg. days', v: '3.2' }, { l: 'Expiring', v: '1' }] },
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
