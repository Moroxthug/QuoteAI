    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var freq = self.g('freq', 1);
    var due = [['Septembre', 'Dû le 31 oct.'], ['1er juil. – 30 sept.', 'Dû le 31 oct.'], ['2026', 'Dû le 31 mars']][freq];
    var collected = ['2 071,60 $', '6 214,80 $', '24 907,35 $'][freq];
    var split = self.g('split', false);
    return {
      roBanner: roBanner, rate: '13 %', taxName: 'TVH', pctIc: ic('percent', 'violet'),
      gProv: grp('Où vous travaillez', [
        lnk('pin', 'clay', 'Province', 'Taxe des soumissions et factures', 'Ontario', RO ? '' : '#'),
        val('receipt', 'violet', 'N° de TPS/TVH', 'Figure sur vos documents', '81234 5678 RT0001', true),
        sw('byJob', true, 'house', 'amber', 'Province du chantier', 'Pour les chantiers hors Ontario')
      ], '', 80),
      gEx: grp('Clients exonérés', [
        lnk('user', 'teal', 'Gill Residence', 'Remboursement habitation neuve cédé', 'Remboursement', 'Client.dc.html'),
        lnk('user', 'sky', 'Chen Family', 'Certificat d’exonération au dossier', 'Exonéré', 'Client.dc.html'),
        lnk('plus', 'slate', 'Ajouter une exonération', 'Choisissez un client et le motif', '', '#')
      ].slice(0, RO ? 2 : 3), 'Leurs soumissions et factures partent sans TVH. Gardez les justificatifs pour l’ARC.', 130),
      gSplit: grp('Matériaux et main-d’œuvre', [
        sw('split', false, 'bricks', 'stone', 'Séparer la main-d’œuvre', split ? 'Chaque soumission montre deux sous-totaux' : 'Requis pour les chantiers en C.-B. et au Québec')
      ], 'C.-B. : vous payez vous-même la TVP de 7 % sur les matériaux et ne la facturez pas sur la main-d’œuvre. Québec : facturez la TPS de 5 % et la TVQ de 9,975 % sur les deux.', 180),
      gDocs: grp('Sur vos documents', [
        seg('show', 0, 'doc', 'azure', 'Afficher la taxe', '', ['Ligne distincte', 'Incluse aux prix']),
        sw('perLine', false, 'list', 'lilac', 'Taxe par ligne', 'Plus clair si certaines lignes sont exonérées'),
        sw('showNum', true, 'receipt', 'violet', 'Afficher votre n° de TPS/TVH', 'Vos clients en ont besoin pour leurs crédits')
      ], '', 230),
      gFile: grp('Déclarations', [
        seg('freq', 1, 'cal', 'teal', 'Fréquence des déclarations', '', ['Mensuelle', 'Trimestrielle', 'Annuelle']),
        stat(mk('clock', 'amber', 'Prochaine déclaration', due[0]), due[1], 'st-warn si-clock'),
        lnk('bank', 'sage', 'TVH perçue', 'Moins la TVH payée sur les coûts', collected, 'Books.dc.html', true)
      ], 'Réglez-la comme au dossier de l’ARC. Nous vous le rappelons deux semaines avant chaque déclaration.', 280)
    };
