    var sw = function (key, def, label) { var on = self.g(key, def); return { on: on, track: on ? 'background: var(--acc)' : 'background: var(--track-off)', knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)', flip: function () { var o = {}; o[key] = !self.g(key, def); set(o); } }; };
    var fchip = self.g('fc', 'all'), tab = self.g('tab', 0), seg = self.g('seg', 2), days = self.g('days', 30), radio = self.g('radio', 0), sw9 = self.g('swipe', true), tst = self.g('toast', 'shown'), mic = self.g('mic', 0);
    var chk = self.g('chk', { a: true, b: false, t: true });
    var S = function (name, arr) { return { name: name, items: arr.map(function (x) { var p = x[1].split(' '); return { l: x[0], c: 'st-' + p[0] + (p[1] ? ' si-' + p[1] : '') }; }) }; };
    var MIC = [
      { cls: 'idle', title: 'Idle', sub: 'Tap to describe the job', aria: 'Start voice input' },
      { cls: 'live', title: 'Listening', sub: 'Level follows your voice · tap to stop', aria: 'Stop listening' },
      { cls: 'busy', title: 'Transcribing', sub: 'Turning your words into line items', aria: 'Transcribing' }
    ];
    return {
      i: { receipt: ic('receipt', 'clay'), house: ic('house', 'teal'), box: ic('box', 'slate'), warn2: ic('warn', 'clay'), building: ic('building', 'violet'), percent: ic('percent', 'azure'),
        eye: ic('eye', 'sky'), cloud: ic('cloud', 'amber'), check: ic('check', 'sage'), warn: ic('warn', 'clay'), star: ic('star', 'violet'), doc: ic('doc', 'violet'), warn3: ic('cloud', 'slate'), user: ic('user', 'slate'), building2: ic('building', 'violet') },
      btns: [['Primary', 'btn-p', 'Send quote', 'Sending'], ['Secondary', 'btn-s', 'Preview', 'Loading'], ['Destructive', 'btn-d', 'Delete draft', 'Deleting'], ['Accent', 'btn-a', 'Ask quoteAI', 'Thinking'], ['Link', 'cp-link', 'Forgot password?', 'Opening']]
        .map(function (b) { return { name: b[0], cls: b[1], label: b[2], busy: b[3] }; }),
      chips: [['all', 'All', 9], ['draft', 'Draft', 1], ['waiting', 'Waiting', 3], ['accepted', 'Accepted', 3], ['closed', 'Closed', 2]].map(function (c) { var on = c[0] === fchip; return { label: c[1], n: c[2], on: on, cls: on ? 'on' : '', pick: function () { set({ fc: c[0] }); } }; }),
      tabs: ['Overview', 'Schedule', 'Crew', 'Costs', 'Photos', 'Reports', 'Money', 'Permits'].map(function (t, n) { return { label: t, cls: n === tab ? 'on' : '', pick: function () { set({ tab: n }); } }; }),
      sw1: sw('sw1', true), sw2: sw('sw2', false),
      days: days, minD: days <= 7, dec: function () { set({ days: Math.max(7, self.g('days', 30) - 7) }); }, inc: function () { set({ days: self.g('days', 30) + 7 }); },
      segInd: 'transform: translateX(' + (seg * 100) + '%)',
      seg: ['Light', 'Dark', 'Auto'].map(function (l, n) { var on = n === seg; return { label: l, on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ seg: n }); } }; }),
      checks: [['a', 'Include materials', 'Checkbox · checked', false, false], ['b', 'Show hours on the quote', 'Checkbox · unchecked', false, false], ['t', 'Drywall taped', 'Round tick · task done', true, false], ['z', 'Final walkthrough', 'Disabled', false, true]].map(function (c) {
        var on = !!chk[c[0]];
        return { label: c[1], sub: c[2], on: on, dis: c[4], cls: (on ? 'on ' : '') + (c[3] ? 'rd ' : '') + (c[4] ? 'off' : ''), flip: function () { var o = Object.assign({}, self.g('chk', { a: true, b: false, t: true })); o[c[0]] = !o[c[0]]; set({ chk: o }); } };
      }),
      radios: [['50% deposit, 50% at the end', 'Most common for small jobs'], ['30 / 40 / 30', 'Deposit, midpoint, completion'], ['All at the end', 'One invoice when the job is done']].map(function (r, n) { var on = n === radio; return { label: r[0], sub: r[1], on: on, cls: on ? 'on' : '', pick: function () { set({ radio: n }); } }; }),
      status: [
        S('Quotes', [['Draft', 'mute draft'], ['Sent', 'info q1'], ['Viewed', 'acc q2'], ['Accepted', 'ok check'], ['Declined', 'bad x'], ['Expired', 'mute off']]),
        S('Invoices', [['Draft', 'mute draft'], ['Scheduled', 'info clock'], ['Sent', 'info q1'], ['Viewed', 'acc q2'], ['Awaiting confirmation', 'warn clock'], ['Partially paid', 'warn q3'], ['Paid', 'ok check'], ['Overdue', 'bad alert'], ['Void', 'mute x']]),
        S('Jobs', [['Planning', 'info q1'], ['Active', 'ok live'], ['On hold', 'warn pause'], ['Completed', 'mute check']]),
        S('Contracts', [['Draft', 'mute draft'], ['Sent', 'info q1'], ['Viewed', 'acc q2'], ['Signed', 'ok check'], ['Declined', 'bad x'], ['Voided', 'mute x'], ['Expired', 'mute off']]),
        S('Leads', [['New', 'acc dot'], ['Contacted', 'info q1'], ['Quoted', 'acc q2'], ['Won', 'ok check'], ['Lost', 'bad x'], ['Unsubscribed', 'mute off']]),
        S('Crew and time', [['On site', 'ok live'], ['En route', 'warn q1'], ['Off', 'mute off'], ['To approve', 'warn clock'], ['Approved', 'ok check'], ['Rejected', 'bad x']]),
        S('Permits', [['Needed', 'warn clock'], ['Applied', 'info q1'], ['Issued', 'ok check'], ['Closed', 'mute check'], ['Not required', 'mute off']])
      ],
      shapes: [['Not sent yet', 'mute draft'], ['On its way', 'info q1'], ['Seen, halfway', 'acc q2'], ['Nearly there', 'warn q3'], ['Done', 'ok check'], ['Happening now', 'ok live'], ['Waiting', 'warn clock'], ['Paused', 'warn pause'], ['Needs you', 'bad alert'], ['Stopped', 'bad x'], ['No longer active', 'mute off']].map(function (x) { var p = x[1].split(' '); return { l: x[0], c: 'st-' + p[0] + ' si-' + p[1] }; }),
      swipe: function () { set({ swipe: !self.g('swipe', true) }); }, swipeTx: 'transform: translateX(' + (sw9 ? -156 : 0) + 'px)',
      kpis: [
        { label: 'Waiting', value: '$15,396', sub: '4 quotes', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Won this month', value: '$6,165', sub: '2 accepted', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Win rate', value: '62%', sub: '↑ 4 pts', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      tiles: [
        { label: 'Collected in September', value: '$48,230', sub: '↑ 12% vs August', subStyle: 'color: var(--ok)' },
        { label: 'Overdue', value: '$3,120', sub: '2 invoices', subStyle: 'color: var(--bad)' },
        { label: 'Crew hours', value: '126.5 h', sub: 'this week', subStyle: 'color: var(--muted)' },
        { label: 'Active jobs', value: '3', sub: '1 starts Oct 5', subStyle: 'color: var(--muted)' }
      ],
      bars: [
        { label: 'Basement finish', val: '64%', vs: '', w: 'width: 64%' },
        { label: 'Hallway flooring', val: '20%', vs: '', w: 'width: 20%; background: var(--acc)' },
        { label: 'Hart budget', val: '90%', vs: 'color: var(--warn)', w: 'width: 90%; background: var(--warn-dot)' },
        { label: 'Deck refinish budget', val: '108%', vs: 'color: var(--bad)', w: 'width: 100%; background: var(--bad)' }
      ],
      skels: [{ a: 'width: 55%', b: 'width: 75%' }, { a: 'width: 42%', b: 'width: 66%' }, { a: 'width: 60%', b: 'width: 50%' }],
      toast: { msg: tst === 'shown' ? 'Quote Q-2026-110 archived' : 'Restored to Quotes', can: tst === 'shown', done: tst !== 'shown', undo: function () { set({ toast: 'undone' }); }, reset: function () { set({ toast: 'shown' }); } },
      crew: [['LB', 'Luca', 'tn1', ''], ['AO', 'Amara', 'tn2', ''], ['SM', 'Sofia', 'tn3', 'later'], ['JR', 'Jonah', 'tn4', 'later'], ['DP', 'Dev', 'tn5', 'off']].map(function (c) { return { ini: c[0], name: c[1], tn: c[2], ring: c[3] }; }),
      mics: MIC.map(function (m, n) {
        var st = n === 0 ? MIC[mic] : m;
        return { cls: st.cls, title: st.title, sub: st.sub, aria: st.aria, isBusy: st.cls === 'busy', notBusy: st.cls !== 'busy', isLive: st.cls === 'live', tap: function () { if (n === 0) set({ mic: (self.g('mic', 0) + 1) % 3 }); } };
      })
    };
