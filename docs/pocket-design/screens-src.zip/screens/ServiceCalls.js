    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var f = this.g('f', 'active'), sheet = this.g('sheet', null), booked = this.g('booked', {}), bill = this.g('bill', {});
    var day = this.g('day', 1), time = this.g('time', 0), who = this.g('who', 0), txt = this.g('txt', true);
    var DAYS = ['Thu Oct 1', 'Fri Oct 2', 'Mon Oct 5', 'Tue Oct 6'], TIMES = ['8–10 am', '10 am–12 pm', '1–3 pm'];
    var CREW = [['Dev Patel', 'DP', 'tn4', 'Installed it'], ['Luca Bianchi', 'LB', 'tn2', 'Foreman'], ['Amara Okafor', 'AO', 'tn1', '']];
    var C = [
      { id: 'ok', client: 'Okoye Condo', ini: 'OC', tn: 'tn3', job: 'Hallway flooring · done Sep 24', issue: 'Squeaky board by the entry',
        reported: 'Reported Sep 28 by Grace Okoye, from the client portal', note: 'One plank near the front door squeaks under the runner. No gap or lifting. Probably needs a trim screw into the joist.',
        photos: [['a', 'photo', 'amber', 'Photo of the plank by the entry'], ['b', 'camera', 'violet', 'Video of the squeak']],
        warranty: true, wTitle: 'Under warranty until Sep 2027', wSub: '1-year workmanship · materials by the maker', defBill: 0, prebooked: null, sec: 'Call Grace' },
      { id: 'gi', client: 'Gill Residence', ini: 'GR', tn: 'tn1', job: 'Deck refinish · done Aug 2025', issue: 'Stain peeling on the top step',
        reported: 'Reported Sep 26 by phone, Harjit Gill', note: 'Top step and the first board of the landing. Heavy foot traffic. Rest of the deck looks good.',
        photos: [['a', 'photo', 'amber', 'Photo of the top step']],
        warranty: false, wTitle: 'Warranty ended Aug 2026', wSub: 'Quote the repair, or bill a service call', defBill: 1, prebooked: null, sec: 'Quote repair' },
      { id: 'hd', client: 'Harbourfront Dental', ini: 'HD', tn: 'tn4', job: 'Repaint · done Mar 2025', issue: 'Scuffs on the reception wall',
        reported: 'Reported Sep 21 by email, office manager', note: 'Chair marks behind the front desk. Touch up with the same eggshell, Dulux Timeless Grey.',
        photos: [['b', 'photo', 'violet', 'Photo of the scuffs']],
        warranty: true, wTitle: 'Under warranty until Mar 2027', wSub: '2-year workmanship on commercial jobs', defBill: 0, prebooked: [0, 0, 1], sec: 'Reschedule' }
    ];
    var NW = 'New', NC = 'No charge';
    var calls = C.map(function (c, i) {
      var bk = booked[c.id] || c.prebooked, bi = bill[c.id] !== undefined ? bill[c.id] : c.defBill;
      var status = bk ? ['Scheduled', 'st-info si-q1'] : [NW, 'st-warn si-alert'];
      return { client: c.client, ini: c.ini, tn: c.tn, job: c.job, issue: c.issue, reported: c.reported, note: c.note, status: status[0], st: status[1],
        photos: c.photos.map(function (p) { return { cls: p[0], ic: ic(p[1], p[2]), label: p[3] }; }),
        wIc: c.warranty ? ic('shield', 'sage') : ic('shield', 'stone'), wTitle: c.wTitle, wSub: c.wSub,
        isBooked: !!bk, visit: bk ? DAYS[bk[0]] + ', ' + TIMES[bk[1]] : '', visitWho: bk ? CREW[bk[2]][0] : '', calIc: ic('cal', 'azure'),
        segStyle: RO ? 'opacity: .55' : '', ind: 'width: calc((100% - 4px) / 2); transform: translateX(' + (bi * 100) + '%)',
        bill: ['No charge', 'Bill the client'].map(function (l, j) { return { label: l, on: j === bi, style: j === bi ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var n = Object.assign({}, self.g('bill', {})); n[c.id] = j; set({ bill: n }); } }; }),
        canAct: !RO, primLabel: bk ? 'Visit details' : 'Schedule visit', primCls: bk ? 'btn-s' : 'btn-p', secLabel: c.sec,
        schedule: function () { if (bk) return; set({ sheet: i, day: 1, time: 0, who: 0 }); } };
    });
    var D = [
      ['Grout touch-up in the laundry room', 'Chen Family', 'Sep 3', 0, NC, 'st-mute si-check', 'check', 'sage'],
      ['Cabinet door alignment', 'Priya Nair', 'Aug 19', 95, 'Paid', 'st-ok si-check', 'receipt', 'amber'],
      ['Paint touch-up, hallway', 'Dana Whitfield', 'Jul 30', 0, NC, 'st-mute si-check', 'check', 'sage'],
      ['Caulking on the storefront trim', 'Marchetti Bakery', 'Jun 12', 180, 'Paid', 'st-ok si-check', 'receipt', 'amber']
    ];
    var done = D.map(function (d) { return { issue: d[0], client: d[1], when: d[2], amt: '$' + d[3].toFixed(2), status: d[4], st: d[5], ic: ic(d[6], d[7]) }; });
    var W = [
      ['Okoye Condo · hallway flooring', 'Finished Sep 24, 2026 · until Sep 2027', 'Covered', 'st-ok', 'si-check', 2],
      ['Harbourfront Dental · reception repaint', 'Finished Mar 2025 · until Mar 2027', 'Covered', 'st-ok', 'si-check', 75],
      ['Priya Nair · kitchen paint', 'Finished Nov 2025 · until Nov 3', 'Ends in 5 weeks', 'st-warn', 'si-clock', 90],
      ['Gill Residence · deck refinish', 'Finished Aug 2025 · ended Aug 2026', 'Ended', 'st-mute', 'si-off', 100]
    ];
    var warranty = W.map(function (w, i) { return { job: w[0], sub: w[1], status: w[2], st: w[3] + ' ' + w[4], sep: i ? 'border-top: 1px solid var(--line)' : '',
      bar: 'width: ' + w[5] + '%; background: ' + (w[5] >= 100 ? 'var(--line2)' : w[5] >= 85 ? 'var(--warn-dot)' : 'var(--ok-dot)') }; });
    var cur = sheet === null ? null : C[sheet];
    var sh = { title: '', days: [], times: [], crew: [], cta: '' };
    if (cur) sh = { title: cur.client + ' · ' + cur.issue.toLowerCase(),
      days: DAYS.map(function (d, j) { var on = j === day; return { label: d, on: on, cls: on ? 'on' : '', pick: function () { set({ day: j }); } }; }),
      times: TIMES.map(function (t, j) { var on = j === time; return { label: t, on: on, cls: on ? 'on' : '', pick: function () { set({ time: j }); } }; }),
      crew: CREW.map(function (c, j) { var on = j === who; return { name: c[0].split(' ')[0], ini: c[1], tn: c[2], note: c[3] || ' ', on: on, bg: on ? 'background: var(--sunk)' : '', ring: on ? 'box-shadow: 0 0 0 2px var(--card), 0 0 0 4px var(--ink)' : '', pick: function () { set({ who: j }); } }; }),
      cta: 'Book ' + DAYS[day] + ', ' + TIMES[time] };
    var nOpen = calls.length;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'You’re offline.', 'Showing calls saved on this phone. Bookings send when you’re back.'],
      readOnly: ['b-info', 'eye', 'sky', 'View only.', 'Your role can see service calls but not book or bill them.']
    };
    var b = B[ST];
    var hasData = ST !== 'empty';
    return {
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      isEmpty: ST === 'empty', hasData: hasData, emptyIc: ic('shield', 'sage'),
      kpis: [
        { label: 'Open calls', value: String(nOpen), sub: Object.keys(booked).length + 1 + ' booked', sep: '' },
        { label: 'Under warranty', value: '5', sub: 'finished jobs', sep: 'border-left: 1px solid var(--line)' },
        { label: 'First visit', value: '2.4 d', sub: 'on average', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: [['active', 'Open', nOpen], ['done', 'Done', done.length]].map(function (x) { var on = x[0] === f; return { label: x[1], count: x[2], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      showActive: f === 'active', showDone: f === 'done', calls: calls, done: done, warranty: warranty,
      sheetOpen: !!cur, sh: sh, close: function () { set({ sheet: null }); },
      txt: txt, txtTrack: txt ? 'background: var(--acc)' : 'background: var(--track-off)', txtKnob: txt ? 'transform: translateX(20px)' : 'transform: translateX(0)', toggleTxt: function () { set({ txt: !txt }); },
      book: function () { var n = Object.assign({}, booked); n[C[sheet].id] = [day, time, who]; set({ booked: n, sheet: null }); }
    };
