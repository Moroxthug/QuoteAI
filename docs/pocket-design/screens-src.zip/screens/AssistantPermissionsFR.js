    var st = this.props.state || 'default';
    var offline = st === 'offline', ro = st === 'readonly';
    var DEF = { fu: 0, rem: 1, rec: 1, sch: 0, crew: 1 };
    var lv = Object.assign({}, DEF, this.g('lv', {}));
    var toast = this.g('toast', null);
    var LAB = ['Me demander', 'Faire et aviser', 'Non'];
    var FR = [1, 1.3, 0.7], indAt = function (i) { var a = 0; for (var k = 0; k < i; k++) a += FR[k]; return 'left: calc(2px + (100% - 4px) * ' + (a / 3).toFixed(4) + '); width: calc((100% - 4px) * ' + (FR[i] / 3).toFixed(4) + ')'; };
    var flash = function (b, s, prev) {
      var tid = Date.now();
      set({ toast: { b: b, s: s, prev: prev, t: tid } });
      setTimeout(function () { var t = self.g('toast', null); if (t && t.t === tid) set({ toast: null }); }, 5000);
    };
    var base = function (gl, tone, label, sub) { return { ic: ic(gl, tone), label: label, sub: sub, isSeg: false, isSwitch: false, isStepper: false, isLink: false, isVoice: false, isFixed: false }; };
    var seg = function (key, gl, tone, label, subs) {
      var cur = lv[key];
      return Object.assign(base(gl, tone, label, subs[cur]), { isSeg: true, segCls: '',
        ind: indAt(cur),
        opts: LAB.map(function (l, i) { return { label: l, on: i === cur, cls: i === cur ? 'on' : '', off: ro, pick: function () {
          if (i === self.g('lv', {})[key] || (self.g('lv', {})[key] === undefined && i === DEF[key])) return;
          var prev = Object.assign({}, DEF, self.g('lv', {})); var n = Object.assign({}, prev); n[key] = i;
          set({ lv: n }); flash(label + ' :', l.toLowerCase() + (offline ? '. S’appliquera à votre retour en ligne.' : '.'), prev);
        } }; }) });
    };
    var fixed = function (gl, tone, label, sub) {
      return Object.assign(base(gl, tone, label, sub), { isSeg: true, isFixed: true, segCls: 'fixed', ind: indAt(0),
        opts: LAB.map(function (l, i) { return { label: l, on: i === 0, cls: i === 0 ? 'on' : '', off: true, pick: function () {} }; }) });
    };
    var sw = function (key, def, gl, tone, label, sub) {
      var on = self.g(key, def);
      return Object.assign(base(gl, tone, label, sub), { isSwitch: true, on: on, track: on ? 'background: var(--acc)' : 'background: var(--track-off)', knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var lim = this.g('lim', 300);
    var money = function (n) { return n.toLocaleString('fr-CA').replace(/\s/g, ' ') + ' $'; };
    var quiet = this.g('quiet', true);
    var groups = [
      { title: 'Clients', rows: [
        seg('fu', 'chat', 'violet', 'Relances', ['Prépare une relance pour les soumissions sans réponse, à approuver', 'Relance après 3 jours, deux fois au plus, puis vous avise', 'Ne relance pas les soumissions']),
        seg('rem', 'bell', 'amber', 'Rappels de facture', ['Prépare un rappel quand une facture a 7 jours de retard', 'Envoie un rappel courtois à 7 jours de retard, puis vous avise', 'N’envoie pas de rappels de facture aux clients'])
      ] },
      { title: 'Argent', rows: [
        seg('rec', 'receipt', 'amber', 'Reçus', ['Lit les photos de reçus et demande à quel chantier les associer', 'Lit les photos de reçus et les classe au bon chantier', 'Ne lit pas les reçus']),
        fixed('tag', 'clay', 'Changements de prix', 'Les prix des soumissions et factures demandent toujours votre accord'),
        Object.assign(base('card', 'sage', 'Limite de dépenses', 'Au-delà, les commandes demandent toujours votre accord'), { isStepper: true, val: money(lim),
          dec: function () { set({ lim: Math.max(0, self.g('lim', 300) - 100) }); }, inc: function () { set({ lim: Math.min(5000, self.g('lim', 300) + 100) }); } })
      ], note: 'Tout montant de plus de 5 000 $ demande toujours votre accord, peu importe ce réglage.' },
      { title: 'Équipe et horaire', rows: [
        seg('sch', 'cal', 'sky', 'Horaire', ['Suggère d’autres dates selon la météo ou l’équipe', 'Déplace les journées de chantier selon la météo, puis vous avise, vous et l’équipe', 'Ne déplace rien à l’horaire']),
        seg('crew', 'users', 'teal', 'Messages à l’équipe', ['Prépare les textos d’horaire à l’équipe, à approuver', 'Texte le plan à l’équipe la veille, puis vous avise', 'N’écrit pas à votre équipe'])
      ] },
      { title: 'Heures de silence', rows: [
        sw('quiet', true, 'moon', 'indigo', 'Heures de silence', quiet ? 'Aucun message aux clients ni à l’équipe. Ils attendent le matin.' : 'Les messages peuvent partir à toute heure'),
        Object.assign(base('clock', 'slate', 'De', 'Soirs de semaine'), { isLink: true, val: '20 h', href: '#', aria: 'Début des heures de silence, 20 h' }),
        Object.assign(base('sun', 'amber', 'Jusqu’à', 'Le lendemain matin'), { isLink: true, val: '7 h', href: '#', aria: 'Fin des heures de silence, 7 h' }),
        sw('sun', true, 'cal', 'stone', 'Silence le dimanche', 'Rien ne part le dimanche')
      ] },
      { title: 'Voix', rows: [
        Object.assign(base('wave', 'violet', 'Voix', 'Aurora · à changer dans les réglages'), { isVoice: true }),
        sw('readback', true, 'speaker', 'lilac', 'Relire d’abord', 'Lit ce qu’il va envoyer avant votre confirmation')
      ] }
    ].map(function (g, gi) { return { title: g.title, rows: g.rows, note: g.note || '', hasNote: !!g.note, delay: 'animation-delay: ' + (60 + gi * 60) + 'ms' }; });
    return {
      offline: offline, readonly: ro, ro: ro, pendingCount: '4', hasCount: true, groups: groups,
      voices: [['#160e36', '#7b3fe4', '#6ec8f5', '#4c9de5'], ['#08172a', '#3d8bff', '#6ef0d2', '#b7a6ff'], ['#1a1a1c', '#c9c4ba', '#8e8a84', '#f4efe6']].map(function (v, i) { return { base: v[0], c1: v[1], c2: v[2], c3: v[3], cls: i === 0 ? 'on' : '' }; }),
      reset: function () { var prev = Object.assign({}, DEF, self.g('lv', {})); set({ lv: {}, lim: 300 }); flash('Réglages recommandés rétablis.', 'Les relances et l’horaire demandent d’abord.', prev); },
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '',
      toastUndo: function () { var t = self.g('toast', null); if (t) set({ lv: t.prev, toast: null }); },
      cloudIc: ic('cloud', 'amber'), eyeIc: ic('eye', 'sky'), actIc: ic('list', 'indigo'), propIc: ic('bell', 'violet')
    };
