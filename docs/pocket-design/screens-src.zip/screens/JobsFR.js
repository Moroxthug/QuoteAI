    var f = this.g('f', 'all');
    var money = function (n) { return n.toLocaleString('fr-CA', { maximumFractionDigits: 0 }).replace(/\s/g, ' ') + ' $'; };
    var P = { AO: ['AO', 'tn3'], SM: ['SM', 'tn2'], LB: ['LB', 'tn1'], JR: ['JR', 'tn4'], DP: ['DP', 'tn5'] };
    var S = { setup: ['À valider', 'st-acc si-q2'], planning: ['En planification', 'st-info si-q1'], active: ['Actif', 'st-ok si-live'], hold: ['En pause', 'st-warn si-pause'], done: ['Terminé', 'st-mute si-check'] };
    // [nom, client, statut, valeur, pct, méta, équipe, note d’équipe]
    var data = [
      ['Plancher du corridor', 'Okoye Condo', 'setup', 2210, 0, 'Plan IA tiré de Q-2026-112', [], ''],
      ['Finition du sous-sol', 'Tom & Lena Hart', 'active', 42355, 64, 'Ensuite : finir le gypse, 2 oct.', ['AO', 'SM', 'LB'], '2 sur place'],
      ['Rafraîchissement du corridor de la clinique', 'Harbourfront Dental', 'active', 12850, 35, 'Ensuite : préparation et apprêt, 1er oct.', ['LB'], 'Luca'],
      ['Clôture et barrière', 'Gill Residence', 'active', 5860, 40, 'Ensuite : teindre la barrière, 30 sept.', ['DP', 'LB'], ''],
      ['Peinture du rez-de-chaussée', 'Dana Whitfield', 'planning', 7900, 0, 'Du 13 au 21 oct.', ['LB', 'SM'], ''],
      ['Étagères de l’arrière-boutique', 'Marchetti Bakery', 'hold', 4650, 20, 'En attente de l’accord du propriétaire', ['DP'], ''],
      ['Salle d’eau', 'Priya Nair', 'done', 3120, 100, 'Terminé le 11 sept.', ['AO', 'LB'], ''],
      ['Reconstruction de la galerie avant', 'Chen Family', 'done', 9840, 100, 'Terminé le 21 août', ['DP', 'JR'], '']
    ];
    var FIL = [['all', 'Tous', function (s) { return s !== 'done'; }, 'Ouverts'], ['setup', 'À valider'], ['planning', 'Planification'], ['active', 'Actifs'], ['hold', 'En pause'], ['done', 'Terminés']];
    var match = function (x, s) { return x[2] ? x[2](s) : s === x[0]; };
    var cur = FIL.filter(function (x) { return x[0] === f; })[0];
    var rows = data.filter(function (d) { return match(cur, d[2]); });
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Commander': 'Commandé', 'Vérifier': 'Vérifié', 'Relancer': 'Relancé', 'Facturer': 'Facturé', 'Corriger': 'Corrigé', 'Demander': 'Demandé', 'Appeler': 'Appel en cours' };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Fait') : r[4], btnCls: d2 ? 'done' : '', act: function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); } }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    var DET = {
      'Finition du sous-sol': { cap: 'Aujourd’hui sur le chantier', rows: [['Amara Okafor', 'Gypse · depuis 7 h 15', 'Sur place', 'st-ok si-live'], ['Sofia Marin', 'Tirage de joints · depuis 7 h 30', 'Sur place', 'st-ok si-live'], ['Ensuite : finir le gypse', 'Jeu. 2 oct. · puis l’apprêt', 'Dans les temps', 'st-ok si-check'], ['Il manque 12 feuilles de gypse ½ po', 'Signalé par Amara à 9 h 12', 'Bloquant', 'st-bad si-alert', 'Commander']], stats: [['Facturé', '46 %'], ['Coûts', '64 %'], ['Marge', '32 %']], second: 'Écrire à l’équipe' },
      'Rafraîchissement du corridor de la clinique': { cap: 'Aujourd’hui', rows: [['Luca Bianchi', 'Préparation et apprêt · dès 9 h', 'Sur place', 'st-ok si-live'], ['Ensuite : préparation et apprêt', 'Mer. 1er oct.', 'Dans les temps', 'st-ok si-check'], ['Main-d’œuvre 18 % au-dessus du budget', '3 960 $ sur 5 400 $ dépensés, à 35 % d’avancement', 'Hors budget', 'st-bad si-alert', 'Vérifier']], stats: [['Facturé', '30 %'], ['Coûts', '52 %'], ['Marge', '21 %']], second: 'Écrire à Luca' },
      'Clôture et barrière': { cap: 'Aujourd’hui', rows: [['Dev Patel', 'Teinture de la barrière · dès 8 h', 'Sur place', 'st-ok si-live'], ['Pluie jeudi et vendredi', 'Finir la teinture d’ici mercredi', 'Météo', 'st-warn si-clock']], stats: [['Facturé', '50 %'], ['Coûts', '20 %'], ['Marge', '41 %']], second: 'Écrire à Dev' },
      'Peinture du rez-de-chaussée': { cap: 'Avant le début', rows: [['Équipe réservée', 'Luca et Sofia · du 13 au 21 oct.'], ['Commande de peinture', 'Dulux · 14 gal, 2 couleurs', 'À commander', 'st-mute si-draft', 'Commander'], ['Acompte', 'Payé le 26 sept.', 'Payé', 'st-ok si-check', '', '2 370,00 $']], stats: [], second: 'Écrire à Dana' },
      'Étagères de l’arrière-boutique': { cap: 'Pourquoi c’est en attente', rows: [['Accord du propriétaire', 'Demandé le 18 sept. · toujours sans réponse', 'En attente', 'st-warn si-pause', 'Relancer']], stats: [['Facturé', '20 %'], ['Coûts', '14 %'], ['Marge', '—']], second: 'Appeler Marchetti' },
      'Salle d’eau': { cap: 'Après les travaux', rows: [['Garantie', 'Jusqu’en sept. 2027', 'Couvert', 'st-ok si-check'], ['Avis du client', 'Pas encore demandé', '', '', 'Demander']], stats: [['Total final', '3 120 $'], ['Marge', '38 %'], ['Jours', '6']], second: 'Écrire à Priya' },
      'Reconstruction de la galerie avant': { cap: 'Après les travaux', rows: [['Garantie', 'Jusqu’en août 2027', 'Couvert', 'st-ok si-check'], ['Avis du client', '5 étoiles sur Google', 'Reçu', 'st-ok si-check']], stats: [['Total final', '9 840 $'], ['Marge', '34 %'], ['Jours', '11']], second: 'Écrire aux Chen' }
    };
    var mk = function (d) {
      var st = d[2];
      return {
        hasBar: st !== 'planning', name: d[0], client: d[1], meta: d[5], value: money(d[3]), pct: d[4] + ' %', pw: Math.max(d[4], 0) + '%',
        barStyle: st === 'done' ? 'background: var(--ok-dot)' : st === 'hold' ? 'background: var(--warn-dot)' : '',
        crew: d[6].map(function (c) { return { ini: P[c][0], tn: P[c][1] }; }), crewNote: d[7],
        status: S[st][0], st: S[st][1], href: 'Job.dc.html', ic: ic('list', 'violet'),
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { x = x || { rows: [], stats: [] }; return { cap: x.cap || '', hasCap: !!x.cap, rows: rowsOf(d[0], x.rows), stats: (x.stats || []).map(function (q) { return { l: q[0], v: q[1] }; }), hasStats: !!(x.stats && x.stats.length), second: x.second || 'Écrire au client' }; })(DET[d[0]])
      };
    };
    var order = [['setup', 'À vérifier'], ['active', 'En cours'], ['planning', 'En planification'], ['hold', 'En pause'], ['done', 'Terminés']];
    var groups = order.map(function (g) {
      var rs = rows.filter(function (d) { return d[2] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + d[3]; }, 0);
      return { title: g[1], total: rs.length && g[0] !== 'setup' ? money(tot) : '', setup: g[0] === 'setup', list: g[0] !== 'setup', rows: rs.map(mk), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '' };
    }).filter(function (g) { return g.has; });
    return {
      kpis: [
        { label: 'En cours', value: '61 065 $', sub: '3 chantiers', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'À facturer', value: '7 680 $', sub: 'Hart, étape 3', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Sur place aujourd’hui', value: '4', sub: '1 conflit', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[3] || x[1], count: data.filter(function (d) { return match(x, d[2]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), rows: rowsOf('kpi', [
        ['Finition du sous-sol', 'Hart · 64 % terminé', '', '', '', '42 355 $'], ['Rafraîchissement du corridor de la clinique', 'Harbourfront · 35 % terminé', '', '', '', '12 850 $'], ['Clôture et barrière', 'Gill · 40 % terminé', '', '', '', '5 860 $'],
        ['Prêt à facturer : Hart, étape 3', 'Étape du gypse atteinte', 'À facturer', 'st-warn si-clock', 'Facturer', '7 680 $'],
        ['Luca est réservé deux fois, de 9 h à 11 h', 'Sous-sol Hart et corridor de la clinique', 'Conflit', 'st-bad si-alert', 'Corriger']]) },
      groups: groups, empty: groups.length === 0, emptyIc: ic('cone', 'amber'), rcIc: ic('receipt', 'amber')
    };
