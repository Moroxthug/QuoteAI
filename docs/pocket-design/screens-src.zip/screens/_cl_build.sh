#!/bin/bash
# _cl_build.sh NAME "Title" HEIGHT 'DC_PROPS' "prop=val prop=val..." (variants: replace default of enum)
S=/tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad
DC_PROPS="$4" python3 $S/kit/assemble.py $1 "$2" $S/screens/$1.body.html $S/screens/$1.js $3 >/dev/null || exit 1
python3 $S/kit/normalize.py $S/screens/$1.body.html $S/screens/$1.js >/dev/null
DC_PROPS="$4" python3 $S/kit/assemble.py $1 "$2" $S/screens/$1.body.html $S/screens/$1.js $3 >/dev/null || exit 1
cp $S/design/project/$1.dc.html $S/prev/
sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/design/project/$1.dc.html > $S/prev/${1}_D.dc.html
awk '/data-dc-script/{f=1;next} /<\/script>/{f=0} f' $S/prev/$1.dc.html | sed 's/extends DCLogic//' > /tmp/chk_$1.js; node --check /tmp/chk_$1.js 2>&1 | head -5
for v in $5; do k=${v%%=*}; val=${v#*=}; python3 - "$S/prev/$1.dc.html" "$S/prev/${1}_$val.dc.html" "$k" "$val" <<'PY'
import sys,re
s=open(sys.argv[1]).read(); k,v=sys.argv[3],sys.argv[4]
s=re.sub(r'("%s":\{"editor":"enum","options":\[[^\]]*\],"default":")[^"]*"'%k, lambda m:m.group(1)+v+'"', s)
open(sys.argv[2],'w').write(s)
PY
sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/prev/${1}_$val.dc.html > $S/prev/${1}_${val}_D.dc.html
done
echo built $1
