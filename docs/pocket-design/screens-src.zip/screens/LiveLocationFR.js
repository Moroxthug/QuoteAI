    var P = this.props.state || 'ask';
    var MK = 'mode_' + P;
    var mode = this.g(MK, P), busy = this.g('busy', false);
    var setMode = function (m) { var o = { busy: false }; o[MK] = m; set(o); };
    var isAsk = mode === 'ask', isOn = mode === 'on', isOff = mode === 'off';
    var allow = function () {
      if (self.g('busy', false)) return;
      set({ busy: true });
      setTimeout(function () { setMode('on'); }, 900);
    };
    var title = isOn ? 'Votre position est activée' : isOff ? 'Position désactivée' : 'Partagez votre position pendant le travail';
    var lede = isOn ? 'Seulement pendant votre quart. Elle se coupe toute seule quand vous pointez la sortie.'
      : isOff ? 'Le bureau voit « Position désactivée » à côté de votre nom. Rien n’est suivi.'
      : 'Partagée seulement pendant votre quart, pour que Luca planifie la journée et dise aux clients quand vous arrivez.';
    return {
      stOn: ['st-ok', 'si-live'].join(' '), stOff: ['st-mute', 'si-off'].join(' '),
      isAsk: isAsk, isOn: isOn, isOff: isOff, title: title, lede: lede,
      youCls: isOn ? 'live' : (isOff ? 'dim' : ''),
      routePath: 'M120 102C150 90 160 80 176 60',
      routeStyle: isOn ? 'opacity: 1' : 'opacity: 0',
      siteIc: ic('house', 'clay'),
      allowLabel: busy ? 'Activation…' : (isOff ? 'Partager de nouveau' : 'Autoriser pendant le quart'),
      allow: allow,
      notNow: function () { setMode('off'); },
      stop: function () { setMode('off'); },
      askRows: [
        { ic: ic('pin', 'rose'), t: 'Votre position, aux quelques minutes', s: 'Affichée comme « Sur place » ou « En route, 14 min »', who: false },
        { ic: ic('clock', 'teal'), t: 'Seulement entre l’arrivée et le départ', s: 'Jamais pendant vos pauses, après les heures ou les jours de congé', who: false },
        { ic: ic('eye', 'violet'), t: 'Vue par Marco Rossi et Luca Bianchi', s: 'Pas par les clients ni par le reste de l’équipe', who: true },
        { ic: ic('lock', 'slate'), t: 'Gardée 30 jours, puis effacée', s: 'Sert aux heures d’arrivée et à vos heures de trajet', who: false }
      ],
      onRows: [
        { ic: ic('clock', 'teal'), t: 'En pause pendant vos pauses', s: 'Le dîner de 12 h à 12 h 30 n’est pas partagé' },
        { ic: ic('truck', 'azure'), t: 'Compte vos trajets', s: 'La route entre chantiers s’ajoute à vos heures' },
        { ic: ic('eye', 'violet'), t: 'Seulement Marco et Luca', s: 'Les clients ont une heure d’arrivée, jamais une carte' }
      ],
      offRows: [
        { ic: ic('pin', 'slate'), t: 'L’arrivée vérifie quand même une fois', s: 'Pour confirmer que vous êtes au chantier. C’est tout.' },
        { ic: ic('truck', 'slate'), t: 'Notez vos trajets à la main', s: 'Depuis le menu ⋯ de la page du jour' },
        { ic: ic('gear', 'slate'), t: 'Réglage de votre téléphone', s: 'La position pour ce lien est réglée sur « Demander »' }
      ]
    };
