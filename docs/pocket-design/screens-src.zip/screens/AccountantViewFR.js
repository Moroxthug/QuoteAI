    var ST = this.props.state || 'default';
    var ended = ST === 'accessEnded';
    var J = function (a) { return a.join(' '); };
    var mi = this.g('month', 2);
    var ck = function (t, a, b, note, money) {
      var pct = Math.round(a / b * 100);
      return { t: t, v: money || (a + ' sur ' + b), vStyle: pct < 100 ? 'color: var(--ink)' : 'color: var(--ok)', note: note,
        bar: 'width: ' + pct + '%; background: ' + (pct < 100 ? 'var(--warn-dot)' : 'var(--ok-dot)') };
    };
    var MONTHS = [
      { label: 'Juillet', name: 'Juillet 2026', short: 'Juillet', sub: 'Fermé par Rosa Lima le 6 août', w: 'Fermé', st: J(['st-mute', 'si-check']),
        checks: [ck('Lignes bancaires liées', 171, 171, 'Compte d’entreprise RBC et Visa'), ck('Reçus joints', 46, 46, 'Toutes les dépenses de plus de 30 $'), ck('Factures émises', 1, 1, '12 factures', '44 910 $'), ck('Paies traitées', 2, 2, '15 et 31 juil.')] },
      { label: 'Août', name: 'Août 2026', short: 'Août', sub: 'Fermé par Rosa Lima le 4 sept.', w: 'Fermé', st: J(['st-mute', 'si-check']),
        checks: [ck('Lignes bancaires liées', 158, 158, 'Compte d’entreprise RBC et Visa'), ck('Reçus joints', 39, 39, 'Toutes les dépenses de plus de 30 $'), ck('Factures émises', 1, 1, '11 factures', '41 275 $'), ck('Paies traitées', 2, 2, '14 et 31 août')] },
      { label: 'Septembre', name: 'Septembre 2026', short: 'Septembre', sub: 'Rosa y travaille', w: 'En cours', st: J(['st-ok', 'si-live']),
        checks: [ck('Lignes bancaires liées', 142, 160, 'Il en reste 18, surtout des paiements par carte depuis le 24 sept.'), ck('Reçus joints', 38, 41, '3 manquants : Home Depot, Rona, Esso'), ck('Factures émises', 1, 1, '14 factures', '52 380 $'), ck('Paies traitées', 1, 2, '15 sept. faite · 30 sept. demain')] }
    ];
    var mo = MONTHS[mi];
    var dl = this.g('dl', {});
    var EXP = [
      ['tx', 'Transactions', 'CSV · toutes les lignes', 'file', 'sage'],
      ['qb', 'QuickBooks Online', 'Écritures de journal · IIF', 'sync', 'teal'],
      ['hst', 'Feuille de calcul TVH', 'PDF · T3, lignes sources', 'percent', 'violet'],
      ['pay', 'Sommaire de la paie', 'CSV · brut, retenues, remises', 'bank', 'azure']
    ];
    var exports = EXP.map(function (e) {
      var key = e[0] + mi, st = dl[key];
      return { t: e[1], s: e[2], ic: ic(e[3], e[4]), done: st === 'done', notDone: st !== 'done', doneSt: J(['st-ok', 'si-check']),
        btn: st === 'busy' ? 'Préparation…' : 'Télécharger', aria: 'Télécharger ' + e[1] + ', ' + mo.short,
        dl: function () {
          var d = Object.assign({}, self.g('dl', {})); if (d[key]) return; d[key] = 'busy'; set({ dl: d });
          setTimeout(function () { var x = Object.assign({}, self.g('dl', {})); x[key] = 'done'; set({ dl: x }); }, 1100);
        } };
    });
    var BASE = [
      { who: 'Farah Haddad', me: true, time: '28 sept., 16 h 10', text: 'Deux reçus Home Depot du 12 sept. semblent être le même achat, 412,66 $ chacun. Quelqu’un peut vérifier ?', ref: 'Home Depot · Warden Ave · 412,66 $', refIc: 'receipt' },
      { who: 'Rosa Lima', me: false, time: '29 sept., 8 h 40', text: 'L’un a été retourné. Le remboursement est le 14 sept., je les lie aujourd’hui.', ref: '', refIc: '' },
      { who: 'Marco Rossi', me: false, time: '29 sept., 9 h 02', text: 'Merci Farah. Produire la TVH d’ici le 20 oct., ça nous va.', ref: '', refIc: '' }
    ];
    var extra = this.g('extra', []);
    var thread = BASE.concat(extra).map(function (m) {
      return { who: m.who, time: m.time, text: m.text, hasRef: !!m.ref, ref: m.ref, refIc: ic(m.refIc || 'receipt', 'rose'),
        wrap: m.me ? 'align-self: flex-end; align-items: flex-end' : 'align-self: flex-start',
        metaAlign: m.me ? 'text-align: right' : '',
        bubble: m.me ? 'background: var(--inv); color: var(--on-inv); border-radius: 18px 18px 6px 18px' : 'background: var(--sunk); color: var(--ink); border-radius: 18px 18px 18px 6px' };
    });
    var draft = this.g('draft', '');
    return {
      ended: ended, active: !ended, lockIc: ic('lock', 'azure'),
      shareLine: ended ? 'Farah Haddad, CPA' : 'Farah Haddad, CPA · partagé par Marco Rossi',
      months: MONTHS.map(function (m, i) { return { label: m.label, on: i === mi, cls: i === mi ? 'on' : '', pick: function () { set({ month: i }); } }; }),
      mo: mo, exports: exports,
      dueSt: J(['st-warn', 'si-clock']),
      deadlines: [
        { ic: ic('truck', 'clay'), t: 'Plaque du fourgon', s: 'ServiceOntario · 26 sept.', w: '3 j de retard', st: J(['st-bad', 'si-alert']) },
        { ic: ic('bank', 'sage'), t: 'Remise de paie, sept.', s: '4 386,20 $ · ARC', w: 'Dû le 15 oct.', st: J(['st-warn', 'si-clock']) },
        { ic: ic('shield', 'teal'), t: 'Attestation WSIB', s: 'Rossi Renovations', w: 'Expire le 20 oct.', st: J(['st-warn', 'si-clock']) }
      ],
      thread: thread, draft: draft,
      onDraft: function (e) { set({ draft: e.target.value }); },
      send: function () {
        var t = (self.g('draft', '') || '').trim(); if (!t) t = 'Compris, merci. Je commence la déclaration du T3 dès que septembre sera fermé.';
        set({ extra: self.g('extra', []).concat([{ who: 'Farah Haddad', me: true, time: 'Maintenant', text: t, ref: '', refIc: '' }]), draft: '' });
      }
    };
