#!/bin/bash
# _w6_shot.sh FILE OUT [clicks] [H] [scroll]
cd /tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad/prev && PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers python3 shot.py "$1" "$2" "$3" ${4:-844} ${5:-0} | grep -v "ERR_TUNNEL\|Expected moveto"; true
