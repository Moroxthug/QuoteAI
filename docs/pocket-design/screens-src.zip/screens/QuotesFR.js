    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { draft: ['Brouillon', 'st-mute si-draft'], sent: ['Envoyée', 'st-info si-q1'], viewed: ['Consultée', 'st-acc si-q2'], accepted: ['Acceptée', 'st-ok si-check'], declined: ['Refusée', 'st-bad si-x'], expired: ['Expirée', 'st-mute si-off'], expiring: ['Expire ven.', 'st-warn si-clock'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    var data = [
      ['Q-2026-119', 'Dana Whitfield', 'Chambres et plafond de salle de bain', 4131.05, 'draft', 'week', 'Aujourd’hui'],
      ['Q-2026-118', 'Priya Nair', 'Dosseret de cuisine', 1865.10, 'viewed', 'week', 'Consultée il y a 2 h'],
      ['Q-2026-117', 'Harbourfront Dental', 'Peinture de la réception', 6420.00, 'expiring', 'week', 'Envoyée le 24 sept.'],
      ['Q-2026-116', 'Gill Residence', 'Remise à neuf du patio', 2980.00, 'sent', 'week', 'Envoyée lundi'],
      ['Q-2026-114', 'Tom & Lena Hart', 'Ordre de changement, sous-sol', 3955.00, 'accepted', 'earlier', 'Acceptée le 19 sept.'],
      ['Q-2026-112', 'Okoye Condo', 'Plancher du corridor', 2210.00, 'accepted', 'earlier', 'Acceptée le 15 sept.'],
      ['Q-2026-110', 'Marchetti Bakery', 'Moulures de la devanture', 1480.00, 'declined', 'earlier', 'Refusée le 12 sept.'],
      ['Q-2026-108', 'Chen Family', 'Rafraîchissement de la salle de lavage', 3300.00, 'expired', 'earlier', 'Expirée le 9 sept.'],
      ['Q-2026-107', 'Tom & Lena Hart', 'Finition du sous-sol', 38400.00, 'accepted', 'earlier', 'Acceptée le 28 août']
    ];
    var FIL = [['all', 'Toutes', function () { return true; }], ['draft', 'Brouillons', function (s) { return s === 'draft'; }], ['waiting', 'En attente', function (s) { return s === 'sent' || s === 'viewed' || s === 'expiring'; }], ['accepted', 'Acceptées', function (s) { return s === 'accepted'; }], ['closed', 'Fermées', function (s) { return s === 'declined' || s === 'expired'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[0]).toLowerCase().indexOf(ql) >= 0); });
    var acted = this.g('acted', {});
    var mkActs = function (no, list) { return list.map(function (a) { return { label: a[0], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); if (!a[4]) return; var n = Object.assign({}, self.g('acted', {})); n[no] = [a[4], a[5]]; set({ acted: n }); } }; }); };
    var QA = {
      draft: [['Envoyer', 'send', 'azure', 'info', 'Envoyée', 'st-info si-q1'], ['Dupliquer', 'doc', 'slate', 'mute']],
      sent: [['Relancer', 'chat', 'violet', 'acc', 'Relancée', 'st-info si-q1'], ['Marquer gagnée', 'check', 'sage', 'ok', 'Acceptée', 'st-ok si-check']],
      accepted: [['Facturer l’acompte', 'receipt', 'amber', 'warn', 'Acompte envoyé', 'st-info si-q1'], ['Lancer les travaux', 'cone', 'amber', 'ok', 'Travaux lancés', 'st-ok si-live']],
      declined: [['Réactiver', 'sync', 'indigo', 'acc', 'Brouillon', 'st-mute si-draft'], ['Archiver', 'box', 'stone', 'mute', 'Archivée', 'st-mute si-off']]
    };
    QA.viewed = QA.sent; QA.expiring = QA.sent; QA.expired = QA.declined;
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Relancer': 'Relancée', 'Marquer gagnée': 'Marquée gagnée', 'Envoyer': 'Envoyée', 'Facturer l’acompte': 'Acompte facturé', 'Réactiver': 'Réactivée', 'Lancer les travaux': 'Travaux lancés', 'Prolonger': 'Prolongée', 'Appeler': 'Appel en cours', 'Vérifier': 'Vérifié', 'Planifier': 'Planifiée', 'Facturer l’étape 3': 'Étape 3 facturée', 'Demander': 'Demandé', 'Renouveler': 'Renouvelée' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Fait') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); var sw = el && el.closest('.swr'); if (sw) sw.scrollLeft = 0; var go = function () { var c = el.closest('.xc'); if (c && c.classList.contains('open')) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }; if (cur !== id && el) { setTimeout(go, 120); setTimeout(go, 520); } }; };
    // par soumission : légende (portée), lignes [titre, contexte, statut, classe du statut, bouton, montant], action principale
    var DET = {
      'Q-2026-119': { cap: 'Deux chambres et le plafond de la salle de bain, 2 couches', main: 'Envoyer', rows: [['Rédigée aujourd’hui', 'À partir de vos notes de chantier, 9 h 40', 'Non envoyée', 'st-mute si-draft'], ['Deux chambres', 'Murs et moulures, réparations et peinture', '', '', '', '2 685,25 $'], ['Plafond de la salle de bain', 'Apprêt et peinture antimoisissure', '', '', '', '1 445,80 $'], ['Valide 30 jours', 'À compter de l’envoi']] },
      'Q-2026-118': { cap: 'Dosseret en tuiles métro, 28 pi²', main: 'Relancer', rows: [['Envoyée le 25 sept.', 'Par courriel et texto', 'Livrée', 'st-ok si-check'], ['Consultée deux fois', 'Hier à 20 h 14 et il y a 2 h', 'Consultée', 'st-acc si-q2', 'Appeler'], ['2 options', 'Blanc standard ou fait main (+620,00 $)'], ['Valide jusqu’au 25 oct.', 'Encore 26 jours']] },
      'Q-2026-117': { cap: 'Peinture de la réception, en soirée sur 2 fins de semaine', main: 'Relancer', rows: [['Envoyée le 24 sept.', 'À la gestionnaire du bureau', 'Livrée', 'st-ok si-check'], ['Ouverte une fois', '24 sept., 16 h 02 · aucune réponse depuis', 'Consultée', 'st-acc si-q2'], ['Main-d’œuvre et matériaux', '2 peintres, 4 soirs · Benjamin Moore', '', '', '', '6 420,00 $'], ['Expire le ven. 2 oct.', 'Encore 3 jours', 'Expire ven.', 'st-warn si-clock', 'Prolonger']] },
      'Q-2026-116': { cap: 'Décapage, teinture et scellant, patio de 320 pi²', main: 'Relancer', rows: [['Envoyée le lun. 28 sept.', 'Par courriel', 'Livrée', 'st-ok si-check'], ['Pas encore ouverte', 'Envoyée il y a 1 jour', 'Non ouverte', 'st-mute si-off'], ['Un oui au téléphone ?', 'Marquez-la gagnée pour lancer les travaux', '', '', 'Marquer gagnée'], ['Valide jusqu’au 28 oct.', 'Encore 29 jours']] },
      'Q-2026-114': { cap: 'Fenêtre d’évacuation et encastrés supplémentaires', main: 'Planifier', rows: [['Acceptée le 19 sept.', 'Signée par Lena Hart', 'Acceptée', 'st-ok si-check'], ['Facturée', 'INV-0420 · moitié payée le 24 sept.', 'Payée en partie', 'st-warn si-q3'], ['Ajoutée à Finition du sous-sol', 'Ajoute 3 jours au plan']] },
      'Q-2026-112': { cap: 'Planche de vinyle de luxe, corridor de 240 pi²', main: 'Lancer les travaux', rows: [['Acceptée le 15 sept.', 'Signée en ligne', 'Acceptée', 'st-ok si-check'], ['Chantier préparé', 'Plancher du corridor · plan à vérifier', 'À valider', 'st-acc si-q2', 'Vérifier'], ['Facturée au complet', 'INV-0418 · payée le 22 sept.', 'Payée', 'st-ok si-check', '', '2 497,30 $']] },
      'Q-2026-110': { cap: 'Moulures de la devanture, grattage et peinture', main: 'Réactiver', rows: [['Refusée le 12 sept.', 'Consultée 3 fois avant', 'Refusée', 'st-bad si-x'], ['Aucune raison donnée', 'Un petit mot suffit souvent à relancer la discussion', '', '', 'Demander']] },
      'Q-2026-108': { cap: 'Peinture de la salle de lavage et nouvelles tablettes', main: 'Renouveler', rows: [['Envoyée le 10 août', 'Consultée une fois, le 11 août', 'Consultée', 'st-acc si-q2'], ['Expirée le 9 sept.', 'Aucune réponse après 1 relance', 'Expirée', 'st-mute si-off'], ['Renouveler aux prix du jour', 'Matériaux en hausse d’environ 2 % depuis août']] },
      'Q-2026-107': { cap: 'Finition complète du sous-sol, 850 pi²', main: 'Facturer l’étape 3', rows: [['Acceptée le 28 août', 'Signée par Tom et Lena', 'Acceptée', 'st-ok si-check'], ['Finition du sous-sol', '64 % terminé · étape du gypse', 'Actif', 'st-ok si-live'], ['Factures d’étape', '2 sur 4 envoyées · INV-0412 a 9 jours de retard', '1 en retard', 'st-bad si-alert'], ['Retenue de 10 %', 'Libérée le 14 nov.', 'Planifiée', 'st-info si-clock', '', '3 840,00 $']] }
    };
    var mk = function (d, i) { var ini = d[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); var ac = acted[d[0]]; return { no: d[0], client: d[1], job: d[6] + ' · ' + d[2], amt: money(d[3]), status: ac ? ac[0] : S[d[4]][0], st: ac ? ac[1] : S[d[4]][1], ini: ini, tn: tints[i % tints.length], acts: mkActs(d[0], QA[d[4]]),
      open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
      x: (function (x) { var mk2 = d[0] + 'm', dn = !!xd[mk2]; return { cap: x.cap, rows: rowsOf(d[0], x.rows), main: dn ? (DONE[x.main] || 'Fait') : x.main, mainCls: dn ? 'done' : '', mainAct: flip(mk2) }; })(DET[d[0]]) }; };
    var groups = [['week', 'Cette semaine'], ['earlier', 'Plus tôt']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + d[3]; }, 0);
      return { title: g[1], total: rs.length ? money(tot) : '', rows: rs.map(function (d) { return mk(d, data.indexOf(d)); }), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '', first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'En attente', value: '15 396 $', sub: '4 soumissions', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Gagné ce mois‑ci', value: '6 165 $', sub: '2 acceptées', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Taux de réussite', value: '62 %', sub: '↑ 4 points', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), cap: 'En attente depuis le plus longtemps', rows: rowsOf('kpi', [
        ['Harbourfront Dental', 'Peinture de la réception · envoyée le 24 sept.', 'Expire ven.', 'st-warn si-clock', 'Relancer', '6 420,00 $'],
        ['Priya Nair', 'Dosseret de cuisine · consultée deux fois', 'Consultée', 'st-acc si-q2', 'Relancer', '1 865,10 $'],
        ['Gill Residence', 'Remise à neuf du patio · pas encore ouverte', 'Envoyée', 'st-info si-q1', 'Relancer', '2 980,00 $'],
        ['Dana Whitfield', 'Chambres et plafond de salle de bain · brouillon', 'Non envoyée', 'st-mute si-draft', 'Envoyer', '4 131,05 $'],
        ['Gagnées en septembre', 'Ordre de changement Hart, plancher Okoye', 'Acceptées', 'st-ok si-check', '', '6 165,00 $']]),
        stats: [{ l: 'Envoyées en sept.', v: '8' }, { l: 'Délai moyen', v: '3,2 j' }, { l: 'À expirer', v: '1' }] },
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
