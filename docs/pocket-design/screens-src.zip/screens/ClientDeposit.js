    var lang = this.g('lang', 'en'), fr = lang === 'fr';
    var P = this.props.state || 'pay';
    var state = this.g('state', null) || (P === 'eTransfer' ? 'pay' : P);
    var method = this.g('method', null) || (P === 'eTransfer' ? 'et' : 'card');
    var paying = this.g('paying', false), copied = this.g('copied', ''), sent = this.g('sent', false), linkSent = this.g('linkSent', false), dlS = this.g('dl', 0);
    var money = function (n) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return fr ? s + ' $' : '$' + s;
    };
    var EN = {
      from: 'From', backQuote: 'Quote', confirmed: 'Confirmed by Priya on Sep 29', copySent: 'A signed copy is on its way to your email.',
      deposit: 'Deposit', payTitle: 'Pay your deposit', paidTitle: 'Deposit received', job: 'Kitchen backsplash',
      depLabel: '30% deposit', due: 'Due to book', paid: 'Paid', quoteTotal: 'Quote total', hstIn: 'HST included', later: 'Balance', onCompletion: 'On completion',
      how: 'How would you like to pay?',
      m: [['Card', 'Visa, Mastercard, Amex, Apple Pay · 2.4% fee'], ['Interac e-Transfer', 'No fee · from your bank app'], ['Pay later', 'We’ll email you the link']],
      cardNo: 'Card number', expiry: 'Expiry', postal: 'Postal code', cardFee: 'Card fee 2.4%', charged: 'Total charged', pay: 'Pay', processing: 'Processing…',
      secure: 'Secure payment through Stripe', declinedTitle: 'Your bank declined this card.', declinedSub: 'Try another card or pay by e-Transfer. You weren’t charged.',
      sendTo: 'Send to', amount: 'Amount', ref: 'Message or reference', copy: 'Copy', copiedL: 'Copied',
      autoDep: 'Auto-deposit is on, so there’s no security question. Your start date is held once it lands.', iSent: 'I sent it',
      awaitTitle: 'We told Rossi Renovations you sent it.', awaitSub: 'They confirm when it lands, usually within a day.', undo: 'I haven’t sent it yet',
      laterBody: 'No problem. Your start date is held once the deposit is in, so the sooner the better. We’ll email you a link to pay whenever you’re ready.',
      emailLink: 'Email me the link', linkSent: 'Link sent to',
      thanks: 'Thank you, Priya', thanksSub: 'Your start date is booked. A receipt is on its way to your email.',
      rNo: 'Receipt', rDate: 'Paid', rMethod: 'Method', rAmt: 'Deposit', rFee: 'Card fee', rTotal: 'Total charged', rDateV: 'Sep 29, 9:41 AM',
      dlReceipt: 'Download receipt', next: 'What happens next',
      steps: [['Quote accepted', 'Signed by Priya Nair', 'Sep 29'], ['Deposit paid', 'Card ending 4242', 'Sep 29'], ['Tile ordered', 'Herringbone, 37 sq ft with overage', 'Oct 1'], ['Work starts', 'Marco and Dev, about 2 days', 'Oct 6'], ['Final payment', 'Balance on completion', 'Oct 8']],
      signedTitle: 'Your signed quote', signedFile: 'Q-2026-118 signed.pdf', signedBy: 'Signed Sep 29', download: 'Download', downloading: 'Saving…', saved: 'Saved',
      summary: 'Quote summary',
      secs: [['Prep', 'Remove old tile, cement board, waterproofing', 344], ['Tile', 'Herringbone install, tile, grout and trim', 1098.53], ['Finish', 'Outlet extenders, sealing and cleanup', 208]],
      subtotal: 'Subtotal', hst: 'HST, Ontario 13%', total: 'Total', depDue: 'Deposit due today', depPaid: 'Deposit paid Sep 29', onCompletionRow: 'Balance on completion',
      questions: 'Questions? Call Marco at', portal: 'Open your project portal', sentWith: 'Sent with quoteAI'
    };
    var FR = {
      from: 'De la part de', backQuote: 'Soumission', confirmed: 'Confirmée par Priya le 29 sept.', copySent: 'Une copie signée est envoyée à votre courriel.',
      deposit: 'Dépôt', payTitle: 'Payer votre dépôt', paidTitle: 'Dépôt reçu', job: 'Dosseret de cuisine',
      depLabel: 'Dépôt de 30 %', due: 'À payer pour réserver', paid: 'Payé', quoteTotal: 'Total de la soumission', hstIn: 'TVH incluse', later: 'Solde', onCompletion: 'À la fin des travaux',
      how: 'Comment voulez-vous payer?',
      m: [['Carte', 'Visa, Mastercard, Amex, Apple Pay · frais 2,4 %'], ['Virement Interac', 'Sans frais · depuis votre banque'], ['Payer plus tard', 'Nous vous enverrons le lien']],
      cardNo: 'Numéro de carte', expiry: 'Expiration', postal: 'Code postal', cardFee: 'Frais de carte 2,4 %', charged: 'Total facturé', pay: 'Payer', processing: 'Traitement…',
      secure: 'Paiement sécurisé par Stripe', declinedTitle: 'Votre banque a refusé cette carte.', declinedSub: 'Essayez une autre carte ou payez par virement. Aucun montant n’a été prélevé.',
      sendTo: 'Envoyer à', amount: 'Montant', ref: 'Message ou référence', copy: 'Copier', copiedL: 'Copié',
      autoDep: 'Le dépôt automatique est activé : aucune question de sécurité. Votre date de début est réservée dès sa réception.', iSent: 'Je l’ai envoyé',
      awaitTitle: 'Nous avons avisé Rossi Renovations.', awaitSub: 'Ils confirment à la réception, habituellement en un jour.', undo: 'Je ne l’ai pas encore envoyé',
      laterBody: 'Aucun problème. Votre date de début est réservée dès la réception du dépôt, alors le plus tôt sera le mieux. Nous vous enverrons un lien pour payer quand vous serez prêt.',
      emailLink: 'M’envoyer le lien', linkSent: 'Lien envoyé à',
      thanks: 'Merci, Priya', thanksSub: 'Votre date de début est réservée. Un reçu est envoyé à votre courriel.',
      rNo: 'Reçu', rDate: 'Payé le', rMethod: 'Mode', rAmt: 'Dépôt', rFee: 'Frais de carte', rTotal: 'Total facturé', rDateV: '29 sept., 9 h 41',
      dlReceipt: 'Télécharger le reçu', next: 'La suite',
      steps: [['Soumission acceptée', 'Signée par Priya Nair', '29 sept.'], ['Dépôt payé', 'Carte se terminant par 4242', '29 sept.'], ['Carreaux commandés', 'Chevrons, 37 pi² avec surplus', '1 oct.'], ['Début des travaux', 'Marco et Dev, environ 2 jours', '6 oct.'], ['Paiement final', 'Solde à la fin des travaux', '8 oct.']],
      signedTitle: 'Votre soumission signée', signedFile: 'Q-2026-118 signée.pdf', signedBy: 'Signée le 29 sept.', download: 'Télécharger', downloading: 'Enregistrement…', saved: 'Enregistré',
      summary: 'Résumé de la soumission',
      secs: [['Préparation', 'Retrait des carreaux, panneau de ciment, imperméabilisation', 344], ['Carrelage', 'Pose en chevrons, carreaux, coulis et bordures', 1098.53], ['Finition', 'Rallonges de prises, scellant et nettoyage', 208]],
      subtotal: 'Sous-total', hst: 'TVH, Ontario 13 %', total: 'Total', depDue: 'Dépôt dû aujourd’hui', depPaid: 'Dépôt payé le 29 sept.', onCompletionRow: 'Solde à la fin des travaux',
      questions: 'Des questions? Appelez Marco au', portal: 'Ouvrir votre portail de projet', sentWith: 'Envoyé avec quoteAI'
    };
    var t = fr ? FR : EN;
    var total = 1865.10, sub = 1650.53, tax = 214.57, dep = 559.53, bal = 1305.57, fee = 13.43, charged = 572.96;
    var isPaid = state === 'paid', declined = state === 'declined';
    var depStr = money(dep);
    var MK = [['card', 'card', 'violet'], ['et', 'send', 'indigo'], ['later', 'clock', 'slate']];
    var mkCopy = function (key, label, value, cls, raw) {
      var on = copied === key;
      return { label: label, value: value, cls: cls, copied: on, notCopied: !on, btn: on ? t.copiedL : t.copy, aria: t.copy + ' ' + label,
        btnStyle: on ? 'background: var(--ok-soft); color: var(--ok)' : 'background: var(--sunk); color: var(--ink)',
        copy: function () {
          try { var pr = navigator.clipboard && navigator.clipboard.writeText(raw); if (pr && pr.catch) pr.catch(function () {}); } catch (e) {}
          set({ copied: key }); setTimeout(function () { if (self.g('copied', '') === key) set({ copied: '' }); }, 1600);
        } };
    };
    var nSteps = t.steps.length;
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      notPaid: !isPaid, isPaid: isPaid, declined: declined, formCls: declined ? 'err' : '',
      title: isPaid ? t.paidTitle : t.payTitle,
      status: isPaid ? t.paid : t.due, statusSt: isPaid ? 'st-ok si-check' : 'st-warn si-clock',
      depWhole: fr ? depStr : depStr.slice(0, -3), depCents: fr ? '' : depStr.slice(-3),
      amtStyle: isPaid ? 'color: var(--ok)' : '', barStyle: isPaid ? 'background: var(--ok-dot)' : 'background: var(--inv)',
      total: money(total), balance: money(bal), dep: depStr, fee: money(fee), charged: money(charged), sub: money(sub), tax: money(tax),
      methods: MK.map(function (m, i) {
        var on = m[0] === method;
        return { id: 'm-' + m[0], name: t.m[i][0], desc: t.m[i][1], on: on, ic: ic(m[1], m[2]),
          ring: on ? 'box-shadow: 0 0 0 2px var(--ink)' : 'box-shadow: 0 0 0 1px var(--ring)',
          radio: on ? 'background: var(--inv); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
          dot: on ? 'transform: scale(1)' : 'transform: scale(0)',
          pick: function () { set({ method: m[0] }); } };
      }),
      isCard: method === 'card', isEt: method === 'et', isLater: method === 'later',
      cardNo: declined ? '4000 0000 0000 0002' : '4242 4242 4242 4242', cardBrand: 'Visa',
      paying: paying, payLabel: paying ? t.processing : t.pay + ' ' + money(charged),
      payCard: function () {
        if (self.g('paying', false)) return;
        set({ paying: true });
        setTimeout(function () { set({ paying: false, state: 'paid' }); }, 1500);
      },
      copyRows: [mkCopy('to', t.sendTo, 'pay@rossireno.ca', '', 'pay@rossireno.ca'), mkCopy('amt', t.amount, depStr, 'num', dep.toFixed(2)), mkCopy('ref', t.ref, 'Q-2026-118', 'mono', 'Q-2026-118')],
      sent: sent, notSent: !sent, iSent: function () { set({ sent: true }); }, unsend: function () { set({ sent: false }); },
      linkSent: linkSent, notLinkSent: !linkSent, sendLink: function () { set({ linkSent: true }); },
      receipt: [[t.rNo, 'R-2026-0388', 'mono'], [t.rDate, t.rDateV, ''], [t.rMethod, 'Visa •••• 4242', ''], [t.rAmt, depStr, 'num'], [t.rFee, money(fee), 'num'], [t.rTotal, money(charged), 'num']].map(function (r, i) {
        return { k: r[0], v: r[1], cls: r[2], st: i === 5 ? 'font-weight: 600' : '' };
      }),
      steps: t.steps.map(function (s, i) {
        var done = i < 2;
        return { name: s[0], sub: s[1], date: s[2],
          dotStyle: done ? 'background: var(--ok-dot); color: #ffffff' : 'background: var(--card); box-shadow: inset 0 0 0 1.6px var(--line2)',
          tick: done ? '' : 'display: none',
          lnStyle: i === nSteps - 1 ? 'visibility: hidden' : (i < 1 ? 'background: var(--ok-dot)' : '') };
      }),
      okIc: ic('check', 'sage'), warnIc: ic('warn', 'rose'), syncIc: ic('sync', 'azure'), mailIc: ic('mail', 'sage'), pdfIc: ic('file', 'clay'),
      dlLabel: dlS === 0 ? t.download : (dlS === 1 ? t.downloading : t.saved),
      dlStyle: dlS === 2 ? 'background: var(--ok-soft); color: var(--ok)' : '',
      dl: function () { if (self.g('dl', 0)) return; set({ dl: 1 }); setTimeout(function () { set({ dl: 2 }); }, 1100); },
      secs: t.secs.map(function (s) { return { name: s[0], detail: s[1], amt: money(s[2]) }; }),
      depRowLabel: isPaid ? t.depPaid : t.depDue, depRowAmt: (isPaid ? '−' : '') + depStr,
      depRowStyle: isPaid ? 'color: var(--ok)' : 'color: var(--muted)'
    };
