    var ORDER = ['describe', 'check', 'send', 'done'];
    var step = self.g('step', null) || this.props.step || 'describe';
    var idx = ORDER.indexOf(step); if (idx < 0) { idx = 0; step = 'describe'; }
    var SAMPLE = 'Repeindre une chambre de 12×14, deux couches. Murs seulement, boucher quelques trous de clous, couleur pâle sur du beige.';
    var txt = self.g('txt', ''), writing = self.g('writing', false), listening = self.g('listening', false);
    var sending = self.g('sending', false), dest = self.g('dest', 'me'), notif = self.g('notif', false);
    var S = [['Décrivez les travaux', 'À voix haute ou par écrit'], ['Vérifiez le prix', 'Modifiez n’importe quelle ligne avant l’envoi'], ['Envoyez-la', 'À vous-même d’abord, si vous voulez']];
    var steps = S.map(function (s, i) {
      var done = i < idx, now = i === idx;
      return { n: i + 1, name: s[0], sub: s[1], done: done, open: !done, now: now, cls: done ? 'done' : now ? 'now' : 'later', sr: done ? 'Terminé' : now ? 'Étape en cours' : 'À venir' };
    });
    var T = { describe: ['Votre première soumission', 'Trois étapes rapides. Environ deux minutes.'], check: ['Vérifiez le prix', 'Établi selon votre métier et les prix en Ontario.'], send: ['Envoyez-la', 'Envoyez-la-vous pour voir ce que vos clients reçoivent.'] }[step] || ['', ''];
    return {
      title: T[0], sub: T[1], steps: steps,
      isDescribe: step === 'describe', isCheck: step === 'check', isSend: step === 'send', isDone: step === 'done', notDone: step !== 'done',
      canBack: idx === 1 || idx === 2, noBack: !(idx === 1 || idx === 2),
      back: function () { set({ step: ORDER[Math.max(0, idx - 1)] }); },
      txt: txt, onTxt: function (e) { set({ txt: e.target.value }); },
      hint: listening ? 'À l’écoute…' : txt ? txt.length + ' caractères' : 'Touchez le micro et parlez',
      mic: function () { set({ listening: true }); setTimeout(function () { set({ listening: false, txt: SAMPLE }); }, 1300); },
      showTry: !txt, useTry: function () { set({ txt: SAMPLE }); },
      brushIc: ic('brush', 'violet'),
      cantWrite: !txt.trim() || writing, writing: writing, writeLabel: writing ? 'Rédaction de votre soumission…' : 'Rédiger ma soumission',
      write: function () { set({ writing: true }); setTimeout(function () { set({ writing: false, step: 'check' }); }, 1500); },
      lines: [
        { name: 'Préparation et protection', sub: 'Boucher les trous, poncer, protéger les planchers', amt: '160,00 $' },
        { name: 'Murs, deux couches', sub: '416 pi² à 1,35 $', amt: '561,60 $' },
        { name: 'Peinture et fournitures', sub: 'Coquille d’œuf, deux gallons, ruban, rouleaux', amt: '145,00 $' }
      ],
      checkIc: ic('check', 'sage'),
      toSend: function () { set({ step: 'send' }); },
      to: [['me', 'Moi d’abord', 'marco@rossireno.ca', 'user', 'violet'], ['client', 'Un client', 'Choisir dans vos contacts', 'users', 'teal']].map(function (o) {
        return { name: o[1], sub: o[2], ic: ic(o[3], o[4]), on: dest === o[0], cls: dest === o[0] ? 'on' : '', pick: function () { set({ dest: o[0] }); } };
      }),
      docIc: ic('doc', 'indigo'),
      sending: sending, sendLabel: sending ? 'Envoi…' : dest === 'me' ? 'M’envoyer la soumission' : 'Choisir un client',
      send: function () { set({ sending: true }); setTimeout(function () { set({ sending: false, step: 'done' }); }, 1200); },
      sentIc: ic('send', 'sage'), bellIc: ic('bell', 'amber'),
      notif: notif, notifOff: !notif, notifOn: function () { set({ notif: true }); }
    };
