    var TOTAL = 2340;
    var claim = this.g('claim', 'open');           // open | denied | done
    var sheet = this.g('sheet', false), menuOpen = this.g('menu', false);
    var amt = this.g('amt', '2,340.00'), method = this.g('method', 'e-Transfer'), ref = this.g('ref', '');
    var receipt = this.g('receipt', true), remOn = this.g('remOn', true);
    var pays = this.g('pays', []), copied = this.g('copied', false), reminded = this.g('reminded', false);
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var parse = function (s) { var n = parseFloat(String(s).replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    var paid = pays.reduce(function (a, p) { return a + p.n; }, 0);
    var bal = Math.max(0, TOTAL - paid);
    var amtN = parse(amt);
    var over = amtN - bal;
    var status = bal <= 0 ? ['Paid', 'st-ok si-check', 'var(--ok-dot)', 'Paid · Sep 29'] : paid > 0 ? ['Partly paid', 'st-warn si-q3', 'var(--warn-dot)', 'Partly paid · 9 days overdue'] : ['Overdue', 'st-bad si-alert', 'var(--bad)', 'Overdue · 9 days · viewed Sep 22'];
    var bw = money(bal).split('.');
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var rs = sw(remOn), rc = sw(receipt);
    var closeAll = function () { set({ sheet: false, menu: false }); };
    var openPay = function () { set({ sheet: true, menu: false, amt: bal > 0 ? money(bal).slice(1) : '0.00', method: 'e-Transfer' }); };
    var MICON = { 'e-Transfer': ['send', 'violet'], 'Cheque': ['doc', 'stone'], 'Cash': ['card', 'sage'], 'Card': ['card', 'azure'], 'Bank transfer': ['bank', 'teal'], 'Other': ['dot', 'slate'] };
    var last = pays.length ? pays[pays.length - 1] : null;
    var remRows = [
      ['3 days before due', 'Sep 17', 'Sent', 'st-info si-q1'],
      ['On the due date', 'Sep 20', 'Sent', 'st-info si-q1'],
      ['7 days late', 'Sep 27', 'Sent', 'st-info si-q1'],
      ['14 days late', 'Oct 4', bal <= 0 ? 'Cancelled' : (remOn ? 'Scheduled' : 'Off'), bal <= 0 || !remOn ? 'st-mute' : 'st-info'],
      ['30 days late', 'Oct 20', bal <= 0 ? 'Cancelled' : (remOn ? 'Scheduled' : 'Off'), bal <= 0 || !remOn ? 'st-mute' : 'st-info']
    ];
    var act = [];
    if (last) act.push(['Payment recorded', 'Today', money(last.n) + ' by ' + last.method + (last.receipt ? ' · receipt emailed' : '')]);
    if (claim === 'denied') act.push(['Told Lena it hasn’t arrived', 'Today', 'Sent by text']);
    act = act.concat([
      ['Lena says she paid', '8:14 am', '$2,340 by e-Transfer, from the client’s link'],
      ['Reminder sent', 'Sep 27', 'Email and text · 7 days late'],
      ['Viewed by Lena Hart', 'Sep 22', 'Opened the client’s link on a phone'],
      ['Reminder sent', 'Sep 20', 'Email · due today'],
      ['Sent to Tom & Lena Hart', 'Sep 5', 'Email to lena.hart@gmail.com'],
      ['Created from the job', 'Sep 5', 'Progress 2 of 4 · drywall 60% done']
    ]);
    return {
      stLine: status[3], stDot: 'background: ' + status[2], stWord: status[0], stCls: status[1],
      balWhole: bw[0], balCents: '.' + bw[1], balance: money(bal),
      paid: money(paid), paidColor: paid > 0 ? 'color: var(--ok)' : '', paidOf: money(paid) + ' of $2,340.00',
      paidBar: 'width: ' + Math.max(0, Math.min(100, paid / TOTAL * 100)).toFixed(1) + '%; background: var(--ok-dot)',
      claimOpen: claim === 'open' && bal > 0, claimDenied: claim === 'denied' && bal > 0,
      confirmClaim: function () { set({ sheet: true, amt: '2,340.00', method: 'e-Transfer', ref: 'Interac from Lena Hart' }); },
      denyClaim: function () { set({ claim: 'denied' }); }, undoClaim: function () { set({ claim: 'open' }); },
      recorded: !!last, recordedMsg: last ? money(last.n) + ' by ' + last.method : '', receiptMsg: last && last.receipt ? ' · receipt emailed to Lena' : '',
      claimIc: ic('send', 'violet'), okIc: ic('check', 'sage'), linkIc: ic('link', 'azure'), cardIc: ic('card', 'slate'),
      quick: [
        { label: 'Resend', ic: ic('send', 'violet'), go: function () {} },
        { label: reminded ? 'Reminded' : 'Remind', ic: ic('bell', 'amber'), go: function () { set({ reminded: true }); } },
        { label: 'PDF', ic: ic('doc', 'azure'), go: function () {} },
        { label: 'Credit note', ic: ic('receipt', 'rose'), go: function () {} }
      ],
      lines: [
        { name: 'Drywall hang, basement', amt: '$1,480.00', detail: '1,850 sq ft · board, screws, corner bead', sep: '' },
        { name: 'Taping and first coat', amt: '$590.80', detail: 'Walls and ceiling · 2 days', sep: 'border-top: 1px solid var(--line)' }
      ],
      copyLabel: copied ? 'Copied' : 'Copy link', copyLink: function () { set({ copied: true }); },
      payments: pays.map(function (p) { var m = MICON[p.method] || MICON.Other; return { method: p.method, meta: 'Sep 29, 2026' + (p.ref ? ' · ' + p.ref : ''), amt: money(p.n), receipt: p.receipt ? 'Receipt sent' : 'No receipt', ic: ic(m[0], m[1]) }; }),
      noPayments: pays.length === 0,
      remOn: remOn, remTrack: rs.t, remKnob: rs.k, toggleRem: function () { set({ remOn: !remOn }); },
      remLabel: bal <= 0 ? 'All stopped' : (remOn ? 'Next Oct 4' : 'Paused'),
      reminders: remRows.map(function (r) { return { when: r[0], date: r[1], status: r[2], st: r[3], fade: r[3] === 'st-mute' ? 'opacity: .6' : '' }; }),
      activity: act.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], dot: i === 0 ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === act.length - 1 ? 'display: none' : '' }; }),
      primaryLabel: bal > 0 ? 'Record payment' : 'Send receipt',
      openPay: openPay, openMenu: function () { set({ menu: true, sheet: false }); }, closeAll: closeAll,
      sheetOpen: sheet, menuOpen: menuOpen,
      amt: amt, onAmt: function (e) { set({ amt: e.target.value }); }, fillBalance: function () { set({ amt: money(bal).slice(1) }); },
      ref: ref, onRef: function (e) { set({ ref: e.target.value }); },
      overpay: over > 0.004, overBy: money(over > 0 ? over : 0),
      amtRing: over > 0.004 ? 'box-shadow: 0 0 0 1.5px var(--warn-dot)' : 'box-shadow: 0 0 0 1px var(--line2)',
      methods: ['e-Transfer', 'Cheque', 'Cash', 'Card', 'Bank transfer', 'Other'].map(function (m) { var on = m === method; return { label: m, on: on, cls: on ? 'on' : '', pick: function () { set({ method: m }); } }; }),
      receipt: receipt, rcTrack: rc.t, rcKnob: rc.k, toggleReceipt: function () { set({ receipt: !receipt }); },
      saveLabel: amtN > 0 ? 'Save ' + money(amtN) + ' payment' : 'Enter an amount',
      saveStyle: amtN > 0 ? '' : 'opacity: .4;',
      savePay: function () { if (amtN <= 0) return; set({ pays: pays.concat([{ n: amtN, method: method, ref: ref, receipt: receipt }]), sheet: false, claim: 'done' }); },
      menu: [
        { label: 'Resend', sub: 'Email and text to the Harts', ic: ic('send', 'violet'), style: '' },
        { label: 'Copy client’s link', sub: 'Or open their view', ic: ic('link', 'azure'), style: '' },
        { label: 'Download PDF', sub: 'INV-0412.pdf', ic: ic('doc', 'azure'), style: '' },
        { label: 'Credit note', sub: 'Reduce what the Harts owe', ic: ic('receipt', 'rose'), style: '' },
        { label: 'Archive', sub: 'Hide from the list', ic: ic('box', 'stone'), style: '' },
        { label: 'Void invoice', sub: 'Keeps the number, cancels the amount', ic: ic('warn', 'clay'), style: 'color: var(--bad)' }
      ]
    };
