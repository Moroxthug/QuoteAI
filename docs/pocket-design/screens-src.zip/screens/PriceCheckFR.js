    var mode = this.props.state || 'default';
    var loading = mode === 'loading', thin = mode === 'noHistory';
    var applied = this.g('applied', {});
    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var money = function (n) { var s = Math.abs(n).toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' '); return (n < 0 ? '−' : '') + s + ' $'; };
    var pct = function (n) { return (n * 100).toFixed(1).replace('.', ',') + ' %'; };
    var LINES = [
      { id: 'a', name: 'Retrait du dosseret existant', qty: 32, unit: 'pi²', rate: 4.50, cost: 3.10, lo: 5.00, hi: 8.00, avg: 6.10, sug: 6.00, v: 'Low',
        why: 'Sous votre propre moyenne et sous la fourchette de Toronto. Vous avez facturé 6,10 $ en moyenne sur vos 9 dernières cuisines.' },
      { id: 'b', name: 'Panneau de ciment et imperméabilisation', qty: 32, unit: 'pi²', rate: 6.25, cost: 3.90, lo: 5.50, hi: 8.00, avg: 6.40, v: 'In range',
        why: 'Proche de ce que vous facturez habituellement.' },
      { id: 'c', name: 'Pose de tuiles en chevrons', qty: 32, unit: 'pi²', rate: 18.50, cost: 11.20, lo: 16.00, hi: 24.00, avg: 19.20, v: 'In range',
        why: 'Un peu sous votre moyenne pour les chevrons. Rien à changer.' },
      { id: 'd', name: 'Fourniture de tuiles, coulis et moulures', qty: 37, unit: 'pi²', rate: 13.69, cost: 9.80, lo: 9.00, hi: 12.50, avg: 11.10, sug: 12.40, v: 'High',
        why: 'Au-dessus de la fourchette pour la fourniture. Gardez ce prix si cette tuile a coûté plus cher que d’habitude : le reçu n’est pas encore entré.' },
      { id: 'e', name: 'Rallonges de prises et plaques', qty: 4, unit: 'unité', rate: 22.00, cost: 9.00, v: 'Not enough data',
        why: 'Présent sur seulement 2 chantiers passés. Rien de fiable à comparer pour l’instant.' },
      { id: 'f', name: 'Silicone, scellement et nettoyage', qty: 1, unit: 'forfait', rate: 120.00, cost: 70.00, lo: 150, hi: 240, avg: 185, sug: 175, v: 'Low',
        why: 'Sur vos 9 dernières cuisines, ce poste était en moyenne à 185 $. À 120 $, il couvre à peine la demi-journée.' }
    ];
    var VCLS = { 'Low': ['warn', 'alert'], 'High': ['info', 'alert'], 'In range': ['ok', 'check'], 'Not enough data': ['mute', 'off'] };
    var subB = 0, subA = 0, cost = 0, nSug = 0, nApp = 0;
    var rows = LINES.map(function (l) {
      var ap = !!applied[l.id], hasSug = l.sug !== undefined;
      if (hasSug) { nSug++; if (ap) nApp++; }
      var cur = ap ? l.sug : l.rate;
      subB += r2(l.qty * l.rate); subA += r2(l.qty * cur); cost += l.qty * l.cost;
      var hasBar = l.lo !== undefined && !(thin && l.id === 'e');
      var o = { name: l.name, rate: money(l.rate) + ' / ' + l.unit, qty: l.qty + ' ' + (l.unit === 'unité' && l.qty > 1 ? 'unités' : l.unit), why: l.why, hasBar: hasBar, hasSug: hasSug, applied: ap };
      var vc = VCLS[l.v]; var word = ap ? 'Appliqué' : { 'Low': 'Bas', 'High': 'Élevé', 'In range': 'Dans la norme', 'Not enough data': 'Données insuffisantes' }[l.v];
      o.word = word; o.cls = ap ? 'st-ok si-check' : 'st-' + vc[0] + ' si-' + vc[1];
      if (hasBar) {
        var mn = Math.min(l.lo, l.rate, l.avg) * 0.8, mx = Math.max(l.hi, l.rate) * 1.15;
        var p = function (x) { return ((x - mn) / (mx - mn) * 100).toFixed(1) + '%'; };
        o.band = 'left: ' + p(l.lo) + '; width: calc(' + p(l.hi) + ' - ' + p(l.lo) + ')';
        o.avg = 'left: ' + p(l.avg);
        o.you = 'left: ' + p(cur) + '; background: ' + (ap || l.v === 'In range' ? 'var(--ok-dot)' : 'var(--ink)');
        o.showSug = hasSug && !ap; o.sug = hasSug ? 'left: ' + p(l.sug) : '';
        o.lo = money(l.lo).slice(0, -2); o.hi = money(l.hi); o.avgTxt = 'Votre moyenne ' + money(l.avg);
        o.aria = 'Toronto de ' + money(l.lo) + ' à ' + money(l.hi) + ', votre moyenne ' + money(l.avg) + ', cette soumission ' + money(cur);
      }
      if (hasSug) {
        var d = r2(l.qty * (l.sug - l.rate));
        o.sugTxt = 'Essayez ' + money(l.sug) + (l.unit === 'forfait' ? '' : ' / ' + l.unit);
        o.sugDelta = (d > 0 ? '+' : '') + money(d); o.dCol = d > 0 ? 'color: var(--ok)' : 'color: var(--muted)';
        o.mB = Math.round((l.rate - l.cost) / l.rate * 100) + ' %'; o.mA = Math.round((l.sug - l.cost) / l.sug * 100) + ' %';
        o.btn = ap ? 'Annuler' : 'Appliquer'; o.btnCls = ap ? 'btn-s' : 'btn-p';
        o.toggle = function () { var n = Object.assign({}, self.g('applied', {})); n[l.id] = !n[l.id]; set({ applied: n }); };
      }
      return o;
    });
    subB = r2(subB); subA = r2(subA);
    var totB = r2(subB * 1.13), totA = r2(subA * 1.13);
    var allSug = {}; LINES.forEach(function (l) { if (l.sug !== undefined) allSug[l.id] = true; });
    var fullA = 0; LINES.forEach(function (l) { fullA += r2(l.qty * (l.sug !== undefined ? l.sug : l.rate)); });
    var fullTot = r2(r2(fullA) * 1.13);
    var showTot = nApp ? totA : fullTot;
    var tw = money(showTot);
    var allDone = nApp === nSug;
    return {
      loading: loading, thin: thin, ready: !loading, infoIc: ic('help', 'azure'),
      headline: loading ? 'Vérification de 6 lignes' : allDone ? 'Toutes les suggestions sont appliquées' : (nSug - nApp) + ' prix à revoir',
      basis: loading ? 'Comparaison avec vos chantiers passés et les fourchettes de Toronto.' : thin ? 'Selon 2 de vos chantiers et des soumissions à Toronto pour des travaux semblables.' : 'Selon 14 de vos chantiers de dosseret et des soumissions à Toronto pour des travaux semblables.',
      totLabel: nApp ? 'Nouveau total, TVH incl.' : 'Total si appliqué',
      totWhole: tw.slice(0, -5), totCents: tw.slice(-5),
      totDelta: (showTot - totB >= 0 ? '+' : '') + money(r2(showTot - totB)) + ' vs actuel',
      deltaCol: showTot > totB ? 'color: var(--ok)' : 'color: var(--muted)',
      mBefore: pct((subB - cost) / subB),
      mAfterLbl: nApp ? 'Après changements' : 'Si appliqué',
      mAfter: pct(((nApp ? subA : fullA) - cost) / (nApp ? subA : fullA)), mAfterCol: 'color: var(--ok)',
      rows: rows,
      applyAll: function () { if (allDone) return; set({ applied: allSug }); },
      allLabel: allDone ? 'Appliqué à la soumission' : 'Tout appliquer (' + (nSug - nApp) + ')',
      allStyle: allDone ? 'background: var(--ok-dot); color: #ffffff' : ''
    };
