    var P = this.props.state || 'default';
    var offline = P === 'offline';
    var defQ = P === 'search' ? 'deposit' : (P === 'noresults' ? 'warranty paperwork' : '');
    var q = self.g('q', defQ), helpful = self.g('helpful', null);
    var A = [
      ['Send your first quote', 'Quotes', 3, 'doc', 'violet'],
      ['Take a deposit on a quote', 'Invoices', 2, 'receipt', 'sage'],
      ['Add your crew and share their links', 'Crew', 4, 'users', 'azure'],
      ['Connect QuickBooks', 'Integrations', 3, 'link', 'indigo'],
      ['Change your HST number', 'Account', 1, 'percent', 'slate'],
      ['Turn a deposit into the first invoice', 'Invoices', 2, 'receipt', 'amber'],
      ['Refund a deposit', 'Invoices', 2, 'bank', 'teal'],
      ['Start a job from an accepted quote', 'Jobs', 3, 'cone', 'amber'],
      ['Add a change order mid-job', 'Jobs', 3, 'pen', 'clay']
    ];
    var art = function (a) { return { title: a[0], meta: a[1] + ' · ' + a[2] + ' min read', ic: ic(a[3], a[4]) }; };
    var ql = q.trim().toLowerCase();
    var res = ql ? A.filter(function (a) { return (a[0] + ' ' + a[1]).toLowerCase().indexOf(ql) >= 0; }) : [];
    var vid = function (t, topic, dur, g, tone, secs) { return { title: t, meta: topic, dur: offline ? 'Offline' : dur, ic: ic(g, tone), aria: 'Watch ' + t + ', ' + dur }; };
    return {
      offline: offline, cloudIc: ic('cloud', 'amber'), searchIc: ic('search', 'slate'), sparkIc: ic('spark', 'violet'), okIc: ic('check', 'sage'), chatIc: ic('chat', 'violet'),
      chatSt: offline ? 'st-mute si-off' : 'st-ok si-live', chatWord: offline ? 'Chat offline' : 'Chat online',
      q: q, hasQ: !!ql, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '' }); },
      showResults: !!ql && res.length > 0, noResults: !!ql && res.length === 0, browse: !ql,
      results: res.map(art), resultCount: String(res.length),
      popular: A.slice(0, 5).map(art),
      topics: [['Quotes', 'doc', 'violet', 18], ['Jobs', 'cone', 'amber', 14], ['Invoices', 'receipt', 'sage', 12], ['Crew', 'users', 'azure', 11], ['Integrations', 'link', 'indigo', 9], ['Account', 'user', 'slate', 16]].map(function (t) { return { label: t[0], ic: ic(t[1], t[2]), n: String(t[3]) }; }),
      videos: [
        vid('Your first quote', 'Quotes', '1:12', 'mic', 'violet'),
        vid('quoteAI in 60 seconds', 'Overview', '1:00', 'orb', 'indigo'),
        vid('Start a job from a quote', 'Jobs', '1:34', 'cone', 'amber'),
        vid('Your crew’s first day', 'Crew', '0:58', 'users', 'azure'),
        vid('Get paid by e-Transfer', 'Invoices', '1:05', 'bank', 'sage'),
        vid('Connect QuickBooks', 'Integrations', '1:20', 'link', 'teal')
      ],
      contact: [
        { title: 'Chat with us', sub: offline ? 'Needs a connection' : 'Usually replies in 5 min', ic: ic('chat', 'violet'), href: '#', hasSt: true, st: offline ? 'st-mute si-off' : 'st-ok si-live', word: offline ? 'Offline' : 'Online' },
        { title: 'Email', sub: 'support@quoteai.ca · replies within a day', ic: ic('mail', 'azure'), href: '#', hasSt: false, st: '', word: '' },
        { title: 'Call', sub: '1-855-786-8324', ic: ic('phone', 'sage'), href: '#', hasSt: true, st: 'st-ok si-check', word: 'Open now' },
        { title: 'Report a problem', sub: 'Send a screenshot and a note', ic: ic('warn', 'amber'), href: 'Feedback.dc.html', hasSt: false, st: '', word: '' }
      ],
      steps: [
        ['Tap New quote', 'On the Quotes tab, or the + button anywhere in the app.'],
        ['Describe the job', 'Talk or type, the way you’d explain it to the client: rooms, sizes, materials, who does what.'],
        ['Check the lines', 'Labour and materials come out itemized, with HST 13% for Ontario. Tap any line to change it.'],
        ['Ask for a deposit', 'Turn on a deposit so the client can pay it when they accept.'],
        ['Send it', 'By text or email. You’ll see the moment they open it.']
      ].map(function (s, i) { return { n: String(i + 1), title: s[0], text: s[1] }; }),
      askHelpful: helpful === null, saidYes: helpful === 'yes', saidNo: helpful === 'no',
      yes: function () { set({ helpful: 'yes' }); }, no: function () { set({ helpful: 'no' }); },
      related: [A[1], A[7]].map(art)
    };
