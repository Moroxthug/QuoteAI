    var P = this.props.state || 'default';
    var offline = P === 'offline';
    var defQ = P === 'search' ? 'dépôt' : (P === 'noresults' ? 'papiers de garantie' : '');
    var q = self.g('q', defQ), helpful = self.g('helpful', null);
    var A = [
      ['Envoyer votre première soumission', 'Soumissions', 3, 'doc', 'violet'],
      ['Demander un dépôt sur une soumission', 'Factures', 2, 'receipt', 'sage'],
      ['Ajouter votre équipe et partager ses liens', 'Équipe', 4, 'users', 'azure'],
      ['Connecter QuickBooks', 'Intégrations', 3, 'link', 'indigo'],
      ['Modifier votre numéro de TVH', 'Compte', 1, 'percent', 'slate'],
      ['Transformer un dépôt en première facture', 'Factures', 2, 'receipt', 'amber'],
      ['Rembourser un dépôt', 'Factures', 2, 'bank', 'teal'],
      ['Lancer un chantier depuis une soumission', 'Travaux', 3, 'cone', 'amber'],
      ['Ajouter un ordre de changement en cours de chantier', 'Travaux', 3, 'pen', 'clay']
    ];
    var art = function (a) { return { title: a[0], meta: a[1] + ' · ' + a[2] + ' min de lecture', ic: ic(a[3], a[4]) }; };
    var ql = q.trim().toLowerCase();
    var res = ql ? A.filter(function (a) { return (a[0] + ' ' + a[1]).toLowerCase().indexOf(ql) >= 0; }) : [];
    var vid = function (t, topic, dur, g, tone, secs) { return { title: t, meta: topic, dur: offline ? 'Hors ligne' : dur, ic: ic(g, tone), aria: 'Regarder ' + t + ', ' + dur }; };
    return {
      offline: offline, cloudIc: ic('cloud', 'amber'), searchIc: ic('search', 'slate'), sparkIc: ic('spark', 'violet'), okIc: ic('check', 'sage'), chatIc: ic('chat', 'violet'),
      chatSt: offline ? 'st-mute si-off' : 'st-ok si-live', chatWord: offline ? 'Clavardage fermé' : 'Clavardage ouvert',
      q: q, hasQ: !!ql, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '' }); },
      showResults: !!ql && res.length > 0, noResults: !!ql && res.length === 0, browse: !ql,
      results: res.map(art), resultCount: String(res.length),
      popular: A.slice(0, 5).map(art),
      topics: [['Soumissions', 'doc', 'violet', 18], ['Travaux', 'cone', 'amber', 14], ['Factures', 'receipt', 'sage', 12], ['Équipe', 'users', 'azure', 11], ['Intégrations', 'link', 'indigo', 9], ['Compte', 'user', 'slate', 16]].map(function (t) { return { label: t[0], ic: ic(t[1], t[2]), n: String(t[3]) }; }),
      videos: [
        vid('Votre première soumission', 'Soumissions', '1:12', 'mic', 'violet'),
        vid('quoteAI en 60 secondes', 'Aperçu', '1:00', 'orb', 'indigo'),
        vid('Lancer un chantier depuis une soumission', 'Travaux', '1:34', 'cone', 'amber'),
        vid('Le premier jour de votre équipe', 'Équipe', '0:58', 'users', 'azure'),
        vid('Être payé par virement Interac', 'Factures', '1:05', 'bank', 'sage'),
        vid('Connecter QuickBooks', 'Intégrations', '1:20', 'link', 'teal')
      ],
      contact: [
        { title: 'Clavarder avec nous', sub: offline ? 'Connexion requise' : 'Répond en général en 5 min', ic: ic('chat', 'violet'), href: '#', hasSt: true, st: offline ? 'st-mute si-off' : 'st-ok si-live', word: offline ? 'Hors ligne' : 'En ligne' },
        { title: 'Courriel', sub: 'support@quoteai.ca · réponse en 1 jour', ic: ic('mail', 'azure'), href: '#', hasSt: false, st: '', word: '' },
        { title: 'Téléphone', sub: '1-855-786-8324', ic: ic('phone', 'sage'), href: '#', hasSt: true, st: 'st-ok si-check', word: 'Ouvert' },
        { title: 'Signaler un problème', sub: 'Envoyez une capture d’écran et une note', ic: ic('warn', 'amber'), href: 'Feedback.dc.html', hasSt: false, st: '', word: '' }
      ],
      steps: [
        ['Touchez Nouvelle soumission', 'Dans l’onglet Soumissions, ou avec le bouton + partout dans l’app.'],
        ['Décrivez les travaux', 'Parlez ou tapez, comme vous l’expliqueriez au client : pièces, dimensions, matériaux, qui fait quoi.'],
        ['Vérifiez les lignes', 'La main-d’œuvre et les matériaux sont détaillés, avec la TVH de 13 % pour l’Ontario. Touchez une ligne pour la modifier.'],
        ['Demandez un dépôt', 'Activez le dépôt pour que le client puisse le payer en acceptant.'],
        ['Envoyez-la', 'Par texto ou par courriel. Vous saurez dès que le client l’ouvre.']
      ].map(function (s, i) { return { n: String(i + 1), title: s[0], text: s[1] }; }),
      askHelpful: helpful === null, saidYes: helpful === 'yes', saidNo: helpful === 'no',
      yes: function () { set({ helpful: 'yes' }); }, no: function () { set({ helpful: 'no' }); },
      related: [A[1], A[7]].map(art)
    };
