    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var seen = ST !== 'notInstalled';
    var SW = [['Couleur de marque, bleu port', '#1F4F86'], ['Violet', '#6A2FBF'], ['Forêt', '#1F7A45'], ['Brique', '#B4462B'], ['Sarcelle', '#1E7F80'], ['Anthracite', '#2B2B30']];
    var bi = self.g('wc', 0), brand = SW[bi][1];
    var theme = self.g('wTheme', 0);
    var darkW = theme === 1;
    var F = [['fPhone', 'Téléphone'], ['fEmail', 'Courriel'], ['fPostal', 'Code postal']];
    var wFields = ['Votre nom'].concat(F.filter(function (f) { return self.g(f[0], f[0] !== 'fEmail' || true); }).map(function (f) { return f[1]; }));
    var copied = self.g('copied', false), mailed = self.g('mailed', false);
    var statusRows = seen ? [
      stat(mk('globe', 'azure', 'rossireno.ca/contact', 'Vu il y a 12 minutes'), 'En ligne', 'st-ok'),
      lnk('funnel', 'teal', 'Demandes du site', 'Ce mois-ci', '18', 'Leads.dc.html', true)
    ] : [
      stat(mk('globe', 'azure', 'rossireno.ca', 'Vu sur aucune page pour l’instant'), 'Non installé', 'st-mute'),
      lnk('eye', 'indigo', 'Ouvrir la page de test', 'Essayez le formulaire comme un client', '', '#')
    ];
    return {
      roBanner: roBanner, notSeen: !seen, warnIc: ic('warn', 'amber'),
      brandBg: 'background: ' + brand, brushIc: ic('brush', 'lilac'), swName: bi === 0 ? 'Couleur de votre marque' : SW[bi][0],
      wSurface: darkW ? 'background: #1b1b1f; color: #f3f2ef' : 'background: #ffffff; color: #141416',
      wInput: darkW ? 'background: #2a2a30; color: #9d9ca4' : 'background: #f3f2ef; color: #8a8a90',
      kinds: ['Cuisine', 'Salle de bain', 'Sous-sol'].map(function (t, i) { return { t: t, style: i === 2 ? 'color: #ffffff; background: ' + brand : (darkW ? 'background: #2a2a30; color: #d0cfd5' : 'background: #f3f2ef; color: #3c3c43') }; }),
      wFields: wFields.slice(0, 3), btnText: self.g('instant', true) ? 'Voir mon estimation' : 'Envoyer la demande',
      gStatus: grp('', statusRows, '', 80),
      swatches: SW.map(function (s, i) { var on = i === bi; return { name: s[0], on: on, style: 'background: ' + s[1] + '; ' + (on ? 'box-shadow: 0 0 0 2px var(--card), 0 0 0 4px ' + s[1] + '; transform: scale(1.04)' : 'box-shadow: 0 0 0 1px var(--line2)'), pick: function () { set({ wc: i }); } }; }),
      gLook: (function (g) { g.rows[0].sep = 'border-top: 1px solid var(--line)'; return g; })(grp('Apparence', [
        seg('wTheme', 0, 'moon', 'slate', 'Arrière-plan', '', ['Clair', 'Sombre', 'Automatique']),
        seg('wStyle', 0, 'grid', 'lilac', 'Affichage', '', ['Formulaire intégré', 'Bouton flottant'])
      ], '', 130)),
      gFields: grp('Champs demandés', [
        val('user', 'violet', 'Nom', 'Toujours demandé', 'Obligatoire'),
        sw('fPhone', true, 'phone', 'sage', 'Téléphone', 'Requis pour les relances par texto'),
        sw('fEmail', true, 'mail', 'sky', 'Courriel', ''),
        sw('fPostal', true, 'pin', 'clay', 'Code postal', 'Écarte les chantiers hors de votre zone'),
        sw('fPhotos', false, 'camera', 'amber', 'Photos', 'Jusqu’à 5 depuis leur téléphone'),
        sw('fBudget', false, 'bars', 'teal', 'Fourchette de budget', ''),
        sw('instant', true, 'spark', 'violet', 'Estimation immédiate', 'Une fourchette tirée de votre liste de prix')
      ], '', 180),
      code: '<script src="https://quoteai.ca/w.js" data-key="wk_7Hq2LmR9" async><\/script>',
      copyLabel: copied ? 'Copié' : 'Copier le code', copy: function () { set({ copied: true }); setTimeout(function () { set({ copied: false }); }, 1800); },
      mailLabel: mailed ? 'Envoyé' : 'Au webmestre', mail: function () { set({ mailed: true }); },
      gCode: { rows: (function () { var r = [ val('key', 'violet', 'Clé du widget', 'Seulement sur rossireno.ca', 'wk_7Hq2LmR9', true), lnk('eye', 'indigo', 'Page de test', 'Essayez le formulaire comme un client', '', '#') ]; r[0].sep = 'border-top: 1px solid var(--line)'; r[1].sep = 'border-top: 1px solid var(--line)'; return r; })() },
      gLeads: grp('Destination des demandes', [
        lnk('funnel', 'teal', 'Demandes', 'Étiquette « Site Web »', 'Ouvrir', 'Leads.dc.html'),
        lnk('user', 'violet', 'Assigner à', 'Qui fait le premier suivi', 'Marco Rossi', '#'),
        sw('notify', true, 'bell', 'amber', 'M’aviser', 'Sur ce téléphone, tout de suite'),
        sw('autoReply', true, 'chat', 'sky', 'Réponse automatique', 'Texto au client en moins d’une minute')
      ], '', 260)
    };
