    var lang = this.g('lang', 'en'), fr = lang === 'fr';
    var state = this.g('state', 'open'), confirming = this.g('confirming', false), paying = this.g('paying', false), copied = this.g('copied', '');
    var money = function (n) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return fr ? s + ' $' : '$' + s;
    };
    var EN = {
      from: 'From', invoice: 'Invoice', issued: 'Sep 13, 2026', title: 'Basement finish, progress bill 3 of 5',
      balance: 'Balance due', due: 'Due date', dueDate: 'Sep 20', paidSoFar: 'Paid so far', of: 'of',
      overdue: 'Overdue', overdueSub: '9 days ago', awaiting: 'Awaiting confirmation', paid: 'Paid', paidOn: 'Paid Sep 29',
      awaitTitle: 'We told Rossi Renovations you sent it.', awaitSub: 'They confirm when the e-Transfer lands, usually within a day.', undo: 'I haven’t sent it yet',
      paidTitle: 'Paid in full', paidSub: 'Thank you, Tom and Lena. A receipt is on its way to your email.', receipt: 'Download receipt',
      howTo: 'How to pay', etransfer: 'Interac e-Transfer', noFee: 'No fee · from your bank app',
      sendTo: 'Send to', amount: 'Amount', ref: 'Message or reference', copy: 'Copy', copiedL: 'Copied',
      autoDep: 'Auto-deposit is on, so there is no security question.', iSent: 'I sent it',
      confirmTitle: 'Tell us about your e-Transfer', sentOn: 'Sent on', today: 'Today, Sep 29', cancel: 'Cancel', confirm: 'Confirm',
      card: 'Pay by card', cardSub: 'Visa, Mastercard, Amex · Apple Pay', cardFee: 'Card fee 2.4%', charged: 'Total charged', payCard: 'Pay by card', paying: 'Processing…',
      secure: 'Secure payment through Stripe', cheque: 'Cheque', chequeSub: 'Payable to Rossi Renovations Inc. Hand it to Luca on site or mail it to 88 Dufferin St, Toronto M6K 1Z6.',
      details: 'Invoice details', progress: 'Progress 3 of 5', subtotal: 'Subtotal', hst: 'HST, Ontario 13%', total: 'Invoice total',
      pay1: 'Paid Sep 14 · e-Transfer', pay2: 'Paid Sep 29 · card',
      pdf: 'Download PDF', questions: 'Questions? Call Marco at', portal: 'Open your project portal',
      lines: [['Framing, completed', 'Basement walls and bulkheads', 1850], ['Drywall, supply and hang', '1,480 sq ft, 1/2" moisture-resistant', 2400], ['Electrical rough-in', 'Reyes Electric, ESA inspected', 750]]
    };
    var FR = {
      from: 'De la part de', invoice: 'Facture', issued: '13 sept. 2026', title: 'Finition du sous-sol, facture d’étape 3 de 5',
      balance: 'Solde dû', due: 'Échéance', dueDate: '20 sept.', paidSoFar: 'Payé à ce jour', of: 'sur',
      overdue: 'En retard', overdueSub: 'il y a 9 jours', awaiting: 'Confirmation en attente', paid: 'Payée', paidOn: 'Payée le 29 sept.',
      awaitTitle: 'Nous avons avisé Rossi Renovations.', awaitSub: 'Ils confirment à la réception du virement, habituellement en un jour.', undo: 'Je ne l’ai pas encore envoyé',
      paidTitle: 'Payée en entier', paidSub: 'Merci, Tom et Lena. Un reçu est envoyé à votre courriel.', receipt: 'Télécharger le reçu',
      howTo: 'Comment payer', etransfer: 'Virement Interac', noFee: 'Sans frais · depuis votre banque',
      sendTo: 'Envoyer à', amount: 'Montant', ref: 'Message ou référence', copy: 'Copier', copiedL: 'Copié',
      autoDep: 'Le dépôt automatique est activé : aucune question de sécurité.', iSent: 'Je l’ai envoyé',
      confirmTitle: 'Détails de votre virement', sentOn: 'Envoyé le', today: 'Aujourd’hui, 29 sept.', cancel: 'Annuler', confirm: 'Confirmer',
      card: 'Payer par carte', cardSub: 'Visa, Mastercard, Amex · Apple Pay', cardFee: 'Frais de carte 2,4 %', charged: 'Total facturé', payCard: 'Payer par carte', paying: 'Traitement…',
      secure: 'Paiement sécurisé par Stripe', cheque: 'Chèque', chequeSub: 'À l’ordre de Rossi Renovations Inc. Remettez-le à Luca sur le chantier ou postez-le au 88, rue Dufferin, Toronto M6K 1Z6.',
      details: 'Détails de la facture', progress: 'Étape 3 de 5', subtotal: 'Sous-total', hst: 'TVH, Ontario 13 %', total: 'Total de la facture',
      pay1: 'Payé le 14 sept. · virement', pay2: 'Payé le 29 sept. · carte',
      pdf: 'Télécharger le PDF', questions: 'Des questions? Appelez Marco au', portal: 'Ouvrir votre portail de projet',
      lines: [['Charpente, terminée', 'Murs et retombées du sous-sol', 1850], ['Cloisons sèches, fourniture et pose', '1 480 pi², 1/2 po résistant à l’humidité', 2400], ['Électricité, pré-filage', 'Reyes Electric, inspecté par l’ESA', 750]]
    };
    var t = fr ? FR : EN;
    var sub = 5000, tax = 650, total = 5650, prior = 3310, bal = total - prior;
    var isPaid = state === 'paid', isAwaiting = state === 'awaiting';
    var balance = isPaid ? 0 : bal;
    var balStr = money(balance);
    var fee = Math.round(bal * 0.024 * 100) / 100;
    var paidSoFar = isPaid ? total : prior;
    var mkCopy = function (key, label, value, cls, raw) {
      var on = copied === key;
      return {
        label: label, value: value, cls: cls, copied: on, notCopied: !on, btn: on ? t.copiedL : t.copy, aria: t.copy + ' ' + label,
        btnStyle: on ? 'background: var(--ok-soft); color: var(--ok)' : 'background: var(--sunk); color: var(--ink)',
        sep: 'border-top: 1px solid var(--line)',
        copy: function () {
          try { var pr = navigator.clipboard && navigator.clipboard.writeText(raw); if (pr && pr.catch) pr.catch(function () {}); } catch (e) {}
          self.setState({ copied: key });
          setTimeout(function () { if (self.g('copied', '') === key) self.setState({ copied: '' }); }, 1600);
        }
      };
    };
    var payments = [{ label: t.pay1, amt: '−' + money(prior) }];
    if (isPaid) payments.push({ label: t.pay2, amt: '−' + money(bal) });
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      status: isPaid ? t.paid : (isAwaiting ? t.awaiting : t.overdue),
      statusSt: isPaid ? 'st-ok' : (isAwaiting ? 'st-info' : 'st-warn'),
      balance: balStr, balWhole: fr ? balStr : balStr.slice(0, -3), balCents: fr ? '' : balStr.slice(-3),
      balStyle: isPaid ? 'color: var(--ok)' : '',
      paidPct: Math.round(paidSoFar / total * 100) + '%', barStyle: isPaid ? 'background: var(--ok-dot)' : 'background: var(--inv)',
      dueStyle: (isPaid || isAwaiting) ? '' : 'color: var(--warn)',
      dueSub: isPaid ? t.paidOn : t.overdueSub,
      paidSoFar: money(paidSoFar), ofTotal: t.of + ' ' + money(total),
      isPaid: isPaid, isAwaiting: isAwaiting, isOpen: !isPaid,
      okIc: ic('check', 'sage'), syncIc: ic('sync', 'azure'), etIc: ic('send', 'indigo'), cardIc: ic('card', 'violet'), chqIc: ic('doc', 'stone'),
      copyRows: [
        mkCopy('to', t.sendTo, 'pay@rossireno.ca', '', 'pay@rossireno.ca'),
        mkCopy('amt', t.amount, money(bal), 'num', bal.toFixed(2)),
        mkCopy('ref', t.ref, 'INV-0412', 'mono', 'INV-0412')
      ],
      confirming: confirming && !isAwaiting, notConfirming: !confirming && !isAwaiting,
      startSent: function () { self.setState({ confirming: true }); },
      cancelSent: function () { self.setState({ confirming: false }); },
      confirmSent: function () { self.setState({ confirming: false, state: 'awaiting' }); },
      undoSent: function () { self.setState({ state: 'open' }); },
      fee: money(fee), charged: money(bal + fee), paying: paying,
      payLabel: paying ? t.paying : t.payCard + ' · ' + money(bal + fee),
      payCard: function () {
        if (self.g('paying', false)) return;
        self.setState({ paying: true });
        setTimeout(function () { self.setState({ paying: false, state: 'paid', confirming: false }); }, 1500);
      },
      lines: t.lines.map(function (l, i) { return { name: l[0], detail: l[1], amt: money(l[2]), sep: i ? 'border-top: 1px solid var(--line)' : '' }; }),
      sub: money(sub), tax: money(tax), total: money(total), payments: payments
    };
