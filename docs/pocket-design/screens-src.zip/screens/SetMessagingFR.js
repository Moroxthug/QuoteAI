    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var wa = self.g('wa', ST !== 'whatsappNotConnected');
    var usedUp = ST === 'textsUsedUp';
    var smsUsed = usedUp ? 1000 : 412;
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('fr-CA'), total: total.toLocaleString('fr-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : '', sub: full ? 'Épuisé · remise à zéro le 1er oct.' : sub, subStyle: full ? 'color: var(--bad)' : 'color: var(--muted)' };
    };
    var meters = [ meter('Textos ce mois-ci', smsUsed, 1000, 'Remise à zéro le 1er oct.') ];
    if (wa) meters.push(meter('Messages WhatsApp', 86, 500, 'Remise à zéro le 1er oct.'));
    var waRows;
    if (wa) waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', '(416) 555-0142 · vérifié le 2 sept.'), 'Connecté', 'st-ok'),
      sw('waPref', true, 'send', 'teal', 'Si le client le préfère', 'Sinon, on envoie un texto'),
      btnRow('link', 'slate', 'Déconnecter', 'Retour aux textos et courriels', 'Déconnecter', function () { set({ wa: false }); }, 'btn-d')
    ];
    else waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', 'Soumissions et réponses dans WhatsApp'), 'Non connecté', 'st-mute si-off'),
      btnRow('phone', 'violet', 'Connecter votre numéro', 'Code à 6 chiffres envoyé par WhatsApp', 'Connecter', function () { set({ wa: true }); }, 'btn-p')
    ];
    var logSt = function (r, w, c) { return stat(r, w, c); };
    return {
      roBanner: roBanner, usedUp: usedUp, waOn: wa, warnIc: ic('warn', 'rose'), phoneIc: ic('phone', 'violet'),
      numSt: usedUp ? { w: 'En pause', cls: 'st-warn si-pause' } : { w: 'Actif', cls: 'st-ok si-live' },
      meters: meters,
      gSms: grp('Textos', [
        sw('sms', !usedUp, 'chat', 'sky', 'Envoi de textos', usedUp ? 'En pause jusqu’au 1er oct.' : 'Liens de soumission et de facture, rappels'),
        sw('leadFu', true, 'funnel', 'teal', 'Suivi des demandes', 'Quand une demande attend une réponse'),
        sw('crewRem', true, 'users', 'amber', 'Rappels à l’équipe', 'Chantier du lendemain, la veille à 19 h'),
        btnRow('send', 'indigo', 'Envoyer un test', 'À votre téléphone, (416) 555-0142', self.g('tested', false) ? 'Envoyé' : 'Envoyer', function () { set({ tested: true }); })
      ], '', 80),
      gWa: grp('WhatsApp', waRows, wa ? '' : 'Requiert un compte WhatsApp Business sur un numéro à vous. Environ 5 minutes.', 130),
      gTpl: grp('Modèles WhatsApp', [
        stat(lnk('doc', 'violet', 'Soumission prête', 'Lien vers la soumission', '', '#'), 'Approuvé', 'st-ok si-check'),
        stat(lnk('receipt', 'amber', 'Rappel de facture', 'Solde et lien de paiement', '', '#'), 'Approuvé', 'st-ok si-check'),
        stat(lnk('truck', 'teal', 'En route', 'Heure d’arrivée pour le client', '', '#'), 'Approuvé', 'st-ok si-check'),
        stat(lnk('star', 'gold', 'Demande d’avis', 'Liens Google et HomeStars', '', '#'), 'En révision', 'st-acc si-q2'),
        stat(lnk('funnel', 'rose', 'Suivi de demande', 'Trop promotionnel. Modifiez et renvoyez', '', '#'), 'Refusé', 'st-bad si-x')
      ], 'WhatsApp vérifie chaque modèle avant son utilisation, en général en moins d’un jour.', 170),
      gQuiet: grp('Heures de silence', [
        sw('quiet', true, 'moon', 'indigo', 'Heures de silence', 'Les messages attendent le matin'),
        val('clock', 'slate', 'De', 'Tous les jours', '21 h', true),
        val('sun', 'amber', 'Jusqu’à', 'Rappels d’équipe inclus', '8 h', true)
      ], '', 210),
      gOpt: grp('Désabonnements', [
        val('shield', 'sage', 'Répondre STOP', 'Ajouté au 1er message de chaque client', 'Toujours actif'),
        lnk('users', 'stone', 'Désabonnés', 'Courriel seulement', '3 clients', '#')
      ], 'La loi anti-pourriel (LCAP) exige un consentement et un moyen simple de se désabonner. On s’occupe des deux.', 250),
      gLog: grp('Messages récents', [
        logSt(mk('user', 'violet', 'Dana Whitfield', 'Lien de soumission · 9 h 12'), 'Envoyé', 'st-info si-q1'),
        logSt(mk('user', 'teal', 'Harbourfront Dental', '« Pouvez-vous commencer lundi ? » · 8 h 40'), 'Reçu', 'st-acc'),
        logSt(mk('user', 'amber', 'Priya Nair', 'Suivi · envoi à 8 h'), 'En attente', 'st-warn si-clock'),
        logSt(mk('user', 'rose', 'Tom & Lena Hart', 'Rappel INV-0412 · ligne fixe'), 'Échec', 'st-bad si-x')
      ], '', 290)
    };
