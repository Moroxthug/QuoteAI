    var S0 = [
      { day: 'Day 2', name: 'Friendly nudge', via: 'Text', when: 'If the quote hasn’t been opened', msg: 'Hi Dana, just making sure the kitchen quote reached you. Here it is again: {link}. Happy to walk through it. Marco, Rossi Renovations' },
      { day: 'Day 5', name: 'Questions', via: 'Email', when: 'If it was opened but not accepted', msg: 'Hi Dana, any questions on the kitchen quote? I can adjust the scope or split it into phases if that helps. Marco' },
      { day: 'Day 10', name: 'Last check-in', via: 'Text', when: 'Before the quote expires', msg: 'Hi Dana, your quote is good until Oct 29. Want me to hold a start date for you? {link}' }
    ];
    var si = self.g('fu', 0);
    var msgs = self.g('msgs', S0.map(function (s) { return s.msg; }));
    var on = [self.g('fuOn0', true), self.g('fuOn1', true), self.g('fuOn2', true)];
    var cur = Object.assign({}, S0[si], { msg: msgs[si] });
    var rev = self.g('rev', true);
    var revRows = [ sw('rev', true, 'star', 'gold', 'Ask for a review', 'When a job is marked done') ];
    if (rev) revRows = revRows.concat([
      step('revDelay', 3, 1, 0, 14, function (x) { return x === 0 ? 'Same day' : x + (x === 1 ? ' day' : ' days'); }, 'clock', 'amber', 'Wait', 'After the final invoice is paid'),
      lnk('globe', 'azure', 'Google', 'Your review link', 'g.page/rossireno', RO ? '' : '#'),
      lnk('house', 'clay', 'HomeStars', 'Your review link', 'Added', RO ? '' : '#')
    ]);
    var stepSw = sw('fuOn' + si, true, 'bell', 'amber', 'Send ' + S0[si].day.toLowerCase() + ' follow-up', S0[si].name);
    stepSw.sep = 'border-top: 1px solid var(--line)';
    var fuRows = [ stepSw,
      step('lead', 1, 1, 0, 7, function (x) { return x === 0 ? 'Same day' : x + (x === 1 ? ' day' : ' days'); }, 'funnel', 'teal', 'New leads', 'First follow-up if you haven’t replied') ];
    fuRows[1].sep = 'border-top: 1px solid var(--line)';
    return {
      roBanner: roBanner, ro: RO,
      gDef: grp('Defaults', [
        step('valid', 30, 5, 5, 90, ' days', 'clock', 'teal', 'Valid for', 'Then the quote expires'),
        step('dep', 30, 5, 0, 50, '%', 'percent', 'amber', 'Deposit', 'Asked on acceptance'),
        sw('gbb', true, 'bars', 'violet', 'Good, Better, Best', 'Three options on every new quote'),
        sw('accMail', true, 'mail', 'sky', 'Email me on acceptance', 'With the signed quote attached')
      ], '', 60),
      steps: S0.map(function (s, i) { var sel = i === si; return { day: s.day, name: s.name, on: sel,
        style: sel ? 'background: var(--card); box-shadow: 0 0 0 2px var(--ink)' : 'background: var(--sunk); box-shadow: none',
        dot: on[i] ? 'background: var(--ok-dot)' : 'background: var(--line2)', pick: function () { set({ fu: i, tested: false }); } }; }),
      cur: cur,
      onMsg: function (e) { var m = self.g('msgs', msgs).slice(); m[self.g('fu', 0)] = e.target.value; set({ msgs: m }); },
      testLabel: self.g('tested', false) ? 'Sent to you' : 'Send me a test', test: function () { set({ tested: true }); },
      gFu: { rows: fuRows },
      terms: 'Price includes labour, materials and disposal listed above. Not included: permits unless listed, asbestos or mould removal, hidden damage found behind walls, and changes you ask for once work starts. Changes are priced as change orders before we do them. 1-year warranty on workmanship.',
      gRev: grp('Reviews', revRows, rev ? 'We send one request per job, never more.' : '', 230)
    };
