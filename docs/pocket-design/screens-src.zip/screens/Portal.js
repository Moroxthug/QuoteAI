    var lang = this.g('lang', 'en'), fr = lang === 'fr', tab = this.g('tab', 0), draft = this.g('draft', '');
    var money = function (n, dec) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: dec ? 2 : 0, maximumFractionDigits: dec ? 2 : 0 });
      return fr ? s + ' $' : '$' + s;
    };
    var EN = {
      portalOf: 'Your project with', hi: 'Hi Tom and Lena', jobLine: 'Basement finish · 48 Galloway Rd, Scarborough',
      tabs: ['Home', 'Quotes', 'Contracts', 'Invoices', 'Photos', 'Messages'],
      attention: 'Needs your attention', progress: 'Job progress', onTrack: 'On track for Oct 20', job: 'Basement finish', phaseNow: 'Now: drywall, taping and mud',
      inProgress: 'In progress', latestPhotos: 'Latest photos', seeAll: 'See all', messages: 'Messages', open: 'Open',
      write: 'Write to Marco', send: 'Send', replyTime: 'Marco usually replies within a few hours',
      a: [['Invoice INV-0412', 'Progress bill 3 of 5. Was due Sep 20.', 'Overdue', 'Pay'], ['Change order CO-3', 'Four pot lights in the family room. Adds one day.', 'To sign', 'Review'], ['Pick paint colours', 'Walls and trim, by Friday Oct 2 so paint can be ordered.', 'Due Fri', 'Reply']],
      ms: ['Demolition and framing', 'Electrical and plumbing rough-in', 'Insulation and inspection', 'Drywall', 'Paint and trim', 'Flooring', 'Final walkthrough'],
      paid: 'Paid', signed: 'Signed', accepted: 'Accepted', toSign: 'To sign', overdue: 'Overdue',
      k: ['Job total', 'Paid so far', 'Left to pay'],
      pg: ['Drywall', 'Insulation and inspection', 'Framing'], photo: 'Photo'
    };
    var FR = {
      portalOf: 'Votre projet avec', hi: 'Bonjour Tom et Lena', jobLine: 'Finition du sous-sol · 48 Galloway Rd, Scarborough',
      tabs: ['Accueil', 'Soumissions', 'Contrats', 'Factures', 'Photos', 'Messages'],
      attention: 'À faire', progress: 'Avancement', onTrack: 'Prévu pour le 20 oct.', job: 'Finition du sous-sol', phaseNow: 'En cours : cloisons sèches, joints',
      inProgress: 'En cours', latestPhotos: 'Photos récentes', seeAll: 'Tout voir', messages: 'Messages', open: 'Ouvrir',
      write: 'Écrire à Marco', send: 'Envoyer', replyTime: 'Marco répond habituellement en quelques heures',
      a: [['Facture INV-0412', 'Facture d’étape 3 de 5. Échue le 20 sept.', 'En retard', 'Payer'], ['Avenant CO-3', 'Quatre lumières encastrées au salon familial. Ajoute un jour.', 'À signer', 'Voir'], ['Choisir les couleurs', 'Murs et boiseries, d’ici le vendredi 2 oct. pour commander la peinture.', 'Ven.', 'Répondre']],
      ms: ['Démolition et charpente', 'Pré-filage électrique et plomberie', 'Isolation et inspection', 'Cloisons sèches', 'Peinture et boiseries', 'Revêtement de sol', 'Visite finale'],
      paid: 'Payée', signed: 'Signé', accepted: 'Acceptée', toSign: 'À signer', overdue: 'En retard',
      k: ['Total du projet', 'Payé à ce jour', 'Reste à payer'],
      pg: ['Cloisons sèches', 'Isolation et inspection', 'Charpente'], photo: 'Photo'
    };
    var t = fr ? FR : EN;
    var go = function (i) { return function () { self.setState({ tab: i }); }; };
    var tabs = t.tabs.map(function (l, i) {
      var on = i === tab, badge = i === 2 ? 1 : (i === 3 ? 1 : (i === 5 ? 1 : 0));
      return { label: l, on: on, cls: on ? 'on' : '', pick: go(i), hasBadge: badge > 0 && !on, badge: badge };
    });
    var AT = [
      { ic: ic('receipt', 'amber'), st: 'st-warn si-alert', amt: money(2340, true), href: 'ClientInvoice.dc.html', btnCls: 'btn-p', link: true },
      { ic: ic('pen', 'violet'), st: 'st-warn', amt: '+' + money(1120, true), href: 'ClientSign.dc.html', btnCls: 'btn-s', link: true },
      { ic: ic('chat', 'azure'), st: 'st-warn', amt: '', href: '', btnCls: 'btn-s', link: false }
    ];
    var attention = AT.map(function (a, i) {
      return { ic: a.ic, st: a.st, amt: a.amt, href: a.href, btnCls: a.btnCls, isLink: a.link, isBtn: !a.link, go: go(5), title: t.a[i][0], sub: t.a[i][1], status: t.a[i][2], cta: t.a[i][3] };
    });
    var MD = fr ? ['31 août', '11 sept.', '18 sept.', '2 oct.', '9 oct.', '16 oct.', '20 oct.'] : ['Aug 31', 'Sep 11', 'Sep 18', 'Oct 2', 'Oct 9', 'Oct 16', 'Oct 20'];
    var milestones = t.ms.map(function (n, i) {
      var done = i < 3, now = i === 3, last = i === t.ms.length - 1;
      return {
        name: n, date: MD[i], done: done, now: now,
        disc: done ? 'background: var(--ok-dot)' : (now ? 'background: var(--acc-soft); box-shadow: inset 0 0 0 2px var(--acc)' : 'background: var(--card); box-shadow: inset 0 0 0 1.6px var(--line2)'),
        line: last ? 'display: none' : (done ? 'background: var(--ok-dot); opacity: .45' : 'background: var(--line2)'),
        txt: done ? 'color: var(--muted)' : (now ? 'color: var(--ink); font-weight: 600' : 'color: var(--ink)')
      };
    });
    var mkPhoto = function (s, cap) { return { a: s === 'a', b: s === 'b', c: s === 'c', cap: cap, aria: t.photo + ' ' + cap }; };
    var D1 = fr ? '28 sept.' : 'Sep 28', D2 = fr ? '25 sept.' : 'Sep 25', D3 = fr ? '18 sept.' : 'Sep 18', D4 = fr ? '4 sept.' : 'Sep 4';
    var recentPhotos = [mkPhoto('b', D1), mkPhoto('c', D1), mkPhoto('b', D2), mkPhoto('a', D3), mkPhoto('c', D3), mkPhoto('a', D4)];
    var photoGroups = [
      { title: t.pg[0], count: 6, photos: [mkPhoto('b', D1), mkPhoto('c', D1), mkPhoto('b', D1), mkPhoto('b', D2), mkPhoto('c', D2), mkPhoto('b', D2)] },
      { title: t.pg[1], count: 3, photos: [mkPhoto('a', D3), mkPhoto('c', D3), mkPhoto('a', D3)] },
      { title: t.pg[2], count: 6, photos: [mkPhoto('a', D4), mkPhoto('a', D4), mkPhoto('a', D4), mkPhoto('c', D4), mkPhoto('a', D4), mkPhoto('a', D4)] }
    ];
    var base = [
      { day: fr ? 'Hier' : 'Yesterday' },
      { who: 'Marco Rossi', ini: 'MR', tn: 'tn3', time: '4:12 pm', text: fr ? 'Les panneaux sont posés. Amara commence les joints demain matin.' : 'Board is up in the whole basement. Amara starts taping tomorrow morning.', ph: true },
      { me: true, time: '6:40 pm', text: fr ? 'Super, ça avance vite. Pouvez-vous ajouter une prise près du bar?' : 'Looks great. Could we add an outlet by the bar?' },
      { day: fr ? 'Aujourd’hui' : 'Today' },
      { who: 'Luca Bianchi', ini: 'LB', tn: 'tn1', time: '8:05 am', text: fr ? 'Jonah peut l’ajouter avant les joints. 95 $ plus TVH, on l’ajoute à l’avenant CO-3.' : 'Jonah can add it before we tape that wall. $95 plus HST, added to change order CO-3.' },
      { who: 'Marco Rossi', ini: 'MR', tn: 'tn3', time: '9:20 am', text: fr ? 'Dernière chose : pouvez-vous choisir les couleurs d’ici vendredi? Je vous envoie des échantillons.' : 'One more thing: could you pick paint colours by Friday? I dropped samples by the side door.' }
    ];
    var sent = this.g('sent', []);
    var thread = base.concat(sent).map(function (m) {
      if (m.day) return { isDay: true, isThem: false, isMe: false, text: m.day };
      return { isDay: false, isThem: !m.me, isMe: !!m.me, who: m.who || '', ini: m.ini || '', tn: m.tn || '', time: m.time, text: m.text, hasPhoto: !!m.ph, ph: { a: false, b: true, c: false } };
    });
    var last = base[base.length - 1];
    var LISTS = {
      1: { kpis: false, rows: [
        { ic: ic('doc', 'indigo'), title: fr ? 'Finition du sous-sol' : 'Basement finish', no: 'Q-2026-107', sub: fr ? '28 août' : 'Aug 28', amt: money(38400, true), st: 'st-ok', status: t.accepted, href: 'ClientQuote.dc.html' },
        { ic: ic('doc', 'indigo'), title: fr ? 'Avenant, rangement' : 'Change order, storage room', no: 'Q-2026-114', sub: fr ? '19 sept.' : 'Sep 19', amt: money(3955, true), st: 'st-ok', status: t.accepted, href: 'ClientQuote.dc.html' }
      ] },
      2: { kpis: false, rows: [
        { ic: ic('pen', 'violet'), title: fr ? 'Avenant, lumières encastrées' : 'Change order, pot lights', no: 'CO-3', sub: fr ? 'Envoyé aujourd’hui' : 'Sent today', amt: money(1120, true), st: 'st-warn', status: t.toSign, href: 'ClientSign.dc.html' },
        { ic: ic('pen', 'violet'), title: fr ? 'Avenant, rangement' : 'Change order, storage room', no: 'CO-2', sub: fr ? '19 sept.' : 'Sep 19', amt: money(3955, true), st: 'st-ok', status: t.signed, href: 'ClientSign.dc.html' },
        { ic: ic('shield', 'sage'), title: fr ? 'Contrat, finition du sous-sol' : 'Contract, basement finish', no: 'C-2026-018', sub: fr ? '29 août' : 'Aug 29', amt: money(38400, true), st: 'st-ok', status: t.signed, href: 'ClientSign.dc.html' }
      ] },
      3: { kpis: true, rows: [
        { ic: ic('receipt', 'amber'), title: fr ? 'Étape 3 de 5' : 'Progress 3 of 5', no: 'INV-0412', sub: fr ? 'Échue le 20 sept.' : 'Due Sep 20', amt: money(2340, true), st: 'st-warn si-alert', status: t.overdue, href: 'ClientInvoice.dc.html' },
        { ic: ic('receipt', 'sage'), title: fr ? 'Étape 2 de 5' : 'Progress 2 of 5', no: 'INV-0398', sub: fr ? '1er sept.' : 'Sep 1', amt: money(7910, true), st: 'st-ok', status: t.paid, href: 'ClientInvoice.dc.html' },
        { ic: ic('receipt', 'sage'), title: fr ? 'Dépôt' : 'Deposit', no: 'INV-0371', sub: fr ? '29 août' : 'Aug 29', amt: money(11520, true), st: 'st-ok', status: t.paid, href: 'ClientInvoice.dc.html' }
      ] }
    };
    var L = LISTS[tab] || { kpis: false, rows: [] };
    var send = function () {
      var d = self.g('draft', '').trim(); if (!d) return;
      var n = new Date(), h = n.getHours(), mi = n.getMinutes();
      var tm = ((h % 12) || 12) + ':' + (mi < 10 ? '0' : '') + mi + (h < 12 ? ' am' : ' pm');
      self.setState({ sent: self.g('sent', []).concat([{ me: true, time: tm, text: d }]), draft: '' });
    };
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      tabs: tabs, isHome: tab === 0, isList: tab >= 1 && tab <= 3, isPhotos: tab === 4, isMessages: tab === 5,
      attention: attention, attnCount: String(attention.length), milestones: milestones,
      recentPhotos: recentPhotos, photoGroups: photoGroups, goPhotos: go(4), goMessages: go(5),
      lastMsg: last.text, lastTime: last.time,
      hasKpis: L.kpis, rows: L.rows,
      kpis: [
        { label: t.k[0], value: money(42355), sep: '' },
        { label: t.k[1], value: money(22740), sep: 'border-left: 1px solid var(--line)' },
        { label: t.k[2], value: money(19615), sep: 'border-left: 1px solid var(--line)' }
      ],
      thread: thread, draft: draft, onDraft: function (e) { self.setState({ draft: e.target.value }); },
      send: send,
      sendStyle: draft.trim() ? 'background: var(--inv); color: var(--on-inv)' : 'background: var(--sunk); color: var(--faint)'
    };
