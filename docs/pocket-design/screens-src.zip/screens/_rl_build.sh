#!/bin/bash
# _rl_build.sh NAME "Title" HEIGHT TAB 'DC_PROPS' "states"
S=/tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad
N=$1
python3 $S/kit/normalize.py $S/screens/$N.body.html $S/screens/$N.js >/dev/null
DC_PROPS="$5" python3 $S/kit/assemble.py $N "$2" $S/screens/$N.body.html $S/screens/$N.js $3 $4 >/dev/null || exit 1
cp $S/design/project/$N.dc.html $S/prev/
sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/design/project/$N.dc.html > $S/prev/${N}_D.dc.html
awk '/data-dc-script/{f=1;next} /<\/script>/{f=0} f' $S/prev/$N.dc.html | sed 's/extends DCLogic//' > /tmp/chk_$N.js; node --check /tmp/chk_$N.js 2>&1 | head -5
for st in $6; do
 python3 - "$S/prev/$N.dc.html" "$st" "$S/prev/${N}_$st.dc.html" <<'P'
import sys,re
s=open(sys.argv[1]).read()
s=re.sub(r'("(?:state|role)":\{"editor":"enum","options":\[[^\]]*\],"default":)"[^"]*"',lambda m:m.group(1)+'"%s"'%sys.argv[2],s)
open(sys.argv[3],'w').write(s)
P
 sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/prev/${N}_$st.dc.html > $S/prev/${N}_${st}_D.dc.html
done
echo built $N
