    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var ts = self.g('ts', ST !== 'twoStepOff');
    var sched = self.g('sched', ST === 'deleteScheduled');
    var chromeOn = self.g('chrome', true), ipadOn = self.g('ipad', true);
    var exp = self.g('exp', 'idle');
    var signRows = [
      lnk('key', 'violet', 'Password', 'Last changed May 12', 'Change', 'ForgotPassword.dc.html'),
      sw('face', true, 'face', 'slate', 'Face ID', 'Sign in and unlock after 5 minutes away'),
      sw('ts', ST !== 'twoStepOff', 'shield', 'indigo', 'Two-step verification', ts ? 'A code by text to (416) 555-0142' : 'Off. A code on top of your password')
    ];
    if (ts) {
      signRows.push(seg('tsBy', 0, 'chat', 'sky', 'Send codes by', '', ['Text', 'Authenticator app']));
      signRows.push(lnk('list', 'stone', 'Backup codes', 'For when you lose your phone', '8 left', 'TwoStep.dc.html'));
    } else {
      signRows.push(lnk('shield', 'amber', 'Set up two-step', 'Takes about a minute', '', 'TwoStep.dc.html'));
    }
    var sess = [ stat(mk('phone', 'violet', 'This iPhone', 'iPhone 15 Pro · Toronto'), 'Active now', 'st-ok') ];
    if (chromeOn) sess.push(btnRow('globe', 'azure', 'Chrome on Windows', 'Toronto · 2 hours ago', 'Sign out', function () { set({ chrome: false, lastOut: 'Chrome on Windows' }); }));
    if (ipadOn) sess.push(btnRow('photo', 'teal', 'Safari on iPad', 'Mississauga · Sep 21', 'Sign out', function () { set({ ipad: false, lastOut: 'Safari on iPad' }); }));
    var others = (chromeOn ? 1 : 0) + (ipadOn ? 1 : 0);
    var lastOut = self.g('lastOut', '');
    var expRow;
    if (exp === 'idle') expRow = lnk('export', 'stone', 'Export my data', 'Quotes, clients, invoices and photos', '', '');
    else if (exp === 'prep') expRow = stat(mk('export', 'stone', 'Export my data', 'Preparing your files. We’ll email you too.'), 'Preparing', 'st-info');
    else expRow = btnRow('export', 'sage', 'Your export is ready', '214 MB · link works until Oct 6', 'Download', function () {}, 'btn-p');
    if (exp === 'idle') { expRow.isA = false; expRow.notA = true; expRow.isLink = false; expRow.isBtn = true; expRow.btn = 'Export'; expRow.act = function () { set({ exp: 'prep' }); setTimeout(function () { set({ exp: 'ready' }); }, 1800); }; }
    var typed = self.g('typed', '');
    var delOpen = self.g('delOpen', false) && !sched;
    return {
      roBanner: roBanner, sched: sched, cancelled: self.g('cancelled', false), tsOffBanner: !ts,
      warnIc: ic('warn', 'rose'), okIc: ic('check', 'sage'), shieldWarn: ic('shield', 'amber'),
      gSign: grp('Sign in', signRows, '', 60),
      gSessions: grp('Where you’re signed in', sess, lastOut ? 'Signed out of ' + lastOut + '.' : 'Don’t recognise one? Sign it out and change your password.', 120),
      signOutAll: function () { set({ chrome: false, ipad: false, lastOut: 'every other device' }); },
      onlyThis: others === 0, allStyle: others === 0 ? 'opacity: .45' : '',
      allLabel: others === 0 ? 'Only this phone is signed in' : 'Sign out everywhere else',
      gActivity: grp('Recent activity', [
        val('globe', 'azure', 'New sign-in', 'Chrome on Windows · Toronto', 'Sep 27', true),
        val('shield', 'indigo', ST === 'twoStepOff' ? 'Two-step turned off' : 'Two-step turned on', 'On this iPhone', 'Sep 2', true),
        val('key', 'violet', 'Password changed', 'On this iPhone', 'May 12', true)
      ], '', 180),
      gData: grp('Your data', [expRow], 'Keep records for 6 years for the CRA. An export is the easiest way.', 240),
      grace: [
        { ic: ic('clock', 'amber'), t: '30 days to change your mind', s: 'Sign in any time before Oct 29 to cancel. Nothing is lost.' },
        { ic: ic('lock', 'slate'), t: 'Client links stop working', s: 'Open quotes, invoices and the portal close on day 30.' },
        { ic: ic('warn', 'rose'), t: 'Then it’s erased for good', s: 'Quotes, clients, invoices, photos and crew hours.' }
      ],
      showDelBtn: !delOpen && !sched, delOpen: delOpen, typed: typed,
      openDelete: function () { set({ delOpen: true }); }, closeDelete: function () { set({ delOpen: false, typed: '' }); },
      onType: function (e) { set({ typed: e.target.value }); },
      delDisabled: typed.trim().toUpperCase() !== 'DELETE', delBtnStyle: typed.trim().toUpperCase() !== 'DELETE' ? 'opacity: .45' : '',
      confirmDelete: function () { if (self.g('typed', '').trim().toUpperCase() !== 'DELETE') return; set({ sched: true, delOpen: false, cancelled: false }); },
      cancelDelete: function () { set({ sched: false, cancelled: true }); }
    };
