    var ps = this.props.state || 'single';
    var view = self.g('view', ps);
    var declined = self.g('declined', false);
    var ans = self.g('ans', { r: '', h: '' });
    var pick = self.g('pick', 'r');
    var INV = [['r', 'Rossi Renovations', 'Contremaître', 'Marco Rossi', '27 sept.', 'building', 'violet'], ['h', 'Harbourfront Builders', 'Bureau', 'Nadia Haddad', '28 sept.', 'house', 'teal']];
    var setAns = function (k, v) { var cur = self.g('ans', { r: '', h: '' }), n = { r: cur.r, h: cur.h }; n[k] = v; set({ ans: n }); };
    var invites = INV.map(function (v) {
      var a = ans[v[0]];
      return { co: v[1], role: v[2], from: v[3], when: v[4], ic: ic(v[5], v[6]), open: !a, done: !!a,
        stCls: a === 'yes' ? 'st-ok si-check' : 'st-bad si-x', stLabel: a === 'yes' ? 'Acceptée' : 'Refusée',
        accept: function () { setAns(v[0], 'yes'); }, decline: function () { setAns(v[0], 'no'); }, undo: function () { setAns(v[0], ''); } };
    });
    var yes = INV.filter(function (v) { return ans[v[0]] === 'yes'; });
    var COS = [['r', 'Rossi Renovations', 'Toronto · 6 personnes', 'Contremaître', 'building', 'violet', 'ForemanHome.dc.html'], ['h', 'Harbourfront Builders', 'Mississauga · 14 personnes', 'Bureau', 'house', 'teal', 'SmartHome.dc.html']];
    var cur = COS.filter(function (c) { return c[0] === pick; })[0];
    var TT = {
      single: [declined ? 'Invitation refusée' : 'Invitation en attente', declined ? 'Marco ne saura pas pourquoi. Vous pourrez toujours rejoindre l’équipe avec une nouvelle invitation.' : 'Connecté en tant que luca@rossireno.ca'],
      multiple: ['Invitations en attente', 'Deux équipes vous invitent. Rejoignez-en une ou les deux.'],
      picker: ['Choisir une entreprise', 'Vous faites partie de deux équipes. Laquelle ouvrir?'],
      wrongAccount: ['Mauvais compte', 'Chaque invitation est liée à un seul courriel.'],
      expired: ['Invitation en attente', 'Connecté en tant que luca@rossireno.ca']
    }[view];
    return {
      title: TT[0], sub: TT[1],
      isSingle: view === 'single', isMulti: view === 'multiple', isPicker: view === 'picker', isWrong: view === 'wrongAccount', isExpired: view === 'expired',
      can: ['Gérer les chantiers, noter les coûts et les photos', 'Consulter les soumissions et factures, sans les modifier'],
      declined: declined, notDeclined: !declined,
      declineOne: function () { set({ declined: !self.g('declined', false) }); },
      invites: invites, singleOpen: view === 'single' && !declined, singleDeclined: view === 'single' && declined,
      multiClick: function (e) { if (yes.length === 2) { if (e && e.preventDefault) e.preventDefault(); set({ view: 'picker' }); } },
      multiGo: view === 'multiple' && yes.length > 0,
      multiHref: yes.length === 2 ? '#' : yes.length === 1 && yes[0][0] === 'h' ? 'SmartHome.dc.html' : 'ForemanHome.dc.html',
      cos: COS.map(function (c) { return { name: c[1], meta: c[2], role: c[3], ic: ic(c[4], c[5]), on: c[0] === pick, cls: c[0] === pick ? 'on' : '', tagCls: '', pick: function () { set({ pick: c[0] }); } }; }),
      pickHref: cur[6], pickLabel: 'Ouvrir ' + cur[1],
      showOwn: view === 'single' || view === 'multiple' || view === 'expired',
      coIc: ic('building', 'violet'), mailIc: ic('mail', 'amber'), linkIc: ic('clock', 'amber')
    };
