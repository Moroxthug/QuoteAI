    var f = this.g('f', 'all'), q = this.g('q', ''), sel = this.g('sel', 'Q-2026-119'), acted = this.g('acted', {});
    var S = { draft: ['Brouillon', 'st-mute si-draft'], sent: ['Envoyée', 'st-info si-q1'], viewed: ['Consultée', 'st-acc si-q2'], accepted: ['Acceptée', 'st-ok si-check'], declined: ['Refusée', 'st-bad si-x'], expired: ['Expirée', 'st-mute si-off'], expiring: ['Expire ven.', 'st-warn si-clock'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // no, client, job, total, status, group, when, address, valid, scope, lines [name, amt, detail]
    var data = [
      ['Q-2026-119', 'Dana Whitfield', 'Chambres et plafond de salle de bain', 4131.05, 'draft', 'week', 'Aujourd’hui', '17 Castle Frank Cres, Toronto', '29 oct.',
        'Murs et plafonds de 3 chambres et du corridor, deux couches. Plafond de salle de bain découpé, réparé, tiré à l’enduit et scellé contre les taches avant la peinture. Matériaux fournis.',
        [['Peinture, 3 chambres et corridor', 2352, '2,10 $/pi² · 1 120 pi² · deux couches'], ['Réparation du dégât d’eau, plafond de salle de bain', 640, 'Découpe, gypse, ruban, enduit'], ['Apprêt anti-taches', 88.80, '1,85 $/pi² · 48 pi²'], ['Peinture et fournitures', 395, 'Fournies par Rossi Renovations'], ['Protection des planchers et nettoyage', 180, 'Bâches, balayage quotidien, nettoyage final']]],
      ['Q-2026-118', 'Priya Nair', 'Dosseret de cuisine', 1865.10, 'viewed', 'week', 'Consultée il y a 2 h', '212 Dovercourt Rd, Toronto', '27 oct.',
        'Dosseret en tuiles métro derrière les comptoirs et la cuisinière, environ 32 pi². Boîtes de prises rallongées pour affleurer. Coulis scellé.',
        [['Pose des tuiles du dosseret', 1120, '32 pi² · tracé, pose, coulis'], ['Tuiles, coulis et scellant', 410.53, 'Tuile métro blanche 3×6, mate'], ['Rallonges de boîtes de prises', 120, '4 prises, par Jonah Reyes']]],
      ['Q-2026-117', 'Harbourfront Dental', 'Peinture de la réception', 6420.00, 'expiring', 'week', 'Envoyée le 24 sept.', 'Queens Quay W, Toronto', '2 oct.',
        'Murs de la réception et de la salle d’attente, deux couches coquille d’œuf. Cadres de porte et moulures en semi-lustré. Travaux après 18 h pour que le bureau reste ouvert.',
        [['Murs de la réception et de la salle d’attente', 3960, '1 800 pi² · deux couches'], ['Cadres de porte et moulures', 1121.42, '14 cadres, semi-lustré'], ['Supplément hors heures', 600, '3 soirs, après 18 h']]],
      ['Q-2026-116', 'Gill Residence', 'Remise à neuf du patio', 2980.00, 'sent', 'week', 'Envoyée lundi', 'Brampton', '28 oct.',
        'Décaper et poncer le patio et l’escalier, deux couches de teinture semi-transparente. Retouches à la rampe aux endroits usés.',
        [['Décapage et ponçage du patio', 1480, '420 pi² plus l’escalier'], ['Teinture semi-transparente, 2 couches', 957.17, 'Ton cèdre, matériaux inclus'], ['Retouches à la rampe', 200, 'Endroits usés seulement']]],
      ['Q-2026-114', 'Tom & Lena Hart', 'Ordre de changement, sous-sol', 3955.00, 'accepted', 'earlier', 'Acceptée le 19 sept.', '48 Galloway Rd, Scarborough', 'Acceptée',
        'Six encastrés dans la salle familiale, un caisson autour du nouveau conduit et la peinture des murs supplémentaires.',
        [['Encastrés, 6', 1680, 'Par Jonah Reyes, électricien certifié'], ['Charpente et gypse du caisson', 1320, '14 pi linéaires'], ['Peinture supplémentaire', 500, 'Deux couches, 2 murs']]],
      ['Q-2026-112', 'Okoye Condo', 'Plancher du corridor', 2210.00, 'accepted', 'earlier', 'Acceptée le 15 sept.', 'Okoye Condo, Liberty Village', 'Acceptée',
        'Retirer l’ancien tapis, poser du chêne d’ingénierie avec sous-couche et seuils vers la cuisine et la salle de bain.',
        [['Pose du chêne d’ingénierie', 1440, '180 pi²'], ['Sous-couche et seuils', 315.75, '2 seuils'], ['Retrait et élimination du tapis', 200, 'Corridor et entrée']]],
      ['Q-2026-110', 'Marchetti Bakery', 'Moulures de la devanture', 1480.00, 'declined', 'earlier', 'Refusée le 12 sept.', 'College St, Toronto', 'Refusée',
        'Repeindre les moulures de la devanture et les cadres de fenêtres dans le vert actuel. Calfeutrage et préparation d’abord.',
        [['Peinture des moulures de la devanture', 980, 'Deux couches, émail extérieur'], ['Calfeutrage et préparation', 329.73, 'Grattage, remplissage, apprêt sur le bois nu']]],
      ['Q-2026-108', 'Chen Family', 'Rafraîchissement de la salle de lavage', 3300.00, 'expired', 'earlier', 'Expirée le 9 sept.', 'Markham', 'Expirée le 9 sept.',
        'Peindre les murs et le plafond de la salle de lavage, refaire la finition des armoires, nouvelles poignées.',
        [['Murs et plafond', 1860, 'Deux couches, lavable'], ['Finition des armoires', 860.35, '8 portes, 3 tiroirs'], ['Matériaux', 200, 'Peinture, apprêt, quincaillerie']]],
      ['Q-2026-107', 'Tom & Lena Hart', 'Finition du sous-sol', 38400.00, 'accepted', 'earlier', 'Acceptée le 28 août', '48 Galloway Rd, Scarborough', 'Acceptée',
        'Finition du sous-sol : charpente, isolation, gypse, électricité, plancher et peinture. Permis obtenu par Rossi Renovations.',
        [['Charpente et isolation', 9800, 'Murs extérieurs R-24, nouvelles cloisons'], ['Gypse et finition', 8600, '1 850 pi², niveau 4'], ['Électricité', 6200, 'Par Jonah Reyes'], ['Plancher', 5400, 'Planche de vinyle, 820 pi²'], ['Peinture', 2600, 'Deux couches partout'], ['Permis et élimination', 1382.30, 'Permis de construction, conteneurs']]]
    ];
    var FIL = [['all', 'Toutes', function () { return true; }], ['draft', 'Brouillons', function (s) { return s === 'draft'; }], ['waiting', 'En attente', function (s) { return s === 'sent' || s === 'viewed' || s === 'expiring'; }], ['accepted', 'Acceptées', function (s) { return s === 'accepted'; }], ['closed', 'Fermées', function (s) { return s === 'declined' || s === 'expired'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var ini = function (n) { return n.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[0]).toLowerCase().indexOf(ql) >= 0); });
    var stOf = function (d) { var a = acted[d[0]]; return a ? a : S[d[4]]; };
    var groups = [['week', 'Cette semaine'], ['earlier', 'Plus tôt']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      return { title: g[1], total: rs.length ? money(rs.reduce(function (a, d) { return a + d[3]; }, 0)) : '', has: rs.length > 0,
        rows: rs.map(function (d) { var on = d[0] === sel, s = stOf(d); return { client: d[1], job: d[6] + ' · ' + d[2], amt: money(d[3]), status: s[0], st: s[1], ini: ini(d[1]), tn: tints[data.indexOf(d) % 5], on: on, cls: on ? 'on' : '', pick: function () { set({ sel: d[0] }); } }; }) };
    }).filter(function (g) { return g.has; });
    var D = data.filter(function (d) { return d[0] === sel; })[0] || data[0];
    var sub = D[10].reduce(function (a, l) { return a + l[1]; }, 0), hst = Math.round(D[3] * 100 - sub * 100) / 100;
    var tw = money(D[3]).split(',');
    var s = stOf(D);
    var PR = { draft: ['Envoyer la soumission', 'Aperçu', 'Envoyée', 'st-info si-q1'], sent: ['Relancer', 'Marquer gagnée', 'Relancée', 'st-info' + ' si-q1'], accepted: ['Ouvrir le chantier', 'Facturer le dépôt', '', ''], declined: ['Réactiver', 'Archiver', 'Brouillon', 'st-mute si-draft'] };
    PR.viewed = PR.sent; PR.expiring = PR.sent; PR.expired = PR.declined;
    var pr = PR[D[4]];
    var ACT = {
      draft: [['Créée par la voix', 'Aujourd’hui', 'L’assistant a rédigé 5 lignes à partir de vos notes'], ['Visite du chantier', '26 sept.', 'Photos et mesures enregistrées']],
      viewed: [['Consultée par ' + D[1].split(' ')[0], 'il y a 2 h', 'Lien ouvert sur un téléphone, 3 minutes'], ['Envoyée', '27 sept.', 'Courriel et texto'], ['Créée', '26 sept.', 'À partir d’une visite du chantier']],
      sent: [['Envoyée', 'lun.', 'Courriel au client'], ['Créée', '25 sept.', 'À partir de la liste de prix']],
      expiring: [['Relance envoyée', '27 sept.', 'Relance 1, par courriel'], ['Consultée', '25 sept.', 'Gestionnaire du bureau, sur ordinateur'], ['Envoyée', '24 sept.', 'Courriel et PDF']],
      accepted: [['Acceptée et signée', D[6].split(' le ')[1], 'Signée en ligne · dépôt demandé'], ['Consultée', 'Avant', 'Lien ouvert deux fois'], ['Envoyée', 'Avant', 'Courriel et texto']],
      declined: [['Refusée', D[6].split(' le ')[1], '« On choisit une option moins chère cette année »'], ['Consultée', 'Avant', 'Ouverte une fois']],
      expired: [['Expirée', D[6].split(' le ')[1], 'Aucune réponse après 3 relances'], ['Envoyée', '10 août', 'Courriel et PDF']]
    };
    var act = (acted[D[0]] ? [[pr[2], 'À l’instant', 'Depuis la tablette']] : []).concat(ACT[D[4]]);
    var RAIL = [['Accueil', 'house', 'amber', 'SmartHome.dc.html'], ['Soumissions', 'doc', 'violet', 'Quotes.dc.html'], ['Travaux', 'cone', 'amber', 'Jobs.dc.html'], ['Clients', 'users', 'sage', 'Clients.dc.html'], ['Factures', 'receipt', 'rose', 'Invoices.dc.html'], ['Horaire', 'cal', 'azure', 'Schedule.dc.html']];
    return {
      rail: RAIL.map(function (r) { var on = r[3] === 'Quotes.dc.html'; return { label: r[0], ic: ic(r[1], r[2]), href: r[3], cls: on ? 'on' : '', cur: on ? 'page' : 'false' }; }),
      menuIc: ic('list', 'slate'), emptyIc: ic('search', 'slate'),
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'En attente', value: '15 396 $', sub: '4 soumissions', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Gagné ce mois‑ci', value: '6 165 $', sub: '2 acceptées', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Taux de réussite', value: '62 %', sub: '↑ 4 points', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0,
      d: {
        no: D[0], client: D[1], job: D[2], addr: D[7], ini: ini(D[1]), tn: tints[data.indexOf(D) % 5], status: s[0], st: s[1],
        statusLine: D[4] === 'draft' ? 'Pas encore envoyée · valide jusqu’au ' + D[8] : D[6], valid: ['draft', 'sent', 'viewed', 'expiring'].indexOf(D[4]) >= 0 ? D[8] : D[6].split(' le ')[1], validLabel: ['draft', 'sent', 'viewed', 'expiring'].indexOf(D[4]) >= 0 ? 'Valide jusqu’au' : D[6].split(' le ')[0], scope: D[9],
        lineCount: D[10].length + ' lignes',
        lines: D[10].map(function (l, i) { return { name: l[0], amt: money(l[1]), detail: l[2], sep: i ? 'border-top: 1px solid var(--line)' : '' }; }),
        sub: money(sub), hst: money(hst), total: money(D[3]), totWhole: tw[0], totCents: ',' + tw[1], deposit: money(Math.round(D[3] * 30) / 100),
        activity: act.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], dot: i === 0 ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === act.length - 1 ? 'display: none' : '' }; }),
        primary: acted[D[0]] ? pr[2] : pr[0], secondary: pr[1], href: D[4] === 'accepted' ? 'Job.dc.html' : '#',
        act: function () { if (D[4] === 'accepted') return; var n = Object.assign({}, self.g('acted', {})); n[D[0]] = [pr[2], pr[3]]; set({ acted: n }); }
      }
    };
