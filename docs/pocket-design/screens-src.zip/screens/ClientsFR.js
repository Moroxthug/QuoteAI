    var f = this.g('f', 'all'), q = this.g('q', '');
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // nom, coordonnées, soumissions, valeur totale, statut, dernière activité, teinte
    var data = [
      ['Tom & Lena Hart', '416 555-0148 · Scarborough', 3, 42355, 'active', 'Rappel de facture aujourd’hui', 2],
      ['Dana Whitfield', 'dana.w@rogers.com · Rosedale', 1, 0, 'prospect', 'Soumission rédigée aujourd’hui', 0],
      ['Priya Nair', '647 555-0121 · Dovercourt', 2, 6240, 'active', 'A consulté une soumission il y a 2 h', 1],
      ['Harbourfront Dental', 'office@hfdental.ca · Queens Quay W', 4, 14860, 'active', 'Soumission envoyée le 24 sept.', 3],
      ['Gill Residence', '905 555-0187 · Mississauga', 1, 0, 'prospect', 'Soumission envoyée lundi', 4],
      ['Okoye Condo', '416 555-0133 · Liberty Village', 1, 2210, 'active', 'Chantier confirmé le 15 sept.', 0],
      ['Marchetti Bakery', 'hello@marchetti.ca · Roncesvalles', 1, 0, 'prospect', 'A refusé une soumission le 12 sept.', 1],
      ['Chen Family', '416 555-0164 · North York', 3, 9850, 'active', 'Soumission expirée le 9 sept.', 2]
    ];
    var FIL = [['all', 'Tous'], ['active', 'Actifs'], ['prospect', 'Prospects']];
    var money = function (n) { return n.toLocaleString('fr-CA').replace(/\s/g, ' ') + ' $'; };
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Relancer': 'Relancé', 'Envoyer': 'Envoyée', 'Vérifier': 'Vérifié', 'Renvoyer': 'Renvoyée', 'Rappeler': 'Rappel prévu', 'Appeler': 'En appel', 'Texto': 'Envoyé', 'Courriel': 'Envoyé' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Fait') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var btnOf = function (key, label) { var k = key + ':' + label, d2 = !!xd[k]; return { label: d2 ? DONE[label] : label, cls: d2 ? 'done' : '', act: flip(k) }; };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    // légende, lignes [titre, contexte, statut, classe du statut, action, montant], statistiques [libellé, valeur, dû ?]
    var DET = {
      'Tom & Lena Hart': { cap: '416 555-0148 · lena.hart@gmail.com · 48 Galloway Rd', rows: [['Finition du sous-sol', 'Chantier · 64 % terminé · étape du gypse', 'Actif', 'st-ok si-live', '', '42 355 $'], ['INV-0412 · Étape du gypse', 'Échéance le 20 sept. · 9 jours de retard', 'En retard', 'st-bad si-alert', 'Relancer', '2 340,00 $'], ['Q-2026-114 · Ordre de changement', 'Acceptée le 19 sept.', 'Acceptée', 'st-ok si-check', '', '3 955,00 $'], ['Dernier contact', 'Rappel de facture envoyé aujourd’hui, 8 h'], ['Notes', 'Passer par la porte de côté. Lena préfère les textos après 17 h.']], stats: [['Valeur totale', '42 355 $'], ['À recevoir', '2 340 $', 1], ['Soumissions', '3']] },
      'Dana Whitfield': { cap: '416 555-0172 · dana.w@rogers.com · 17 Castle Frank Cres', rows: [['Q-2026-119 · Chambres et plafond de salle de bain', 'Rédigée aujourd’hui après la visite', 'Brouillon', 'st-mute si-draft', 'Envoyer', '4 131,05 $'], ['Provenance', 'Recommandée par Priya Nair · 27 sept.'], ['Dernier contact', 'Visite le 28 sept. · 3 pièces mesurées'], ['Notes', 'Veut que ce soit terminé avant la visite de la famille en novembre.']], stats: [['Valeur totale', '0 $'], ['À recevoir', '0 $'], ['Soumissions', '1']] },
      'Priya Nair': { cap: '647 555-0121 · priya.nair@gmail.com · 212 Dovercourt Rd', rows: [['Q-2026-118 · Dosseret de cuisine', 'Consultée il y a 2 h · pas encore signée', 'Consultée', 'st-acc si-q2', 'Relancer', '1 865,10 $'], ['Salle d’eau', 'Chantier · terminé le 11 sept.', 'Terminé', 'st-mute si-check', '', '3 120 $'], ['Dernier contact', 'Soumission du dosseret envoyée le 28 sept.'], ['Notes', 'Travaille de la maison. Pas de bruit le matin.']], stats: [['Valeur totale', '6 240 $'], ['À recevoir', '0 $'], ['Soumissions', '2']] },
      'Harbourfront Dental': { cap: '416 555-0190 · office@hfdental.ca · Queens Quay W', rows: [['Rafraîchissement du corridor de la clinique', 'Chantier · 35 % terminé · préparation et apprêt', 'Actif', 'st-ok si-live', '', '12 850 $'], ['INV-0419 · Finale', 'Échéance le 26 sept. · 3 jours de retard', 'En retard', 'st-bad si-alert', 'Relancer', '780,00 $'], ['Q-2026-117 · Peinture de la réception', 'Envoyée le 24 sept. · expire ven.', 'Expire bientôt', 'st-warn si-clock', 'Appeler', '6 420,00 $'], ['Dernier contact', 'Soumission envoyée le 24 sept. à la gestionnaire du bureau'], ['Notes', 'Travaux après 18 h ou la fin de semaine seulement.']], stats: [['Valeur totale', '14 860 $'], ['À recevoir', '780 $', 1], ['Soumissions', '4']] },
      'Gill Residence': { cap: '905 555-0187 · gill.family@outlook.com · Mississauga', rows: [['Q-2026-116 · Remise à neuf du patio', 'Envoyée lundi · pas encore ouverte', 'Envoyée', 'st-info si-q1', 'Relancer', '2 980,00 $'], ['Dernier contact', 'Soumission envoyée lundi par courriel'], ['Notes', 'Veut commencer une fin de semaine. Code de la barrière sur le côté.']], stats: [['Valeur totale', '0 $'], ['À recevoir', '0 $'], ['Soumissions', '1']] },
      'Okoye Condo': { cap: '416 555-0133 · n.okoye@gmail.com · Liberty Village', rows: [['Plancher du corridor', 'Chantier · plan IA tiré de Q-2026-112', 'À valider', 'st-acc si-q2', 'Vérifier', '2 210 $'], ['Dernier contact', 'Chantier confirmé le 15 sept.'], ['Notes', 'Le syndicat de copropriété exige un certificat d’assurance avant le début des travaux.']], stats: [['Valeur totale', '2 210 $'], ['À recevoir', '0 $'], ['Soumissions', '1']] },
      'Marchetti Bakery': { cap: '416 555-0156 · hello@marchetti.ca · Roncesvalles', rows: [['Q-2026-110 · Moulures de la devanture', 'Refusée le 12 sept. · trop cher pour cette saison', 'Refusée', 'st-bad si-x', '', '1 480,00 $'], ['Réessayer au printemps', 'Un rappel en mars', '', '', 'Rappeler'], ['Dernier contact', 'Appel avec Gina Marchetti, 12 sept.'], ['Notes', 'Fermé le lundi. Se stationner dans la ruelle arrière.']], stats: [['Valeur totale', '0 $'], ['À recevoir', '0 $'], ['Soumissions', '1']] },
      'Chen Family': { cap: '416 555-0164 · chen.home@gmail.com · North York', rows: [['Q-2026-108 · Rafraîchissement de la salle de lavage', 'Expirée le 9 sept. · aucune réponse', 'Expirée', 'st-mute si-off', 'Renvoyer', '3 300,00 $'], ['Reconstruction de la galerie avant', 'Chantier · terminé le 21 août · 5 étoiles sur Google', 'Terminé', 'st-mute si-check'], ['Dernier contact', 'Relance de la soumission le 2 sept.'], ['Notes', 'Commencer après 9 h en semaine.']], stats: [['Valeur totale', '9 850 $'], ['À recevoir', '0 $'], ['Soumissions', '3']] }
    };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return (f === 'all' || d[4] === f) && (!ql || (d[0] + ' ' + d[1]).toLowerCase().indexOf(ql) >= 0); }).map(function (d) {
      var ini = d[0].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var act = d[4] === 'active';
      return {
        name: d[0], contact: d[1], meta: d[2] + (d[2] === 1 ? ' soumission' : ' soumissions') + ' · ' + d[5],
        value: d[3] ? money(d[3]) : 'Aucun chantier', valStyle: d[3] ? 'font-size: 14.5px; font-weight: 600' : 'font-size: 12.5px; font-weight: 500; color: var(--faint)',
        status: act ? 'Actif' : 'Prospect', st: act ? 'st-ok' : 'st-info', ini: ini, tn: tints[d[6]],
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { return { cap: x.cap, rows: rowsOf(d[0], x.rows), stats: x.stats.map(function (q) { return { l: q[0], v: q[1], style: q[2] ? 'color: var(--bad)' : '' }; }), call: btnOf(d[0], 'Appeler'), text: btnOf(d[0], 'Texto'), mail: btnOf(d[0], 'Courriel') }; })(DET[d[0]])
      };
    });
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Actifs', value: '5', sub: '2 chantiers en cours', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Valeur totale', value: '75 515 $', sub: '↑ 18 % cette année', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'À recevoir', value: '3 120 $', sub: '2 en retard', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[0] === 'all' || d[4] === x[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'),
        owed: rowsOf('kpi', [['Tom & Lena Hart', 'INV-0412 · 9 jours de retard', 'En retard', 'st-bad si-alert', 'Relancer', '2 340,00 $'], ['Harbourfront Dental', 'INV-0419 · 3 jours de retard', 'En retard', 'st-bad si-alert', 'Relancer', '780,00 $']]),
        top: rowsOf('kpt', [['Tom & Lena Hart', 'Finition du sous-sol · 3 soumissions', '', '', '', '42 355 $'], ['Harbourfront Dental', '4 soumissions · corridor de la clinique', '', '', '', '14 860 $'], ['Chen Family', '3 soumissions · galerie avant', '', '', '', '9 850 $']]) },
      openCls: rows.some(function (r) { return r.open; }) ? 'has-open' : '',
      rows: rows, has: rows.length > 0, countLabel: rows.length + (rows.length === 1 ? ' client' : ' clients'),
      empty: rows.length === 0, emptyIc: ic('users', 'slate')
    };
