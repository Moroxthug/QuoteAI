    var lang = this.props.lang || 'en', fr = lang === 'fr';
    var rating = this.g('rating', 0);
    var money = function (n) {
      var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
      return fr ? s + ' $' : '$' + s;
    };
    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var EN = {
      back: 'Back to inbox', inbox: 'Inbox', archive: 'Archive',
      subject: 'Your quote from Rossi Renovations', sender: 'Marco at Rossi Renovations', toMe: 'to me',
      hi: 'Hi Dana,',
      body: 'Here’s the quote for the bedrooms and bath ceiling. There are three options inside, so pick the one that suits you and accept it online. The PDF is attached too.',
      quote: 'Quote', job: 'Bedrooms and bath ceiling', totalWith: 'Total with HST, Better option',
      options: 'Options', optionsV: 'Good, Better, Best', deposit: '30% deposit to book', valid: 'Valid until', validV: 'Oct 29',
      view: 'View your quote', dl: 'Download PDF',
      sign1: 'We can start Tuesday Oct 13. Any questions, just reply or call me.', owner: 'Owner',
      why: 'You got this because you asked for a quote.', unsub: 'Stop follow-ups', sentWith: 'Sent with quoteAI',
      remSubject: 'A quick reminder about invoice INV-0412', toHart: 'to Tom & Lena', remDate: 'Sep 29',
      remHi: 'Hi Tom and Lena,',
      remBody: 'Just a friendly note that progress bill 3 of 5 for the basement was due on Sep 20. If it’s already on its way, thank you, and please ignore this.',
      progress: 'Progress 3 of 5', overdue: 'Overdue', balance: 'Balance due', due: 'Due date', dueV: 'Sep 20', paidSoFar: 'Paid so far',
      pay: 'Pay', orEt: 'Or send an Interac e-Transfer to', ref: 'reference',
      remSign: 'Drywall is going up this week. Thanks for being great to work with. Marco',
      remWhy: 'Invoices and receipts always reach you while your job is open.',
      revSubject: 'How did we do, Chen family?', toChen: 'to Wei Chen', revDate: 'Sep 26',
      revHi: 'Hi Wei,',
      revBody: 'Thanks for having us for the kitchen repaint. If you’re happy with the work, a short review helps a small crew like ours more than anything.',
      rate: 'How was your experience?', tapStar: 'Tap a star', google: 'Leave a Google review', homestars: 'Review us on HomeStars',
      tellMarco: 'Tell Marco what went wrong', private: 'This goes straight to Marco, not a public site.',
      revSign: 'Thanks again, and enjoy the new kitchen. Marco and the crew',
      revWhy: 'One review request per job.',
      stars: ['1 star', '2 stars', '3 stars', '4 stars', '5 stars'], notes: ['', 'Sorry to hear that', 'Sorry to hear that', 'Thanks, we can do better', 'Glad you liked it', 'That made our day']
    };
    var FR = {
      back: 'Retour à la boîte de réception', inbox: 'Réception', archive: 'Archiver',
      subject: 'Votre soumission de Rossi Renovations', sender: 'Marco de Rossi Renovations', toMe: 'à moi',
      hi: 'Bonjour Dana,',
      body: 'Voici la soumission pour les chambres et le plafond de la salle de bain. Elle comprend trois options : choisissez celle qui vous convient et acceptez-la en ligne. Le PDF est aussi joint.',
      quote: 'Soumission', job: 'Chambres et plafond de salle de bain', totalWith: 'Total avec TVH, option Mieux',
      options: 'Options', optionsV: 'Bon, Mieux, Optimal', deposit: 'Dépôt de 30 % pour réserver', valid: 'Valide jusqu’au', validV: '29 oct.',
      view: 'Voir votre soumission', dl: 'Télécharger le PDF',
      sign1: 'Nous pouvons commencer le mardi 13 octobre. Des questions? Répondez ou appelez-moi.', owner: 'Propriétaire',
      why: 'Vous recevez ce courriel parce que vous avez demandé une soumission.', unsub: 'Arrêter les relances', sentWith: 'Envoyé avec quoteAI',
      remSubject: 'Petit rappel pour la facture INV-0412', toHart: 'à Tom et Lena', remDate: '29 sept.',
      remHi: 'Bonjour Tom et Lena,',
      remBody: 'Un petit mot amical : la facture d’étape 3 de 5 pour le sous-sol était due le 20 septembre. Si le paiement est déjà en route, merci et ne tenez pas compte de ce message.',
      progress: 'Étape 3 de 5', overdue: 'En retard', balance: 'Solde dû', due: 'Échéance', dueV: '20 sept.', paidSoFar: 'Payé à ce jour',
      pay: 'Payer', orEt: 'Ou envoyez un virement Interac à', ref: 'référence',
      remSign: 'Les cloisons sèches montent cette semaine. Merci de votre confiance. Marco',
      remWhy: 'Les factures et reçus vous parviennent toujours tant que les travaux sont en cours.',
      revSubject: 'Comment avons-nous fait, famille Chen?', toChen: 'à Wei Chen', revDate: '26 sept.',
      revHi: 'Bonjour Wei,',
      revBody: 'Merci de nous avoir confié la peinture de la cuisine. Si vous êtes satisfait, un court avis aide une petite équipe comme la nôtre plus que tout.',
      rate: 'Comment s’est passée votre expérience?', tapStar: 'Touchez une étoile', google: 'Laisser un avis Google', homestars: 'Nous évaluer sur HomeStars',
      tellMarco: 'Dire à Marco ce qui n’a pas marché', private: 'Ceci va directement à Marco, pas sur un site public.',
      revSign: 'Merci encore, et profitez de la nouvelle cuisine. Marco et l’équipe',
      revWhy: 'Une seule demande d’avis par projet.',
      stars: ['1 étoile', '2 étoiles', '3 étoiles', '4 étoiles', '5 étoiles'], notes: ['', 'Désolé de l’apprendre', 'Désolé de l’apprendre', 'Merci, on peut faire mieux', 'Content que ça vous plaise', 'Vous faites notre journée']
    };
    var t = fr ? FR : EN;
    var total = 4131.05, bal = 2340, paid = 3310;
    var totalStr = money(total), balStr = money(bal);
    return {
      t: t,
      totalWhole: fr ? totalStr : totalStr.slice(0, -3), totalCents: fr ? '' : totalStr.slice(-3),
      balWhole: fr ? balStr : balStr.slice(0, -3), balCents: fr ? '' : balStr.slice(-3),
      deposit: money(r2(total * 0.3)), paid: money(paid),
      payLabel: t.pay + ' ' + balStr,
      pdfIc: ic('file', 'clay'),
      stars: [1, 2, 3, 4, 5].map(function (n) {
        var on = rating >= n;
        return { on: rating === n, cls: rating && !on ? 'off' : (on ? 'on' : ''), label: t.stars[n - 1], ic: ic('star', 'gold'), pick: function () { set({ rating: n }); } };
      }),
      rateNote: rating ? t.notes[rating] : t.tapStar,
      happy: rating === 0 || rating >= 4, unhappy: rating > 0 && rating < 4
    };
