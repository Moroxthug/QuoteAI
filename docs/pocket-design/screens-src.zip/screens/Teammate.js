    var st = this.props.state || 'default';
    var ro = st === 'readonly';
    var role = this.g('role', 'crew'), link = this.g('link', st === 'nolink' ? 'off' : 'on'), copied = this.g('copied', false), resent = this.g('resent', false);
    var inactive = this.g('inactive', st === 'deactivated'), sheet = this.g('sheet', false), renew = this.g('renew', false);
    var perms = this.g('perms', { pay: false, margins: false, approve: false, tasks: true });
    var fore = role === 'foreman';
    var sw = function (on) { return { track: on ? 'background: var(--acc)' : 'background: var(--track-off)', knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var linkOn = link === 'on' && !inactive;
    var P = [
      ['tasks', 'Add tasks from site', 'Crew and foremen can add to the job list', 'list', 'violet', false],
      ['pay', 'See her own pay', 'Rate and hours on her link', 'card', 'sage', false],
      ['margins', 'See job margins', 'Costs and profit on her jobs', 'percent', 'amber', !fore],
      ['approve', 'Approve crew time', fore ? 'Hours from her crew on her jobs' : 'Foremen only', 'check', 'teal', !fore]
    ];
    var lock = ro || inactive;
    return {
      readonly: ro, inactive: inactive, roLock: lock, linkOff: !linkOn,
      eyeIc: ic('eye', 'azure'), pauseIc: ic('lock', 'amber'), linkIc: ic('link', 'azure'), clockIc: ic('clock', 'amber'),
      roleName: fore ? 'Foreman' : 'Crew', roleTagCls: fore ? 'tag-acc' : '',
      roleHint: fore ? 'Promoted today' : 'Since Mar 2024',
      linkWord: inactive ? 'Link off' : linkOn ? 'Link active' : 'No link', linkSt: inactive || !linkOn ? 'st-mute si-off' : 'st-ok si-live',
      linkTitle: linkOn ? 'quoteai.ca/t/amara-7K2' : 'No personal link',
      linkSub: linkOn ? (resent ? 'Sent again by text just now' : 'Opened today at 7:15 am') : 'She can’t clock in until you send one',
      quick: [
        { label: 'Call', ic: ic('phone', 'sage'), href: '#' },
        { label: 'Message', ic: ic('chat', 'violet'), href: '#' },
        { label: 'Timesheet', ic: ic('clock', 'teal'), href: 'CrewHours.dc.html' }
      ],
      roles: [['crew', 'Crew', 'Clocks in, sees her tasks, sends photos'], ['foreman', 'Foreman', 'Runs a job on site, approves crew time']].map(function (r) {
        var on = r[0] === role;
        return { label: r[1], sub: r[2], on: on, cls: on ? 'on' : '', dis: lock, pick: function () { var n = Object.assign({}, perms); if (r[0] === 'foreman') n.approve = true; else { n.approve = false; n.margins = false; } set({ role: r[0], perms: n }); } };
      }),
      jobs: [
        { name: 'Basement finish', sub: 'Tom & Lena Hart · drywall', hours: '46.0 h', status: 'On site', st: 'st-ok si-live', ic: ic('house', 'violet'), href: 'Job.dc.html' },
        { name: 'Hallway flooring', sub: 'Okoye Condo · patch and prep', hours: '28.5 h', status: 'In progress', st: 'st-ok si-live', ic: ic('bricks', 'amber'), href: 'Job.dc.html' },
        { name: 'Reception repaint', sub: 'Harbourfront Dental · Oct 13', hours: '8.0 h', status: 'Scheduled', st: 'st-info si-q1', ic: ic('brush', 'teal'), href: 'Job.dc.html' }
      ],
      certs: [
        { name: 'Working at Heights', sub: 'IHSA · card WAH-448120', status: renew ? 'Renewal asked' : 'Expires Nov 12', st: renew ? 'st-info si-q1' : 'st-warn si-clock', ic: ic('shield', 'amber') },
        { name: 'WHMIS', sub: 'Valid to Mar 4, 2027', status: 'Valid', st: 'st-ok si-check', ic: ic('shield', 'teal') }
      ],
      renewLabel: renew ? 'Asked' : 'Ask to renew', askRenew: function () { if (!lock) set({ renew: true }); },
      copyLabel: copied ? 'Copied' : 'Copy', copy: function () { set({ copied: true }); },
      resendLabel: linkOn ? (resent ? 'Sent' : 'Resend') : 'Send link', resend: function () { set({ link: 'on', resent: true }); },
      revokeLabel: 'Revoke', revoke: function () { set({ link: 'off', resent: false, copied: false }); },
      perms: P.map(function (p) {
        var on = !!perms[p[0]], s = sw(on && !p[5]);
        return { label: p[1], sub: p[2], ic: ic(p[3], p[4]), on: on && !p[5], dis: p[5] || lock, track: s.track, knob: s.knob, flip: function () { var n = Object.assign({}, perms); n[p[0]] = !on; set({ perms: n }); } };
      }),
      canDeactivate: !inactive && !ro,
      sheet: sheet, askDeact: function () { set({ sheet: true }); }, closeAll: function () { set({ sheet: false }); },
      deactivate: function () { set({ sheet: false, inactive: true }); },
      reactivate: function () { set({ inactive: false }); }
    };
