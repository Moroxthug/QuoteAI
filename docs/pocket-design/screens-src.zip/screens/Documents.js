    var st = this.props.state || 'default', empty = st === 'empty';
    var upOpen = this.g('up', false), pb = this.g('pb', ''), job = this.g('job', 'hart'), uploads = this.g('uploads', 0);
    var line = function (vals, w, h, pad) {
      var mn = Math.min.apply(null, vals), mx = Math.max.apply(null, vals), rg = mx - mn || 1;
      return vals.map(function (v, i) { return [(pad + i * (w - 2 * pad) / (vals.length - 1)).toFixed(1), (h - pad - (v - mn) / rg * (h - 2 * pad)).toFixed(1)]; });
    };
    var big = line([18.40, 18.40, 18.75, 18.90, 19.40, 19.95], 320, 64, 4);
    var bigLine = big.map(function (p) { return p.join(','); }).join(' ');
    var M = [
      ['Joint compound, 17 L', 'Gypsum Supply · 4 invoices', [23.10, 23.40, 23.40, 24.10, 24.60], '$24.60', '+6.5%', 'up'],
      ['Regal paint, 3.79 L', 'Benjamin Moore · 6 receipts', [78.99, 78.99, 78.99, 78.99, 78.99], '$78.99', 'Same', 'flat'],
      ['SPF stud 2×4×8', 'Home Depot Pro · 5 invoices', [5.95, 5.80, 5.65, 5.60, 5.48], '$5.48', '−3.0%', 'down'],
      ['Insulation R14, bag', 'Kent · 2 invoices', [71.50, 73.20], '$73.20', '+2.4%', 'up']
    ];
    var col = { up: 'color: var(--warn)', flat: 'color: var(--muted)', down: 'color: var(--ok)' };
    var docs = [];
    for (var i = 0; i < uploads; i++) docs.push({ name: 'Photo just now', sub: 'Filed under ' + (job === 'hart' ? 'Basement finish' : job === 'hd' ? 'Reception repaint' : 'Company'), status: 'Reading', st: 'st-info si-live', ic: ic('camera', 'violet') });
    docs = docs.concat([
      { name: 'Home Depot Pro · 88213', sub: 'Sep 26 · 14 prices · Basement finish', status: 'Read', st: 'st-ok si-check', ic: ic('receipt', 'amber') },
      { name: 'Gypsum Supply · INV-40771', sub: 'Sep 24 · 6 prices read · 2 changed', status: 'Read', st: 'st-ok si-check', ic: ic('receipt', 'stone') },
      { name: 'Benjamin Moore Leaside', sub: 'Sep 22 · 2 lines we couldn’t read', status: 'Check', st: 'st-warn si-clock', ic: ic('receipt', 'sky') },
      { name: 'Old quote, Chen laundry.pdf', sub: 'Sep 18 · 11 prices added to the book', status: 'Read', st: 'st-ok si-check', ic: ic('doc', 'violet') }
    ]);
    return {
      isEmpty: empty, hasDocs: !empty, upCls: 'st-warn si-alert',
      docIc: ic('doc', 'violet'), trendIc: ic('bars', 'amber'), almostIc: ic('box', 'teal'), okIc: ic('check', 'sage'),
      bigLine: bigLine, bigArea: '4,64 ' + bigLine + ' 316,64', bigLastY: big[big.length - 1][1],
      suppliers: [
        { name: 'Home Depot Pro', when: 'Sep 26', price: '$19.95', style: '' },
        { name: 'Gypsum Supply Toronto', when: 'Sep 24', price: '$19.10', style: 'color: var(--ok)' },
        { name: 'RONA+ Scarborough', when: 'Sep 9', price: '$20.40', style: '' }
      ],
      pbPending: !pb, pbDone: !!pb, pbMsg: pb === 'up' ? 'Price book updated to $19.95' : 'Kept $18.40 · we’ll remind you next month',
      updatePb: function () { set({ pb: 'up' }); }, keepPb: function () { set({ pb: 'keep' }); },
      mats: M.map(function (m) { return { name: m[0], sub: m[1], price: m[3], chg: m[4], color: col[m[5]], pts: line(m[2], 58, 26, 3).map(function (p) { return p.join(','); }).join(' ') }; }),
      readCount: (14 + uploads) + ' this month',
      docs: docs,
      folders: [
        { name: 'Basement finish', sub: 'Tom & Lena Hart · 18', ic: ic('house', 'violet'), href: 'Job.dc.html' },
        { name: 'Hallway flooring', sub: 'Okoye Condo · 9', ic: ic('bricks', 'amber'), href: 'Job.dc.html' },
        { name: 'Reception repaint', sub: 'Harbourfront Dental · 6', ic: ic('brush', 'teal'), href: 'Job.dc.html' },
        { name: 'Company', sub: 'WSIB, insurance · 24', ic: ic('building', 'slate'), href: '#' }
      ],
      upOpen: upOpen, openUp: function () { set({ up: true }); }, closeUp: function () { set({ up: false }); },
      upOpts: [
        ['Take a photo', 'Invoice or receipt on paper', 'camera', 'violet'],
        ['Choose a file', 'PDF, photo or spreadsheet', 'file', 'azure'],
        ['Forward by email', 'docs@rossireno.quoteai.ca', 'mail', 'sky']
      ].map(function (o) { return { label: o[0], sub: o[1], ic: ic(o[2], o[3]), go: function () { set({ up: false, uploads: uploads + 1 }); } }; }),
      jobChips: [['hart', 'Basement finish'], ['hd', 'Reception repaint'], ['co', 'Company']].map(function (c) { var on = c[0] === job; return { label: c[1], on: on, cls: on ? 'on' : '', pick: function () { set({ job: c[0] }); } }; })
    };
