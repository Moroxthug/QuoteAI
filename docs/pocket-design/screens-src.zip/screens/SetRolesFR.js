    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly' || ST === 'locked';
    var ROLES = [
      { k: 'owner', name: 'Propriétaire', ic: ['star', 'gold'], people: [['MR', 'tn5', 'Marco Rossi']], access: 'Propriétaire', accessSub: 'Tout, y compris forfait et sécurité', secs: ['À traiter', 'Argent', 'Soumissions', 'Équipe'], tabs: ['Accueil', 'Soumissions', 'Travaux', 'Clients'], sens: [1, 1, 1, 1] },
      { k: 'officeManager', name: 'Gestionnaire de bureau', ic: ['building', 'azure'], people: [['CM', 'tn4', 'Carla Mendes']], access: 'Bureau', accessSub: 'Soumissions, chantiers, coûts et facturation', secs: ['À traiter', 'Argent', 'Aujourd’hui', 'Cette semaine'], tabs: ['Accueil', 'Soumissions', 'Factures', 'Clients'], sens: [0, 1, 1, 1] },
      { k: 'estimator', name: 'Estimateur', ic: ['ruler', 'violet'], people: [['BW', 'tn2', 'Ben Walsh']], access: 'Bureau', accessSub: 'Soumissions, chantiers, coûts et facturation', secs: ['Soumissions à faire', 'Visites de chantier', 'Taux de réussite', 'En attente des clients'], tabs: ['Accueil', 'Soumissions', 'Demandes', 'Clients'], sens: [0, 1, 0, 0] },
      { k: 'projectManager', name: 'Chargé de projet', ic: ['list', 'teal'], people: [['HK', 'tn1', 'Hannah Kim']], access: 'Bureau', accessSub: 'Soumissions, chantiers, coûts et facturation', secs: ['À risque', 'Chantiers actifs', 'Budget vs réel', 'Ordres de changement'], tabs: ['Accueil', 'Travaux', 'Horaire', 'Clients'], sens: [0, 1, 1, 0] },
      { k: 'dispatcher', name: 'Répartiteur', ic: ['truck', 'amber'], people: [['OH', 'tn3', 'Omar Haddad']], access: 'Bureau', accessSub: 'Soumissions, chantiers, coûts et facturation', secs: ['Équipe en ce moment', 'Non assignés', 'Demain', 'Cette semaine'], tabs: ['Accueil', 'Horaire', 'Travaux', 'Carte'], sens: [0, 0, 1, 0] },
      { k: 'bookkeeper', name: 'Commis comptable', ic: ['bank', 'sage'], people: [['RL', 'tn1', 'Rosa Lima']], access: 'Bureau', accessSub: 'Soumissions, chantiers, coûts et facturation', secs: ['À rapprocher', 'Reçus', 'TVH', 'À venir'], tabs: ['Accueil', 'Factures', 'Comptes', 'Paie'], sens: [1, 1, 1, 1] },
      { k: 'safety', name: 'Coordonnateur SST', ic: ['shield', 'rose'], people: [['KT', 'tn4', 'Kevin Tran']], access: 'Lecteur', accessSub: 'Lecture seule, plus certificats et incidents', secs: ['Certificats à renouveler', 'Incidents', 'Causeries sécurité', 'Inspections de chantier'], tabs: ['Accueil', 'Travaux', 'Équipe', 'Documents'], sens: [0, 0, 0, 0] },
      { k: 'foreman', name: 'Contremaître', ic: ['hammer', 'clay'], people: [['LB', 'tn1', 'Luca Bianchi']], access: 'Contremaître', accessSub: 'Chantiers et coûts sur place, le reste en lecture', secs: ['Pointage', 'Blocages', 'Équipe du jour', 'Tâches'], tabs: ['Accueil', 'Travaux', 'Horaire', 'Équipe'], sens: [0, 0, 1, 0] },
      { k: 'crew', name: 'Équipe', ic: ['users', 'slate'], people: [['AO', 'tn3', 'Amara Okafor'], ['SM', 'tn5', 'Sofia Marin'], ['DP', 'tn2', 'Dev Patel'], ['JR', 'tn4', 'Jonah Reyes']], access: 'Lien', accessSub: 'Lien personnel, sans connexion', secs: ['Pointage', 'Tâches du jour', 'À venir', 'Vos rapports'], tabs: ['Aujourd’hui', 'Heures', 'Photos', 'Trajets'], sens: [0, 0, 0, 0] }
    ];
    var sel = this.g('role', 'estimator');
    var R = ROLES.filter(function (r) { return r.k === sel; })[0] || ROLES[2];
    var roles = ROLES.map(function (r) {
      var on = r.k === sel, names = r.people.map(function (p) { return p[2].split(' ')[0]; });
      return {
        name: r.name, ic: ic(r.ic[0], r.ic[1]), on: on, cls: on ? 'on' : '',
        who: r.people.length > 1 ? names.slice(0, 2).join(', ') + ' et ' + (names.length - 2) + ' autres' : r.people[0][2],
        avs: r.people.slice(0, 2).map(function (p) { return { ini: p[0], tn: p[1] }; }),
        radio: on ? 'background: var(--inv)' : 'box-shadow: inset 0 0 0 1.6px var(--line2)', tick: on ? 'opacity: 1' : 'opacity: 0',
        pick: function () { set({ role: r.k }); }
      };
    });
    var own = this.g('own_' + sel, sel !== 'crew');

    // people with sensitive switches (everyone who signs in, except the owner)
    var PEOPLE = [];
    ROLES.forEach(function (r) { if (r.k === 'owner' || r.k === 'crew') return; r.people.forEach(function (p) { PEOPLE.push({ ini: p[0], tn: p[1], name: p[2], role: r.name, def: r.sens }); }); });
    var pSel = this.g('person', 'BW');
    var person = PEOPLE.filter(function (p) { return p.ini === pSel; })[0] || PEOPLE[1];
    var OVR = { BW: [0, 1, 0, 1] };
    var cur = this.g('sens_' + person.ini, OVR[person.ini] || person.def);
    var LABELS = [['Voir les taux de paie', 'card', 'rose'], ['Voir marges et coûts', 'percent', 'violet'], ['Approuver les heures', 'clock', 'teal'], ['Envoyer les factures', 'send', 'azure']];
    var changed = 0;
    var switches = LABELS.map(function (l, i) {
      var on = !!cur[i], diff = !!cur[i] !== !!person.def[i];
      if (diff) changed++;
      return {
        label: l[0], ic: ic(l[1], l[2]), on: on,
        sub: diff ? 'Modifié · ' + (person.def[i] ? 'activé' : 'désactivé') + ' par défaut' : 'Par défaut (' + person.role.toLowerCase() + ')',
        subStyle: diff ? 'color: var(--acc-t)' : '',
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var a = self.g('sens_' + person.ini, OVR[person.ini] || person.def).slice(); a[i] = a[i] ? 0 : 1; var o = {}; o['sens_' + person.ini] = a; set(o); }
      };
    });
    return {
      ro: ST === 'readOnly', locked: ST === 'locked', lockIc: ic('lock', 'slate'), tierIc: ic('tier3', 'violet'),
      canEdit: !RO, roles: roles, roleName: R.name, roleFirst: R.people[0][2].split(' ')[0],
      access: R.access, accessSub: R.accessSub,
      secs: R.secs.map(function (t, i) { return { n: String(i + 1), t: t }; }),
      tabs: R.tabs.map(function (t, i) { return { t: t, cls: i ? '' : 'on' }; }),
      dim: ST === 'locked' ? 'opacity: .55' : '',
      ownOn: own, ownTrack: (own ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45' : ''),
      ownKnob: own ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipOwn: function () { if (RO) return; var o = {}; o['own_' + sel] = !self.g('own_' + sel, sel !== 'crew'); set(o); },
      eyeIc: ic('eye', 'indigo'),
      people: PEOPLE.map(function (p) { var on = p.ini === person.ini; return { ini: p.ini, tn: p.tn, first: p.name.split(' ')[0], on: on, cls: on ? 'on' : '', pick: function () { set({ person: p.ini }); } }; }),
      person: person, switches: switches, hasChanged: changed > 0, changedN: changed + (changed > 1 ? ' modifiés' : ' modifié')
    };
