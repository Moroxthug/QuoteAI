    var mode = this.g('mode', 0), txt = this.g('txt', ''), trade = this.g('trade', -1), lay = this.g('lay', 1), cl = this.g('cl', 'dw'), w = this.g('w', 0), remember = this.g('rem', true);
    var fig = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var money = function (n) { return fig(n) + ' $'; };
    var pnum = function (s) { return parseFloat(String(s).replace(/[\s\u00a0\u202f$]/g, '').replace(',', '.')) || 0; };
    var seg = function (key, cur, labels) {
      var n = labels.length;
      return { cols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))', ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { var o = {}; o[key] = i; set(o); } }; }) };
    };
    // ---------- AI mode ----------
    var EX = [
      ['Peinture', 'Repeindre 3 chambres et le corridor, environ 1 120 pi² de murs et plafonds, deux couches. Le plafond de la salle de bain a un dégât d’eau : découper et réparer. Peinture fournie.'],
      ['Gypse', 'Poser, tirer les joints et plâtrer une salle familiale de 600 pi² au sous-sol, finition niveau 4, un caisson autour du conduit.'],
      ['Planchers', 'Enlever le tapis dans 2 chambres (320 pi²) et poser des lattes de vinyle à clic avec de nouvelles plinthes.'],
      ['Patios', 'Laver à pression et teindre un patio en cèdre de 14 pi sur 16 pi avec 30 pi de garde-corps, deux couches semi-transparentes.'],
      ['Salles de bain', 'Refaire au complet une salle de bain de 5 pi sur 8 pi : bain remplacé par une douche ouverte, céramique au sol et aux murs, nouvelle vanité et toilette.'],
      ['Cuisines', 'Peindre 24 portes et caissons d’armoires, nouvelles poignées et un dosseret en céramique métro d’environ 30 pi².'],
      ['Sous-sols', 'Finir un sous-sol de 750 pi² : charpente, isolation, gypse, lumières encastrées, plancher de vinyle et préparation pour une salle de bain 3 pièces.']
    ];
    var examples = EX.map(function (e, i) { var on = i === trade; return { label: e[0], cls: on ? 'on' : '', on: on, pick: function () { set({ trade: i, txt: e[1] }); } }; });
    var clients = [['dw', 'Dana Whitfield', '17 Castle Frank Cres', 'tn1'], ['pn', 'Priya Nair', '212 Dovercourt Rd', 'tn2'], ['th', 'Tom & Lena Hart', '48 Galloway Rd, Scarborough', 'tn3'], ['hd', 'Harbourfront Dental', 'Queens Quay W', 'tn4']].map(function (c) {
      var on = cl === c[0];
      return { id: c[0], name: c[1], addr: c[2], tn: c[3], ini: c[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (x) { return x[0]; }).join('').slice(0, 2).toUpperCase(), on: on,
        radio: on ? 'box-shadow: inset 0 0 0 6px var(--ink)' : 'box-shadow: inset 0 0 0 1.5px var(--line2)', pick: function () { set({ cl: c[0] }); } };
    });
    var newOn = cl === 'new';
    var clientName = newOn ? 'un nouveau client' : clients.filter(function (c) { return c.on; })[0].name;
    var STEPS = ['Lecture de votre description', 'Mesure des pièces et des quantités', 'Prix tirés de votre liste de prix', 'Ajout de la TVH, Ontario 13 %', 'Mise en page du PDF'];
    var wsteps = STEPS.map(function (s, i) {
      var done = w > i + 1, cur = w === i + 1;
      return { label: s, done: done, cur: cur, todo: !done && !cur, lab: done ? 'color: var(--ink)' : cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--faint)' };
    });
    var tick = function (n) { setTimeout(function () { self.setState({ w: n }); if (n < 6) tick(n + 1); }, 750); };
    // ---------- Manual mode ----------
    var ml = this.g('ml', {});
    var CH = [
      ['Préparation', [['Protection des planchers et nettoyage', 'forfait', 1, 180], ['Réparation du dégât d’eau au plafond de la salle de bain', 'forfait', 1, 640], ['Apprêt anti-taches', 'pi²', 48, 1.85]]],
      ['Peinture', [['Murs et plafonds, 3 chambres et corridor', 'pi²', 1120, 2.10], ['Peinture et fournitures', 'forfait', 1, 395]]]
    ];
    var exempt = this.g('ex', false), terms = this.g('terms', 0);
    var sub = 0;
    var chapters = CH.map(function (c, ci) {
      var cs = 0;
      var lines = c[1].map(function (l, li) {
        var kq = ci + '-' + li + 'q', kp = ci + '-' + li + 'p';
        var qv = ml[kq] !== undefined ? ml[kq] : String(l[2]), pv = ml[kp] !== undefined ? ml[kp] : fig(l[3]);
        var tot = Math.round(pnum(qv) * pnum(pv) * 100) / 100;
        cs += tot;
        var upd = function (k) { return function (e) { var o = Object.assign({}, self.g('ml', {})); o[k] = e.target.value; set({ ml: o }); }; };
        return { desc: l[0], unit: l[1], q: qv, p: pv, total: money(tot), onQ: upd(kq), onP: upd(kp), sep: li ? 'border-top: 1px solid var(--line)' : '', idq: 'q' + kq, idp: 'p' + kp, aiIc: ic('orb', 'violet') };
      });
      cs = Math.round(cs * 100) / 100; sub += cs;
      return { n: (ci + 1) + '', title: c[0], lines: lines, subtotal: money(cs) };
    });
    sub = Math.round(sub * 100) / 100;
    var tax = exempt ? 0 : Math.round(sub * 0.13 * 100) / 100;
    var TERMS = ['Acompte de 30 %, solde à la fin des travaux', '50 % maintenant, 50 % à la fin', 'Tout à la fin des travaux', 'Net 15 jours'];
    // ---------- Price list ----------
    var pq = this.g('pq', ''), pcat = this.g('pcat', 0), sel = this.g('sel', { p1: 1120, p3: 48, p8: 1 });
    var CATS = ['Tout', 'Peinture', 'Gypse', 'Planchers', 'Chantier'];
    var PB = [
      ['p1', 'Murs intérieurs, deux couches', 'Peinture', 'pi²', 2.10, 100, 20],
      ['p2', 'Plafonds, deux couches', 'Peinture', 'pi²', 1.65, 100, 20],
      ['p3', 'Apprêt anti-taches', 'Peinture', 'pi²', 1.85, 40, 4],
      ['p4', 'Petite réparation de gypse', 'Gypse', 'unité', 85, 1, 1],
      ['p5', 'Enduit complet, niveau 5', 'Gypse', 'pi²', 1.40, 100, 20],
      ['p6', 'Lattes de vinyle, fournies et posées', 'Planchers', 'pi²', 6.80, 100, 20],
      ['p7', 'Plinthes, fournies et posées', 'Planchers', 'pi lin.', 4.25, 50, 10],
      ['p8', 'Protection des planchers et nettoyage', 'Chantier', 'forfait', 180, 1, 1],
      ['p9', 'Conteneur à déchets, 14 vg³', 'Chantier', 'unité', 425, 1, 1]
    ];
    var catIc = { Peinture: ['pen', 'violet'], Gypse: ['box', 'stone'], Planchers: ['ruler', 'amber'], Chantier: ['truck', 'teal'] };
    var pql = pq.trim().toLowerCase();
    var items = PB.filter(function (p) { return (pcat === 0 || p[2] === CATS[pcat]) && (!pql || p[1].toLowerCase().indexOf(pql) >= 0); }).map(function (p) {
      var on = sel[p[0]] !== undefined;
      return { name: p[1], rate: money(p[4]) + ' / ' + p[3], cat: p[2], ic: ic(catIc[p[2]][0], catIc[p[2]][1]), on: on, off: !on,
        toggle: function () { var o = Object.assign({}, self.g('sel', { p1: 1120, p3: 48, p8: 1 })); if (o[p[0]] !== undefined) delete o[p[0]]; else o[p[0]] = p[5]; set({ sel: o }); } };
    });
    var picked = PB.filter(function (p) { return sel[p[0]] !== undefined; });
    var ptot = 0;
    var selRows = picked.map(function (p, i) {
      var q = sel[p[0]], t = Math.round(q * p[4] * 100) / 100; ptot += t;
      var chg = function (d) { return function () { var o = Object.assign({}, self.g('sel', { p1: 1120, p3: 48, p8: 1 })); o[p[0]] = Math.max(p[6], o[p[0]] + d); set({ sel: o }); }; };
      return { name: p[1], qty: q.toLocaleString('fr-CA') + ' ' + (p[3] === 'forfait' ? '' : p[3]), total: money(t), dec: chg(-p[6]), inc: chg(p[6]), sep: i ? 'border-top: 1px solid var(--line)' : '', decL: 'Moins : ' + p[1], incL: 'Plus : ' + p[1] };
    });
    ptot = Math.round(ptot * 100) / 100;
    var modeSeg = seg('mode', mode, ['Avec l’IA', 'Manuel', 'Liste de prix']);
    return {
      modeSeg: modeSeg, isAI: mode === 0, isMan: mode === 1, isPB: mode === 2,
      // AI
      aiForm: mode === 0 && w === 0, aiWriting: mode === 0 && w > 0, txt: txt, onTxt: function (e) { set({ txt: e.target.value, trade: -1 }); },
      examples: examples, laySeg: seg('lay', lay, ['Standard', 'Professionnel', 'Élégant']),
      clients: clients, newOn: newOn, newRadio: newOn ? 'box-shadow: inset 0 0 0 6px var(--ink)' : 'box-shadow: inset 0 0 0 1.5px var(--line2)', pickNew: function () { set({ cl: 'new' }); },
      remTrack: remember ? 'background: var(--acc)' : 'background: var(--track-off)', remKnob: remember ? 'transform: translateX(20px)' : 'transform: translateX(0)', remember: remember, flipRem: function () { set({ rem: !self.g('rem', true) }); },
      micIc: ic('mic', 'violet'), orbIc: ic('orb', 'violet'), photoIc: ic('photo', 'sky'), fileIc: ic('file', 'clay'), sheetIc: ic('bars', 'sage'),
      write: function () { set({ w: 1 }); tick(2); },
      wsteps: wsteps, wDone: w >= 6, wBusy: w > 0 && w < 6,
      wTitle: w >= 6 ? 'Votre soumission est prête' : 'Rédaction de votre soumission', wSub: 'Pour ' + clientName + ' · mise en page ' + ['Standard', 'Professionnelle', 'Élégante'][lay],
      restart: function () { set({ w: 0 }); },
      aiPrimary: mode === 0 && w < 6, aiOpen: mode === 0 && w >= 6, aiLabel: w > 0 ? 'Rédaction…' : 'Rédiger ma soumission', aiBtnStyle: w > 0 ? 'opacity: .55' : '',
      // Manual
      chapters: chapters, exempt: exempt, exTrack: exempt ? 'background: var(--acc)' : 'background: var(--track-off)', exKnob: exempt ? 'transform: translateX(20px)' : 'transform: translateX(0)', flipEx: function () { set({ ex: !self.g('ex', false) }); },
      mSub: money(sub), mTax: exempt ? 'Exonéré' : money(tax), mTaxLabel: exempt ? 'Taxe' : 'TVH, Ontario 13 %', mTotal: money(Math.round((sub + tax) * 100) / 100),
      terms: TERMS.map(function (t, i) { var on = i === terms; return { label: t, cls: on ? 'on' : '', on: on, pick: function () { set({ terms: i }); } }; }),
      // Price list
      pq: pq, onPq: function (e) { set({ pq: e.target.value }); },
      cats: CATS.map(function (c, i) { var on = i === pcat; return { label: c, cls: on ? 'on' : '', on: on, pick: function () { set({ pcat: i }); } }; }),
      items: items, noItems: items.length === 0, selRows: selRows, hasSel: selRows.length > 0, noSel: selRows.length === 0,
      selCount: selRows.length + (selRows.length === 1 ? ' article' : ' articles'), pSub: money(ptot),
      pbLabel: selRows.length ? 'Créer avec ' + selRows.length + (selRows.length === 1 ? ' article' : ' articles') : 'Ajoutez des articles',
      emptyIc: ic('search', 'slate'), listIc: ic('list', 'slate')
    };
