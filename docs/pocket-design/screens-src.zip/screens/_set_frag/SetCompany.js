    var D0 = { legal: 'Rossi Renovations Inc.', op: 'Rossi Renovations', gst: '81234 5678 RT0001', wsib: '1234567', addr: '1180 Dundas St W, Toronto, ON M6J 1X5', phone: '(416) 555-0142', email: 'marco@rossireno.ca', web: 'rossireno.ca' };
    var vals = self.g('vals', ST === 'unsaved' ? Object.assign({}, D0, { op: 'Rossi Renovations & Design' }) : D0);
    var dirty = self.g('dirty', ST === 'unsaved');
    var F = function (id, icon, tone, label, extra) {
      return Object.assign({ id: 'co-' + id, ic: ic(icon, tone), label: label, v: vals[id], type: 'text', mode: 'text', cls: '', hasSt: false, st: '', stCls: '',
        on: function (e) { var nv = Object.assign({}, self.g('vals', vals)); nv[id] = e.target.value; set({ vals: nv, dirty: true, saved: false }); } }, extra || {});
    };
    var seps = function (l) { l.forEach(function (f, i) { f.sep = i ? 'border-top: 1px solid var(--line)' : ''; }); return l; };
    var SW = [['Violet', '#6A2FBF'], ['Harbour blue', '#1F4F86'], ['Forest', '#1F7A45'], ['Brick', '#B4462B'], ['Teal', '#1E7F80'], ['Charcoal', '#2B2B30']];
    var bi = self.g('brand', 1), brand = SW[bi][1];
    var lang = self.g('docLang', 0);
    return {
      roBanner: roBanner, ro: RO,
      opName: vals.op || 'Rossi Renovations', logoBg: 'background: ' + brand, brandText: 'color: ' + brand, brandHex: brand,
      fBiz: seps([
        F('legal', 'building', 'slate', 'Legal name'),
        F('op', 'star', 'amber', 'Operating name'),
        F('gst', 'receipt', 'violet', 'GST/HST number', { cls: 'mono', hasSt: true, st: 'Verified', stCls: 'st-ok si-check' }),
        F('wsib', 'shield', 'teal', 'WSIB firm number', { cls: 'mono', hasSt: true, st: 'Clearance valid', stCls: 'st-ok si-check' })
      ]),
      fBizFoot: { show: true, t: 'Your GST/HST number prints on every quote and invoice. Clients ask for the WSIB clearance on larger jobs.' },
      fContact: seps([
        F('addr', 'pin', 'clay', 'Business address'),
        F('phone', 'phone', 'sage', 'Phone', { type: 'tel', mode: 'tel', cls: 'mono' }),
        F('email', 'mail', 'sky', 'Email', { type: 'email', mode: 'email' }),
        F('web', 'globe', 'azure', 'Website', { mode: 'url' })
      ]),
      fContactFoot: { show: false, t: '' },
      brushIc: ic('brush', 'lilac'),
      swatches: SW.map(function (s, i) { var on = i === bi; return { name: s[0], on: on, style: 'background: ' + s[1] + '; ' + (on ? 'box-shadow: 0 0 0 2px var(--card), 0 0 0 4px ' + s[1] + '; transform: scale(1.04)' : 'box-shadow: 0 0 0 1px var(--line2)'), pick: function () { if (RO) return; set({ brand: i, dirty: true, saved: false }); } }; }),
      quoteWord: lang === 1 ? 'Soumission' : 'Quote', acceptWord: lang === 1 ? 'Accepter' : 'Accept quote', hstLine: lang === 1 ? 'TVH 13 % incluse' : 'HST 13% included',
      gLang: (function (g) { g.rows[0].sep = 'border-top: 1px solid var(--line)'; return g; })(grp('', [seg('docLang', 0, 'globe', 'azure', 'Default language', 'For quotes, invoices and client pages', ['English', 'Français'])], '', 240)),
      dirty: dirty && !RO, saved: self.g('saved', false),
      discard: function () { set({ vals: D0, dirty: false, brand: 1 }); },
      save: function () { set({ dirty: false, saved: true }); setTimeout(function () { set({ saved: false }); }, 2200); }
    };
