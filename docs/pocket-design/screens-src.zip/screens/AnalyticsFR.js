    var mode = this.props.state || 'default';
    var per = self.g('per', 'm');
    var P = {
      m: { label: 'Septembre 2026', revBy: 'Par mois', revLabel: 'Facturé en septembre', rev: '48 230 $', revSub: 'Hausse de 12 % sur août', revCap: 'Votre meilleur mois de l’année.', win: '42 %', winOf: '14 gagnées sur 33 soumissions tranchées', avg: '6 840 $', avgSub: 'Contre 4 920 $ en avril', q2c: '23', d1: '6 j', d2: '9 j', d3: '8 j', n: [6, 9, 8], util: '78 %',
        bars: [['avr.', 31.2], ['mai', 36.8], ['juin', 44.1], ['juil.', 39.6], ['août', 43.1], ['sept.', 48.2]],
        k: [['Facturé', '48 230 $', 'Hausse de 12 %', 1], ['Encaissé', '41 870 $', '87 % du facturé', 0], ['Coûts', '30 910 $', 'Matériaux, main-d’œuvre, sous-traitants', 0], ['Marge', '36 %', '17 320 $ gardés', 1], ['À recevoir', '12 480 $', '3 120 $ en retard', 2], ['À facturer', '18 760 $', '30 prochains jours', 0]] },
      q: { label: 'T3 2026, juil. à sept.', revBy: 'Par trimestre', revLabel: 'Facturé au T3', rev: '130 930 $', revSub: 'Hausse de 17 % sur le T2', revCap: 'Votre meilleur trimestre à ce jour.', win: '39 %', winOf: '41 gagnées sur 105 soumissions tranchées', avg: '6 480 $', avgSub: 'Contre 5 210 $ au T2', q2c: '26', d1: '7 j', d2: '10 j', d3: '9 j', n: [7, 10, 9], util: '81 %',
        bars: [['T4 ’25', 88.4], ['T1', 71.9], ['T2', 112.1], ['T3', 130.9]],
        k: [['Facturé', '130 930 $', 'Hausse de 17 %', 1], ['Encaissé', '121 480 $', '93 % du facturé', 0], ['Coûts', '86 410 $', 'Matériaux, main-d’œuvre, sous-traitants', 0], ['Marge', '34 %', '44 520 $ gardés', 1], ['À recevoir', '12 480 $', '3 120 $ en retard', 2], ['À facturer', '18 760 $', '30 prochains jours', 0]] },
      y: { label: '2026 à ce jour', revBy: 'Par année', revLabel: 'Facturé en 2026 à ce jour', rev: '314 900 $', revSub: 'En voie d’atteindre environ 420 000 $', revCap: 'Presque autant que toute l’année 2025, avec un trimestre à venir.', win: '38 %', winOf: '96 gagnées sur 252 soumissions tranchées', avg: '5 960 $', avgSub: 'Contre 4 870 $ en 2025', q2c: '29', d1: '8 j', d2: '11 j', d3: '10 j', n: [8, 11, 10], util: '80 %',
        bars: [['2023', 212.4], ['2024', 268.7], ['2025', 331.5], ['2026', 314.9]],
        k: [['Facturé', '314 900 $', 'Hausse de 24 % sur l’an dernier à pareille date', 1], ['Encaissé', '298 640 $', '95 % du facturé', 0], ['Coûts', '212 560 $', 'Matériaux, main-d’œuvre, sous-traitants', 0], ['Marge', '32 %', '102 340 $ gardés', 1], ['À recevoir', '12 480 $', '3 120 $ en retard', 2], ['À facturer', '18 760 $', '30 prochains jours', 0]] }
    };
    var p = P[per];
    var max = Math.max.apply(null, p.bars.map(function (b) { return b[1]; }));
    var fmtK = function (v) { return v >= 100 ? Math.round(v) + ' k$' : v.toFixed(1).replace('.', ',') + ' k$'; };
    var tot = p.n[0] + p.n[1] + p.n[2];
    var hb = function (rows, hi) { return rows.map(function (r, i) { return { name: r[0], v: r[1] + ' %', w: 'width: ' + r[1] + '%' + (i === hi ? '; background: var(--ok-dot)' : ''), share: r[2] ? r[2] + ' %' : '', wonStyle: i === hi ? 'color: var(--ok)' : '' }; }); };
    var sixBars = P.m.bars;
    return {
      isLoading: mode === 'loading', isLocked: mode === 'locked', isData: mode === 'default', notLocked: mode !== 'locked',
      p: Object.assign({}, p, { revAria: 'Facturé ' + p.bars.map(function (b) { return b[0] + ' ' + fmtK(b[1]); }).join(', '), q2cAria: p.d1 + ' pour l’acceptation, ' + p.d2 + ' pour la facturation, ' + p.d3 + ' pour le paiement' }),
      periods: [['m', 'Mois'], ['q', 'Trimestre'], ['y', 'Année']].map(function (c) { var on = c[0] === per; return { label: c[1], on: on, cls: on ? 'on' : '', pick: function () { set({ per: c[0] }); } }; }),
      kpis: p.k.map(function (k) { return { label: k[0], value: k[1], sub: k[2], subStyle: k[3] === 1 ? 'color: var(--ok)' : (k[3] === 2 ? 'color: var(--bad)' : 'color: var(--muted)') }; }),
      revBars: p.bars.map(function (b, i) { var last = i === p.bars.length - 1; return { m: b[0], v: last ? fmtK(b[1]) : '', cls: last ? 'on' : '', h: 'height: ' + Math.max(6, b[1] / max * 82).toFixed(1) + '%; animation-delay: ' + (i * 60) + 'ms' }; }),
      ghostBars: sixBars.map(function (b, i) { return { m: b[0], cls: i === 5 ? 'on' : '', h: 'height: ' + (b[1] / 48.2 * 82).toFixed(1) + '%' }; }),
      risk: [
        { name: 'Okoye Condo', sub: 'Plancher · 108 % du budget', word: 'Hors budget', st: 'st-bad si-alert', ic: ic('bars', 'clay'), href: 'Job.dc.html' },
        { name: 'Gill Residence', sub: 'Patio · 2 980 $ non facturés', word: 'À facturer', st: 'st-warn si-clock', ic: ic('receipt', 'amber'), href: 'Job.dc.html' },
        { name: 'Harbourfront Dental', sub: 'INV-0419 · 780 $', word: '3 j de retard', st: 'st-bad si-alert', ic: ic('doc', 'azure'), href: 'Invoice.dc.html' }
      ],
      winBy: hb([['Patios', 61], ['Peinture', 48], ['Sous-sols', 40], ['Cuisines', 33], ['Salles de bain', 22]], 0),
      q2c: { a: 'flex: ' + p.n[0] + ' 1 0; background: var(--acc)', b: 'flex: ' + p.n[1] + ' 1 0; background: var(--warn-dot)', c: 'flex: ' + p.n[2] + ' 1 0; background: var(--ok-dot)' },
      margin: hb([['Peinture', 38], ['Patios', 34], ['Gypse', 29], ['Sous-sols', 24], ['Salles de bain', 17]], 0),
      clients: [['TL', 'tn1', 'Tom & Lena Hart', 'Sous-sol · 2 ordres de changement', '42 355 $', '13'], ['HD', 'tn4', 'Harbourfront Dental', 'Réception et 3 salles de soins', '18 920 $', '6'], ['OC', 'tn2', 'Okoye Condo', 'Plancher et peinture du corridor', '9 640 $', '3']].map(function (c) { return { ini: c[0], tn: c[1], name: c[2], sub: c[3], amt: c[4], share: c[5] + ' % de 2026' }; }),
      crew: hb([['Amara Okafor', 91], ['Dev Patel', 84], ['Sofia Marin', 76], ['Luca Bianchi', 64]], -1),
      leads: hb([['Références', 58, 41], ['Formulaire Web', 31, 24], ['Google', 27, 18], ['HomeStars', 22, 11], ['Autre', 15, 6]], 0).map(function (r, i) { r.w = 'width: ' + [41, 24, 18, 11, 6][i] / 41 * 100 + '%' + (i === 0 ? '; background: var(--ok-dot)' : ''); return r; }),
      skKpis: [1, 2, 3, 4, 5, 6],
      skCards: [0, 1, 2].map(function () { return { bars: [42, 55, 70, 60, 68, 82].map(function (h) { return { h: 'height: ' + h + '%' }; }) }; }),
      lockIc: ic('bars', 'azure'),
      lockFeats: [['Revenus, coûts et marge par mois', 'bars', 'azure'], ['Taux de réussite et soumission moyenne', 'star', 'gold'], ['Marge par type de chantier', 'percent', 'violet'], ['Heures de l’équipe et sources des demandes', 'users', 'teal']].map(function (f) { return { label: f[0], ic: ic(f[1], f[2]) }; })
    };
