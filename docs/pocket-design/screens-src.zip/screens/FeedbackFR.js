    var P = this.props.state || 'compose';
    var phase = self.g('phase', null) || P;
    var isOffline = P === 'offline';
    var kind = self.g('kind', 'wrong'), logs = self.g('logs', true), reply = self.g('reply', true);
    var marked = self.g('marked', true), hasShot = self.g('shot', true), pen = self.g('pen', false);
    var note = self.g('note', 'L’étape Gypse terminé affiche 12 288 $, mais le PDF de la soumission indique 12 290 $. Lequel va sur la facture ?');
    var sw = function (key, val, label, sub) { return { label: label, sub: sub, on: val, track: val ? 'background: var(--acc)' : 'background: var(--track-off)', knob: val ? 'transform: translateX(20px)' : 'transform: translateX(0)', flip: function () { var o = {}; o[key] = !val; set(o); } }; };
    var K = [['wrong', 'Un problème'], ['idea', 'Idée'], ['question', 'Question']];
    var PH = { wrong: 'Que s’est-il passé, et à quoi vous attendiez-vous ?', idea: 'Qu’est-ce qui vous simplifierait la tâche ?', question: 'Qu’essayez-vous de faire ?' };
    var sending = phase === 'sending';
    return {
      isDone: phase === 'sent', isForm: phase !== 'sent', offline: isOffline && phase !== 'sending',
      busyCls: sending ? 'fb-busy' : '', sending: sending,
      sendLabel: sending ? 'Envoi…' : (isOffline ? 'Enregistrer, envoyer plus tard' : 'Envoyer'),
      doneTitle: isOffline ? 'Enregistré, envoi plus tard' : 'Merci, c’est envoyé',
      doneText: isOffline ? 'Il est sur ce téléphone et partira dès votre retour en ligne.' : (reply ? 'Nous lisons chaque message. S’il nous faut plus de détails, nous écrirons à marco@rossireno.ca.' : 'Nous lisons chaque message. Merci de nous aider à corriger le problème.'),
      logsWord: logs ? 'Joints' : 'Non inclus', logsSt: logs ? 'st-ok si-check' : 'st-mute si-off',
      okIc: ic(isOffline ? 'cloud' : 'check', isOffline ? 'amber' : 'sage'), cloudIc: ic('cloud', 'amber'),
      penIc: ic('pen', 'violet'), syncIc: ic('sync', 'slate'), photoIc: ic('photo', 'azure'), photoIc2: ic('photo', 'slate'),
      penOn: pen, penCls: pen ? 'on' : '', togglePen: function () { set({ pen: !pen, marked: true }); },
      undo: function () { set({ marked: false }); },
      hasShot: hasShot, noShot: !hasShot, marked: marked && hasShot,
      shotLabel: hasShot ? 'Retirer la capture' : 'Ajouter une capture', toggleShot: function () { set({ shot: !hasShot }); },
      hint: pen ? 'Dessinez avec le doigt. Touchez Annoter de nouveau pour terminer.' : 'Encerclez ce qui semble anormal.',
      kinds: K.map(function (k) { var on = k[0] === kind; return { label: k[1], on: on, cls: on ? 'on' : '', pick: function () { set({ kind: k[0] }); } }; }),
      note: note, notePh: PH[kind], onNote: function (e) { set({ note: e.target.value }); },
      switches: [
        sw('logs', logs, 'Joindre les journaux', 'Version de l’app, modèle du téléphone et les 10 dernières minutes d’activité. Aucune donnée client.'),
        sw('reply', reply, 'Me répondre par courriel', 'marco@rossireno.ca')
      ],
      send: function () { if (sending) return; if (isOffline) { set({ phase: 'sent' }); return; } set({ phase: 'sending' }); setTimeout(function () { set({ phase: 'sent' }); }, 1400); },
      again: function () { set({ phase: 'compose', note: '', marked: false }); }
    };
