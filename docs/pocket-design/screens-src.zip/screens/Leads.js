    var stage = this.g('stage', 0), moved = this.g('moved', {}), chan = this.g('chan', {}), form = this.g('form', false), fch = this.g('fch', 0), toast = this.g('toast', null), nm = this.g('nm', '');
    var STAGES = ['New', 'Contacted', 'Quoted', 'Won', 'Lost'];
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // id, name, source, when, ask, channel(0 text,1 email), follow-up, due tone, stage
    var base = [
      ['am', 'Aaron Mitchell', 'Website form', '2 h ago', 'Kitchen and hallway repaint, about 400 sq ft. Hopes to finish before Thanksgiving.', 0, 'Today, 4:00 pm', 'due', 0],
      ['so', 'Sam Oduya', 'Google Local Services', '5 h ago', 'Damp corner in the basement. Wants a waterproofing quote.', 0, 'Today, 5:30 pm', 'due', 0],
      ['rt', 'Rebecca Tran', 'Instagram', 'Yesterday', 'Deck stain and two railings in Etobicoke.', 1, 'Tomorrow, 9:00 am', '', 0],
      ['jp', 'Jordan Price', 'Added by you', 'Sep 24', 'Ensuite tile, walk-in shower. Asked for photos of past work.', 0, 'Yesterday, missed', 'late', 1],
      ['ml', 'Mei Lin', 'Facebook', 'Sep 25', 'Two bedrooms and a stairwell, dark colours to cover.', 1, 'Thu Oct 1', '', 1],
      ['cd', 'Claire Dubois', 'Website form', 'Sep 26', 'Condo baseboards and trim, 900 sq ft.', 0, 'Fri Oct 2', '', 1],
      ['ha', 'Hassan Ali', 'Imported list', 'Sep 21', 'Spring deck rebuild, wants a price this fall.', 1, 'Sat Oct 3', '', 1],
      ['dw', 'Dana Whitfield', 'Referral from Priya Nair', 'Sep 27', 'Bedrooms and bath ceiling · Q-2026-119, $4,131.05', 0, 'Today, after 6:00 pm', 'due', 2],
      ['gr', 'Gill Residence', 'Website form', 'Sep 22', 'Deck refinish · Q-2026-116, $2,980.00', 1, 'Thu Oct 1', '', 2],
      ['hd', 'Harbourfront Dental', 'Google Local Services', 'Sep 18', 'Reception repaint · Q-2026-117, expires Fri', 1, 'Wed Sep 30', '', 2],
      ['oc', 'Okoye Condo', 'Instagram', 'Sep 10', 'Hallway flooring · won $2,210.00', 0, 'Review request, Oct 20', '', 3],
      ['th', 'Tom & Lena Hart', 'Referral', 'Aug 14', 'Basement finish · won $38,400.00', 1, 'Job running', '', 3]
    ];
    var leads = base.map(function (d) { return { id: d[0], name: d[1], src: d[2], when: d[3], ask: d[4], ch: chan[d[0]] !== undefined ? chan[d[0]] : d[5], follow: d[6], tone: d[7], stage: moved[d[0]] !== undefined ? moved[d[0]] : d[8], i: base.indexOf(d) }; });
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    // full request, photos, plan after the next follow-up, drafted reply
    var DET = {
      am: ['Walls and ceilings, trim stays white. Thanksgiving is Oct 12, so the paint needs to be dry by the 10th. Home on weekdays after 3.', '4 photos · kitchen, hallway', 'Then Thu and Mon if no answer', 'Hi Aaron, Marco from Rossi Renovations. Thanks for the photos. I can come by Thursday at 4 to measure and send a price Friday. Does that work?'],
      so: ['North wall, near the laundry. White residue on the block and a musty smell after rain. Wants to know how urgent it is.', '2 photos · basement corner', 'Then Thu if no answer', 'Hi Sam, Marco from Rossi Renovations. Damp corners are common after this much rain. I can take a look Wednesday at 9:00 and tell you what it needs.'],
      rt: ['About 220 sq ft, last stained in 2021. Semi-transparent, same cedar tone. Wants it done before the cold sets in.', '3 photos · deck, railings', 'Then Mon if no answer', 'Hi Rebecca, thanks for reaching out. A deck this size with two railings takes us about two days. Send one photo of the stairs and I can quote from your photos.'],
      jp: ['About 60 sq ft with a curbless shower and a niche. Wants to see past ensuites before booking a visit.', '', 'Missed yesterday · retry today', 'Hi Jordan, sorry I missed you yesterday. Here are three ensuites we did this year. Happy to come by this week to measure.'],
      ml: ['Navy and forest green going to warm white. Two coats plus primer where needed. Stairwell is two storeys.', '5 photos · bedrooms, stairwell', 'Then Mon Oct 5', 'Hi Mei, following up on the bedrooms and stairwell. I have Oct 8 open for a visit. Would the morning work?'],
      cd: ['The building needs a certificate of insurance and an elevator booking. Semi-gloss, white.', '1 photo · living room trim', 'Then Tue Oct 6', 'Hi Claire, I have our certificate of insurance ready for your building. Once the elevator is booked I can measure in 30 minutes.'],
      ha: ['About 300 sq ft. Wants pressure-treated and composite priced side by side to plan the budget.', '', 'Then monthly until March', 'Hi Hassan, happy to price both options. A quick visit this month lets me lock in this year’s lumber prices.'],
      dw: ['Q-2026-119 drafted today after the site visit on Sep 28. Two bedrooms plus the bath ceiling, low-VOC paint.', '6 photos · from the site visit', 'Then Thu if not opened', 'Hi Dana, your quote for the bedrooms and bath ceiling is ready. I kept the dates you asked for. Let me know if anything needs a change.'],
      gr: ['Q-2026-116 sent Monday by email, not opened yet. Weekend start preferred.', '3 photos · deck', 'Then Mon Oct 5', 'Hi, just checking the deck quote reached you. Happy to walk through it by phone this week.'],
      hd: ['Q-2026-117 sent Sep 24 to the office manager. After hours only, patients on site in the day.', '4 photos · reception', 'Last reminder Thu before it expires', 'Hi, a reminder that the reception repaint quote expires Friday. We can start the week of Oct 19, evenings only.'],
      oc: ['Accepted Sep 15. The job plan is drafted from Q-2026-112 and waiting for your review.', '2 photos · hallway', 'Review request Oct 20', 'Hi, thanks again for choosing Rossi Renovations. We start the hallway on Oct 5 and will send a reminder the day before.'],
      th: ['Accepted Aug 28. The job is 64% done, drywall phase, with a $3,955.00 change order.', '8 photos · basement', 'Review request after the job', 'Hi Lena, quick update: drywall wraps up Thursday, then priming. I will send photos at the end of the day.']
    };
    var srcIc = { 'Website form': ['globe', 'azure'], 'Google Local Services': ['search', 'sage'], 'Instagram': ['camera', 'rose'], 'Facebook': ['users', 'indigo'], 'Added by you': ['pen', 'slate'], 'Imported list': ['file', 'stone'] };
    var cards = leads.filter(function (l) { return l.stage === stage; }).map(function (l) {
      var ini = l.name.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var si = srcIc[l.src] || ['star', 'gold'];
      var open = stage < 3;
      return {
        name: l.name, ini: ini, tn: tints[l.i % 5], src: l.src, when: l.when, ask: l.ask, follow: l.follow, srcIc: ic(si[0], si[1]),
        followStyle: l.tone === 'late' ? 'color: var(--bad)' : l.tone === 'due' ? 'color: var(--warn)' : 'color: var(--ink)',
        open: open, won: l.stage === 3,
        chans: ['Text', 'Email'].map(function (c, ci) { var on = ci === l.ch; return { label: c, on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { var o = Object.assign({}, self.g('chan', {})); o[l.id] = ci; set({ chan: o }); } }; }),
        ind: 'width: calc((100% - 4px) / 2); transform: translateX(' + (l.ch * 100) + '%)',
        send: function () { var o = Object.assign({}, self.g('moved', {})); var mv = l.stage === 0; if (mv) o[l.id] = 1; set({ moved: o, xo: mv ? null : self.g('xo', null), toast: { id: l.id, name: l.name, from: l.stage, to: mv ? 'Contacted' : null, via: l.ch ? 'email' : 'text' } }); },
        sendLabel: 'Send ' + (l.ch ? 'email' : 'text'),
        isOpen: xo === l.id, xcls: xo === l.id ? 'open' : '', toggle: toggleOf(l.id),
        x: (function (x) {
          var st = l.stage, sk = l.id + ':sec', sd = !!xd[sk];
          var sec = st < 2 ? ['Book visit', 'Visit booked'] : st === 2 ? ['Call', 'Calling'] : st === 3 ? ['Ask review', 'Review asked'] : ['Reopen', 'Reopened'];
          var main = st < 2 ? ['Make quote', 'NewQuote.dc.html'] : st === 2 ? ['Open quote', 'Quote.dc.html'] : st === 3 ? ['Open client', 'Client.dc.html'] : ['Make quote', 'NewQuote.dc.html'];
          var tone = l.tone === 'late' ? ['Missed', 'st-bad si-alert'] : l.tone === 'due' ? ['Due today', 'st-warn si-clock'] : ['Planned', 'st-info si-q1'];
          var rows = [];
          rows.push({ t: x[1] ? 'Photos' : 'No photos yet', s: x[1] || 'Ask for a few with the reply', hasS: true, hasSt: false, hasBtn: !x[1], btnLabel: xd[l.id + ':ph'] ? 'Asked' : 'Ask', btnCls: xd[l.id + ':ph'] ? 'done' : '', act: flip(l.id + ':ph'), hasSeg: false });
          rows.push({ t: 'Source', s: l.src + ' · ' + l.when, hasS: true, hasSt: false, hasBtn: false, hasSeg: false });
          if (st < 3) rows.push({ t: 'Follow-up plan', s: x[2], hasS: true, st: tone[0], stCls: tone[1], hasSt: true, hasBtn: false, hasSeg: true });
          else rows.push({ t: st === 4 ? 'Marked lost' : l.follow, s: st === 4 ? 'Reach out again next season' : x[2], hasS: true, hasSt: false, hasBtn: false, hasSeg: false });
          return {
            full: x[0], cap: st < 3 ? 'More from ' + l.name.split(' ')[0] : 'Details', reply: x[3], via: l.ch ? 'by email' : 'by text', rows: rows,
            second: sd ? sec[1] : sec[0], secCls: sd ? 'done' : '',
            secAct: st === 4 ? function () { var o = Object.assign({}, self.g('moved', {})); o[l.id] = base[l.i][8]; set({ moved: o, xo: null, toast: null }); } : flip(sk),
            main: main[0], href: main[1], canLose: st < 3, loseLabel: 'Mark lost',
            lose: function () { var o = Object.assign({}, self.g('moved', {})); o[l.id] = 4; set({ moved: o, xo: null, toast: { id: l.id, name: l.name, from: l.stage, to: 'Lost', lost: true } }); }
          };
        })(DET[l.id])
      };
    });
    var counts = STAGES.map(function (s, i) { return leads.filter(function (l) { return l.stage === i; }).length; });
    return {
      tabs: STAGES.map(function (s, i) { var on = i === stage; return { label: s, count: counts[i], cls: on ? 'on' : '', on: on, pick: function () { set({ stage: i, toast: null, xo: null }); } }; }),
      openCls: cards.some(function (c) { return c.isOpen; }) ? 'has-open' : '',
      cards: cards, has: cards.length > 0, empty: cards.length === 0, isNew: stage === 0,
      emptyIc: ic('users', 'slate'), plugIc: ic('funnel', 'violet'),
      dueLine: counts[0] + counts[1] + counts[2] + ' open leads · 3 follow-ups due today',
      form: form, openForm: function () { set({ form: !self.g('form', false) }); }, closeForm: function () { set({ form: false }); },
      onName: function (e) { set({ nm: e.target.value }); }, nm: nm,
      fchans: ['Text', 'Email'].map(function (c, ci) { var on = ci === fch; return { label: c, on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ fch: ci }); } }; }),
      find: 'width: calc((100% - 4px) / 2); transform: translateX(' + (fch * 100) + '%)',
      save: function () { set({ form: false, stage: 0, toast: { id: null, name: (self.g('nm', '') || 'New lead'), to: 'New', saved: true } }); },
      toast: !!toast, toastText: toast ? (toast.lost ? toast.name + ' moved to Lost.' : toast.saved ? toast.name + ' added to New. First follow-up goes out tomorrow at 9:00 am.' : toast.to ? 'Sent by ' + toast.via + '. ' + toast.name + ' moved to ' + toast.to + '.' : 'Follow-up sent to ' + toast.name + ' by ' + toast.via + '.') : '',
      undoShow: !!(toast && !toast.saved && toast.to),
      undo: function () { var t = self.g('toast', null); if (!t) return; var o = Object.assign({}, self.g('moved', {})); o[t.id] = t.from; set({ moved: o, toast: null }); },
      okIc: ic('check', 'sage')
    };
