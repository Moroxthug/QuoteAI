    var st = this.props.state || 'default', offline = st === 'offline';
    var lang = this.g('lang', 'en'), period = this.g('period', 0), dirty = this.g('dirty', false), toast = this.g('toast', false), outOpen = this.g('out', false), sigV = this.g('sigV', 0);
    var vals = this.g('vals', { name: 'Marco Rossi', title: 'Estimator', phone: '416-555-0142', email: 'marco@rossireno.ca' });
    var T = {
      en: { title: 'Profile', photo: 'Change photo', owner: 'Owner', numbers: 'My numbers', period: 'Period', month: 'Month', sent: 'Sent', won: 'Won', invoiced: 'Invoiced', details: 'Details', name: 'Full name', jtitle: 'Job title', phone: 'Mobile', email: 'Email', lang: 'Language', langSub: 'App, quotes and emails to you', sig: 'Signature for quotes', redraw: 'Redraw', sigAlt: 'Your signature', sigOn: 'Added to quotes and contracts', notif: 'Notifications', notifSub: 'Push on · summary at 7 am · quiet 9 pm to 7 am', sec: 'Sign-in and security', secSub: 'Face ID on · two-step on · 2 devices', signout: 'Sign out', saved: 'Profile saved', save: 'Save changes', saveOff: 'Save on this phone', discard: 'Discard changes', outQ: 'Sign out of quoteAI?', outSub: 'Your work stays in Rossi Renovations. Sign in again any time.', cancel: 'Cancel', offB: 'No connection.', offS: 'Changes stay on this phone and sync later.', unsent: '2 changes not sent yet.', unsentS: 'They’re lost if you sign out now.', p: ['Month', 'Quarter', 'Year'], k: ['Quotes made', 'Sent', 'Won', 'Invoiced', 'Hours', 'Jobs'] },
      fr: { title: 'Profil', photo: 'Changer la photo', owner: 'Propriétaire', numbers: 'Mes chiffres', period: 'Période', month: 'Mois', sent: 'Envoyées', won: 'Gagnées', invoiced: 'Facturé', details: 'Coordonnées', name: 'Nom complet', jtitle: 'Poste', phone: 'Cellulaire', email: 'Courriel', lang: 'Langue', langSub: 'Appli, soumissions et courriels', sig: 'Signature des soumissions', redraw: 'Refaire', sigAlt: 'Votre signature', sigOn: 'Ajoutée aux soumissions et contrats', notif: 'Notifications', notifSub: 'Push activé · résumé à 7 h · silence de 21 h à 7 h', sec: 'Connexion et sécurité', secSub: 'Face ID activé · deux étapes · 2 appareils', signout: 'Se déconnecter', saved: 'Profil enregistré', save: 'Enregistrer', saveOff: 'Enregistrer sur ce téléphone', discard: 'Annuler les changements', outQ: 'Se déconnecter de quoteAI?', outSub: 'Votre travail reste dans Rossi Renovations. Reconnectez-vous quand vous voulez.', cancel: 'Annuler', offB: 'Pas de connexion.', offS: 'Les changements restent sur ce téléphone.', unsent: '2 changements non envoyés.', unsentS: 'Ils seront perdus si vous vous déconnectez.', p: ['Mois', 'Trimestre', 'Année'], k: ['Soumissions', 'Envoyées', 'Gagnées', 'Facturé', 'Heures', 'Chantiers'] }
    };
    var t = T[lang];
    var fr = lang === 'fr';
    var money = function (n) { return fr ? n.toLocaleString('fr-CA').replace(/ | /g, ' ') + ' $' : '$' + n.toLocaleString('en-CA'); };
    var P = [
      [14, 12, 58, 41870, 96, 4, '↑ 2 on Aug', '↑ 6 pts', '↑ 12%'],
      [38, 33, 61, 128450, 262, 9, '↑ 5 on Q2', '↑ 3 pts', '↑ 9%'],
      [131, 117, 62, 436900, 914, 27, '↑ 18 on 2025', '↑ 4 pts', '↑ 21%']
    ][period];
    var segStyle = function (on) { return on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)'; };
    var dot = function (n) { return fr ? String(n).replace('.', ',') : String(n); };
    var sigs = [
      'M26 62c6-18 14-36 18-34 4 2-6 30-4 34 3-9 11-26 15-24 3 2-3 20 0 22 4 1 9-12 13-12 3 0-1 10 3 11 5 1 8-9 13-9-4 2-6 10-1 10s8-7 11-9M112 58c10-4 16-14 14-16-3-3-12 10-9 15 3 4 12-4 16-8 2 6 4 8 9 4 3-3 6-9 9-9-3 5-5 10-1 11 4 1 7-6 10-9 1 5 3 7 7 5M168 60c10-20 22-40 26-38 4 3-10 26-8 30 6-6 12-10 18-8 5 3-6 14-14 14 8 2 18 4 26-2 4-3 6-8 9-8-3 5-3 9 1 9 5 0 8-8 12-10-3 6-3 10 1 10 4 0 7-5 10-8 1 6 5 7 9 3 3-3 6-7 10-7-5 4-5 9-1 9 5 0 9-5 12-8M288 40c4 1 8 1 12-1',
      'M24 60c8-22 16-38 20-36 3 3-6 28-3 32 4-10 10-24 15-22 3 2-2 18 1 20 4 2 10-12 14-11 3 1-1 9 3 10 4 1 9-8 13-8-3 3-4 9 0 9 5 0 9-6 12-8M110 56c9-5 15-13 13-15-4-3-11 9-8 14 3 4 11-3 15-7 2 6 5 8 10 4 2-3 5-8 8-8-2 5-4 10 0 10 4 1 7-6 10-8 2 5 4 6 8 4M170 60c9-18 20-38 25-36 5 3-9 25-7 29 7-6 13-9 19-7 4 3-7 13-15 13 9 3 19 4 27-1 4-3 6-8 9-8-2 5-2 9 1 9 5 0 8-7 12-9-3 6-2 10 2 10 4 0 7-5 10-8 1 6 5 6 9 2 3-3 6-6 10-6-4 4-4 8 0 8 5 0 9-4 12-7'
    ];
    var mk = function (id, key, label, type, icn, tone) { return { id: id, label: label, type: type, val: vals[key], ic: ic(icn, tone), change: function (e) { var n = Object.assign({}, self.g('vals', vals)); n[key] = e.target.value; set({ vals: n, dirty: true, toast: false }); } }; };
    return {
      t: t, offline: offline, name: vals.name, subLine: vals.title + ' · Rossi Renovations',
      cloudIc: ic('cloud', 'amber'), globeIc: ic('globe', 'azure'), bellIc: ic('bell', 'amber'), shieldIc: ic('shield', 'teal'), okIc: ic('check', 'sage'), outIc: ic('user', 'rose'), warnIc: ic('warn', 'amber'),
      periodInd: 'transform: translateX(' + (period * 100) + '%)',
      periods: t.p.map(function (l, i) { return { label: l, on: i === period, style: segStyle(i === period), pick: function () { set({ period: i }); } }; }),
      kpis: [
        { label: t.k[0], value: String(P[0]), sub: P[6], subStyle: 'color: var(--ok)', sep: '' },
        { label: t.k[1], value: String(P[1]), sub: Math.round(P[1] / P[0] * 100) + '% of made', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: t.k[2], value: P[2] + ' %'.trim(), sub: P[7], subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: t.k[3], value: money(P[3]), sub: P[8], subStyle: 'color: var(--ok)', sep: 'border-top: 1px solid var(--line)' },
        { label: t.k[4], value: dot(P[4]) + ' h', sub: 'On site and office', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line); border-top: 1px solid var(--line)' },
        { label: t.k[5], value: String(P[5]), sub: '3 active now', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line); border-top: 1px solid var(--line)' }
      ],
      months: [
        { m: fr ? 'Septembre' : 'September', sent: '12', won: '7', inv: money(41870) },
        { m: fr ? 'Août' : 'August', sent: '10', won: '5', inv: money(37420) },
        { m: fr ? 'Juillet' : 'July', sent: '11', won: '7', inv: money(49160) }
      ],
      fields: [mk('pf-name', 'name', t.name, 'text', 'user', 'violet'), mk('pf-title', 'title', t.jtitle, 'text', 'tag', 'indigo'), mk('pf-phone', 'phone', t.phone, 'tel', 'phone', 'sage'), mk('pf-email', 'email', t.email, 'email', 'mail', 'sky')],
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { return { label: l[1], on: l[0] === lang, style: segStyle(l[0] === lang), pick: function () { set({ lang: l[0] }); } }; }),
      sigPath: sigs[sigV % 2], sigDate: sigV ? (fr ? 'Aujourd’hui' : 'Today') : 'Mar 3, 2026',
      redraw: function () { set({ sigV: sigV + 1, toast: false }); },
      dirty: dirty, saveLabel: offline ? t.saveOff : t.save,
      save: function () { set({ dirty: false, toast: true }); },
      discard: function () { set({ dirty: false, vals: undefined }); },
      toast: toast && !dirty,
      outOpen: outOpen, outSub: t.outSub,
      askOut: function () { set({ out: true }); }, closeOut: function () { set({ out: false }); }
    };
