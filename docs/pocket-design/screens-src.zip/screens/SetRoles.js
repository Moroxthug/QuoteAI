    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly' || ST === 'locked';
    var ROLES = [
      { k: 'owner', name: 'Owner', ic: ['star', 'gold'], people: [['MR', 'tn5', 'Marco Rossi']], access: 'Owner', accessSub: 'Everything, including plan and security', secs: ['Needs you', 'Money', 'Quotes', 'Crew'], tabs: ['Home', 'Quotes', 'Jobs', 'Clients'], sens: [1, 1, 1, 1] },
      { k: 'officeManager', name: 'Office manager', ic: ['building', 'azure'], people: [['CM', 'tn4', 'Carla Mendes']], access: 'Office', accessSub: 'Quotes, jobs, costs and invoicing', secs: ['Needs you', 'Money', 'Today', 'This week'], tabs: ['Home', 'Quotes', 'Invoices', 'Clients'], sens: [0, 1, 1, 1] },
      { k: 'estimator', name: 'Estimator', ic: ['ruler', 'violet'], people: [['BW', 'tn2', 'Ben Walsh']], access: 'Office', accessSub: 'Quotes, jobs, costs and invoicing', secs: ['Quotes to write', 'Site visits', 'Win rate', 'Waiting on clients'], tabs: ['Home', 'Quotes', 'Leads', 'Clients'], sens: [0, 1, 0, 0] },
      { k: 'projectManager', name: 'Project manager', ic: ['list', 'teal'], people: [['HK', 'tn1', 'Hannah Kim']], access: 'Office', accessSub: 'Quotes, jobs, costs and invoicing', secs: ['At risk', 'Active jobs', 'Budget vs actual', 'Change orders'], tabs: ['Home', 'Jobs', 'Schedule', 'Clients'], sens: [0, 1, 1, 0] },
      { k: 'dispatcher', name: 'Dispatcher', ic: ['truck', 'amber'], people: [['OH', 'tn3', 'Omar Haddad']], access: 'Office', accessSub: 'Quotes, jobs, costs and invoicing', secs: ['Crew now', 'Not assigned', 'Tomorrow', 'This week'], tabs: ['Home', 'Schedule', 'Jobs', 'Crew map'], sens: [0, 0, 1, 0] },
      { k: 'bookkeeper', name: 'Bookkeeper', ic: ['bank', 'sage'], people: [['RL', 'tn1', 'Rosa Lima']], access: 'Office', accessSub: 'Quotes, jobs, costs and invoicing', secs: ['To reconcile', 'Receipts', 'HST', 'Coming up'], tabs: ['Home', 'Invoices', 'Books', 'Pay'], sens: [1, 1, 1, 1] },
      { k: 'safety', name: 'Safety coordinator', ic: ['shield', 'rose'], people: [['KT', 'tn4', 'Kevin Tran']], access: 'Viewer', accessSub: 'Read-only, plus certificates and incidents', secs: ['Certificates expiring', 'Incidents', 'Toolbox talks', 'Site inspections'], tabs: ['Home', 'Jobs', 'Team', 'Documents'], sens: [0, 0, 0, 0] },
      { k: 'foreman', name: 'Foreman', ic: ['hammer', 'clay'], people: [['LB', 'tn1', 'Luca Bianchi']], access: 'Foreman', accessSub: 'Jobs and costs on site, the rest read-only', secs: ['Clock', 'Blockers', 'Crew today', 'Tasks'], tabs: ['Home', 'Jobs', 'Schedule', 'Team'], sens: [0, 0, 1, 0] },
      { k: 'crew', name: 'Crew', ic: ['users', 'slate'], people: [['AO', 'tn3', 'Amara Okafor'], ['SM', 'tn5', 'Sofia Marin'], ['DP', 'tn2', 'Dev Patel'], ['JR', 'tn4', 'Jonah Reyes']], access: 'Link', accessSub: 'Personal link, no sign-in', secs: ['Clock', 'Today’s tasks', 'Coming up', 'Your reports'], tabs: ['Today', 'Hours', 'Photos', 'Travel'], sens: [0, 0, 0, 0] }
    ];
    var sel = this.g('role', 'estimator');
    var R = ROLES.filter(function (r) { return r.k === sel; })[0] || ROLES[2];
    var roles = ROLES.map(function (r) {
      var on = r.k === sel, names = r.people.map(function (p) { return p[2].split(' ')[0]; });
      return {
        name: r.name, ic: ic(r.ic[0], r.ic[1]), on: on, cls: on ? 'on' : '',
        who: r.people.length > 1 ? names.slice(0, 2).join(', ') + ' and ' + (names.length - 2) + ' more' : r.people[0][2],
        avs: r.people.slice(0, 2).map(function (p) { return { ini: p[0], tn: p[1] }; }),
        radio: on ? 'background: var(--inv)' : 'box-shadow: inset 0 0 0 1.6px var(--line2)', tick: on ? 'opacity: 1' : 'opacity: 0',
        pick: function () { set({ role: r.k }); }
      };
    });
    var own = this.g('own_' + sel, sel !== 'crew');

    // people with sensitive switches (everyone who signs in, except the owner)
    var PEOPLE = [];
    ROLES.forEach(function (r) { if (r.k === 'owner' || r.k === 'crew') return; r.people.forEach(function (p) { PEOPLE.push({ ini: p[0], tn: p[1], name: p[2], role: r.name, def: r.sens }); }); });
    var pSel = this.g('person', 'BW');
    var person = PEOPLE.filter(function (p) { return p.ini === pSel; })[0] || PEOPLE[1];
    var OVR = { BW: [0, 1, 0, 1] };
    var cur = this.g('sens_' + person.ini, OVR[person.ini] || person.def);
    var LABELS = [['See pay rates', 'card', 'rose'], ['See margins and costs', 'percent', 'violet'], ['Approve time', 'clock', 'teal'], ['Send invoices', 'send', 'azure']];
    var changed = 0;
    var switches = LABELS.map(function (l, i) {
      var on = !!cur[i], diff = !!cur[i] !== !!person.def[i];
      if (diff) changed++;
      return {
        label: l[0], ic: ic(l[1], l[2]), on: on,
        sub: diff ? 'Changed · ' + person.role + ' default is ' + (person.def[i] ? 'on' : 'off') : person.role + ' default',
        subStyle: diff ? 'color: var(--acc-t)' : '',
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var a = self.g('sens_' + person.ini, OVR[person.ini] || person.def).slice(); a[i] = a[i] ? 0 : 1; var o = {}; o['sens_' + person.ini] = a; set(o); }
      };
    });
    return {
      ro: ST === 'readOnly', locked: ST === 'locked', lockIc: ic('lock', 'slate'), tierIc: ic('tier3', 'violet'),
      canEdit: !RO, roles: roles, roleName: R.name, roleFirst: R.people[0][2].split(' ')[0],
      access: R.access, accessSub: R.accessSub,
      secs: R.secs.map(function (t, i) { return { n: String(i + 1), t: t }; }),
      tabs: R.tabs.map(function (t, i) { return { t: t, cls: i ? '' : 'on' }; }),
      dim: ST === 'locked' ? 'opacity: .55' : '',
      ownOn: own, ownTrack: (own ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45' : ''),
      ownKnob: own ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipOwn: function () { if (RO) return; var o = {}; o['own_' + sel] = !self.g('own_' + sel, sel !== 'crew'); set(o); },
      eyeIc: ic('eye', 'indigo'),
      people: PEOPLE.map(function (p) { var on = p.ini === person.ini; return { ini: p.ini, tn: p.tn, first: p.name.split(' ')[0], on: on, cls: on ? 'on' : '', pick: function () { set({ person: p.ini }); } }; }),
      person: person, switches: switches, hasChanged: changed > 0, changedN: changed + ' changed'
    };
