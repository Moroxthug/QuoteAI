    var st = this.props.state || 'default';
    var offline = st === 'offline', emptySt = st === 'empty';
    var f = this.g('f', 'all'), undone = this.g('undone', {}), toast = this.g('toast', null);
    // id, time, group, glyph, tone, title, detail, who, whoKind, cat, action(undo|void|open|none), fixedWord, fixedSt, undoToast
    var D = [
      ['a1', '10 h 12', 'today', 'receipt', 'amber', 'Coût de 212,40 $ ajouté au sous-sol Hart', 'Reçu Home Depot · vis et ruban à joints', 'Règle · Reçus', 'auto', 'money', 'undo', '', '', 'Coût de 212,40 $ retiré du sous-sol Hart.'],
      ['a2', '9 h 58', 'today', 'cal', 'sky', 'Plancher du corridor Okoye déplacé au ven. 2 oct.', 'Dev a reçu un texto avec la nouvelle date', 'Marco · voix', 'you', 'jobs', 'undo', '', '', 'Le plancher Okoye revient au jeu. 1er oct. Dev reçoit un texto.'],
      ['a3', '9 h 41', 'today', 'chat', 'teal', 'Plan de demain envoyé par texto à Luca et Sofia', 'Patio Gill, sur place à 7 h 30', 'Règle · Messages à l’équipe', 'auto', 'msg', 'none', 'Envoyé', 'st-info si-q1', ''],
      ['a4', '8 h 30', 'today', 'bank', 'gold', 'Virement Interac de 1 200,00 $ de Chen inscrit', 'INV-0415 est maintenant payée en partie', 'Marco · écrit', 'you', 'money', 'void', '', '', 'Paiement annulé. INV-0415 revient à 2 480,00 $ dû.'],
      ['a5', '7 h 05', 'today', 'receipt', 'violet', 'Facture INV-0421 préparée pour Harbourfront', 'Facture d’étape 2 sur 4 · 3 210,00 $', 'Règle · Factures', 'auto', 'money', 'open', '', '', ''],
      ['b1', '17 h 47', 'yesterday', 'mail', 'violet', 'Relance envoyée aux Gill pour Q-2026-116', 'Courriel · remise à neuf du patio · 2 980,00 $', 'Règle · Relances', 'auto', 'msg', 'none', 'Ouvert', 'st-acc si-q2', ''],
      ['b2', '15 h 20', 'yesterday', 'list', 'indigo', 'Tâche « Commander la peinture » ajoutée à Marchetti Bakery', 'Tâche pour Luca, pour ven.', 'Marco · voix', 'you', 'jobs', 'none', 'Annulé', 'st-mute' + ' si-x', ''],
      ['b3', '14 h 02', 'yesterday', 'send', 'azure', 'Soumission Q-2026-119 envoyée à Dana Whitfield', '4 131,05 $ · relue avant l’envoi', 'Marco · voix', 'you', 'msg', 'none', 'Envoyée', 'st-info si-q1', ''],
      ['b4', '11 h 15', 'yesterday', 'receipt', 'amber', 'Reçu Rona de 86,14 $ classé à la patio Gill', 'Teinture et pinceaux', 'Règle · Reçus', 'auto', 'money', 'undo', '', '', 'Coût de 86,14 $ retiré de la patio Gill.'],
      ['b5', '8 h 02', 'yesterday', 'bell', 'amber', 'Rappel envoyé à Harbourfront Dental pour INV-0419', 'Texto · 780,00 $ · 3 jours de retard', 'Règle · Rappels de facture', 'auto', 'msg', 'none', 'Envoyé', 'st-info si-q1', '']
    ];
    if (emptySt) D = [];
    var FIL = [['all', 'Tout', function () { return true; }], ['you', 'À votre demande', function (d) { return d[8] === 'you'; }], ['auto', 'Automatique', function (d) { return d[8] === 'auto'; }],
      ['msg', 'Messages', function (d) { return d[9] === 'msg'; }], ['money', 'Argent', function (d) { return d[9] === 'money'; }], ['jobs', 'Travaux', function (d) { return d[9] === 'jobs'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var rows = D.filter(fn);
    var mk = function (d) {
      var u = undone[d[0]], act = d[10];
      var canUndo = !u && (act === 'undo' || act === 'void');
      var word = d[11], stc = d[12];
      if (u) { word = u === 'pending' ? 'Annulation en attente' : (act === 'void' ? 'Annulé' : 'Annulé'); stc = u === 'pending' ? 'st-warn si-clock' : 'st-mute' + ' si-x'; }
      return {
        ic: ic(d[3], d[4]), title: d[5], detail: d[6], time: d[1], who: d[7], whoCls: d[8] === 'auto' ? 'tag-acc' : '',
        cls: (u === 'done' || d[11] === 'Annulé') ? 'undone' : '',
        canUndo: canUndo, undoLabel: act === 'void' ? 'Annuler' : 'Annuler', undoAria: (act === 'void' ? 'Annuler le paiement : ' : 'Annuler : ') + d[5],
        canOpen: act === 'open', href: 'Invoice.dc.html',
        hasSt: !!word && !canUndo, word: word, st: stc,
        undo: function () {
          var n = Object.assign({}, self.g('undone', {})); n[d[0]] = offline ? 'pending' : 'done';
          var tid = Date.now();
          set({ undone: n, toast: { id: d[0], t: tid, b: offline ? 'Enregistré.' : (act === 'void' ? 'Paiement annulé.' : 'Annulé.'), s: offline ? 'Ça se fera à votre retour en ligne.' : d[13] } });
          setTimeout(function () { var t = self.g('toast', null); if (t && t.t === tid) set({ toast: null }); }, 6000);
        }
      };
    };
    var groups = [['today', 'Aujourd’hui', 'mar. 29 sept.'], ['yesterday', 'Hier', 'lun. 28 sept.']].map(function (g) {
      var rs = rows.filter(function (d) { return d[2] === g[0]; });
      return { title: g[1], count: g[2], rows: rs.map(mk), has: rs.length > 0 };
    }).filter(function (g) { return g.has; });
    return {
      offline: offline, hasData: !emptySt,
      pendingCount: '4', hasCount: true,
      kpis: [
        { label: 'Aujourd’hui', value: emptySt ? '0' : '5', sub: emptySt ? 'actions' : '2 demandées', sep: '' },
        { label: 'Ce mois-ci', value: emptySt ? '0' : '86', sub: 'actions', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Annulées', value: emptySt ? '0' : '3', sub: 'ce mois-ci', sep: 'border-left: 1px solid var(--line)' }
      ],
      minUsed: emptySt ? '0' : '142', minTotal: '300 min', minPct: emptySt ? '0%' : '47%',
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: D.filter(x[2]).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, noMatch: !emptySt && groups.length === 0, isEmpty: emptySt, clear: function () { set({ f: 'all' }); },
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '',
      redo: function () { var t = self.g('toast', null); if (!t) return; var n = Object.assign({}, self.g('undone', {})); delete n[t.id]; set({ undone: n, toast: null }); },
      cloudIc: ic('cloud', 'amber'), searchIc: ic('search', 'slate'), orbIc: ic('orb', 'violet'), propIc: ic('bell', 'violet'), permIc: ic('shield', 'indigo')
    };
