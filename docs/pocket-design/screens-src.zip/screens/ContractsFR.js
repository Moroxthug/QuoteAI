    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { draft: ['Brouillon', 'st-mute si-draft'], await: ['En attente', 'st-warn si-clock'], viewed: ['Consulté', 'st-acc si-q2'], signed: ['Signé', 'st-ok si-check'], void: ['Annulé', 'st-bad si-x'], done: ['Terminé', 'st-mute si-check'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // no, client, title, total, status, group, sent, signed, tint
    var data = [
      ['C-2026-034', 'Dana Whitfield', 'Chambres et plafond de salle de bain', 4131.05, 'draft', 'open', 'Rédigé aujourd’hui', '', 0],
      ['C-2026-033', 'Harbourfront Dental', 'Peinture de la réception', 6420.00, 'viewed', 'open', 'Envoyé 24 sept.', 'consulté 26 sept.', 3],
      ['C-2026-032', 'Tom & Lena Hart', 'Ordre de changement 2, fenêtre d’évacuation', 2860.00, 'await', 'open', 'Envoyé 28 sept.', 'non ouvert', 2],
      ['C-2026-029', 'Okoye Condo', 'Plancher du corridor', 2210.00, 'signed', 'signed', 'Envoyé 15 sept.', 'signé 16 sept.', 0],
      ['C-2026-027', 'Tom & Lena Hart', 'Ordre de changement 1, sous-sol', 3955.00, 'signed', 'signed', 'Envoyé 19 sept.', 'signé 20 sept.', 2],
      ['C-2026-025', 'Tom & Lena Hart', 'Finition du sous-sol', 38400.00, 'signed', 'signed', 'Envoyé 28 août', 'signé 29 août', 2],
      ['C-2026-022', 'Marchetti Bakery', 'Moulures de la devanture', 1480.00, 'void', 'closed', 'Envoyé 8 sept.', 'annulé 13 sept.', 1],
      ['C-2026-018', 'Chen Family', 'Rafraîchissement de la salle de lavage', 3300.00, 'done', 'closed', 'Terminé 30 juil.', '', 2]
    ];
    var FIL = [['all', 'Tous', function () { return true; }], ['draft', 'Brouillons', function (s) { return s === 'draft'; }], ['await', 'En attente', function (s) { return s === 'await' || s === 'viewed'; }], ['signed', 'Signés', function (s) { return s === 'signed'; }], ['closed', 'Fermés', function (s) { return s === 'void' || s === 'done'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[0] + ' ' + d[1] + ' ' + d[2]).toLowerCase().indexOf(ql) >= 0); });
    var groups = [['open', 'Signature requise'], ['signed', 'Signés'], ['closed', 'Fermés']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      return { title: g[1], count: rs.length ? rs.length + '' : '', has: rs.length > 0, rows: rs.map(function (d) {
        var ini = d[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
        return { no: d[0], client: d[1], title: d[2], amt: money(d[4] === 'draft' ? d[3] : d[3]), status: S[d[4]][0], st: S[d[4]][1], ini: ini, tn: tints[d[8]], dates: d[6] + (d[7] ? ' · ' + d[7] : '') };
      }) };
    }).filter(function (g) { return g.has; });
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'À signer', value: '3', sub: '1 à vous', subStyle: 'color: var(--warn)', sep: '' },
        { label: 'Signés ce mois‑ci', value: '6 165 $', sub: '2 contrats', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Délai de signature', value: '1,2 j', sub: '↓ 0,4 j', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
