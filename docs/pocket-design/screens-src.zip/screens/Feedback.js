    var P = this.props.state || 'compose';
    var phase = self.g('phase', null) || P;
    var isOffline = P === 'offline';
    var kind = self.g('kind', 'wrong'), logs = self.g('logs', true), reply = self.g('reply', true);
    var marked = self.g('marked', true), hasShot = self.g('shot', true), pen = self.g('pen', false);
    var note = self.g('note', 'The Drywall done milestone shows $12,288, but the quote PDF says $12,290. Which one goes on the invoice?');
    var sw = function (key, val, label, sub) { return { label: label, sub: sub, on: val, track: val ? 'background: var(--acc)' : 'background: var(--track-off)', knob: val ? 'transform: translateX(20px)' : 'transform: translateX(0)', flip: function () { var o = {}; o[key] = !val; set(o); } }; };
    var K = [['wrong', 'Something’s wrong'], ['idea', 'Idea'], ['question', 'Question']];
    var PH = { wrong: 'What happened, and what did you expect?', idea: 'What would make this easier?', question: 'What are you trying to do?' };
    var sending = phase === 'sending';
    return {
      isDone: phase === 'sent', isForm: phase !== 'sent', offline: isOffline && phase !== 'sending',
      busyCls: sending ? 'fb-busy' : '', sending: sending,
      sendLabel: sending ? 'Sending…' : (isOffline ? 'Save and send later' : 'Send'),
      doneTitle: isOffline ? 'Saved, sends later' : 'Thanks, sent',
      doneText: isOffline ? 'It’s on this phone and goes out as soon as you’re back online.' : (reply ? 'We read every note. If we need more, we’ll email marco@rossireno.ca.' : 'We read every note. Thanks for helping us fix it.'),
      logsWord: logs ? 'Attached' : 'Not included', logsSt: logs ? 'st-ok si-check' : 'st-mute si-off',
      okIc: ic(isOffline ? 'cloud' : 'check', isOffline ? 'amber' : 'sage'), cloudIc: ic('cloud', 'amber'),
      penIc: ic('pen', 'violet'), syncIc: ic('sync', 'slate'), photoIc: ic('photo', 'azure'), photoIc2: ic('photo', 'slate'),
      penOn: pen, penCls: pen ? 'on' : '', togglePen: function () { set({ pen: !pen, marked: true }); },
      undo: function () { set({ marked: false }); },
      hasShot: hasShot, noShot: !hasShot, marked: marked && hasShot,
      shotLabel: hasShot ? 'Remove screenshot' : 'Add screenshot', toggleShot: function () { set({ shot: !hasShot }); },
      hint: pen ? 'Draw with your finger. Tap Mark up again when you’re done.' : 'Circle anything that looks off.',
      kinds: K.map(function (k) { var on = k[0] === kind; return { label: k[1], on: on, cls: on ? 'on' : '', pick: function () { set({ kind: k[0] }); } }; }),
      note: note, notePh: PH[kind], onNote: function (e) { set({ note: e.target.value }); },
      switches: [
        sw('logs', logs, 'Include logs', 'App version, phone model and the last 10 minutes of activity. No client details.'),
        sw('reply', reply, 'OK to email me back', 'marco@rossireno.ca')
      ],
      send: function () { if (sending) return; if (isOffline) { set({ phase: 'sent' }); return; } set({ phase: 'sending' }); setTimeout(function () { set({ phase: 'sent' }); }, 1400); },
      again: function () { set({ phase: 'compose', note: '', marked: false }); }
    };
