    var ps = this.props.state || 'default';
    var lang = self.g('lang', 'fr'), shown = self.g('shown', false);
    var name = self.g('name', 'Marco Rossi'), email = self.g('email', 'marco@rossireno.ca'), co = self.g('co', 'Rossi Renovations');
    var pass = self.g('pass', ps === 'weakPassword' ? 'reno24' : 'rossi-reno-24');
    var takenOn = self.g('takenOn', ps === 'emailTaken');
    var T = {
      en: { title: 'Create account', sub: 'Set it up once. Quote from anywhere.', name: 'Your name', email: 'Work email', password: 'Password', company: 'Company name', create: 'Create account', terms1: 'By creating an account you agree to the', terms: 'Terms', and: 'and', privacy: 'Privacy Policy', have: 'Already have an account?', signin: 'Sign in', taken: 'Email already in use',
        s: [['', 'Use 8 characters or more.'], ['Too short.', 'Use 8 characters or more.'], ['Okay.', 'Add a number or symbol to make it stronger.'], ['Good.', 'Hard to guess.'], ['Strong.', 'Hard to guess.']] },
      fr: { title: 'Créer un compte', sub: 'Une seule configuration. Des soumissions de partout.', name: 'Votre nom', email: 'Courriel professionnel', password: 'Mot de passe', company: 'Nom de l’entreprise', create: 'Créer le compte', terms1: 'En créant un compte, vous acceptez les', terms: 'Conditions d’utilisation', and: 'et la', privacy: 'Politique de confidentialité', have: 'Déjà un compte?', signin: 'Se connecter', taken: 'Courriel déjà utilisé',
        s: [['', 'Au moins 8 caractères.'], ['Trop court.', 'Au moins 8 caractères.'], ['Moyen.', 'Ajoutez un chiffre ou un symbole pour le renforcer.'], ['Bon.', 'Difficile à deviner.'], ['Solide.', 'Difficile à deviner.']] }
    };
    var t = T[lang];
    var lvl = 0;
    if (pass.length) {
      if (pass.length < 8) lvl = 1;
      else {
        var extra = /[0-9]/.test(pass) || /[^A-Za-z0-9]/.test(pass);
        lvl = !extra ? 2 : pass.length >= 14 ? 4 : 3;
      }
    }
    var tone = lvl === 1 ? 'bad' : lvl === 2 ? 'warn' : lvl >= 3 ? 'ok' : '';
    var meter = [1, 2, 3, 4].map(function (n) { return { cls: n <= lvl ? tone : '' }; });
    var weak = lvl === 1;
    var closed = ps === 'closed';
    var banner = { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '', link: '', href: '#' };
    if (takenOn) banner = lang === 'en'
      ? { show: true, cls: 'b-bad', ic: ic('mail', 'rose'), title: 'That email already has an account.', text: 'Sign in with it, or use a different email.', link: 'Sign in', href: 'SignIn.dc.html' }
      : { show: true, cls: 'b-bad', ic: ic('mail', 'rose'), title: 'Ce courriel a déjà un compte.', text: 'Connectez-vous ou utilisez un autre courriel.', link: 'Se connecter', href: 'SignIn.dc.html' };
    else if (closed) banner = lang === 'en'
      ? { show: true, cls: 'b-acc', ic: ic('lock', 'violet'), title: 'Sign-ups are closed during the beta.', text: 'Leave your email and we’ll let you in soon.', link: 'Request access', href: '#' }
      : { show: true, cls: 'b-acc', ic: ic('lock', 'violet'), title: 'Les inscriptions sont fermées pendant la bêta.', text: 'Laissez votre courriel et nous vous donnerons accès bientôt.', link: 'Demander l’accès', href: '#' };
    var ok = name.trim() && email.indexOf('@') > 0 && lvl >= 2 && !takenOn && !closed;
    return {
      t: t, banner: banner, name: name, email: email, pass: pass, co: co,
      isEn: lang === 'en', isFr: lang === 'fr', langInd: lang === 'en' ? 'transform: translateX(0)' : 'transform: translateX(100%)',
      enStyle: lang === 'en' ? 'color: var(--ink)' : 'color: var(--muted)', frStyle: lang === 'fr' ? 'color: var(--ink)' : 'color: var(--muted)',
      en: function () { set({ lang: 'en' }); }, fr: function () { set({ lang: 'fr' }); },
      onName: function (e) { set({ name: e.target.value }); },
      onEmail: function (e) { set({ email: e.target.value, takenOn: false }); },
      onPass: function (e) { set({ pass: e.target.value }); },
      onCo: function (e) { set({ co: e.target.value }); },
      taken: takenOn, emailCls: takenOn ? 'su-bad' : '', emailLabel: takenOn ? t.taken : t.email,
      weak: weak, passCls: weak ? 'su-bad' : '',
      shown: shown, notShown: !shown, passType: shown ? 'text' : 'password', showLabel: shown ? 'Masquer le mot de passe' : 'Afficher le mot de passe',
      toggleShow: function () { set({ shown: !self.g('shown', false) }); },
      meter: meter,
      str: { word: t.s[lvl][0], note: t.s[lvl][1], style: lvl === 1 ? 'color: var(--bad)' : lvl === 2 ? 'color: var(--warn)' : lvl >= 3 ? 'color: var(--ok)' : '' },
      canGo: !!ok, cantGo: !ok,
      nudge: function () { var el = document.getElementById(weak || lvl === 0 ? 'su-pass' : takenOn ? 'su-email' : 'su-name'); if (el) el.focus(); },
      nameIc: ic('user', 'violet'), mailIc: ic('mail', 'sky'), keyIc: ic('key', 'violet'), coIc: ic('building', 'indigo')
    };
