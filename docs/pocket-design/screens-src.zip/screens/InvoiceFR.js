    var TOTAL = 2340;
    var claim = this.g('claim', 'open');           // open | denied | done
    var sheet = this.g('sheet', false), menuOpen = this.g('menu', false);
    var amt = this.g('amt', '2 340,00'), method = this.g('method', 'Virement Interac'), ref = this.g('ref', '');
    var receipt = this.g('receipt', true), remOn = this.g('remOn', true);
    var pays = this.g('pays', []), copied = this.g('copied', false), reminded = this.g('reminded', false);
    var fig = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var money = function (n) { return fig(n) + '\u00a0$'; };
    var parse = function (s) { var n = parseFloat(String(s).replace(/,/g, '.').replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    var paid = pays.reduce(function (a, p) { return a + p.n; }, 0);
    var bal = Math.max(0, TOTAL - paid);
    var amtN = parse(amt);
    var over = amtN - bal;
    var status = bal <= 0 ? ['Payée', 'st-ok si-check', 'var(--ok-dot)', 'Payée · 29\u00a0sept.'] : paid > 0 ? ['Payée en partie', 'st-warn si-q3', 'var(--warn-dot)', 'Payée en partie · 9 jours de retard'] : ['En retard', 'st-bad si-alert', 'var(--bad)', 'En retard · 9 jours · consultée le 22\u00a0sept.'];
    var bw = money(bal).split(',');
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var rs = sw(remOn), rc = sw(receipt);
    var closeAll = function () { set({ sheet: false, menu: false }); };
    var openPay = function () { set({ sheet: true, menu: false, amt: bal > 0 ? fig(bal) : '0,00', method: 'Virement Interac' }); };
    var MICON = { 'Virement Interac': ['send', 'violet'], 'Chèque': ['doc', 'stone'], 'Comptant': ['card', 'sage'], 'Carte': ['card', 'azure'], 'Virement bancaire': ['bank', 'teal'], 'Autre': ['dot', 'slate'] };
    var last = pays.length ? pays[pays.length - 1] : null;
    var remRows = [
      ['3 jours avant l’échéance', '17\u00a0sept.', 'Envoyé', 'st-info si-q1'],
      ['À la date d’échéance', '20\u00a0sept.', 'Envoyé', 'st-info si-q1'],
      ['7 jours de retard', '27\u00a0sept.', 'Envoyé', 'st-info si-q1'],
      ['14 jours de retard', '4\u00a0oct.', bal <= 0 ? 'Annulé' : (remOn ? 'Planifié' : 'Désactivé'), bal <= 0 || !remOn ? 'st-mute' : 'st-info'],
      ['30 jours de retard', '20\u00a0oct.', bal <= 0 ? 'Annulé' : (remOn ? 'Planifié' : 'Désactivé'), bal <= 0 || !remOn ? 'st-mute' : 'st-info']
    ];
    var act = [];
    if (last) act.push(['Paiement enregistré', 'Aujourd’hui', money(last.n) + ' par ' + last.method.toLowerCase().replace('interac', 'Interac') + (last.receipt ? ' · reçu envoyé par courriel' : '')]);
    if (claim === 'denied') act.push(['Lena avisée que rien n’est arrivé', 'Aujourd’hui', 'Envoyé par texto']);
    act = act.concat([
      ['Lena dit avoir payé', '8\u00a0h\u00a014', '2\u00a0340\u00a0$ par virement Interac, depuis le lien du client'],
      ['Rappel envoyé', '27\u00a0sept.', 'Courriel et texto · 7 jours de retard'],
      ['Consultée par Lena Hart', '22\u00a0sept.', 'A ouvert le lien du client sur son téléphone'],
      ['Rappel envoyé', '20\u00a0sept.', 'Courriel · échéance aujourd’hui'],
      ['Envoyée à Tom & Lena Hart', '5\u00a0sept.', 'Courriel à lena.hart@gmail.com'],
      ['Créée à partir du chantier', '5\u00a0sept.', 'Étape 2 sur 4 · gypse terminé à 60\u00a0%']
    ]);
    return {
      stLine: status[3], stDot: 'background: ' + status[2], stWord: status[0], stCls: status[1],
      balWhole: bw[0], balCents: ',' + bw[1], balance: money(bal),
      paid: money(paid), paidColor: paid > 0 ? 'color: var(--ok)' : '', paidOf: money(paid) + ' sur 2\u00a0340,00\u00a0$',
      paidBar: 'width: ' + Math.max(0, Math.min(100, paid / TOTAL * 100)).toFixed(1) + '%; background: var(--ok-dot)',
      claimOpen: claim === 'open' && bal > 0, claimDenied: claim === 'denied' && bal > 0,
      confirmClaim: function () { set({ sheet: true, amt: '2 340,00', method: 'Virement Interac', ref: 'Interac de Lena Hart' }); },
      denyClaim: function () { set({ claim: 'denied' }); }, undoClaim: function () { set({ claim: 'open' }); },
      recorded: !!last, recordedMsg: last ? money(last.n) + ' par ' + last.method.toLowerCase().replace('interac', 'Interac') : '', receiptMsg: last && last.receipt ? ' · reçu envoyé à Lena par courriel' : '',
      claimIc: ic('send', 'violet'), okIc: ic('check', 'sage'), linkIc: ic('link', 'azure'), cardIc: ic('card', 'slate'),
      quick: [
        { label: 'Renvoyer', ic: ic('send', 'violet'), go: function () {} },
        { label: reminded ? 'Relancée' : 'Relancer', ic: ic('bell', 'amber'), go: function () { set({ reminded: true }); } },
        { label: 'PDF', ic: ic('doc', 'azure'), go: function () {} },
        { label: 'Note de crédit', ic: ic('receipt', 'rose'), go: function () {} }
      ],
      lines: [
        { name: 'Pose de gypse, sous-sol', amt: '1\u00a0480,00\u00a0$', detail: '1\u00a0850 pi² · panneaux, vis, cornières', sep: '' },
        { name: 'Tirage de joints et première couche', amt: '590,80\u00a0$', detail: 'Murs et plafond · 2 jours', sep: 'border-top: 1px solid var(--line)' }
      ],
      copyLabel: copied ? 'Copié' : 'Copier le lien', copyLink: function () { set({ copied: true }); },
      payments: pays.map(function (p) { var m = MICON[p.method] || MICON.Other; return { method: p.method, meta: '29\u00a0sept. 2026' + (p.ref ? ' · ' + p.ref : ''), amt: money(p.n), receipt: p.receipt ? 'Reçu envoyé' : 'Sans reçu', ic: ic(m[0], m[1]) }; }),
      noPayments: pays.length === 0,
      remOn: remOn, remTrack: rs.t, remKnob: rs.k, toggleRem: function () { set({ remOn: !remOn }); },
      remLabel: bal <= 0 ? 'Tous arrêtés' : (remOn ? 'Prochain le 4\u00a0oct.' : 'En pause'),
      reminders: remRows.map(function (r) { return { when: r[0], date: r[1], status: r[2], st: r[3], fade: r[3] === 'st-mute' ? 'opacity: .6' : '' }; }),
      activity: act.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], dot: i === 0 ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === act.length - 1 ? 'display: none' : '' }; }),
      primaryLabel: bal > 0 ? 'Enregistrer un paiement' : 'Envoyer le reçu',
      openPay: openPay, openMenu: function () { set({ menu: true, sheet: false }); }, closeAll: closeAll,
      sheetOpen: sheet, menuOpen: menuOpen,
      amt: amt, onAmt: function (e) { set({ amt: e.target.value }); }, fillBalance: function () { set({ amt: fig(bal) }); },
      ref: ref, onRef: function (e) { set({ ref: e.target.value }); },
      overpay: over > 0.004, overBy: money(over > 0 ? over : 0),
      amtRing: over > 0.004 ? 'box-shadow: 0 0 0 1.5px var(--warn-dot)' : 'box-shadow: 0 0 0 1px var(--line2)',
      methods: ['Virement Interac', 'Chèque', 'Comptant', 'Carte', 'Virement bancaire', 'Autre'].map(function (m) { var on = m === method; return { label: m, on: on, cls: on ? 'on' : '', pick: function () { set({ method: m }); } }; }),
      receipt: receipt, rcTrack: rc.t, rcKnob: rc.k, toggleReceipt: function () { set({ receipt: !receipt }); },
      saveLabel: amtN > 0 ? 'Enregistrer ' + money(amtN) : 'Entrez un montant',
      saveStyle: amtN > 0 ? '' : 'opacity: .4;',
      savePay: function () { if (amtN <= 0) return; set({ pays: pays.concat([{ n: amtN, method: method, ref: ref, receipt: receipt }]), sheet: false, claim: 'done' }); },
      menu: [
        { label: 'Renvoyer', sub: 'Par courriel et texto aux Hart', ic: ic('send', 'violet'), style: '' },
        { label: 'Copier le lien du client', sub: 'Ou ouvrir sa vue', ic: ic('link', 'azure'), style: '' },
        { label: 'Télécharger le PDF', sub: 'INV-0412.pdf', ic: ic('doc', 'azure'), style: '' },
        { label: 'Note de crédit', sub: 'Réduire le montant dû par les Hart', ic: ic('receipt', 'rose'), style: '' },
        { label: 'Archiver', sub: 'Masquer de la liste', ic: ic('box', 'stone'), style: '' },
        { label: 'Annuler la facture', sub: 'Garde le numéro, annule le montant', ic: ic('warn', 'clay'), style: 'color: var(--bad)' }
      ]
    };
