    var q = self.g('q', ''), t = self.g('t', 'all');
    var ql = q.trim().toLowerCase();
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var ini = function (s) { return s.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); };
    var QS = { draft: ['Brouillon', 'st-mute si-draft'], sent: ['Envoyée', 'st-info si-q1'], viewed: ['Consultée', 'st-acc si-q2'], accepted: ['Acceptée', 'st-ok si-check'], declined: ['Refusée', 'st-bad si-x'], expired: ['Expirée', 'st-mute si-off'] };
    var ALL = [];
    [['Q-2026-119', 'Dana Whitfield', 'Chambres et plafond de salle de bain', 4131.05, 'draft'], ['Q-2026-118', 'Priya Nair', 'Dosseret de cuisine', 1865.10, 'viewed'], ['Q-2026-117', 'Harbourfront Dental', 'Peinture de la réception', 6420, 'sent'], ['Q-2026-116', 'Gill Residence', 'Remise à neuf du patio', 2980, 'sent'], ['Q-2026-114', 'Tom & Lena Hart', 'Ordre de changement, sous-sol', 3955, 'accepted'], ['Q-2026-112', 'Okoye Condo', 'Plancher du corridor', 2210, 'accepted'], ['Q-2026-110', 'Marchetti Bakery', 'Moulures de la devanture', 1480, 'declined'], ['Q-2026-108', 'Chen Family', 'Rafraîchissement de la salle de lavage', 3300, 'expired'], ['Q-2026-107', 'Tom & Lena Hart', 'Finition du sous-sol', 38400, 'accepted']]
      .forEach(function (d) { ALL.push({ type: 'quotes', title: d[1], sub: d[0] + ' · ' + d[2], key: d[0] + ' ' + d[1] + ' ' + d[2], amt: money(d[3]), st: QS[d[4]], ic: ['doc', 'violet'], href: 'Quote.dc.html' }); });
    [['Dana Whitfield', '17 Castle Frank Cres, Toronto'], ['Priya Nair', '212 Dovercourt Rd, Toronto'], ['Tom & Lena Hart', '48 Galloway Rd, Scarborough'], ['Harbourfront Dental', 'Queens Quay W, Toronto'], ['Gill Residence', 'Etobicoke'], ['Okoye Condo', 'Liberty Village, Toronto'], ['Marchetti Bakery', 'College St, Toronto'], ['Chen Family', 'North York']]
      .forEach(function (d, n) { ALL.push({ type: 'clients', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], av: ini(d[0]), tn: ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'][n % 5], href: 'Client.dc.html' }); });
    [['Finition du sous-sol', 'Tom & Lena Hart · 64 % · étape du gypse', ['Actif', 'st-ok si-live'], 'house', 'teal'], ['Plancher du corridor', 'Okoye Condo · début le 5 oct.', ['Planification', 'st-info si-q1'], 'cone', 'amber'], ['Peinture de la cuisine', 'Chen Family · terminé le 30 août', ['Terminé', 'st-mute si-check'], 'house', 'slate'], ['Remise à neuf du patio', 'Gill Residence · en attente de la météo', ['En pause', 'st-warn si-pause'], 'cone', 'amber']]
      .forEach(function (d) { ALL.push({ type: 'jobs', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], st: d[2], ic: [d[3], d[4]], href: 'Job.dc.html' }); });
    [['INV-0412', 'Tom & Lena Hart', 2340, ['9 jours de retard', 'st-bad']], ['INV-0419', 'Harbourfront Dental', 780, ['3 jours de retard', 'st-bad']], ['INV-0417', 'Chen Family', 1650, ['À confirmer', 'st-warn si-clock']], ['INV-0421', 'Okoye Condo', 2210, ['Payée', 'st-ok si-check']], ['INV-0415', 'Tom & Lena Hart', 11520, ['Payée', 'st-ok si-check']]]
      .forEach(function (d) { ALL.push({ type: 'invoices', title: d[0], sub: d[1], key: d[0] + ' ' + d[1] + (d[3][1] === 'st-bad' ? ' en retard' : ''), amt: money(d[2]), st: d[3], ic: ['receipt', d[3][1] === 'st-bad' ? 'clay' : 'amber'], href: 'Invoice.dc.html' }); });
    [['Réglages', 'Langue, apparence, notifications', 'gear', 'slate', 'Settings.dc.html'], ['Notifications', '6 non lues', 'bell', 'violet', 'Notifications.dc.html'], ['Menu', 'Profil, entreprise, forfait', 'list', 'slate', 'Menu.dc.html'], ['Équipe', 'Utilisateurs et équipe de chantier', 'users', 'lilac', 'Team.dc.html'], ['Liste de prix', 'Vos articles et tarifs', 'tag', 'sage', '#'], ['Conformité', 'Échéances fiscales et de licences', 'shield', 'teal', '#'], ['Applications connectées', 'QuickBooks, Google Agenda, Gmail', 'link', 'azure', '#'], ['Accueil', 'Aujourd’hui, finances et chantiers', 'house', 'violet', 'SmartHome.dc.html']]
      .forEach(function (d) { ALL.push({ type: 'pages', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], ic: [d[2], d[3]], href: d[4] }); });
    var TY = [['all', 'Tout'], ['quotes', 'Soumissions'], ['clients', 'Clients'], ['jobs', 'Chantiers'], ['invoices', 'Factures'], ['pages', 'Pages']];
    var hits = ql ? ALL.filter(function (x) { return x.key.toLowerCase().indexOf(ql) >= 0; }) : [];
    var mk = function (x) {
      var i = ql ? x.title.toLowerCase().indexOf(ql) : -1;
      var a = i >= 0 ? x.title.slice(0, i) : x.title, b = i >= 0 ? x.title.slice(i, i + ql.length) : '', c = i >= 0 ? x.title.slice(i + ql.length) : '';
      return { a: a, b: b, c: c, hlc: b ? 'sr-hl' : '', title: x.title, sub: x.sub, href: x.href, isAv: !!x.av, isIc: !x.av, ini: x.av, tn: x.tn, ic: x.ic ? ic(x.ic[0], x.ic[1]) : ic('dot', 'slate'),
        hasAmt: !!x.amt, amt: x.amt, hasSt: !!x.st, st: x.st ? x.st[1] : '', status: x.st ? x.st[0] : '', chev: !x.amt && !x.st };
    };
    var groups = TY.slice(1).filter(function (ty) { return t === 'all' || t === ty[0]; }).map(function (ty) {
      var rs = hits.filter(function (x) { return x.type === ty[0]; });
      var lim = t === 'all' ? 3 : 99;
      return { title: ty[1], n: rs.length, rows: rs.slice(0, lim).map(mk), more: rs.length > lim, pick: function () { set({ t: ty[0] }); } };
    }).filter(function (g) { return g.n > 0; });
    var RQ = self.g('rq', ['hart', 'dosseret', 'en retard', 'Harbourfront']);
    return {
      q: q, hasQ: q.length > 0, noQ: !ql, none: !!ql && groups.length === 0,
      onQ: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', t: 'all' }); var el = document.getElementById('sr-q'); if (el) el.focus(); },
      types: TY.map(function (ty) { var on = ty[0] === t; var c = ty[0] === 'all' ? hits.length : hits.filter(function (x) { return x.type === ty[0]; }).length; return { label: ty[1], on: on, cls: on ? 'on' : '', count: c, showCnt: !!ql, pick: function () { set({ t: ty[0] }); } }; }),
      groups: groups, emptyIc: ic('search', 'slate'),
      recentQ: RQ.map(function (r) { return { label: r, pick: function () { set({ q: r }); } }; }),
      clearRecent: function () { set({ rq: [] }); },
      recent: [
        { title: 'Dana Whitfield', sub: 'Q-2026-119 · Chambres et plafond de salle de bain', kind: 'Soumission', isIc: true, isAv: false, ic: ic('doc', 'violet'), href: 'Quote.dc.html' },
        { title: 'Finition du sous-sol', sub: 'Tom & Lena Hart · 64 %', kind: 'Chantier', isIc: true, isAv: false, ic: ic('house', 'teal'), href: 'Job.dc.html' },
        { title: 'INV-0412', sub: 'Tom & Lena Hart · 2 340,00 $', kind: 'Facture', isIc: true, isAv: false, ic: ic('receipt', 'clay'), href: 'Invoice.dc.html' },
        { title: 'Harbourfront Dental', sub: 'Queens Quay W, Toronto', kind: 'Client', isIc: false, isAv: true, ini: 'HD', tn: 'tn3', ic: ic('dot', 'slate'), href: 'Client.dc.html' }
      ]
    };
