    var P = this.props.state || 'ask';
    var MK = 'mode_' + P;
    var mode = this.g(MK, P), busy = this.g('busy', false);
    var setMode = function (m) { var o = { busy: false }; o[MK] = m; set(o); };
    var isAsk = mode === 'ask', isOn = mode === 'on', isOff = mode === 'off';
    var allow = function () {
      if (self.g('busy', false)) return;
      set({ busy: true });
      setTimeout(function () { setMode('on'); }, 900);
    };
    var title = isOn ? 'Your location is on' : isOff ? 'Location is off' : 'Share where you are while you work';
    var lede = isOn ? 'Only while you’re on the clock. It turns off by itself when you clock out.'
      : isOff ? 'The office sees “Location off” next to your name. Nothing about you is tracked.'
      : 'Shared only while you’re on the clock, so Luca can plan the day and tell clients when you’ll arrive.';
    return {
      stOn: ['st-ok', 'si-live'].join(' '), stOff: ['st-mute', 'si-off'].join(' '),
      isAsk: isAsk, isOn: isOn, isOff: isOff, title: title, lede: lede,
      youCls: isOn ? 'live' : (isOff ? 'dim' : ''),
      routePath: 'M120 102C150 90 160 80 176 60',
      routeStyle: isOn ? 'opacity: 1' : 'opacity: 0',
      siteIc: ic('house', 'clay'),
      allowLabel: busy ? 'Turning on…' : (isOff ? 'Share again' : 'Allow while on the clock'),
      allow: allow,
      notNow: function () { setMode('off'); },
      stop: function () { setMode('off'); },
      askRows: [
        { ic: ic('pin', 'rose'), t: 'Where you are, every few minutes', s: 'Shown as “On site” or “On the way, 14 min”', who: false },
        { ic: ic('clock', 'teal'), t: 'Only between clock in and clock out', s: 'Never on breaks you log, after hours or on days off', who: false },
        { ic: ic('eye', 'violet'), t: 'Seen by Marco Rossi and Luca Bianchi', s: 'Not by clients, not by the rest of the crew', who: true },
        { ic: ic('lock', 'slate'), t: 'Kept 30 days, then deleted', s: 'Used for arrival times and your travel hours', who: false }
      ],
      onRows: [
        { ic: ic('clock', 'teal'), t: 'Pauses on your breaks', s: 'Lunch 12:00–12:30 is not shared' },
        { ic: ic('truck', 'azure'), t: 'Counts your travel', s: 'Drive time between sites goes on your hours' },
        { ic: ic('eye', 'violet'), t: 'Only Marco and Luca', s: 'Clients get an arrival time, never a map' }
      ],
      offRows: [
        { ic: ic('pin', 'slate'), t: 'Clock in still checks once', s: 'To confirm you’re at the site. That’s all.' },
        { ic: ic('truck', 'slate'), t: 'Log travel by hand', s: 'From the ⋯ menu on today’s page' },
        { ic: ic('gear', 'slate'), t: 'Your phone setting', s: 'Location for this link is set to “Ask”' }
      ]
    };
