    var t = this.g('t', 'overview');
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { maximumFractionDigits: 0 }); };
    var money2 = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var TABS = [['overview', 'Overview'], ['schedule', 'Schedule'], ['co', 'Change orders'], ['costs', 'Costs'], ['inv', 'Invoices'], ['team', 'Team'], ['photos', 'Photos'], ['msg', 'Messages'], ['docs', 'Documents'], ['ask', 'Assistant']];
    // blockers
    var sorted = this.g('sorted', {});
    var BL = [
      ['b1', 'AO', 'tn3', 'Amara Okafor', '2 h ago', 'Question', 'st-warn si-clock', 'The outlet box behind the bar is 2 in off the plan. Move it, or board around it?'],
      ['b2', 'SM', 'tn2', 'Sofia Marin', 'Yesterday', 'Material', 'st-info si-dot', 'We need 6 more sheets of 1/2 in moisture-resistant board for the bathroom wall.']
    ];
    var blocks = BL.filter(function (b) { return !sorted[b[0]]; }).map(function (b) {
      return { ini: b[1], tn: b[2], who: b[3], when: b[4], kind: b[5], st: b[6], text: b[7], sort: function () { var o = Object.assign({}, sorted); o[b[0]] = true; set({ sorted: o }); } };
    });
    // budget
    var BUD = [['Materials', 6840, 9200], ['Labour', 7420, 11800], ['Subcontractors', 2700, 5400], ['Permits and fees', 850, 850], ['Equipment', 410, 600], ['Misc', 160, 650]];
    var budget = BUD.map(function (b) {
      var r = b[1] / b[2];
      return { name: b[0], spent: money(b[1]), bud: money(b[2]), w: Math.min(100, Math.round(r * 100)) + '%', fill: r > 1 ? 'background: var(--bad)' : (r > 0.85 && b[0] !== 'Permits and fees') ? 'background: var(--warn-dot)' : '' };
    });
    // permits
    var added = this.g('permitAdded', false);
    var PER = [
      ['Building permit', 'City of Toronto · 26 148220 BLD', 'Issued', 'st-info si-q1', 'shield', 'azure'],
      ['Electrical permit', 'ESA · filed by Jonah Reyes', 'Issued', 'st-info si-q1', 'shield', 'azure'],
      ['Insulation inspection', 'Passed Sep 24 · inspector D. Moore', 'Passed', 'st-ok si-check', 'check', 'sage'],
      ['Final inspection', 'Book 48 h ahead · after paint', 'Not booked', 'st-warn si-clock', 'cal', 'amber']
    ];
    if (added) PER.push(['Plumbing permit', 'City of Toronto · wet bar sink', 'To apply', 'st-mute si-draft', 'shield', 'slate']);
    // tasks
    var td = this.g('td', { t1: true, t2: true, t3: true, t4: true, t5: false, t6: false });
    var TK = [['t1', 'Hang board, rec room and bedroom', ''], ['t2', 'Hang board, bathroom (moisture-resistant)', ''], ['t3', 'Tape and first coat', ''], ['t4', 'Corner bead at the bar niche', 'From the site · Amara'], ['t5', 'Second coat, rec room', ''], ['t6', 'Sand and prime', 'From the site · Sofia']];
    var tasks = TK.map(function (k) {
      var on = !!td[k[0]];
      return { name: k[1], site: k[2], on: on, cls: on ? 'on' : '', style: on ? 'color: var(--muted); text-decoration: line-through' : '', tog: function () { var o = Object.assign({}, td); o[k[0]] = !on; set({ td: o }); } };
    });
    var nDone = TK.filter(function (k) { return td[k[0]]; }).length;
    var MI = [
      ['Demolition and framing', 'Sep 8 – 12', '5 of 5 tasks', 'done'],
      ['Electrical and plumbing rough-in', 'Sep 14 – 18', '6 of 6 tasks', 'done'],
      ['Insulation and vapour barrier', 'Sep 21 – 24', '4 of 4 tasks', 'done'],
      ['Drywall', 'Sep 25 – Oct 2', nDone + ' of 6 tasks', 'cur'],
      ['Paint and trim', 'Oct 5 – 16', '7 tasks', 'up'],
      ['Flooring, bar and final clean', 'Oct 19 – 30', '8 tasks', 'up']
    ];
    var miles = MI.map(function (m, i) {
      var s = m[3];
      return {
        title: m[0], dates: m[1], tasks: m[2], done: s === 'done', open: s === 'cur',
        dot: s === 'done' ? 'dn' : s === 'cur' ? 'cu' : 'up',
        st: s === 'done' ? 'st-mute si-check' : s === 'cur' ? 'st-ok si-live' : 'st-mute', status: s === 'done' ? 'Done' : s === 'cur' ? 'In progress' : 'Upcoming',
        titleStyle: s === 'up' ? 'color: var(--t2)' : '', lnStyle: i === MI.length - 1 ? 'visibility: hidden' : s === 'done' ? 'background: var(--ok-dot)' : ''
      };
    });
    // crew weeks: j = this job, o = other, x = clash, '' = free
    var W = { AO: 'jjjjjjjjjjooooooo...', SM: 'jjjjjjjjj.jjjjjjjjjj', LB: 'oooo.xjjjjjjjjjooooo', JR: '..j.......o....jj...' };
    var TN = { AO: 'tn3', SM: 'tn2', LB: 'tn1', JR: 'tn4' };
    var crewWeeks = Object.keys(W).map(function (k) {
      var weeks = [0, 1, 2, 3].map(function (w) { return { days: W[k].slice(w * 5, w * 5 + 5).split('').map(function (c) { return { c: c === '.' ? '' : c }; }) }; });
      return { ini: k, tn: TN[k], weeks: weeks };
    });
    // costs
    var conf = this.g('conf', {});
    var RV = [['r1', 'Home Depot', 'Materials · 96% sure', 412.18, 'receipt', 'amber'], ['r2', 'RONA', 'Materials · 91% sure', 143.62, 'receipt', 'amber'], ['r3', 'Ace Tool Rental', 'Equipment · 88% sure', 56.60, 'receipt', 'slate']];
    var review = RV.filter(function (r) { return !conf[r[0]]; }).map(function (r) {
      return { vendor: r[1], meta: r[2], amt: money2(r[3]), ic: ic(r[4], r[5]), ok: function () { var o = Object.assign({}, conf); o[r[0]] = true; set({ conf: o }); } };
    });
    var EN = [
      ['Drywall 1/2 in, 48 sheets', 'Materials · Receipt · Sep 23', 1248.00, 'box', 'amber'],
      ['Amara Okafor, 32 h', 'Labour · Time · this week', 1120.00, 'clock', 'teal'],
      ['Jonah Reyes, rough-in', 'Subcontractors · Bank line · Sep 18', 2700.00, 'bank', 'clay'],
      ['Building permit', 'Permits and fees · Manual · Sep 2', 850.00, 'shield', 'azure'],
      ['Drywall lift, 1 week', 'Equipment · Equipment use · Sep 25', 210.00, 'truck', 'slate'],
      ['Site trips, 146 km', 'Misc · Travel · September', 97.00, 'pin', 'stone']
    ];
    // invoices
    var made = this.g('made', false), reminded = this.g('reminded', false);
    var terms = [
      ['Term 1 · Deposit', '20% · INV-0388 · paid Aug 31', 7680, 'Paid', 'st-ok si-check'],
      ['Term 2 · Rough-in done', '25% · INV-0401 · paid Sep 21', 9600, 'Paid', 'st-ok si-check'],
      ['Change order CO-01', 'INV-0412 · due Sep 20', 2340, '9 days late', 'st-bad'],
      ['Term 3 · Drywall done', made ? '20% · INV-0421 draft' : '20% · due when the milestone is done', 7680, made ? 'Draft' : '', made ? 'st-mute' : '', !made],
      ['Term 4 · Paint and trim', '20% · Oct 16', 7680, 'Open', 'st-mute si-dot'],
      ['Term 5 · Completion', '15% · Oct 30 · less 10% holdback', 5760, 'Open', 'st-mute si-dot'],
      ['Holdback release', '10% · Dec 14, after the lien period', 3840, 'Held', 'st-warn si-pause']
    ].map(function (x) {
      return { name: x[0], meta: x[1], amt: money(x[2]), status: x[3], st: x[4], action: !!x[5], noAction: !x[5], actLabel: 'Create', act: function () { set({ made: true }); } };
    });
    // team
    var appr = this.g('appr', {});
    var HR = [['h1', 'AO', 'tn3', 'Amara Okafor', '8.0 h', 'Mon, Sep 28 · 7:31 – 15:34 · on site', ''], ['h2', 'SM', 'tn2', 'Sofia Marin', '7.5 h', 'Mon, Sep 28 · 8:02 – 15:40 · on site', ''], ['h3', 'AO', 'tn3', 'Amara Okafor', '4.0 h', 'Sat, Sep 26 · 180 m off site', 'color: var(--warn)']];
    var hours = HR.map(function (h) {
      var d = !!appr[h[0]];
      return { ini: h[1], tn: h[2], name: h[3], hrs: h[4], meta: h[5], metaStyle: h[6], pending: !d, done: d, ok: function () { var o = Object.assign({}, appr); o[h[0]] = true; set({ appr: o }); } };
    });
    var crew = [['AO', 'tn3', 'Amara Okafor', 'Drywall · lead on this job', '96 h'], ['SM', 'tn2', 'Sofia Marin', 'Apprentice', '71.5 h'], ['DP', 'tn5', 'Dev Patel', 'Carpenter · framing done', '48 h'], ['JR', 'tn4', 'Jonah Reyes', 'Electrician · subcontractor', '22 h'], ['LB', 'tn1', 'Luca Bianchi', 'Painter lead · starts Oct 5', '0 h']].map(function (c) { return { ini: c[0], tn: c[1], name: c[2], role: c[3], hrs: c[4] }; });
    // photos
    var sel = this.g('sel', [1, 4, 5]);
    var PH = [['Sep 28', 'photo', 'violet', 'p3'], ['Sep 28', 'house', 'stone', 'p0'], ['Sep 28', 'ruler', 'azure', 'p1'], ['Sep 25', 'hammer', 'clay', 'p5'], ['Sep 25', 'photo', 'sage', 'p4'], ['Sep 24', 'check', 'teal', 'p4'], ['Sep 22', 'cone', 'amber', 'p5'], ['Sep 18', 'bars', 'indigo', 'p1'], ['Sep 18', 'photo', 'slate', 'p2'], ['Sep 12', 'box', 'gold', 'p0'], ['Sep 10', 'house', 'sky', 'p1'], ['Sep 8', 'photo', 'rose', 'p3']];
    var photos = PH.map(function (p, i) {
      var on = sel.indexOf(i) >= 0;
      return { cap: p[0], ic: ic(p[1], p[2]), on: on, cls: p[3] + (on ? ' sel' : ''), label: 'Photo from ' + p[0], tog: function () { set({ sel: on ? sel.filter(function (x) { return x !== i; }) : sel.concat([i]) }); } };
    });
    var docs = [['Contract C-2026-014', 'Signed by Tom and Lena · Aug 28', 'doc', 'violet'], ['Change order CO-01', 'Signed Sep 19', 'pen', 'indigo'], ['Quote Q-2026-107', 'Accepted Aug 28', 'file', 'slate'], ['Invoices', '3 sent · 1 draft', 'card', 'teal'], ['Receipts', '24 files', 'receipt', 'amber'], ['Building permit', 'PDF · City of Toronto', 'shield', 'azure']].map(function (d) { return { name: d[0], meta: d[1], ic: ic(d[2], d[3]) }; });
    var PRI = { overview: 'Record progress', schedule: 'Record progress', co: 'New change order', costs: 'Scan a receipt', inv: made ? 'Send INV-0421' : 'Create term 3 invoice', team: 'Log hours', photos: sel.length ? 'Share ' + sel.length + ' with the client' : 'Take a photo', msg: 'Message the client', docs: 'Share a document', ask: 'Ask the assistant' };
    var omwSent = this.g('omw', false);
    return {
      tabs: TABS.map(function (x) { var on = x[0] === t; return { label: x[1], cls: on ? 'on' : '', cur: on ? 'page' : 'false', pick: function () { set({ t: x[0] }); } }; }),
      tOverview: t === 'overview', tSchedule: t === 'schedule', tCO: t === 'co', tCosts: t === 'costs', tInv: t === 'inv', tTeam: t === 'team', tPhotos: t === 'photos', tMsg: t === 'msg', tDocs: t === 'docs', tAsk: t === 'ask',
      omw: function () { set({ omw: !omwSent }); }, omwLabel: omwSent ? 'ETA sent' : 'On my way',
      omwIc: ic('send', 'teal'), camIc: ic('camera', 'indigo'), micIc: ic('mic', 'violet'),
      blocks: blocks, hasBlocks: blocks.length > 0, noBlocks: blocks.length === 0, blockCount: blocks.length ? blocks.length + ' open' : 'All sorted', okIc: ic('check', 'sage'),
      today: [
        { ini: 'AO', tn: 'tn3', name: 'Amara Okafor', what: 'Drywall · second coat', time: '7:30 – 15:30', status: 'On site', st: 'st-ok' },
        { ini: 'SM', tn: 'tn2', name: 'Sofia Marin', what: 'Drywall · sanding, bedroom', time: '8:00 – 16:00', status: 'On site', st: 'st-ok' },
        { ini: 'JR', tn: 'tn4', name: 'Jonah Reyes', what: 'Panel labels · 1 h', time: 'ETA 10:40', status: 'En route', st: 'st-info' }
      ],
      nextIc: ic('hammer', 'violet'), budget: budget,
      permits: PER.map(function (p) { return { name: p[0], meta: p[1], status: p[2], st: p[3], ic: ic(p[4], p[5]) }; }),
      suggest: !added, addPermit: function () { set({ permitAdded: true }); }, orbIc: ic('orb', 'violet'),
      notes: [
        { text: 'Bar niche goes 6 in deeper. Confirmed with Tom on site.', meta: 'Typed · Marco · Sep 22', ic: ic('pen', 'slate') },
        { text: 'Leave an access panel for the cleanout under the stairs.', meta: 'Dictated · Amara · yesterday', ic: ic('mic', 'violet') },
        { text: 'Panel schedule: circuits 14 and 16 feed the basement.', meta: 'From a photo · Jonah · Sep 18', ic: ic('camera', 'indigo') }
      ],
      miles: miles, tasks: tasks, crewWeeks: crewWeeks, warnIc: ic('warn', 'rose'),
      cos: [
        { no: 'CO-01', title: 'Wet bar rough-in and niche', meta: '+3 days · signed Sep 19', amt: '$3,955', status: 'Signed', st: 'st-ok' },
        { no: 'CO-02', title: 'Soundproof ceiling, rec room', meta: '+2 days · sent Sep 27', amt: '$1,840', status: 'Waiting', st: 'st-info' },
        { no: 'CO-3', title: 'Pot lights, family room', meta: '+1 day · sent Sep 29', amt: '$1,120', status: 'To sign', st: 'st-warn si-clock' }
      ],
      scanIc: ic('camera', 'amber'), review: review, hasReview: review.length > 0, noReview: review.length === 0, reviewCount: review.length ? review.length + ' receipts' : 'Done',
      entries: EN.map(function (e) { return { name: e[0], meta: e[1], amt: money2(e[2]), ic: ic(e[3], e[4]) }; }),
      terms: terms, remind: function () { set({ reminded: true }); }, remindLabel: reminded ? 'Sent' : 'Remind',
      hours: hours, approveAll: function () { set({ appr: { h1: true, h2: true, h3: true } }); }, crew: crew, pinIc: ic('pin', 'rose'),
      photos: photos, hasSel: sel.length > 0, photoHead: sel.length ? sel.length + ' of 12 selected' : '12 photos', selLabel: sel.length ? 'Clear' : 'Select', clearSel: function () { set({ sel: sel.length ? [] : [0] }); },
      photoIc: ic('photo', 'sky'), syncIc: ic('sync', 'azure'),
      globeIc: ic('globe', 'azure'), copy: function () { set({ copied: true }); }, copyLabel: this.g('copied', false) ? 'Copied' : 'Copy link',
      docs: docs, primary: PRI[t]
    };
