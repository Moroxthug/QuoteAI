#!/usr/bin/env python3
"""Generates SetX.body.html from shared settings snippets + per-screen fragments (_set_frag/SetX.html)."""
import os, re, sys
D = os.path.dirname(os.path.abspath(__file__))

CSS = '''<style>
.set-h1{margin:0;font-size:28px;font-weight:600;letter-spacing:-0.04em;line-height:1.12}
.set-lede{margin:6px 0 0;font-size:13.5px;color:var(--muted);line-height:1.4}
.set-gt{margin:26px 20px 10px;font-size:17px;font-weight:600;letter-spacing:-0.025em}
.set-card{margin:0 16px;overflow:hidden}
.set-row{display:flex;align-items:center;gap:14px;padding:0 16px;color:var(--ink)}
a.set-row{transition:background-color .2s}
a.set-row:active{background:var(--soft)}
.set-ic{display:flex;flex-shrink:0}
.set-row:hover .gi{transform:scale(1.08) rotate(-4deg)}
.set-wrap{flex-grow:1;min-width:0;display:flex;flex-direction:column}
.set-line{display:flex;align-items:center;gap:12px;min-height:60px}
.set-txt{flex-grow:1;display:flex;flex-direction:column;gap:2px;padding:11px 0;min-width:0}
.set-txt b{font-size:15px;font-weight:500}
.set-txt small{font-size:12.5px;color:var(--muted);line-height:1.35}
.set-val{display:flex;align-items:center;gap:6px;font-size:13.5px;color:var(--muted);flex-shrink:0;text-align:right;max-width:52%}
.set-val > span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.set-sw{width:51px;height:31px;border-radius:999px;border:0;padding:2px;flex-shrink:0;display:flex}
.set-sw .knob{width:27px;height:27px;border-radius:50%;background:#ffffff;box-shadow:0 2px 6px rgba(0,0,0,.2)}
.set-seg{margin:0 0 14px}
.set-seg button{height:32px;font-size:13.5px}
.set-note{display:block;font-size:12.5px;color:var(--muted);line-height:1.45;padding:0 0 14px;margin-top:-4px}
.set-foot{margin:10px 20px 0;font-size:12.5px;color:var(--muted);line-height:1.45}
.set-step{display:flex;align-items:center;background:var(--sunk);border-radius:11px;padding:2px;flex-shrink:0}
.set-step button{width:34px;height:34px;border-radius:9px;border:0;background:transparent;display:flex;align-items:center;justify-content:center}
.set-in{flex-grow:1;display:flex;flex-direction:column;gap:3px;min-width:0;padding:11px 0}
.set-in label{font-size:12.5px;color:var(--muted)}
.set-in input,.set-in textarea{border:0;outline:none;background:transparent;font-size:15px;padding:0;min-width:0;width:100%;color:var(--ink)}
.set-in input{height:22px}
.set-in textarea{resize:none;line-height:1.45;font-family:inherit}
.set-in input::placeholder,.set-in textarea::placeholder{color:var(--faint)}
.set-in input:disabled,.set-in textarea:disabled{-webkit-text-fill-color:var(--ink);opacity:1}
.set-meter{display:flex;flex-direction:column;gap:8px;padding:14px 16px}
.set-meter + .set-meter{border-top:1px solid var(--line)}
.set-meter .bar{height:6px;border-radius:6px}
.set-meter .bar > span{border-radius:6px}
.set-sheetbar{position:absolute;left:16px;right:16px;bottom:26px;z-index:20;display:flex;align-items:center;gap:8px;padding:8px 8px 8px 18px;border-radius:24px;background:var(--glass);-webkit-backdrop-filter:blur(20px) saturate(1.6);backdrop-filter:blur(20px) saturate(1.6);box-shadow:0 10px 30px -8px var(--shadow),0 0 0 1px var(--ring);animation:rise .6s cubic-bezier(.16,1,.3,1) both}
.set-sw-dot{width:34px;height:34px;border-radius:50%;border:0;padding:0;flex-shrink:0;transition:box-shadow .3s,transform .2s}
</style>
'''

ROW_INNER = '''<span class="set-ic" style="{{r.icStyle}}">[[ICON r.ic 28]]</span>
<span class="set-wrap" style="{{r.sep}}">
<span class="set-line" style="{{r.lineStyle}}">
<span class="set-txt"><b style="{{r.labelStyle}}">{{r.label}}</b><sc-if value="{{r.hasSub}}" hint-placeholder-val="{{ true }}"><small>{{r.sub}}</small></sc-if></span>
<sc-if value="{{r.isStatus}}" hint-placeholder-val="{{ false }}"><span class="st {{r.stCls}}" style="flex-shrink: 0">{{r.stWord}}</span></sc-if>
<sc-if value="{{r.isVal}}" hint-placeholder-val="{{ false }}"><span class="set-val"><span class="{{r.valCls}}">{{r.val}}</span></span></sc-if>
<sc-if value="{{r.isLink}}" hint-placeholder-val="{{ false }}"><span class="set-val"><span class="{{r.valCls}}">{{r.val}}</span>[[CHEV]]</span></sc-if>
%s
</span>
<sc-if value="{{r.isSeg}}" hint-placeholder-val="{{ false }}">
<span role="group" aria-label="{{r.label}}" class="seg set-seg" style="{{r.segCols}}">
<span class="seg-ind" aria-hidden="true" style="{{r.ind}}"></span>
<sc-for list="{{r.opts}}" as="o" hint-placeholder-count="3"><button onClick="{{o.pick}}" aria-pressed="{{o.on}}" style="{{o.style}}">{{o.label}}</button></sc-for>
</span>
</sc-if>
<sc-if value="{{r.hasNote}}" hint-placeholder-val="{{ false }}"><span class="set-note">{{r.note}}</span></sc-if>
</span>'''

CONTROLS = '''<sc-if value="{{r.isBtn}}" hint-placeholder-val="{{ false }}"><button class="btn btn-sm press {{r.btnCls}}" onClick="{{r.act}}">{{r.btn}}</button></sc-if>
<sc-if value="{{r.isSwitch}}" hint-placeholder-val="{{ false }}"><button class="press track set-sw" role="switch" onClick="{{r.flip}}" aria-checked="{{r.on}}" aria-label="{{r.label}}" style="{{r.track}}"><span class="knob" style="{{r.knob}}"></span></button></sc-if>
<sc-if value="{{r.isStepper}}" hint-placeholder-val="{{ false }}">
<span class="set-step" style="{{r.stepStyle}}">
<button class="press" onClick="{{r.dec}}" aria-label="{{r.decLabel}}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 12h14"></path></svg></button>
<span class="mono" style="min-width: 60px; text-align: center; font-size: 13.5px">{{r.val}}</span>
<button class="press" onClick="{{r.inc}}" aria-label="{{r.incLabel}}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M5 12h14M12 5v14"></path></svg></button>
</span>
</sc-if>'''

def rows(listexpr):
    return ('<sc-for list="{{%s}}" as="r" hint-placeholder-count="3">\n'
            '<sc-if value="{{r.isA}}" hint-placeholder-val="{{ false }}"><a class="set-row press" href="{{r.href}}" style="{{r.rowStyle}}">\n%s\n</a></sc-if>\n'
            '<sc-if value="{{r.notA}}" hint-placeholder-val="{{ true }}"><div class="set-row" style="{{r.rowStyle}}">\n%s\n</div></sc-if>\n'
            '</sc-for>') % (listexpr, ROW_INNER % '', ROW_INNER % CONTROLS)

def group(name, pre='', post='', after=''):
    return ('<section class="rise" style="{{%s.delay}}">\n'
            '<sc-if value="{{%s.hasTitle}}" hint-placeholder-val="{{ true }}"><h2 class="set-gt">{{%s.title}}</h2></sc-if>\n'
            '<div class="card set-card">\n%s%s\n%s</div>\n'
            '<sc-if value="{{%s.hasFoot}}" hint-placeholder-val="{{ false }}"><p class="set-foot">{{%s.foot}}</p></sc-if>\n%s'
            '</section>\n') % (name, name, name, pre, rows(name + '.rows'), post, name, name, after)

def header(title, lede_expr):
    return ('<header class="hdr">[[BACK Settings.dc.html]]<span class="ht"></span><span></span></header>\n'
            '<section class="rise" style="padding: 4px 20px 0">\n<h1 class="set-h1">%s</h1>\n<p class="set-lede">%s</p>\n</section>\n'
            '<sc-if value="{{roBanner.show}}" hint-placeholder-val="{{ false }}">\n<div class="rise" style="padding: 16px 16px 0"><div class="banner b-info">[[ICON roBanner.ic 22]]<span><b>View only.</b> Your role can see these settings but not change them. Ask the owner.</span></div></div>\n</sc-if>\n') % (title, lede_expr)

def expand(src):
    # {{> G name}} ... macros in fragment files
    src = re.sub(r'\[\[ROWS (\w+)\]\]', lambda m: rows(m.group(1) + '.rows'), src)
    src = re.sub(r'\[\[G (\w+)\]\]', lambda m: group(m.group(1)), src)
    src = re.sub(r'\[\[GPRE (\w+) (\w+)\]\]', lambda m: group(m.group(1), pre=open(os.path.join(D, '_set_frag', m.group(2) + '.html')).read()), src)
    src = re.sub(r'\[\[GPOST (\w+) (\w+)\]\]', lambda m: group(m.group(1), post=open(os.path.join(D, '_set_frag', m.group(2) + '.html')).read()), src)
    src = re.sub(r'\[\[HEAD "([^"]+)" "([^"]*)"\]\]', lambda m: header(m.group(1), m.group(2)), src)
    return src

if __name__ == '__main__':
    for n in sys.argv[1:]:
        src = open(os.path.join(D, '_set_frag', n + '.html')).read()
        body = CSS + expand(src)
        open(os.path.join(D, n + '.body.html'), 'w').write(body)
        js = open(os.path.join(D, '_set_prelude.js')).read() + open(os.path.join(D, '_set_frag', n + '.js')).read()
        open(os.path.join(D, n + '.js'), 'w').write(js)
        print('gen', n)
