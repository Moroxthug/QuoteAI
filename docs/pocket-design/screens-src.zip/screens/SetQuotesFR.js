    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var S0 = [
      { day: 'Jour 2', name: 'Petit rappel', via: 'Texto', when: 'Si la soumission n’a pas été ouverte', msg: 'Bonjour Dana, je voulais m’assurer que la soumission pour la cuisine vous est parvenue. La revoici : {link}. Je peux vous l’expliquer au besoin. Marco, Rossi Renovations' },
      { day: 'Jour 5', name: 'Questions', via: 'Courriel', when: 'Si elle a été ouverte mais pas acceptée', msg: 'Bonjour Dana, avez-vous des questions sur la soumission pour la cuisine ? Je peux ajuster les travaux ou les faire en étapes si ça aide. Marco' },
      { day: 'Jour 10', name: 'Dernier suivi', via: 'Texto', when: 'Avant l’expiration de la soumission', msg: 'Bonjour Dana, votre soumission est valide jusqu’au 29 oct. Voulez-vous que je vous réserve une date de début ? {link}' }
    ];
    var si = self.g('fu', 0);
    var msgs = self.g('msgs', S0.map(function (s) { return s.msg; }));
    var on = [self.g('fuOn0', true), self.g('fuOn1', true), self.g('fuOn2', true)];
    var cur = Object.assign({}, S0[si], { msg: msgs[si] });
    var rev = self.g('rev', true);
    var revRows = [ sw('rev', true, 'star', 'gold', 'Demander un avis', 'Quand un chantier est terminé') ];
    if (rev) revRows = revRows.concat([
      step('revDelay', 3, 1, 0, 14, function (x) { return x === 0 ? 'Même jour' : x + (x === 1 ? ' jour' : ' jours'); }, 'clock', 'amber', 'Délai', 'Après le paiement de la facture finale'),
      lnk('globe', 'azure', 'Google', 'Votre lien d’avis', 'g.page/rossireno', RO ? '' : '#'),
      lnk('house', 'clay', 'HomeStars', 'Votre lien d’avis', 'Ajouté', RO ? '' : '#')
    ]);
    var stepSw = sw('fuOn' + si, true, 'bell', 'amber', 'Relance du ' + S0[si].day.toLowerCase(), S0[si].name);
    stepSw.sep = 'border-top: 1px solid var(--line)';
    var fuRows = [ stepSw,
      step('lead', 1, 1, 0, 7, function (x) { return x === 0 ? 'Même jour' : x + (x === 1 ? ' jour' : ' jours'); }, 'funnel', 'teal', 'Nouvelles demandes', 'Première relance si vous n’avez pas répondu') ];
    fuRows[1].sep = 'border-top: 1px solid var(--line)';
    return {
      roBanner: roBanner, ro: RO,
      gDef: grp('Par défaut', [
        step('valid', 30, 5, 5, 90, ' jours', 'clock', 'teal', 'Valide pendant', 'Ensuite, la soumission expire'),
        step('dep', 30, 5, 0, 50, ' %', 'percent', 'amber', 'Dépôt', 'Demandé à l’acceptation'),
        sw('gbb', true, 'bars', 'violet', 'Bon, Meilleur, Excellent', 'Trois options sur chaque nouvelle soumission'),
        sw('accMail', true, 'mail', 'sky', 'Courriel à l’acceptation', 'Avec la soumission signée en pièce jointe')
      ], '', 60),
      steps: S0.map(function (s, i) { var sel = i === si; return { day: s.day, name: s.name, on: sel,
        style: sel ? 'background: var(--card); box-shadow: 0 0 0 2px var(--ink)' : 'background: var(--sunk); box-shadow: none',
        dot: on[i] ? 'background: var(--ok-dot)' : 'background: var(--line2)', pick: function () { set({ fu: i, tested: false }); } }; }),
      cur: cur,
      onMsg: function (e) { var m = self.g('msgs', msgs).slice(); m[self.g('fu', 0)] = e.target.value; set({ msgs: m }); },
      testLabel: self.g('tested', false) ? 'Envoyé' : 'M’envoyer un test', test: function () { set({ tested: true }); },
      gFu: { rows: fuRows },
      terms: 'Le prix comprend la main-d’œuvre, les matériaux et l’élimination des rebuts indiqués ci-dessus. Non compris : les permis sauf s’ils sont indiqués, le retrait d’amiante ou de moisissure, les dommages cachés derrière les murs et les changements demandés une fois les travaux commencés. Les changements sont chiffrés en ordres de changement avant d’être faits. Garantie de 1 an sur la main-d’œuvre.',
      gRev: grp('Avis', revRows, rev ? 'Une seule demande par chantier, jamais plus.' : '', 230)
    };
