    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Decrease ' + label.toLowerCase(), incLabel: 'Increase ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var wa = self.g('wa', ST !== 'whatsappNotConnected');
    var usedUp = ST === 'textsUsedUp';
    var smsUsed = usedUp ? 1000 : 412;
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('en-CA'), total: total.toLocaleString('en-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : '', sub: full ? 'Used up · resets Oct 1' : sub, subStyle: full ? 'color: var(--bad)' : 'color: var(--muted)' };
    };
    var meters = [ meter('Texts this month', smsUsed, 1000, 'Resets Oct 1') ];
    if (wa) meters.push(meter('WhatsApp messages', 86, 500, 'Resets Oct 1'));
    var waRows;
    if (wa) waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', '(416) 555-0142 · verified Sep 2'), 'Connected', 'st-ok'),
      sw('waPref', true, 'send', 'teal', 'Use it when clients prefer it', 'Otherwise we send a text'),
      btnRow('link', 'slate', 'Disconnect', 'Messages go back to text and email', 'Disconnect', function () { set({ wa: false }); }, 'btn-d')
    ];
    else waRows = [
      stat(mk('chat', 'sage', 'WhatsApp Business', 'Clients get quotes and replies in WhatsApp'), 'Not connected', 'st-mute si-off'),
      btnRow('phone', 'violet', 'Connect your number', 'We send a 6-digit code to WhatsApp', 'Connect', function () { set({ wa: true }); }, 'btn-p')
    ];
    var logSt = function (r, w, c) { return stat(r, w, c); };
    return {
      roBanner: roBanner, usedUp: usedUp, waOn: wa, warnIc: ic('warn', 'rose'), phoneIc: ic('phone', 'violet'),
      numSt: usedUp ? { w: 'Paused', cls: 'st-warn si-pause' } : { w: 'Active', cls: 'st-ok si-live' },
      meters: meters,
      gSms: grp('Texts', [
        sw('sms', !usedUp, 'chat', 'sky', 'Text messages', usedUp ? 'Paused until Oct 1' : 'Quote and invoice links, reminders'),
        sw('leadFu', true, 'funnel', 'teal', 'Lead follow-ups', 'When a new lead waits for a reply'),
        sw('crewRem', true, 'users', 'amber', 'Crew reminders', 'Tomorrow’s site, the night before at 7 pm'),
        btnRow('send', 'indigo', 'Send a test', 'To your phone, (416) 555-0142', self.g('tested', false) ? 'Sent' : 'Send', function () { set({ tested: true }); })
      ], '', 80),
      gWa: grp('WhatsApp', waRows, wa ? '' : 'Needs a WhatsApp Business account on a number you own. Takes about 5 minutes.', 130),
      gTpl: grp('WhatsApp templates', [
        stat(lnk('doc', 'violet', 'Quote ready', 'Link to the quote', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('receipt', 'amber', 'Invoice reminder', 'Balance and pay link', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('truck', 'teal', 'On my way', 'Arrival time for the client', '', '#'), 'Approved', 'st-ok si-check'),
        stat(lnk('star', 'gold', 'Review request', 'Google and HomeStars links', '', '#'), 'In review', 'st-acc si-q2'),
        stat(lnk('funnel', 'rose', 'Lead follow-up', 'Too promotional. Edit and resend', '', '#'), 'Rejected', 'st-bad si-x')
      ], 'WhatsApp checks each template before you can use it, usually within a day.', 170),
      gQuiet: grp('Quiet hours', [
        sw('quiet', true, 'moon', 'indigo', 'Quiet hours', 'Messages wait until morning'),
        val('clock', 'slate', 'From', 'Every day', '9:00 pm', true),
        val('sun', 'amber', 'Until', 'Crew reminders too', '8:00 am', true)
      ], '', 210),
      gOpt: grp('Opt-outs', [
        val('shield', 'sage', 'Reply STOP to opt out', 'Added to each client’s first message', 'Always on'),
        lnk('users', 'stone', 'Opted out', 'They get email only', '3 clients', '#')
      ], 'Canada’s anti-spam law (CASL) needs consent and an easy way out. We handle both.', 250),
      gLog: grp('Recent messages', [
        logSt(mk('user', 'violet', 'Dana Whitfield', 'Quote link · 9:12 am'), 'Sent', 'st-info si-q1'),
        logSt(mk('user', 'teal', 'Harbourfront Dental', '“Can you start Monday?” · 8:40 am'), 'Received', 'st-acc'),
        logSt(mk('user', 'amber', 'Priya Nair', 'Follow-up · sends at 8:00 am'), 'Waiting', 'st-warn si-clock'),
        logSt(mk('user', 'rose', 'Tom & Lena Hart', 'Reminder INV-0412 · landline'), 'Failed', 'st-bad si-x')
      ], '', 290)
    };
