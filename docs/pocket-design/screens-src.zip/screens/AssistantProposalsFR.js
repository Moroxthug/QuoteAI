    var st = this.props.state || 'default';
    var offline = st === 'offline', ro = st === 'readonly', locked = st === 'locked', emptySt = st === 'empty';
    var dec = this.g('dec', {}), edits = this.g('edits', {}), editing = this.g('editing', null), toast = this.g('toast', null);
    var P = [
      { id: 'hart', gl: 'bell', tone: 'amber', kind: 'msg', title: 'Envoyer un rappel à Tom & Lena Hart', meta: 'INV-0412 · 2 340,00 $ · 9 jours de retard', doLabel: 'Texto prévu', channel: 'Texto à Tom Hart',
        draft: 'Bonjour Tom et Lena, petit rappel : la facture INV-0412 de 2 340,00 $ était due le 20 sept. Vous pouvez payer par carte ou virement Interac ici : pay.quoteai.ca/r/0412. Merci, Marco',
        why: 'Elle a 9 jours de retard. Les Hart ont payé les deux dernières factures dans la journée suivant un rappel.', done: 'Rappel envoyé aux Hart', word: 'Envoyé', cls: 'st-info si-q1', editLabel: 'Texto à Tom Hart' },
      { id: 'drywall', gl: 'truck', tone: 'clay', kind: 'order', title: 'Recommander du gypse pour le sous-sol Hart', meta: 'Home Depot Pro · livraison jeu. 7 h', doLabel: 'Commande prévue', channel: 'Commande fournisseur',
        items: [['30 × gypse 1/2 po, 4 × 8 pi', '441,00 $'], ['2 × vis à gypse, 5 lb', '45,20 $'], ['Livraison au 48 Galloway Rd', '0,00 $']], totLabel: 'Total avant TVH', total: '486,20 $',
        why: 'Amara a noté qu’il reste 6 feuilles et le plafond en demande 36 jeudi. Ça dépasse votre limite de 300 $, alors il demande.', done: 'Gypse commandé pour jeudi', word: 'Commandé', cls: 'st-info si-q1', editHref: 'Supplier.dc.html' },
      { id: 'gill', gl: 'cal', tone: 'sky', kind: 'move', title: 'Déplacer la teinture du patio Gill à mercredi', meta: 'Gill Residence · remise à neuf du patio', doLabel: 'Déplacement prévu', channel: 'Horaire',
        from: 'jeu. 1er oct.', fromSub: 'Pluie 80 % après 10 h', to: 'mer. 30 sept.', toSub: 'Sec, 16°', note: 'Luca et Sofia sont libres mercredi. Il leur texte la nouvelle date et écrit aux Gill par courriel.',
        why: 'La teinture doit sécher 24 h au sec. La météo de jeudi a tourné à la pluie pendant la nuit.', done: 'Teinture du patio déplacée au mer. 30 sept.', word: 'Déplacé', cls: 'st-ok si-check', editHref: 'Schedule.dc.html' },
      { id: 'priya', gl: 'mail', tone: 'violet', kind: 'msg', title: 'Préparer une relance pour Priya Nair', meta: 'Q-2026-118 · dosseret de cuisine · 1 865,10 $', doLabel: 'Courriel prévu', channel: 'Courriel à Priya',
        subj: 'Votre soumission pour le dosseret', draft: 'Bonjour Priya, je fais un suivi sur la soumission du dosseret. Je peux vous présenter les options de carreaux ou ajuster la disposition. On peut commencer la semaine du 12 oct. si ça vous convient. Marco',
        why: 'Elle a ouvert la soumission trois fois depuis vendredi sans répondre. Elle expire le 8 oct.', done: 'Relance envoyée à Priya', word: 'Envoyée', cls: 'st-info si-q1', editLabel: 'Courriel à Priya' }
    ];
    if (emptySt || locked) P = [];
    var showToast = function (b, s, ids) {
      var tid = Date.now();
      set({ toast: { b: b, s: s, ids: ids, id: tid } });
      setTimeout(function () { var t = self.g('toast', null); if (t && t.id === tid) set({ toast: null }); }, 10000);
    };
    var decide = function (ids, how, extra) {
      var n = Object.assign({}, self.g('dec', {}));
      ids.forEach(function (id) { n[id] = how; });
      var o = Object.assign({ dec: n, editing: null }, extra || {});
      set(o);
    };
    var undo = function (ids) { var n = Object.assign({}, self.g('dec', {})); ids.forEach(function (id) { delete n[id]; }); set({ dec: n, toast: null }); };
    var props = P.map(function (p) {
      var d = dec[p.id], isEd = editing === p.id;
      if (d === 'dismissed') return null;
      var draft = edits[p.id] || p.draft;
      var approved = d === 'approved';
      return {
        title: p.title, meta: p.meta, ic: ic(p.gl, p.tone), open: !approved, closed: approved,
        doLabel: p.doLabel, channel: p.channel, isMsg: p.kind === 'msg', isOrder: p.kind === 'order', isMove: p.kind === 'move',
        hasSubj: !!p.subj, subj: p.subj || '', draft: draft, showDo: !isEd,
        items: (p.items || []).map(function (x) { return { name: x[0], amt: x[1] }; }), totLabel: p.totLabel || '', total: p.total || '',
        from: p.from || '', fromSub: p.fromSub || '', to: p.to || '', toSub: p.toSub || '', note: p.note || '',
        why: p.why, editing: isEd, notEditing: !isEd, editInline: p.kind === 'msg', editLink: p.kind !== 'msg', editHref: p.editHref || '#',
        fid: 'ed-' + p.id, editLabel: p.editLabel || '',
        onEdit: function (e) { var n = Object.assign({}, self.g('edits', {})); n[p.id] = e.target.value; set({ edits: n }); },
        edit: function () { set({ editing: p.id }); },
        cancelEdit: function () { set({ editing: null }); },
        saveEdit: function () { decide([p.id], 'approved'); showToast(offline ? 'Enregistré.' : 'Approuvé.', offline ? 'Envoi à votre retour en ligne.' : p.done + '.', [p.id]); },
        approve: function () { decide([p.id], 'approved'); showToast(offline ? 'Enregistré.' : 'Approuvé.', offline ? 'Envoi à votre retour en ligne.' : p.done + '.', [p.id]); },
        dismiss: function () { decide([p.id], 'dismissed'); showToast('Ignoré.', 'Il ne le proposera plus pour ce chantier.', [p.id]); },
        undo: function () { undo([p.id]); },
        doneText: offline ? p.title : p.done, doneWord: offline ? 'Envoi une fois en ligne' : p.word, doneSt: offline ? 'st-warn si-clock' : p.cls
      };
    }).filter(Boolean);
    var pending = P.filter(function (p) { return !dec[p.id]; });
    var n = pending.length;
    var words = ['Rien', 'Une chose', 'Deux choses', 'Trois choses', 'Quatre choses'];
    var title = locked ? 'Votre assistant' : (n ? words[n] + ' à approuver' : 'Tout est à jour');
    var sub = locked ? 'Les propositions de l’assistant s’affichent ici une fois qu’il est inclus dans votre forfait.' : (n ? 'Rien ne part sans votre accord.' : 'Rien ne vous attend pour l’instant.');
    var R = [
      ['receipt', 'amber', '212,40 $ ajoutés à Hart', 'Reçu Home Depot · 10 h 12', 'Approuvé', 'st-ok si-check'],
      ['doc', 'indigo', 'Ordre de changement Okoye', 'Moulures du corridor · 9 h 30', 'Ignoré', 'st-mute' + ' si-x'],
      ['bank', 'gold', 'Virement Chen, 1 200,00 $', 'Aucun lien avec INV-0415 · 8 h 31', 'Échec', 'st-bad si-x'],
      ['receipt', 'violet', 'Brouillon de facture Harbourfront', 'INV-0421 · 3 210,00 $ · 7 h 05', '', '', 'Ouvrir', 'Invoice.dc.html']
    ];
    var recent = R.map(function (r) { return { ic: ic(r[0], r[1]), t: r[2], s: r[3], word: r[4], st: r[5], hasSt: !!r[4] && r[4] !== 'Échec', hasBtn: !!r[6] || r[4] === 'Échec', btn: r[6] || 'Réessayer', href: r[7] || '#' }; });
    return {
      title: title, sub: sub, offline: offline, readonly: ro, locked: locked, ro: ro,
      pendingCount: String(n), hasCount: !locked && n > 0,
      listTitle: n ? 'En attente de vous' : 'Tout juste approuvé', hasPending: props.length > 0, props: props, canBatch: n > 1 && !ro,
      approveAllLabel: 'Tout approuver (' + n + ')',
      approveAll: function () { var ids = pending.map(function (p) { return p.id; }); decide(ids, 'approved'); showToast(ids.length + ' approuvées.', offline ? 'Envoi à votre retour en ligne.' : 'Rappels, commande et changement d’horaire sont en route.', ids); },
      allClear: !locked && props.length === 0,
      showRecent: !locked && !emptySt, recent: recent,
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '', toastUndo: function () { var t = self.g('toast', null); if (t) undo(t.ids); },
      cloudIc: ic('cloud', 'amber'), eyeIc: ic('eye', 'sky'), lockIc: ic('lock', 'violet'), checkIc: ic('check', 'sage')
    };
