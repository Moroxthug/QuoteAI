    var st = this.props.state || 'default';
    var f = this.g('f', 'all'), q = this.g('q', ''), gone = this.g('gone', {}), last = this.g('last', null);
    // id, type, title, sub, amount, month
    var D = st === 'empty' ? [] : [
      ['a1', 'quote', 'Marchetti Bakery', 'Moulures devanture · refusée', '1 480 $', 'sep', '14 sept.'],
      ['a2', 'job', 'Gill Residence', 'Teinture de la clôture · terminé', '2 150 $', 'sep', '12 sept.'],
      ['a3', 'quote', 'Chen Family', 'Salle de lavage · expirée', '3 300 $', 'sep', '10 sept.'],
      ['a4', 'invoice', 'Okoye Condo', 'INV-0388 · payée', '1 105 $', 'sep', '2 sept.'],
      ['a5', 'client', 'Bayview Dental', 'Aucun travail depuis 2024', '', 'aug', '26 août'],
      ['a6', 'contract', 'Dana Whitfield', 'Nouveau patio · non signé', '9 800 $', 'aug', '19 août'],
      ['a7', 'quote', 'Priya Nair', 'Porte d’entrée · refusée', '640 $', 'aug', '11 août'],
      ['a8', 'job', 'Harbourfront Dental', 'Retouches · annulé', '780 $', 'aug', '4 août']
    ];
    var T = { quote: ['Soumission', 'doc', 'violet'], job: ['Chantier', 'cone', 'amber'], client: ['Client', 'user', 'teal'], invoice: ['Facture', 'receipt', 'sage'], contract: ['Contrat', 'pen', 'indigo'] };
    var FIL = [['all', 'Tout'], ['quote', 'Soumissions'], ['job', 'Chantiers'], ['client', 'Clients'], ['invoice', 'Factures'], ['contract', 'Contrats']];
    var live = D.filter(function (d) { return !gone[d[0]]; });
    var ql = q.trim().toLowerCase();
    var rows = live.filter(function (d) { return (f === 'all' || d[1] === f) && (!ql || (d[2] + ' ' + d[3] + ' ' + d[1]).toLowerCase().indexOf(ql) >= 0); });
    var act = function (d, how) {
      return function (e) {
        var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' });
        var n = Object.assign({}, self.g('gone', {})); n[d[0]] = how; set({ gone: n, last: [d[0], how, d[2], T[d[1]][0]] });
      };
    };
    var groups = [['sep', 'Septembre'], ['aug', 'Août']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      return { title: g[1], count: rs.length ? rs.length + (rs.length === 1 ? ' élément' : ' éléments') : '', has: rs.length > 0, first: false,
        rows: rs.map(function (d) { var t = T[d[1]]; return { title: d[2], sub: t[0] + ' · ' + d[3], amt: d[4] || '', when: d[6], kind: t[0], ic: ic(t[1], t[2]),
          acts: [{ label: 'Restaurer', ic: ic('sync', 'sage'), cls: 'sw-ok', go: act(d, 'restored') }, { label: 'Supprimer', ic: ic('warn', 'rose'), cls: 'sw-bad', go: act(d, 'deleted') }] }; }) };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;
    return {
      hasAny: D.length > 0, noneAtAll: D.length === 0, noMatch: D.length > 0 && groups.length === 0,
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: live.filter(function (d) { return x[0] === 'all' || d[1] === x[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, searchIc: ic('search', 'slate'), boxIc: ic('box', 'stone'),
      toast: !!last, toastB: last ? last[2] : '',
      toastS: last ? (last[1] === 'restored' ? 'est de retour dans les ' + last[3].toLowerCase() + 's' : 'supprimé pour de bon') : '',
      undo: function () { if (!last) return; var n = Object.assign({}, gone); delete n[last[0]]; set({ gone: n, last: null }); }
    };
