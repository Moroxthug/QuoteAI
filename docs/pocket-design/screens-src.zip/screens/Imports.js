    var step = this.g('step', this.props.step || 'source');
    var kind = this.g('kind', 0), prog = this.g('prog', 92), maps = this.g('maps', null), rev = this.g('rev', {}), errs = this.g('errs', {});
    var KINDS = ['Clients', 'Price items', 'Jobs'];
    var FIELDS = ['Client name', 'Phone', 'Email', 'Address', 'Notes', 'Don’t import'];
    var COLS = [['Name', 'Dana Whitfield', 0], ['Phone #', '416-555-0187', 1], ['E-mail', 'dana.w@rogers.com', 2], ['Street', '17 Castle Frank Cres', 3], ['Comments', 'Side door, dog is friendly', 4], ['Balance', '$0.00', 5]];
    var cur = maps || COLS.map(function (c) { return c[2]; });
    var segStyle = function (on) { return on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)'; };
    var go = function (s, extra) { return function () { set(Object.assign({ step: s }, extra || {})); }; };
    var pct = Math.min(100, Math.round(prog / 148 * 100));
    var R = [
      ['m1', 'Dana Whitfield', 'DW', 'tn1', 'Same email as your client'],
      ['m2', 'Priya Nair', 'PN', 'tn2', 'Same phone · address changed'],
      ['m3', 'T. Hart', 'TH', 'tn4', 'Looks like Tom & Lena Hart']
    ];
    var E = [
      ['e1', 'Row 41', 'No name', 'No name or email in this row', 'Skip'],
      ['e2', 'Row 77', 'Marchetti Bakery', 'Phone 416-55 is too short', 'Fix'],
      ['e3', 'Row 102', 'Gill Residence', 'Twice in the file · kept the first', 'Add']
    ];
    var revLeft = R.filter(function (r) { return !rev[r[0]]; }).length;
    var errLeft = E.filter(function (e) { return !errs[e[0]]; }).length;
    var kept = R.filter(function (r) { return rev[r[0]] === 'no'; }).length;
    return {
      isSource: step === 'source', notSource: step !== 'source', isMap: step === 'mapping', isRun: step === 'importing', isDone: step === 'done',
      hdrTitle: step === 'source' ? '' : 'Import ' + KINDS[kind].toLowerCase(),
      back: go(step === 'done' ? 'source' : step === 'importing' ? 'mapping' : 'source'),
      s1: 'on', s2: step === 'importing' || step === 'done' ? 'on' : '', s3: step === 'done' ? 'on' : '',
      kindInd: 'transform: translateX(' + (kind * 100) + '%)',
      kinds: KINDS.map(function (k, i) { return { label: k, on: i === kind, style: segStyle(i === kind), pick: function () { set({ kind: i }); } }; }),
      sources: [
        ['CSV or Excel file', 'Any spreadsheet, we match the columns', 'file', 'azure', '', '', go('mapping', { prog: 92, maps: null })],
        ['QuickBooks Online', 'Last sync Sep 27', 'bank', 'sage', 'Connected', 'st-ok', go('mapping', { prog: 92, maps: null })],
        ['Jobber', 'Clients, quotes and jobs', 'sync', 'teal', 'Not connected', 'st-mute si-off', function () {}],
        ['Old quotes as PDFs', 'AI reads clients and prices', 'doc', 'violet', '', '', function () {}]
      ].map(function (s) { return { label: s[0], sub: s[1], ic: ic(s[2], s[3]), status: s[4], st: s[5], hasSt: !!s[4], go: s[6] }; }),
      history: [
        ['Price items · Chen quote.pdf', 'Sep 18 · 11 added', 'Done', 'st-mute si-check', 'doc', 'violet'],
        ['Clients · QuickBooks', 'Aug 30 · 62 added · 4 merged', 'Done', 'st-mute si-check', 'bank', 'sage'],
        ['Jobs · old-jobs.xlsx', 'Aug 12 · stopped at row 18', 'Failed', 'st-bad si-x', 'file', 'rose']
      ].map(function (h) { return { label: h[0], sub: h[1], status: h[2], st: h[3], ic: ic(h[4], h[5]) }; }),
      maps: COLS.map(function (c, i) {
        var to = FIELDS[cur[i]];
        return { col: c[0], ex: c[1], to: to, cls: cur[i] === 5 ? 'skip' : '', aria: c[0] + ' goes to ' + to,
          cycle: function () { var n = cur.slice(); n[i] = (n[i] + 1) % FIELDS.length; set({ maps: n }); } };
      }),
      preview: [
        { a: 'Dana Whitfield', b: '416-555-0187', c: '17 Castle Frank Cres' },
        { a: 'Okoye Condo', b: '647-555-0122', c: '88 Harbour St, unit 2104' },
        { a: 'Chen Family', b: '905-555-0164', c: '9 Thornhill Woods Dr' }
      ],
      syncIc: ic('users', 'sky'),
      importLabel: 'Import 148 ' + KINDS[kind].toLowerCase(),
      start: go('importing', { prog: 92 }),
      pct: pct + '%', doneN: String(Math.min(prog, 148)), ringOff: 'stroke-dashoffset: ' + (389.6 * (1 - pct / 100)).toFixed(1),
      runSteps: [
        { label: 'Reading the file', sub: '148 rows, 6 columns', status: 'Done', st: 'st-mute si-check', ic: ic('file', 'azure') },
        { label: 'Checking for duplicates', sub: '3 look like clients you have', status: prog >= 148 ? 'Done' : 'In progress', st: prog >= 148 ? 'st-mute si-check' : 'st-ok si-live', ic: ic('users', 'violet') },
        { label: 'Adding clients', sub: prog >= 148 ? '142 added' : 'Waiting for the check', status: prog >= 148 ? 'Done' : 'Waiting', st: prog >= 148 ? 'st-mute si-check' : 'st-warn si-clock', ic: ic('plus', 'sage') }
      ],
      tick: function () { if (prog >= 148) set({ step: 'done' }); else set({ prog: Math.min(148, prog + 56) }); },
      okBigIc: ic('check', 'sage'), doneTitle: '142 clients added',
      sum: [
        { label: 'Added', value: String(142 + kept), style: 'color: var(--ok)', sep: '' },
        { label: 'To check', value: String(revLeft), style: revLeft ? 'color: var(--warn)' : '', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Skipped', value: String(errLeft), style: errLeft ? 'color: var(--bad)' : '', sep: 'border-left: 1px solid var(--line)' }
      ],
      hasReview: true, reviewLeft: revLeft ? revLeft + ' left' : 'All done',
      review: R.map(function (r, i) {
        var d = rev[r[0]];
        return { name: r[1], ini: r[2], tn: r[3], sub: d === 'yes' ? 'Merged into your existing client' : d === 'no' ? 'Added as a new client' : r[4],
          status: d === 'yes' ? 'Merged' : d === 'no' ? 'New client' : 'Matched', st: d === 'yes' ? 'st-ok si-check' : d === 'no' ? 'st-info si-dot' : 'st-acc si-q2',
          open: !d, sep: i ? 'border-top: 1px solid var(--line)' : '',
          yes: function () { var n = Object.assign({}, rev); n[r[0]] = 'yes'; set({ rev: n }); },
          no: function () { var n = Object.assign({}, rev); n[r[0]] = 'no'; set({ rev: n }); } };
      }),
      errLeft: errLeft ? errLeft + ' rows' : 'None left',
      errors: E.map(function (e) {
        var f = !!errs[e[0]];
        return { row: e[1], name: e[2], why: f ? (e[4] === 'Skip' ? 'Skipped for good' : 'Fixed and added') : e[3], subStyle: f ? '' : 'color: var(--bad)', action: e[4], open: !f, fixed: f && e[4] !== 'Skip',
          fix: function () { var n = Object.assign({}, errs); n[e[0]] = true; set({ errs: n }); } };
      }),
      restart: go('source', { rev: {}, errs: {}, maps: null, prog: 92 })
    };
