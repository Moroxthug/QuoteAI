    var ps = this.props.state || 'typing';
    var PS = { empty: ['', 'typing'], typing: ['K7Q', 'typing'], invalid: ['K7Q2NX', 'bad'], crew: ['K7Q2MX', 'crew'], foreman: ['F4R8TN', 'foreman'] }[ps] || ['', 'typing'];
    var code = self.g('code', PS[0]), st = self.g('st', PS[1]);
    var CODES = { K7Q2MX: 'crew', F4R8TN: 'foreman' };
    var submit = function (c) {
      set({ code: c, st: 'checking' });
      setTimeout(function () { set({ st: CODES[c] || 'bad', shakeN: self.g('shakeN', 0) + 1 }); }, 900);
    };
    var bad = st === 'bad', checking = st === 'checking', isCrew = st === 'crew', isForeman = st === 'foreman';
    var found = isCrew || isForeman;
    var boxes = [0, 1, 2, 3, 4, 5].map(function (n) {
      return { d: code[n] || '', cls: bad ? 'bad' : (!checking && n === code.length) ? 'act' : '' };
    });
    var clean = function (v) { return (v || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6); };
    return {
      entering: !found, found: found, isCrew: isCrew, isForeman: isForeman,
      boxA: boxes.slice(0, 3), boxB: boxes.slice(3), shake: bad ? 'jc-shake' : '',
      inVal: bad ? '' : code, bad: bad, checking: checking,
      onCode: function (e) { var c = clean(e.target.value); if (c.length === 6) submit(c); else set({ code: c, st: 'typing' }); },
      paste: function () { submit('K7Q2MX'); },
      reset: function () { set({ code: '', st: 'typing' }); },
      codeShow: code.slice(0, 3) + '-' + code.slice(3),
      role: isForeman ? 'Contremaître' : 'Équipier', roleCls: isForeman ? 'tag-acc' : '',
      can: isForeman
        ? ['Gérer les chantiers et noter les coûts', 'Affecter l’équipe et approuver les heures', 'Consulter les soumissions et factures (lecture seule)']
        : ['Pointer à l’arrivée et au départ du chantier', 'Voir les tâches du jour et l’adresse', 'Envoyer photos, notes et reçus'],
      coneIc: ic('cone', 'amber'), coIc: ic('building', 'violet'), userIc: ic('user', 'sage'), keyIc: ic('key', 'azure')
    };
