    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { overdue: 'st-bad', viewed: 'st-acc', sent: 'st-info', partial: 'st-warn si-q3', draft: 'st-mute', scheduled: 'st-info', paid: 'st-ok' };
    var tints = { 'Tom & Lena Hart': 'tn1', 'Harbourfront Dental': 'tn4', 'Marchetti Bakery': 'tn3', 'Priya Nair': 'tn2', 'Dana Whitfield': 'tn5', 'Okoye Condo': 'tn3', 'Gill Residence': 'tn1', 'Chen Family': 'tn4' };
    // no, type, client, montant, solde, genre, statut, dates, groupe
    var data = [
      ['INV-0412', 'Étape 2 sur 4', 'Tom & Lena Hart', 2340.00, 2340.00, 'overdue', '9 j de retard', 'Émise le 5 sept. · due le 20 sept.', 'overdue'],
      ['INV-0419', 'Finale', 'Harbourfront Dental', 780.00, 780.00, 'overdue', '3 j de retard', 'Émise le 27 août · due le 26 sept.', 'overdue'],
      ['INV-0391', 'Ordre de changement', 'Marchetti Bakery', 640.00, 640.00, 'overdue', '47 j de retard', 'Émise le 29 juil. · due le 13 août', 'overdue'],
      ['INV-0420', 'Ordre de changement', 'Tom & Lena Hart', 4469.15, 2234.58, 'partial', 'Payée en partie', 'Émise le 19 sept. · due le 3 oct.', 'open'],
      ['INV-0421', 'Acompte', 'Priya Nair', 559.53, 559.53, 'viewed', 'Consultée', 'Émise le 25 sept. · due le 9 oct.', 'open'],
      ['INV-0423', 'Étape 3 sur 4', 'Tom & Lena Hart', 4339.20, 0, 'draft', 'Brouillon', 'Créée aujourd’hui · due dans 15 jours', 'draft'],
      ['INV-0422', 'Acompte', 'Dana Whitfield', 1239.32, 0, 'draft', 'Brouillon', 'Créée le 28 sept. · Payable sur réception', 'draft'],
      ['INV-0424', 'Libération de la retenue', 'Tom & Lena Hart', 3840.00, 0, 'scheduled', 'Envoi le 14 nov.', 'Retenue de 10 % · due le 28 nov.', 'draft'],
      ['INV-0418', 'Finale', 'Okoye Condo', 2497.30, 0, 'paid', 'Payée', 'Émise le 8 sept. · Payée le 22 sept.', 'paid'],
      ['INV-0417', 'Acompte', 'Gill Residence', 1010.22, 0, 'paid', 'Payée', 'Émise le 14 sept. · Payée le 16 sept.', 'paid'],
      ['INV-0415', 'Finale', 'Chen Family', 3729.00, 0, 'paid', 'Payée', 'Émise le 25 août · Payée le 8 sept.', 'paid'],
      ['INV-0414', 'Étape 1 sur 2', 'Harbourfront Dental', 1695.00, 0, 'paid', 'Payée', 'Émise le 20 août · Payée le 3 sept.', 'paid'],
      ['INV-0410', 'Finale', 'Priya Nair', 675.91, 0, 'paid', 'Payée', 'Émise le 18 août · Payée le 2 sept.', 'paid']
    ];
    var grp = function (s) { return s.replace(/\s/g, ' '); };
    var money = function (n) { return grp(n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 })) + ' $'; };
    var whole = function (n) { return grp(Math.round(n).toLocaleString('fr-CA')) + ' $'; };
    var FIL = [
      ['all', 'Toutes', function () { return true; }],
      ['overdue', 'En retard', function (d) { return d[5] === 'overdue'; }],
      ['unpaid', 'Impayées', function (d) { return d[4] > 0; }],
      ['draft', 'Brouillons', function (d) { return d[5] === 'draft'; }],
      ['scheduled', 'Planifiées', function (d) { return d[5] === 'scheduled'; }],
      ['paid', 'Payées', function (d) { return d[5] === 'paid'; }]
    ];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d) && (!ql || (d[0] + ' ' + d[1] + ' ' + d[2]).toLowerCase().indexOf(ql) >= 0); });
    var acted = this.g('acted', {});
    var mkActs = function (no, list) { return list.map(function (a) { return { label: a[0], ic: ic(a[1], a[2]), cls: 'sw-' + a[3], go: function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); if (!a[4]) return; var n = Object.assign({}, self.g('acted', {})); n[no] = [a[4], a[5]]; set({ acted: n }); } }; }); };
    var IA = {
      overdue: [['Relancer', 'bell', 'azure', 'info', 'Rappel envoyé', 'st-info si-q1'], ['Paiement reçu', 'bank', 'sage', 'ok', 'Payée', 'st-ok si-check']],
      draft: [['Envoyer', 'send', 'azure', 'info', 'Envoyée', 'st-info si-q1'], ['Supprimer', 'warn', 'rose', 'bad', 'Supprimée', 'st-mute si-off']],
      scheduled: [['Envoyer maintenant', 'send', 'azure', 'info', 'Envoyée', 'st-info si-q1'], ['Modifier', 'pen', 'slate', 'mute']],
      paid: [['Envoyer le reçu', 'receipt', 'amber', 'mute', 'Reçu envoyé', 'st-ok si-check'], ['Archiver', 'box', 'stone', 'mute', 'Archivée', 'st-mute si-off']]
    };
    IA.viewed = IA.overdue; IA.sent = IA.overdue; IA.partial = IA.overdue;
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { 'Relancer': 'Rappel envoyé', 'Saisir un paiement': 'Paiement saisi', 'Envoyer': 'Envoyée', 'Envoyer maintenant': 'Envoyée', 'Envoyer le reçu': 'Reçu envoyé', 'Renvoyer le reçu': 'Reçu envoyé', 'Reçu': 'Envoyé', 'Appeler': 'Appel en cours', 'Répondre': 'Répondu', 'Dernier avis': 'Avis envoyé', 'Modifier': 'Modifiée' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Fait') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); var sw = el && el.closest('.swr'); if (sw) sw.scrollLeft = 0; var go = function () { var c = el.closest('.xc'); if (c && c.classList.contains('open')) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }; if (cur !== id && el) { setTimeout(go, 120); setTimeout(go, 520); } }; };
    var paid = function (sent, how, when, amt, rc) { return { main: rc ? 'Renvoyer le reçu' : 'Envoyer le reçu', rows: [['Envoyée le ' + sent, 'Par courriel', 'Livrée', 'st-ok si-check'], ['Payée au complet', how + ' · ' + when, 'Payée', 'st-ok si-check', '', amt], rc ? ['Reçu', 'Envoyé automatiquement le ' + when, 'Envoyé', 'st-ok si-check'] : ['Reçu', 'Pas encore envoyé', 'À envoyer', 'st-mute si-draft']] }; };
    // par facture : lignes [titre, contexte, statut, classe du statut, bouton, montant], statistiques, action principale
    var DET = {
      'INV-0412': { main: 'Relancer', rows: [['Envoyée le 5 sept.', 'Courriel à Tom et Lena', 'Livrée', 'st-ok si-check'], ['Consultée 3 fois', 'Dernière fois le 22 sept.'], ['2 rappels', '21 et 25 sept. · aucune réponse', 'Sans réponse', 'st-warn si-clock', 'Appeler'], ['Paiements', 'Aucun pour l’instant', '', '', '', '0,00 $']], stats: [['Solde', '2 340 $'], ['Retard', '9 jours'], ['Chantier', '64 % fait']] },
      'INV-0419': { main: 'Relancer', rows: [['Envoyée le 27 août', 'Aux comptes fournisseurs', 'Livrée', 'st-ok si-check'], ['1 rappel', '27 sept., envoyé automatiquement', 'Envoyé', 'st-info si-q1'], ['Demande un numéro de bon de commande', 'Comptes fournisseurs · 28 sept.', 'À répondre', 'st-warn si-clock', 'Répondre'], ['Paiements', 'Aucun pour l’instant', '', '', '', '0,00 $']], stats: [['Solde', '780 $'], ['Retard', '3 jours'], ['Paie en moy.', '14 jours']] },
      'INV-0391': { main: 'Relancer', rows: [['Envoyée le 29 juil.', 'Par courriel', 'Livrée', 'st-ok si-check'], ['3 rappels', '14 août, 28 août, 15 sept. · aucune réponse', 'Sans réponse', 'st-bad si-alert', 'Dernier avis'], ['Chantier en pause', 'Étagères de l’arrière-boutique · accord du propriétaire', 'En pause', 'st-warn si-pause', 'Appeler'], ['Paiements', 'Aucun pour l’instant', '', '', '', '0,00 $']], stats: [['Solde', '640 $'], ['Retard', '47 jours'], ['Rappels', '3']] },
      'INV-0420': { main: 'Saisir un paiement', rows: [['Envoyée le 19 sept.', 'Pour l’ordre de changement de la fenêtre d’évacuation', 'Livrée', 'st-ok si-check'], ['Paiement 1', 'Virement Interac · 24 sept.', 'Encaissé', 'st-ok si-check', 'Reçu', '2 234,57 $'], ['Solde', 'Échéance le ven. 3 oct.', 'Payée en partie', 'st-warn si-q3', '', '2 234,58 $']], stats: [['Payé', '50 %'], ['Dû dans', '4 jours'], ['Rappels', '0']] },
      'INV-0421': { main: 'Saisir un paiement', rows: [['Envoyée le 25 sept.', 'Par courriel et texto', 'Livrée', 'st-ok si-check'], ['Consultée', 'Aujourd’hui, 7 h 50', 'Consultée', 'st-acc si-q2'], ['Acompte de 30 %', 'De Q-2026-118, dosseret de cuisine'], ['Paiements', 'Aucun pour l’instant · échéance le 9 oct.', '', '', '', '0,00 $']] },
      'INV-0423': { main: 'Envoyer', rows: [['Créée aujourd’hui', 'Étape du gypse atteinte à Finition du sous-sol', 'Brouillon', 'st-mute si-draft'], ['Étape 3 sur 4', 'L’étape 2 n’est toujours pas payée (INV-0412)', '1 en retard', 'st-bad si-alert'], ['Échéance', '15 jours après l’envoi']] },
      'INV-0422': { main: 'Envoyer', rows: [['Créée le 28 sept.', 'Acompte de 30 % de Q-2026-119', 'Brouillon', 'st-mute si-draft'], ['En attente de la soumission', 'Q-2026-119 n’est pas encore envoyée', 'Non envoyée', 'st-mute si-draft'], ['Payable sur réception', 'Carte ou virement Interac']] },
      'INV-0424': { main: 'Envoyer maintenant', rows: [['Retenue de 10 %', 'Sur Finition du sous-sol, 38 400 $', '', '', '', '3 840,00 $'], ['Envoi le 14 nov.', '45 jours après la fin substantielle des travaux', 'Planifiée', 'st-info si-clock', 'Modifier'], ['Échéance le 28 nov.', '14 jours après l’envoi']] },
      'INV-0418': paid('8 sept.', 'Virement Interac', '22 sept.', '2 497,30 $', false),
      'INV-0417': paid('14 sept.', 'Carte de crédit', '16 sept.', '1 010,22 $', true),
      'INV-0415': paid('25 août', 'Chèque', '8 sept.', '3 729,00 $', false),
      'INV-0414': paid('20 août', 'Virement bancaire', '3 sept.', '1 695,00 $', true),
      'INV-0410': paid('18 août', 'Virement Interac', '2 sept.', '675,91 $', true)
    };
    var mk = function (d) {
      var ini = d[2].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var ac = acted[d[0]]; return { no: d[0], type: /^Étape/.test(d[1]) ? d[1].replace(/ /g, '\u00a0') : d[1], client: d[2], amt: money(d[3]), status: ac ? ac[0] : d[6], st: ac ? ac[1] : S[d[5]], dates: d[7].split(' · ').map(function (x) { return x.replace(/ /g, '\u00a0'); }).join(' · '), ini: ini, tn: tints[d[2]] || 'tn5', acts: mkActs(d[0], IA[d[5]]),
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { var k2 = d[0] + 'm', dn = !!xd[k2]; return { rows: rowsOf(d[0], x.rows), stats: (x.stats || []).map(function (q2) { return { l: q2[0], v: q2[1] }; }), hasStats: !!(x.stats && x.stats.length), main: dn ? (DONE[x.main] || 'Fait') : x.main, mainCls: dn ? 'done' : '', mainAct: flip(k2) }; })(DET[d[0]]) };
    };
    var groups = [['overdue', 'En retard', 4], ['open', 'En attente de paiement', 4], ['draft', 'Brouillons et planifiées', 3], ['paid', 'Payées ce mois-ci', 3]].map(function (g) {
      var rs = rows.filter(function (d) { return d[8] === g[0]; });
      var tot = rs.reduce(function (a, d) { return a + (g[2] === 4 ? d[4] : d[3]); }, 0);
      return { title: g[1], total: rs.length ? money(tot) : '', rows: rs.map(mk), has: rs.length > 0, openCls: rs.some(function (d) { return d[0] === xo; }) ? 'has-open' : '', first: false };
    }).filter(function (g) { return g.has; });
    if (groups.length) groups[0].first = true;

    var out = data.reduce(function (a, d) { return a + d[4]; }, 0);
    var overdue = data.filter(function (d) { return d[5] === 'overdue'; }).reduce(function (a, d) { return a + d[4]; }, 0);
    var AG = [
      ['Non échu', 2794.11, 'background: var(--ok-dot)'],
      ['1 à 30 jours', 3120.00, 'background: var(--warn-dot)'],
      ['31 à 60 jours', 640.00, 'background: var(--bad)'],
      ['61 à 90 jours', 0, 'background: var(--bad); filter: brightness(.78)'],
      ['Plus de 90 jours', 0, 'background: var(--bad); filter: brightness(.58)']
    ];
    var ow = money(out).split(',');
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      outWhole: ow[0], outCents: ',' + ow[1], overdueAmt: whole(overdue),
      agingLabel: 'Ancienneté : ' + AG.map(function (a) { return a[0] + ' ' + whole(a[1]); }).join(', '),
      aging: AG.filter(function (a) { return a[1] > 0; }).map(function (a) { return { seg: 'flex: ' + a[1].toFixed(0) + ' 1 0; min-width: 10px; ' + a[2] }; }),
      agingAll: AG.map(function (a) { return { label: a[0], amt: whole(a[1]), dot: a[2], fade: a[1] > 0 ? '' : 'opacity: .5' }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'), cap: 'Qui vous doit, du plus ancien au plus récent',
        main: xd.kpim ? '3 rappels envoyés' : 'Relancer les 3 retards', mainCls: xd.kpim ? 'done' : '', mainAct: flip('kpim'),
        rows: rowsOf('kpi', [
          ['Marchetti Bakery', 'INV-0391 · 31 à 60 jours', '47 jours de retard', 'st-bad si-alert', 'Relancer', '640,00 $'],
          ['Tom & Lena Hart', 'INV-0412 · 1 à 30 jours', '9 jours de retard', 'st-bad si-alert', 'Relancer', '2 340,00 $'],
          ['Harbourfront Dental', 'INV-0419 · 1 à 30 jours', '3 jours de retard', 'st-bad si-alert', 'Relancer', '780,00 $'],
          ['Tom & Lena Hart', 'INV-0420 · moitié payée, échéance le 3 oct.', 'Non échue', 'st-ok si-check', '', '2 234,58 $'],
          ['Priya Nair', 'INV-0421 · consultée, échéance le 9 oct.', 'Non échue', 'st-ok si-check', '', '559,53 $']]),
        stats: [{ l: 'Délai moyen', v: '14 j' }, { l: 'Payées à temps', v: '78 %' }, { l: 'En retard', v: '3' }] },
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(x[2]).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
