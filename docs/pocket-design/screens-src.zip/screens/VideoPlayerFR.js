    var V = this.props.video || 'quotes', P = this.props.state || 'playing';
    var D = {
      quotes: { head: 'Voir comment', title: 'Votre première soumission', topic: 'Soumissions', total: 72, start: 34, back: 'Quotes.dc.html',
        sub: 'Décrivez les travaux de vive voix et envoyez une soumission détaillée avec TVH, du début à la fin.',
        cta: 'Essayer maintenant', ctaHref: 'NewQuote.dc.html', scene: ['Description des travaux', 'Ligne 3 sur 7', 'Gypse, 3 pièces', '2 480,00 $', 'TVH de 13 % ajoutée'],
        ch: [[0, 'Nouvelle soumission', 'Touchez Nouvelle soumission dans l’onglet Soumissions.'], [14, 'Décrire les travaux', 'Dites-le comme au client : trois chambres, les plafonds aussi.'], [38, 'Vérifier les lignes', 'Chaque ligne est détaillée. Touchez-en une pour changer le prix.'], [58, 'L’envoyer', 'Envoyez par texto ou par courriel, et voyez quand le client l’ouvre.']] },
      overview: { head: 'quoteAI en 60 secondes', title: 'quoteAI en 60 secondes', topic: 'Aperçu', total: 60, start: 22, back: 'Welcome.dc.html',
        sub: 'D’une note vocale à une facture payée, en une minute.',
        cta: 'Commencer', ctaHref: 'SignUp.dc.html', scene: ['Dana Whitfield', 'Signée aujourd’hui, 9 h 12', 'Chambres et plafond de salle de bain', '4 131,05 $', 'Acceptée et signée'],
        ch: [[0, 'Parlez, la soumission suit', 'Décrivez les travaux. quoteAI rédige la soumission.'], [15, 'Le client signe', 'Votre client accepte et signe depuis son téléphone.'], [30, 'Le chantier avance', 'Équipe, horaire, photos et coûts au même endroit.'], [45, 'Vous êtes payé', 'Les factures partent à temps. Carte ou virement Interac.']] }
    };
    var d = D[V] || D.quotes;
    var total = d.total, pos = Math.max(0, Math.min(total, self.g('pos_' + V, d.start)));
    var retried = self.g('retried', false);
    var st = retried ? 'playing' : P;
    var playing = self.g('play', st === 'playing' || st === 'buffering');
    var offline = st === 'offline', buffering = st === 'buffering';
    var cc = self.g('cc', true), speed = self.g('speed', '1');
    var SP = ['1', '1.25', '1.5', '2'];
    var fmt = function (s) { s = Math.round(s); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); };
    var ci = 0; d.ch.forEach(function (c, i) { if (pos >= c[0]) ci = i; });
    var setPos = function (p) { var o = {}; o['pos_' + V] = Math.max(0, Math.min(total, p)); set(o); };
    var segs = d.ch.map(function (c, i) {
      var a = c[0], b = i + 1 < d.ch.length ? d.ch[i + 1][0] : total;
      var f = pos >= b ? 100 : (pos <= a ? 0 : (pos - a) / (b - a) * 100);
      return { fill: 'width: ' + f.toFixed(1) + '%', go: function () { setPos(a); }, aria: 'Chapitre ' + (i + 1) + ': ' + c[1], w: b - a };
    });
    // knob position in px across the scrub (350px wide, 3px gaps)
    var W = 350 - 3 * (d.ch.length - 1), x = 0;
    d.ch.forEach(function (c, i) { var a = c[0], b = i + 1 < d.ch.length ? d.ch[i + 1][0] : total; var w = W / d.ch.length; if (pos >= b) x += w + 3; else if (pos > a) x += w * (pos - a) / (b - a); });
    var waveH = [10, 18, 26, 14, 22, 8, 20, 26, 12, 18, 24, 10, 16, 22, 8, 14];
    return {
      backHref: d.back, headTitle: d.head, title: d.title, sub: d.sub, ctxTopic: d.topic, cta: d.cta, ctaHref: d.ctaHref,
      sceneIc: ic(V === 'overview' ? 'pen' : 'mic', 'violet'), cloudIc: ic('cloud', 'sky'),
      sceneA: d.scene[0], sceneB: d.scene[1], sceneC: d.scene[2], sceneAmt: d.scene[3], sceneD: d.scene[4],
      wave: waveH.map(function (h, i) { return { s: 'height: ' + h + 'px; animation-delay: ' + (i * 70) + 'ms' }; }),
      stillCls: playing && !offline && !buffering ? '' : 'vp-still',
      frameAria: d.title + ', ' + d.ch[ci][1],
      capOn: cc && !offline, caption: d.ch[ci][2], capLang: cc ? 'Français (Canada) · anglais offert' : 'Désactivés',
      paused: !playing && !offline && !buffering, buffering: buffering, offline: offline,
      retry: function () { set({ retried: true, play: true }); },
      playing: playing, notPlaying: !playing, playLabel: playing ? 'Pause' : 'Lire',
      toggle: function () { set({ play: !playing }); },
      back10: function () { setPos(pos - 10); }, fwd10: function () { setPos(pos + 10); },
      segs: segs, knob: 'left: ' + x.toFixed(1) + 'px',
      pos: String(Math.round(pos)), total: String(total), posText: fmt(pos), totalText: fmt(total), chapNow: d.ch[ci][1],
      ccCls: cc ? 'on' : '', flipCc: function () { set({ cc: !cc }); },
      ccTrack: cc ? 'background: var(--acc)' : 'background: var(--track-off)', ccKnob: cc ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      speedText: speed.replace('.', ',') + ' ×', cycleSpeed: function () { set({ speed: SP[(SP.indexOf(speed) + 1) % SP.length] }); },
      speedInd: 'transform: translateX(' + (SP.indexOf(speed) * 100) + '%)',
      speeds: SP.map(function (s) { var on = s === speed; return { label: s.replace('.', ',') + ' ×', on: on, style: on ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { set({ speed: s }); } }; }),
      chapters: d.ch.map(function (c, i) { var cur = i === ci, done = i < ci; return { t: fmt(c[0]), title: c[1], cur: cur, cls: cur ? 'cur' : '', hasSt: cur || done, st: cur ? (playing ? 'st-ok si-live' : 'st-mute si-pause') : 'st-mute si-check', word: cur ? (playing ? 'En lecture' : 'En pause') : 'Vu', go: function () { setPos(c[0]); } }; })
    };
