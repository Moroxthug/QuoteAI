    var mode = this.props.state || 'default';
    var firstTime = mode === 'firstTime', readOnly = mode === 'readOnly';
    var cat = this.g('cat', 'all'), q = this.g('q', ''), added = this.g('added', {}), busy = this.g('busy', ''), toast = this.g('toast', '');
    var CATS = [['all', 'Toutes'], ['acct', 'Comptabilité'], ['pay', 'Paiements'], ['msg', 'Messagerie'], ['cal', 'Calendrier'], ['store', 'Stockage'], ['supp', 'Fournisseurs'], ['lead', 'Sources de demandes']];
    // id, name, cat, glyph, tone, desc, state, connected line
    var APPS = [
      ['qbo', 'QuickBooks Online', 'acct', 'bars', 'sage', 'Factures, paiements et coûts vont dans vos livres avec les codes de taxe', 'attention', '2 factures non synchronisées · 8 h 12', 'Integration.dc.html'],
      ['xero', 'Xero', 'acct', 'orb', 'sky', 'Envoyez factures et paiements vers Xero', 'none', '', ''],
      ['wave', 'Wave', 'acct', 'wave', 'teal', 'Factures payées et coûts vont dans Wave', 'none', '', ''],
      ['stripe', 'Stripe', 'pay', 'card', 'violet', 'Vos clients paient factures et dépôts par carte', 'connected', 'Versements quotidiens à TD ••4410', ''],
      ['gcal', 'Google Agenda', 'cal', 'cal', 'azure', 'Chantiers et visites dans l’agenda de votre choix', 'connected', 'Chantiers et visites dans « Rossi jobs »', ''],
      ['outlook', 'Outlook', 'cal', 'cal', 'indigo', 'Chantiers et visites dans votre calendrier Outlook', 'soon', '', ''],
      ['wa', 'WhatsApp Business', 'msg', 'chat', 'sage', 'Envoyez soumissions et rappels là où vos clients répondent déjà', 'connected', '3 modèles de message sur 5 approuvés', ''],
      ['drive', 'Google Drive', 'store', 'cloud', 'amber', 'Sauvegardez photos de chantier et PDF signés', 'paused', 'En pause depuis le 21 sept. · photos non sauvegardées', ''],
      ['jobber', 'Importation Jobber', 'store', 'export', 'slate', 'Transférez clients, chantiers et soumissions depuis Jobber', 'none', '', 'Imports.dc.html'],
      ['hd', 'Home Depot Pro', 'supp', 'hammer', 'clay', 'Vos prix Pro dans la liste de prix, reçus dans les coûts', 'none', '', ''],
      ['hs', 'HomeStars', 'lead', 'star', 'gold', 'Votre lien d’avis sur les soumissions et factures', 'none', '', ''],
      ['gbp', 'Google Business Profile', 'lead', 'pin', 'rose', 'Demandes et messages de votre fiche Google', 'locked', '', '']
    ];
    var ST = { connected: ['Connecté', 'st-ok'], attention: ['Action requise', 'st-bad'], paused: ['En pause', 'st-warn si-pause'], none: ['Non connecté', 'st-mute si-off'] };
    var stateOf = function (a) {
      if (added[a[0]]) return 'connected';
      if (firstTime && a[6] !== 'soon' && a[6] !== 'locked') return 'none';
      return a[6];
    };
    var ql = q.trim().toLowerCase();
    var match = function (a) { return (cat === 'all' || a[2] === cat) && (!ql || (a[1] + ' ' + a[5]).toLowerCase().indexOf(ql) >= 0); };
    var isOn = function (s) { return s === 'connected' || s === 'attention' || s === 'paused'; };

    var SUG = { qbo: 'Factures et paiements dans vos livres', stripe: 'Paiement des factures par carte', gcal: 'Chantiers et visites dans votre agenda' };
    var sugOn = firstTime && !ql && !APPS.some(function (a) { return isOn(stateOf(a)); });
    var LINES = { xero: 'Première synchro ce soir', wave: 'Première synchro ce soir', jobber: 'Importation prête à vérifier', hd: 'Prix Pro mis à jour chaque semaine', hs: 'Lien d’avis sur les soumissions' };
    var top = APPS.filter(function (a) { return isOn(stateOf(a)) && match(a); }).map(function (a) {
      var s = stateOf(a);
      return { name: a[1], line: added[a[0]] ? (LINES[a[0]] || 'Connecté à l’instant') : a[7], status: ST[s][0], st: ST[s][1], ic: ic(a[3], a[4]), href: a[8] || 'Integration.dc.html' };
    });
    // first-time: suggestions on top
    if (sugOn) {
      top = APPS.filter(function (a) { return ['qbo', 'stripe', 'gcal'].indexOf(a[0]) >= 0 && (cat === 'all' || a[2] === cat); }).map(function (a) {
        var s = stateOf(a);
        return { name: a[1], line: SUG[a[0]], status: ST[s][0], st: ST[s][1], ic: ic(a[3], a[4]), href: 'Integration.dc.html' };
      });
    }
    var catName = {}; CATS.forEach(function (c) { catName[c[0]] = c[1]; });
    var rank = function (a) { var s = stateOf(a); return s === 'soon' ? 1 : s === 'locked' ? 2 : 0; };
    var dir = APPS.filter(function (a) { return !isOn(stateOf(a)) && match(a) && !(sugOn && SUG[a[0]]); });
    dir = dir.map(function (a, i) { return [a, i]; }).sort(function (x, y) { return rank(x[0]) - rank(y[0]) || x[1] - y[1]; }).map(function (x) { return x[0]; });
    var tiles = dir.map(function (a) {
      var s = stateOf(a), b = busy === a[0];
      return {
        name: a[1], desc: a[5], cat: cat === 'all' ? catName[a[2]] : '', ic: ic(a[3], a[4]), plan: 'Inclus dans Elite',
        canConnect: s === 'none' && !b && !readOnly, busy: b, soon: s === 'soon', locked: s === 'locked', ro: s === 'none' && readOnly,
        locked0: s === 'locked',
        connect: function () {
          if (a[8]) { window.location.href = a[8]; return; }
          set({ busy: a[0] });
          setTimeout(function () { var n = Object.assign({}, self.g('added', {})); n[a[0]] = true; set({ busy: '', added: n, toast: a[0] }); }, 1400);
        }
      };
    });
    var suggested = this.g('suggested', false);
    var nOn = APPS.filter(function (a) { return isOn(stateOf(a)); }).length;
    var nAtt = APPS.filter(function (a) { return stateOf(a) === 'attention'; }).length;
    var summary = firstTime && !nOn ? 'Rien de connecté pour l’instant' : nOn + (nOn > 1 ? ' connectées' : ' connectée') + (nAtt ? ' · ' + nAtt + ' à corriger' : '');
    var tApp = APPS.filter(function (a) { return a[0] === toast; })[0];
    return {
      summary: summary, readOnly: readOnly, firstTime: firstTime && nOn === 0,
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', cat: 'all' }); },
      chips: CATS.map(function (c) { var on = c[0] === cat; return { label: c[1], count: c[0] === 'all' ? APPS.length : APPS.filter(function (a) { return a[2] === c[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ cat: c[0] }); } }; }),
      top: top, hasTop: top.length > 0, topTitle: firstTime && nOn === 0 ? 'Pour commencer' : 'Connectées', topCount: top.length + '',
      tiles: tiles, hasTiles: tiles.length > 0 || !ql, dirTitle: cat === 'all' ? 'Autres applications' : catName[cat], dirCount: tiles.length + '',
      showSuggest: !ql && !readOnly, sugTitle: suggested ? 'Merci, c’est noté' : 'Une application manque ?', sugSub: suggested ? 'Nous écrirons à Marco si on l’ajoute' : 'Dites-nous laquelle vous utilisez',
      suggest: function () { set({ suggested: true }); },
      empty: !top.length && !tiles.length && !!ql,
      showLocked: tiles.some(function (t) { return t.locked; }),
      toast: !!tApp, toastName: tApp ? tApp[1] : '', toastSub: tApp ? (LINES[tApp[0]] || '') + '.' : '',
      okIc: ic('check', 'sage'), lockIc: ic('lock', 'azure'), heroIc: ic('sync', 'violet'), emptyIc: ic('search', 'slate')
    };
