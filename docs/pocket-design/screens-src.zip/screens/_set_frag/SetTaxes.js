    var freq = self.g('freq', 1);
    var due = [['September', 'Due Oct 31'], ['Jul 1 – Sep 30', 'Due Oct 31'], ['2026', 'Due Mar 31']][freq];
    var collected = ['$2,071.60', '$6,214.80', '$24,907.35'][freq];
    var split = self.g('split', false);
    return {
      roBanner: roBanner, rate: '13%', taxName: 'HST', pctIc: ic('percent', 'violet'),
      gProv: grp('Where you work', [
        lnk('pin', 'clay', 'Province', 'Sets tax on every quote and invoice', 'Ontario', RO ? '' : '#'),
        val('receipt', 'violet', 'GST/HST number', 'Prints on your documents', '81234 5678 RT0001', true),
        sw('byJob', true, 'house', 'amber', 'Use the job’s province', 'For the odd job outside Ontario')
      ], '', 80),
      gEx: grp('Exempt clients', [
        lnk('user', 'teal', 'Gill Residence', 'New housing rebate assigned to you', 'Rebate', 'Client.dc.html'),
        lnk('user', 'sky', 'Chen Family', 'Exemption certificate on file', 'Exempt', 'Client.dc.html'),
        lnk('plus', 'slate', 'Add an exemption', 'Pick a client and the reason', '', '#')
      ].slice(0, RO ? 2 : 3), 'Their quotes and invoices go out without HST. Keep the paperwork for the CRA.', 130),
      gSplit: grp('Materials and labour', [
        sw('split', false, 'bricks', 'stone', 'Price materials and labour apart', split ? 'Each quote shows two subtotals' : 'Needed for jobs in BC and Quebec')
      ], 'BC: you pay 7% PST on materials yourself and don’t charge it on labour. Quebec: charge GST 5% and QST 9.975% on both.', 180),
      gDocs: grp('On your documents', [
        seg('show', 0, 'doc', 'azure', 'Show tax as', '', ['Separate line', 'Included in prices']),
        sw('perLine', false, 'list', 'lilac', 'Tax on each line', 'Clearer when some lines are exempt'),
        sw('showNum', true, 'receipt', 'violet', 'Show your GST/HST number', 'Clients need it to claim credits')
      ], '', 230),
      gFile: grp('Filing', [
        seg('freq', 1, 'cal', 'teal', 'Filing frequency', '', ['Monthly', 'Quarterly', 'Yearly']),
        stat(mk('clock', 'amber', 'Next return', due[0]), due[1], 'st-warn si-clock'),
        lnk('bank', 'sage', 'HST collected', 'Minus HST you paid on costs', collected, 'Books.dc.html', true)
      ], 'Match this to what the CRA has on file. We remind you two weeks before each return.', 280)
    };
