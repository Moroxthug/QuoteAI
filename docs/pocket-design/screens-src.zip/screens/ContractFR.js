    var step = this.g('step', 1), open = this.g('open', 0);
    var STEPS = ['Révision', 'Signature', 'Envoi', 'Signature du client'];
    var check = 'M5 12.5l4.5 4.5L19 7.5';
    var steps = STEPS.map(function (s, i) {
      var done = i < step, cur = i === step;
      return {
        label: s, n: (i + 1) + '', done: done, todo: !done,
        dot: done ? 'background: var(--inv); color: var(--on-inv)' : cur ? 'background: var(--card); color: var(--ink); box-shadow: 0 0 0 2px var(--ink)' : 'background: var(--sunk); color: var(--faint)',
        lab: done || cur ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
        line: i === 3 ? 'display: none' : (i < step ? 'background: var(--inv)' : 'background: var(--line2)')
      };
    });
    var secs = [
      ['Portée des travaux', true, 'Murs et plafonds des trois chambres et du corridor, deux couches. Plafond de la salle de bain découpé, réparé, enduit et scellé contre les taches avant la peinture. Rossi Renovations fournit la peinture et les petites fournitures, et protège les planchers chaque jour.'],
      ['Prix et paiements', true, 'Prix du contrat : 4 131,05 $, TVH incluse. Dépôt de 30 % (1 239,32 $) à la signature. Solde à la fin des travaux, payable dans les 7 jours par carte ou par virement Interac.'],
      ['Échéancier', true, 'Les travaux commencent le mardi 13 octobre 2026 et durent environ 6 jours ouvrables, selon la météo et l’accès aux lieux. Heures de travail : de 8 h à 17 h.'],
      ['Garantie', true, 'La main-d’œuvre est garantie 1 an à compter de la fin des travaux. Tout écaillement, fissure ou remontée de tache causé par nos travaux est corrigé sans frais.'],
      ['Modifications aux travaux', false, 'Toute modification de la portée, du prix ou de l’échéancier doit être convenue par écrit, dans un ordre de changement signé par les deux parties, avant l’exécution des travaux.'],
      ['Retenue', false, 'Le propriétaire peut retenir 10 % de chaque paiement pendant 60 jours après l’achèvement substantiel des travaux, conformément à la Loi sur la construction (Ontario).'],
      ['Annulation', false, 'Ce contrat est signé ailleurs qu’à notre établissement. Le propriétaire peut donc l’annuler dans les 10 jours suivant la réception d’un exemplaire, sans motif ni pénalité.']
    ];
    var sections = secs.map(function (s, i) {
      var on = i === open;
      return {
        title: s[0], n: (i + 1) + '', ai: s[1], locked: !s[1], body: s[2], on: on, sep: i ? 'border-top: 1px solid var(--line)' : '',
        tag: s[1] ? 'Rédigé par l’IA, modifiable' : 'Clause type, verrouillée',
        chev: on ? 'transform: rotate(180deg)' : 'transform: rotate(0deg)',
        toggle: function () { set({ open: self.g('open', 0) === i ? -1 : i }); }
      };
    });
    var signed = step >= 2, sent = step >= 3;
    var signers = [
      { name: 'Marco Rossi', role: 'Rossi Renovations, propriétaire', ini: 'MR', tn: 'tn5', status: signed ? 'Signé' : 'À vous', st: signed ? 'st-ok' : 'st-warn', sig: signed, meta: signed ? 'Aujourd’hui, 9 h 34 · identité vérifiée' : 'Signez pour envoyer le contrat' },
      { name: 'Dana Whitfield', role: 'Propriétaire, 17 Castle Frank Cres', ini: 'DW', tn: 'tn1', status: sent ? 'En attente' : 'Non envoyé', st: sent ? 'st-info' : 'st-mute', sig: false, meta: sent ? 'Envoyé par courriel aujourd’hui, 9 h 36' : 'Recevra le lien après votre signature' }
    ].map(function (s, i) { return Object.assign(s, { sep: i ? 'border-top: 1px solid var(--line)' : '' }); });
    var acts = [
      ['Aujourd’hui, 9 h 12', 'Rédigé par l’IA à partir de Q-2026-119', 'orb', 'violet'],
      ['Aujourd’hui, 9 h 20', 'Vous avez modifié l’échéancier', 'pen', 'slate'],
      ['Aujourd’hui, 9 h 21', 'Clauses vérifiées pour l’Ontario', 'shield', 'indigo']
    ];
    if (signed) acts.push(['Aujourd’hui, 9 h 34', 'Signé par Marco Rossi', 'check', 'sage']);
    if (sent) acts.push(['Aujourd’hui, 9 h 36', 'Envoyé à Dana par courriel', 'send', 'azure']);
    acts.reverse();
    var activity = acts.map(function (a, i) { return { time: a[0], text: a[1], ic: ic(a[2], a[3]), line: i === acts.length - 1 ? 'visibility: hidden' : '' }; });
    var labels = ['', 'Signer pour Rossi Renovations', 'Envoyer à Dana', 'En attente de Dana'];
    return {
      steps: steps, sections: sections, signers: signers, activity: activity,
      statusLine: sent ? 'Envoyé · en attente de Dana' : signed ? 'Signé par vous · prêt à envoyer' : 'Brouillon · révisé, prêt à signer',
      dotStyle: sent ? 'background: var(--info)' : signed ? 'background: var(--ok-dot)' : 'background: var(--warn-dot)',
      details: [
        ['Province', 'Ontario', ''], ['Langue', 'Français', ''], ['Sous-total', '3 655,80 $', 'num'], ['TVH, Ontario 13 %', '475,25 $', 'num'], ['Total', '4 131,05 $', 'num'], ['Retenue, 10 % pendant 60 jours', '413,11 $', 'num'], ['Date de début', 'mar. 13 oct.', ''], ['Garantie', '1 an', '']
      ].map(function (d, i) { return { k: d[0], v: d[1], cls: d[2], sep: i ? 'border-top: 1px solid var(--line)' : '', vs: d[0] === 'Total' ? 'font-weight: 600' : '' }; }),
      lockIc: ic('lock', 'slate'), aiIc: ic('orb', 'violet'),
      primary: labels[step], primaryStyle: sent ? 'background: var(--sunk); color: var(--muted); box-shadow: none' : '',
      act: function () { var s = self.g('step', 1); if (s < 3) set({ step: s + 1 }); }
    };
