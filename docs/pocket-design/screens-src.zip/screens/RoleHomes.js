    var ROLE = this.props.role || 'estimator';
    var done = this.g('done', {});
    var row = function (key, icn, tone, t, s, w, st, btn, doneWord, doneSt) {
      var d = done[key];
      return { hasIc: true, hasAv: false, ic: ic(icn, tone), t: t, s: s, hasSt: !!w, w: d ? doneWord : w, st: d ? doneSt : st,
        hasVal: false, val: '', hasBtn: !!btn && !d, btn: btn || '', tn: '', ini: '',
        act: function () { var o = Object.assign({}, self.g('done', {})); o[key] = true; set({ done: o }); } };
    };
    var vrow = function (icn, tone, t, s, v) { return { hasIc: true, hasAv: false, ic: ic(icn, tone), t: t, s: s, hasSt: false, w: '', st: '', hasVal: true, val: v, hasBtn: false, btn: '', act: function () {}, tn: '', ini: '' }; };
    var arow = function (key, ini, tn, t, s, w, st, btn, doneWord, doneSt) { var r = row(key, 'dot', 'slate', t, s, w, st, btn, doneWord, doneSt); r.hasIc = false; r.hasAv = true; r.ini = ini; r.tn = tn; return r; };
    var mi = function (t, v, vStyle) { return { t: t, v: v, isNum: true, isSt: false, st: '', vStyle: vStyle || '', style: '' }; };
    var ms = function (t, v, st) { return { t: t, v: v, isNum: false, isSt: true, st: st, vStyle: '', style: '' }; };
    var OK = 'color: var(--ok)', BAD = 'color: var(--bad)', WARN = 'color: var(--warn)', MUT = 'color: var(--muted)';
    var sec = function (o) {
      return Object.assign({ title: '', link: '', href: '#', hasLink: false, isHero: false, isBars: false, isList: false, isKpis: false, isProg: false,
        label: '', meta: '', fig: '', figSub: '', figSubStyle: MUT, hasBar: false, barStyle: '', hasMini: false, mini: [], hasFoot: false, foot: '',
        bars: [], rows: [], kpis: [], prog: [] }, o, { cardHref: o.cardHref || o.href, hasLink: !!o.link, hasMini: !!(o.mini && o.mini.length), hasFoot: !!o.foot });
    };
    var bars = function (vals, labels, hi) {
      var mx = Math.max.apply(null, vals);
      return vals.map(function (v, i) { return { label: labels[i], style: 'height: ' + Math.round(v / mx * 52) + 'px; animation-delay: ' + (i * 70) + 'ms; background: ' + (i === hi ? 'var(--acc)' : 'var(--sunk)') }; });
    };
    var kp = function (l, v, sub, subStyle) { return { l: l, v: v, sub: sub, subStyle: subStyle || MUT }; };
    var pr = function (name, pct, phase, note, noteStyle) { return { name: name, pct: pct + '%', style: 'width: ' + pct + '%', phase: phase, note: note, noteStyle: noteStyle || '' }; };

    var R = {
      officeManager: { name: 'Carla Mendes', role: 'Office manager', tabs: 'Home, Quotes, Invoices, Clients', sections: [
        sec({ title: 'Needs you', link: 'See all', href: 'Notifications.dc.html', isList: true, rows: [
          arow('om1', 'AO', 'tn3', 'Amara Okafor, 12.5 h', 'Hart basement · Sep 21–27', 'To approve', 'st-warn', 'Approve', 'Approved', 'st-ok si-check'),
          row('om2', 'receipt', 'rose', 'INV-0412 · Hart', '$2,340 · sent Sep 11', '9 days overdue', 'st-bad', 'Remind', 'Reminder sent', 'st-info'),
          row('om3', 'user', 'violet', 'New lead · Chen Family', 'Kitchen refresh · from your website', 'New', 'st-acc si-dot', 'Call', 'Called', 'st-ok') ] }),
        sec({ title: 'Money', link: 'Books', href: 'Books.dc.html', isHero: true, label: 'Collected in September', meta: '6 invoices open', fig: '$48,230', figSub: '↑ 12%', figSubStyle: OK,
          mini: [mi('Outstanding', '$9,870'), mi('Overdue', '$3,120', BAD)] }),
        sec({ title: 'Today', link: 'Schedule', href: 'Schedule.dc.html', isList: true, rows: [
          vrow('cal', 'azure', 'Estimate · Priya Nair', 'Ben · 212 Dovercourt Rd', '11:00'),
          vrow('pin', 'rose', 'Site visit · Chen Family', 'Ben · kitchen', '2:30'),
          vrow('truck', 'clay', 'Delivery · Hart basement', 'Drywall, 24 sheets', '4:00') ] }),
        sec({ title: 'This week', isKpis: true, kpis: [kp('Quotes sent', '7', '2 viewed'), kp('Invoiced', '$14,380', '5 invoices'), kp('Messages', '3', 'unread', WARN)] }) ] },

      estimator: { name: 'Ben Walsh', role: 'Estimator', tabs: 'Home, Quotes, Leads, Clients', sections: [
        sec({ title: 'Quotes to write', link: 'Quotes', href: 'Quotes.dc.html', isHero: true, label: 'Drafts and requests', meta: 'This week', fig: '4', figSub: '2 due today', figSubStyle: WARN, cardHref: 'NewQuote.dc.html',
          mini: [ms('Chen Family · kitchen', 'Due today', 'st-warn si-clock'), ms('Marchetti Bakery · counter', 'Due today', 'st-warn si-clock'), ms('Okoye Condo · bathroom', 'Due Thu', 'st-warn si-clock')] }),
        sec({ title: 'Site visits', link: 'Schedule', href: 'Schedule.dc.html', isList: true, rows: [
          row('es1', 'pin', 'rose', '11:00 · Priya Nair', '212 Dovercourt Rd · backsplash', '', '', 'Directions', '', ''),
          row('es2', 'pin', 'amber', '2:30 · Chen Family', '88 Brookside Dr · kitchen', '', '', 'Directions', '', '') ] }),
        sec({ title: 'Win rate', link: 'Analytics', href: 'Analytics.dc.html', isBars: true, label: 'Quotes won, last 4 months', meta: '38 sent', fig: '62%', figSub: '↑ 4 pts', figSubStyle: OK,
          bars: bars([48, 55, 58, 62], ['Jun', 'Jul', 'Aug', 'Sep'], 3) }),
        sec({ title: 'Waiting on clients', isList: true, rows: [
          row('ew1', 'building', 'azure', 'Harbourfront Dental', 'Q-2026-114 · $18,640', 'Viewed', 'st-acc si-q2', 'Follow up', 'Followed up', 'st-info'),
          row('ew2', 'house', 'sage', 'Okoye Condo', 'Q-2026-117 · $9,200', 'Expires Fri', 'st-warn si-clock', '', '', ''),
          row('ew3', 'house', 'clay', 'Gill Residence', 'Change order · $1,180', 'Sent', 'st-info si-q1', '', '', '') ] }) ] },

      projectManager: { name: 'Hannah Kim', role: 'Project manager', tabs: 'Home, Jobs, Schedule, Clients', sections: [
        sec({ title: 'At risk', link: 'Jobs', href: 'Jobs.dc.html', isList: true, rows: [
          row('pm1', 'warn', 'amber', 'Hart basement', 'Drywall 2 days behind · board short', 'Blocked', 'st-bad si-alert', 'Open', 'Opened', 'st-acc si-q2'),
          row('pm2', 'doc', 'violet', 'Harbourfront Dental', 'Change order waiting · $1,180', 'Awaiting', 'st-warn si-clock', 'Nudge', 'Nudged', 'st-info') ] }),
        sec({ title: 'Active jobs', link: '5 active', href: 'Jobs.dc.html', isProg: true, prog: [
          pr('Hart basement', 64, 'Drywall', '2 days behind', BAD), pr('Gill Residence', 85, 'Paint and trim', 'On track', OK),
          pr('Harbourfront Dental', 30, 'Framing', 'On track', OK), pr('Okoye Condo', 10, 'Demolition', 'Starts Thu') ] }),
        sec({ title: 'Budget vs actual', isKpis: true, kpis: [kp('On budget', '3 of 5', 'jobs'), kp('Costs, Sep', '$21,460', 'of $24,900'), kp('Over', '$1,240', 'Hart basement', BAD)] }),
        sec({ title: 'Change orders', link: 'All', href: 'ChangeOrder.dc.html', isList: true, rows: [
          row('pc1', 'doc', 'violet', 'CO-07 · Hart basement', 'Extra outlets · $640', 'Signed', 'st-ok si-check', '', '', ''),
          row('pc2', 'doc', 'violet', 'CO-08 · Harbourfront Dental', 'Reception soffit · $1,180', 'Sent', 'st-info si-q1', '', '', '') ] }) ] },

      dispatcher: { name: 'Omar Haddad', role: 'Dispatcher', tabs: 'Home, Schedule, Jobs, Crew map', sections: [
        sec({ title: 'Crew now', link: 'Map', href: 'CrewMap.dc.html', isHero: true, label: 'Sharing location', meta: '1 off today', fig: '4 live', figSub: '3 on site', figSubStyle: OK, cardHref: 'CrewMap.dc.html',
          mini: [mi('Jonah, on the way to Hart basement', '14 min', 'color: var(--acc-t)'), ms('Luca and Amara · Hart basement', 'On site', 'st-ok si-live'), ms('Dev · Gill Residence', 'On site', 'st-ok si-live')] }),
        sec({ title: 'Not assigned', isList: true, rows: [
          row('dp1', 'hammer', 'amber', 'Harbourfront Dental · Thu', 'Reception patch · needs 1 drywaller', 'Open', 'st-warn si-dot', 'Assign', 'Amara', 'st-ok'),
          row('dp2', 'bolt', 'gold', 'Marchetti Bakery · service call', 'Breaker trips · any day this week', 'Open', 'st-warn si-dot', 'Assign', 'Jonah', 'st-ok') ] }),
        sec({ title: 'Tomorrow', link: 'Schedule', href: 'Schedule.dc.html', isList: true, rows: [
          vrow('house', 'clay', 'Hart basement', 'Luca, Amara, Sofia · second coat', '7:00'),
          vrow('house', 'sage', 'Gill Residence', 'Dev · trim', '7:30'),
          vrow('truck', 'azure', 'Harbourfront Dental', 'Delivery · steel studs', '10:00') ] }),
        sec({ title: 'This week', isKpis: true, kpis: [kp('Booked', '186 h', 'of 200'), kp('Overtime', '6 h', 'Luca', WARN), kp('Rain', 'Thu', 'move outside work', MUT)] }) ] },

      bookkeeper: { name: 'Rosa Lima', role: 'Bookkeeper', tabs: 'Home, Invoices, Books, Pay', sections: [
        sec({ title: 'To reconcile', link: 'Books', href: 'Books.dc.html', isHero: true, label: 'Bank lines, September', meta: 'RBC chequing', fig: '18', figSub: 'to match', figSubStyle: WARN, cardHref: 'Books.dc.html',
          hasBar: true, barStyle: 'width: 89%', foot: '142 of 160 matched · synced 8:12 am' }),
        sec({ title: 'Receipts', link: 'All', href: 'Books.dc.html', isList: true, rows: [
          row('bk1', 'receipt', 'rose', 'Home Depot · Warden Ave', '$412.66 · looks like a duplicate', 'Question', 'st-warn si-clock', 'Review', 'Reviewed', 'st-ok'),
          row('bk2', 'receipt', 'clay', 'Rona · Hart basement', '$86.20 · job not set', 'To confirm', 'st-warn si-clock', 'Review', 'Reviewed', 'st-ok'),
          row('bk3', 'receipt', 'azure', 'Esso · van', '$74.10 · fuel', 'To confirm', 'st-warn si-clock', 'Review', 'Reviewed', 'st-ok') ] }),
        sec({ title: 'HST', link: 'Compliance', href: 'Compliance.dc.html', isHero: true, label: 'Q3 · Jul 1 to Sep 30', meta: 'Quarterly', fig: '$6,212.00', figSub: 'due Oct 31', figSubStyle: WARN, cardHref: 'Compliance.dc.html',
          mini: [mi('HST collected', '$9,868.40'), mi('Input tax credits', '−$3,656.40')] }),
        sec({ title: 'Coming up', isList: true, rows: [
          row('bc1', 'bank', 'sage', 'Payroll remittance, Sep', '$4,386.20 · CRA', 'Due Oct 15', 'st-warn si-clock', '', '', ''),
          row('bc2', 'shield', 'teal', 'WSIB premium, Q3', '$1,912.40', 'Due Oct 30', 'st-warn si-clock', '', '', '') ] }) ] },

      safety: { name: 'Kevin Tran', role: 'Safety coordinator', tabs: 'Home, Jobs, Team, Documents', sections: [
        sec({ title: 'Certificates expiring', link: 'Compliance', href: 'Compliance.dc.html', isList: true, rows: [
          arow('sf1', 'DP', 'tn2', 'Dev Patel', 'First aid · ended Sep 12', 'Expired', ['st-bad', 'si-alert'].join(' '), 'Ask', 'Asked', 'st-info'),
          arow('sf2', 'JR', 'tn4', 'Jonah Reyes', 'WSIB clearance · subcontractor', 'Expires Oct 20', 'st-warn si-clock', 'Ask', 'Asked', 'st-info'),
          arow('sf3', 'SM', 'tn5', 'Sofia Marin', 'Working at heights', 'Expires Nov 3', 'st-warn si-clock', '', '', '') ] }),
        sec({ title: 'Incidents', link: 'Log', href: '#', isKpis: true, kpis: [kp('No lost time', '142 d', 'best: 210'), kp('Near misses', '2', 'in September', WARN), kp('Open', '1', 'ladder, Hart', BAD)] }),
        sec({ title: 'Toolbox talks', link: 'All', href: 'Documents.dc.html', isList: true, rows: [
          row('st1', 'chat', 'violet', 'Ladder safety', 'Thu 7:00 · Hart basement', '3 of 5 signed', 'st-warn si-q3', 'Remind', 'Reminded', 'st-info'),
          row('st2', 'chat', 'teal', 'Silica dust and sanding', 'Sep 22 · all sites', 'Signed', 'st-ok si-check', '', '', '') ] }),
        sec({ title: 'Site inspections', isList: true, rows: [
          row('si1', 'house', 'clay', 'Hart basement', 'Weekly walk-through', 'Due Fri', 'st-warn si-clock', '', '', ''),
          row('si2', 'house', 'sage', 'Gill Residence', 'Sep 24 · Kevin', 'Passed', 'st-ok si-check', '', '', '') ] }) ] }
    };
    var P = R[ROLE] || R.estimator;
    P.sections.forEach(function (s, i) { s.delay = 'animation-delay: ' + (60 + i * 50) + 'ms'; });
    var parts = P.name.split(' ');
    var bannerText = ROLE === 'bookkeeper' ? 'You can see money but not margins. Ask Marco to change it.' : (ROLE === 'estimator' ? 'Pay rates are hidden for your role.' : '');
    return {
      first: parts[0], ini: parts[0][0] + parts[1][0], roleName: P.role,
      hasBanner: false, bannerText: bannerText, bannerIc: ic('lock', 'slate'),
      sections: P.sections,
      custIc: ic('grid', 'violet'), custSub: 'Tabs: ' + P.tabs
    };
