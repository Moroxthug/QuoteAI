    return {
      remindIc: ic('bell', 'azure'), paidIc: ic('check', 'sage'),
      feats: [
        ['bell', 'amber', 'À régler, dès l’accueil', 'Factures en retard, soumissions non signées et questions de l’équipe, dès l’ouverture de l’app.'],
        ['list', 'violet', 'Glissez pour agir vite', 'Glissez une soumission ou une facture vers la gauche pour relancer, envoyer un rappel ou la marquer payée.'],
        ['camera', 'sage', 'Reçus par l’appareil photo', 'Photographiez un reçu. Nous lisons le total et la TVH, puis le classons dans le chantier.'],
        ['eye', 'azure', 'Voir comment', 'De courtes vidéos sous-titrées sur les écrans de première utilisation et dans l’aide.']
      ].map(function (f) { return { ic: ic(f[0], f[1]), title: f[2], text: f[3] }; })
    };
