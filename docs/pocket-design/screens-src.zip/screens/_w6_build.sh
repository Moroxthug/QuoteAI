#!/bin/bash
# _w6_build.sh NAME "Title" HEIGHT 'DC_PROPS' "state1 state2" [wide]
S=/tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad
N=$1
python3 $S/kit/normalize.py $S/screens/$N.body.html $S/screens/$N.js >/dev/null
DC_PROPS="$4" python3 $S/kit/assemble.py $N "$2" $S/screens/$N.body.html $S/screens/$N.js $3 >/dev/null || exit 1
if [ "$6" = "wide" ]; then
python3 - "$S/design/project/$N.dc.html" <<'EOF'
import sys
p=sys.argv[1]; s=open(p).read()
s=s.replace('style="width: 390px; height: 1024px','style="width: 1366px; height: 1024px',1).replace('"$preview":{"width":390','"$preview":{"width":1366',1)
open(p,'w').write(s)
EOF
fi
cp $S/design/project/$N.dc.html $S/prev/w6_$N.dc.html
sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/design/project/$N.dc.html > $S/prev/w6_${N}_D.dc.html
awk '/data-dc-script/{f=1;next} /<\/script>/{f=0} f' $S/prev/w6_$N.dc.html | sed 's/extends DCLogic//' > $S/w6_chk_$N.js; node --check $S/w6_chk_$N.js 2>&1 | head -5
for st in $5; do sed -e "s/\"default\":\"default\"/\"default\":\"$st\"/" $S/prev/w6_$N.dc.html > $S/prev/w6_${N}_$st.dc.html; done
echo built $N
