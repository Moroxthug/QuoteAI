    var step = self.g('step', null) || Number(this.props.step || 1);
    var picked = self.g('picked', ['renovation', 'painting', 'drywall']);
    var provId = self.g('prov', 'ON'), provOpen = self.g('provOpen', false);
    var co = self.g('co', 'Rossi Renovations'), ph = self.g('ph', '416 555 0182'), em = self.g('em', 'marco@rossireno.ca'), bn = self.g('bn', '');
    var more = self.g('more', false), size = self.g('size', 1), field = self.g('field', true), codes = self.g('codes', false);
    var people = self.g('people', [['Luca Bianchi', 'luca@rossireno.ca', 1], ['Amara Okafor', '647 555 0133', 2]]);
    var TR = [['general', 'General contracting', 'house', 'slate'], ['renovation', 'Renovation', 'hammer', 'violet'], ['painting', 'Painting', 'brush', 'rose'], ['electrical', 'Electrical', 'bolt', 'gold'], ['plumbing', 'Plumbing', 'drop', 'azure'], ['hvac', 'Heating and cooling', 'fan', 'sky'], ['roofing', 'Roofing', 'roof', 'clay'], ['flooring', 'Flooring', 'grid', 'amber'], ['drywall', 'Drywall', 'box', 'stone'], ['masonry', 'Masonry', 'bricks', 'clay'], ['landscaping', 'Landscaping', 'leaf', 'sage'], ['other', 'Something else', 'plus', 'lilac']];
    var P = [['ON', 'Ontario', 'HST 13%', 'on quotes and invoices.'], ['QC', 'Quebec', 'GST 5% + QST 9.975%', 'shown as two lines, in French when you choose.'], ['BC', 'British Columbia', 'GST 5% + PST 7%', 'PST applies to materials, not labour.'], ['AB', 'Alberta', 'GST 5%', 'on quotes and invoices.'], ['SK', 'Saskatchewan', 'GST 5% + PST 6%', 'on quotes and invoices.'], ['MB', 'Manitoba', 'GST 5% + RST 7%', 'on quotes and invoices.'], ['NS', 'Nova Scotia', 'HST 14%', 'on quotes and invoices.'], ['NB', 'New Brunswick', 'HST 15%', 'on quotes and invoices.'], ['NL', 'Newfoundland and Labrador', 'HST 15%', 'on quotes and invoices.'], ['PE', 'Prince Edward Island', 'HST 15%', 'on quotes and invoices.'], ['YT', 'Yukon', 'GST 5%', 'on quotes and invoices.'], ['NT', 'Northwest Territories', 'GST 5%', 'on quotes and invoices.'], ['NU', 'Nunavut', 'GST 5%', 'on quotes and invoices.']];
    var pr = P.filter(function (p) { return p[0] === provId; })[0] || P[0];
    var trades = TR.map(function (t) {
      var on = picked.indexOf(t[0]) > -1;
      return { name: t[1], ic: ic(t[2], t[3]), on: on, cls: on ? 'on' : '', toggle: function () { var cur = self.g('picked', ['renovation', 'painting', 'drywall']).slice(), i = cur.indexOf(t[0]); if (i > -1) cur.splice(i, 1); else cur.push(t[0]); set({ picked: cur }); } };
    });
    var names = TR.filter(function (t) { return picked.indexOf(t[0]) > -1; }).map(function (t) { return t[1]; });
    var pickedLine = names.length ? names.length + ' selected · ' + names.join(', ') : 'Nothing picked yet. You can change this later.';
    var ROLES = [['Admin', 'tag-acc'], ['Foreman', ''], ['Crew', '']];
    var TN = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    var ppl = people.map(function (p, i) {
      var r = ROLES[p[2]];
      return { name: p[0], contact: p[1], ini: p[0].split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2), tn: TN[i % 5], role: r[0], roleCls: r[1], cycle: function () { var cur = self.g('people', people).map(function (x) { return x.slice(); }); cur[i][2] = (cur[i][2] + 1) % 3; set({ people: cur }); } };
    });
    var SZ = ['Just me', '2–5', '6–15', '16+'];
    var go = function (n) { set({ step: n }); };
    var nm = co.trim() || 'Your company';
    return {
      step: step, isS1: step === 1, isS2: step === 2, isS3: step === 3, notLast: step < 3, canBack: step > 1, noBack: step === 1,
      s1: 'on', s2: step >= 2 ? 'on' : '', s3: step >= 3 ? 'on' : '',
      back: function () { go(Math.max(1, step - 1)); }, next: function () { go(Math.min(3, step + 1)); },
      skip: function () { if (step < 3) go(step + 1); else window.location.href = 'SmartHome.dc.html'; },
      nextLabel: step === 1 && !names.length ? 'Continue without a trade' : 'Continue',
      trades: trades, pickedLine: pickedLine,
      prov: { name: pr[1], tax: pr[2], note: pr[3], short: pr[1] + ' · ' + pr[2] },
      openProv: function () { set({ provOpen: true }); }, closeProv: function () { set({ provOpen: false }); }, provOpen: provOpen,
      provs: P.map(function (p) { return { name: p[1], tax: p[2], on: p[0] === provId, pick: function () { set({ prov: p[0], provOpen: false }); } }; }),
      co: co, ph: ph, em: em, bn: bn,
      onCo: function (e) { set({ co: e.target.value }); }, onPh: function (e) { set({ ph: e.target.value }); }, onEm: function (e) { set({ em: e.target.value }); }, onBn: function (e) { set({ bn: e.target.value }); },
      coShow: nm, phShow: ph || '—', emShow: em || 'no email yet', bnShow: bn ? 'GST/HST ' + bn : 'GST/HST number not added',
      more: more, moreRot: more ? 'transform: rotate(180deg)' : 'transform: rotate(0)', toggleMore: function () { set({ more: !self.g('more', false) }); },
      licLabel: provId === 'QC' ? 'RBQ licence number' : 'Contractor licence number',
      sizeInd: 'transform: translateX(' + (size * 100) + '%)',
      sizes: SZ.map(function (l, i) { return { label: l, on: i === size, cls: i === size ? '' : '', style: i === size ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ size: i }); } }; }),
      solo: size === 0, hasTeam: size > 0,
      field: field, fieldTrack: field ? 'background: var(--acc)' : 'background: var(--track-off)', fieldKnob: field ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipField: function () { set({ field: !self.g('field', true) }); },
      people: ppl, addPerson: function () { var cur = self.g('people', people).slice(); if (cur.length < 4) cur.push([['Sofia Marin', 'sofia.marin@gmail.com', 2], ['Dev Patel', '416 555 0177', 2]][cur.length - 2] || ['New person', 'Add phone or email', 2]); set({ people: cur }); },
      codesMade: codes, codesNot: !codes, makeCodes: function () { set({ codes: true }); },
      codeSub: codes ? 'Share them from Team any time' : 'For crew without email',
      pinIc: ic('pin', 'rose'), taxIc: ic('percent', 'violet'),
      coIc: ic('building', 'violet'), phIc: ic('phone', 'teal'), emIc: ic('mail', 'sky'), moreIc: ic('list', 'slate'),
      logoIc: ic('camera', 'lilac'), bnIc: ic('doc', 'indigo'), licIc: ic('shield', 'sage'), adIc: ic('pin', 'rose'), etIc: ic('bank', 'gold'),
      soloIc: ic('user', 'violet'), crewIc: ic('cone', 'amber'), codeIc: ic('key', 'indigo')
    };
