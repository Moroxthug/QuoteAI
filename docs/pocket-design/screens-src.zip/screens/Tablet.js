    var f = this.g('f', 'all'), q = this.g('q', ''), sel = this.g('sel', 'Q-2026-119'), acted = this.g('acted', {});
    var S = { draft: ['Draft', 'st-mute si-draft'], sent: ['Sent', 'st-info si-q1'], viewed: ['Viewed', 'st-acc si-q2'], accepted: ['Accepted', 'st-ok si-check'], declined: ['Declined', 'st-bad si-x'], expired: ['Expired', 'st-mute si-off'], expiring: ['Expires Fri', 'st-warn si-clock'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // no, client, job, total, status, group, when, address, valid, scope, lines [name, amt, detail]
    var data = [
      ['Q-2026-119', 'Dana Whitfield', 'Bedrooms and bath ceiling', 4131.05, 'draft', 'week', 'Today', '17 Castle Frank Cres, Toronto', 'Oct 29',
        'Walls and ceilings in 3 bedrooms and hallway, two coats. Bath ceiling cut out, patched, skim coated and stain-blocked before paint. Materials supplied.',
        [['Painting, 3 bedrooms and hallway', 2352, '$2.10 / sq ft · 1,120 sq ft · two coats'], ['Bath ceiling water-damage repair', 640, 'Cut out, board, tape, skim'], ['Stain-blocking primer', 88.80, '$1.85 / sq ft · 48 sq ft'], ['Paint and sundries', 395, 'Supplied by Rossi Renovations'], ['Floor protection and cleanup', 180, 'Drop sheets, daily sweep, final clean']]],
      ['Q-2026-118', 'Priya Nair', 'Kitchen backsplash', 1865.10, 'viewed', 'week', 'Viewed 2 h ago', '212 Dovercourt Rd, Toronto', 'Oct 27',
        'Subway tile backsplash behind the counters and range, about 32 sq ft. Outlet boxes extended to sit flush. Grout sealed.',
        [['Backsplash tile install', 1120, '32 sq ft · layout, set, grout'], ['Tile, grout and sealer', 410.53, 'White 3×6 subway, matte'], ['Outlet box extenders', 120, '4 outlets, by Jonah Reyes']]],
      ['Q-2026-117', 'Harbourfront Dental', 'Reception repaint', 6420.00, 'expiring', 'week', 'Sent Sep 24', 'Queens Quay W, Toronto', 'Oct 2',
        'Reception and waiting room walls, two coats in eggshell. Door frames and trim in semi-gloss. Work after 6 pm so the office stays open.',
        [['Reception and waiting room walls', 3960, '1,800 sq ft · two coats'], ['Door frames and trim', 1121.42, '14 frames, semi-gloss'], ['After-hours premium', 600, '3 evenings, after 6 pm']]],
      ['Q-2026-116', 'Gill Residence', 'Deck refinish', 2980.00, 'sent', 'week', 'Sent Mon', 'Brampton', 'Oct 28',
        'Strip and sand the deck and stairs, two coats of semi-transparent stain. Touch up the railing where it’s worn.',
        [['Deck strip and sand', 1480, '420 sq ft plus stairs'], ['Semi-transparent stain, 2 coats', 957.17, 'Cedar tone, materials included'], ['Railing touch-up', 200, 'Worn spots only']]],
      ['Q-2026-114', 'Tom & Lena Hart', 'Basement change order', 3955.00, 'accepted', 'earlier', 'Accepted Sep 19', '48 Galloway Rd, Scarborough', 'Accepted',
        'Six pot lights in the rec room, a bulkhead around the new duct run, and paint for the extra walls.',
        [['Pot lights, 6', 1680, 'By Jonah Reyes, licensed electrician'], ['Bulkhead framing and drywall', 1320, '14 linear ft'], ['Extra paint', 500, 'Two coats, 2 walls']]],
      ['Q-2026-112', 'Okoye Condo', 'Hallway flooring', 2210.00, 'accepted', 'earlier', 'Accepted Sep 15', 'Okoye Condo, Liberty Village', 'Accepted',
        'Pull the old carpet, install engineered oak with underlay and transitions to the kitchen and bath.',
        [['Engineered oak install', 1440, '180 sq ft'], ['Underlay and transitions', 315.75, '2 transitions'], ['Carpet removal and disposal', 200, 'Hallway and entry']]],
      ['Q-2026-110', 'Marchetti Bakery', 'Storefront trim', 1480.00, 'declined', 'earlier', 'Declined Sep 12', 'College St, Toronto', 'Declined',
        'Repaint the storefront trim and window frames in the existing green. Caulk and prep first.',
        [['Storefront trim repaint', 980, 'Two coats, exterior enamel'], ['Caulk and prep', 329.73, 'Scrape, fill, prime bare spots']]],
      ['Q-2026-108', 'Chen Family', 'Laundry room refresh', 3300.00, 'expired', 'earlier', 'Expired Sep 9', 'Markham', 'Expired Sep 9',
        'Paint the laundry room walls and ceiling, refinish the cabinets, new hardware.',
        [['Walls and ceiling', 1860, 'Two coats, scrub-resistant'], ['Cabinet refinish', 860.35, '8 doors, 3 drawers'], ['Materials', 200, 'Paint, primer, hardware']]],
      ['Q-2026-107', 'Tom & Lena Hart', 'Basement finish', 38400.00, 'accepted', 'earlier', 'Accepted Aug 28', '48 Galloway Rd, Scarborough', 'Accepted',
        'Finish the basement: framing, insulation, drywall, electrical, flooring and paint. Permit pulled by Rossi Renovations.',
        [['Framing and insulation', 9800, 'Exterior walls R-24, new partitions'], ['Drywall and finishing', 8600, '1,850 sq ft, level 4'], ['Electrical', 6200, 'By Jonah Reyes'], ['Flooring', 5400, 'Vinyl plank, 820 sq ft'], ['Paint', 2600, 'Two coats throughout'], ['Permits and disposal', 1382.30, 'Building permit, bins']]]
    ];
    var FIL = [['all', 'All', function () { return true; }], ['draft', 'Draft', function (s) { return s === 'draft'; }], ['waiting', 'Waiting', function (s) { return s === 'sent' || s === 'viewed' || s === 'expiring'; }], ['accepted', 'Accepted', function (s) { return s === 'accepted'; }], ['closed', 'Closed', function (s) { return s === 'declined' || s === 'expired'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ini = function (n) { return n.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[1] + ' ' + d[2] + ' ' + d[0]).toLowerCase().indexOf(ql) >= 0); });
    var stOf = function (d) { var a = acted[d[0]]; return a ? a : S[d[4]]; };
    var groups = [['week', 'This week'], ['earlier', 'Earlier']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      return { title: g[1], total: rs.length ? money(rs.reduce(function (a, d) { return a + d[3]; }, 0)) : '', has: rs.length > 0,
        rows: rs.map(function (d) { var on = d[0] === sel, s = stOf(d); return { client: d[1], job: d[6] + ' · ' + d[2], amt: money(d[3]), status: s[0], st: s[1], ini: ini(d[1]), tn: tints[data.indexOf(d) % 5], on: on, cls: on ? 'on' : '', pick: function () { set({ sel: d[0] }); } }; }) };
    }).filter(function (g) { return g.has; });
    var D = data.filter(function (d) { return d[0] === sel; })[0] || data[0];
    var sub = D[10].reduce(function (a, l) { return a + l[1]; }, 0), hst = Math.round(D[3] * 100 - sub * 100) / 100;
    var tw = money(D[3]).split('.');
    var s = stOf(D);
    var PR = { draft: ['Send quote', 'Preview', 'Sent', 'st-info si-q1'], sent: ['Follow up', 'Mark won', 'Followed up', 'st-info' + ' si-q1'], accepted: ['Open job', 'Invoice deposit', '', ''], declined: ['Revive quote', 'Archive', 'Draft', 'st-mute si-draft'] };
    PR.viewed = PR.sent; PR.expiring = PR.sent; PR.expired = PR.declined;
    var pr = PR[D[4]];
    var ACT = {
      draft: [['Created by voice', 'Today', 'Assistant wrote 5 lines from your notes'], ['Site visit', 'Sep 26', 'Photos and measurements saved']],
      viewed: [['Viewed by ' + D[1].split(' ')[0], '2 h ago', 'Opened the link on a phone, 3 minutes'], ['Sent', 'Sep 27', 'Email and text'], ['Created', 'Sep 26', 'From a site visit']],
      sent: [['Sent', 'Mon', 'Email to the client'], ['Created', 'Sep 25', 'From the price book']],
      expiring: [['Follow-up sent', 'Sep 27', 'Quote follow-up 1, by email'], ['Viewed', 'Sep 25', 'Office manager, on a computer'], ['Sent', 'Sep 24', 'Email and PDF']],
      accepted: [['Accepted and signed', D[6].replace('Accepted ', ''), 'Signed online · deposit requested'], ['Viewed', 'Earlier', 'Opened the link twice'], ['Sent', 'Earlier', 'Email and text']],
      declined: [['Declined', D[6].replace('Declined ', ''), '“Going with a cheaper option this year”'], ['Viewed', 'Earlier', 'Opened once']],
      expired: [['Expired', D[6].replace('Expired ', ''), 'No reply after 3 follow-ups'], ['Sent', 'Aug 10', 'Email and PDF']]
    };
    var act = (acted[D[0]] ? [[pr[2], 'Just now', 'From the tablet']] : []).concat(ACT[D[4]]);
    var RAIL = [['Home', 'house', 'amber', 'SmartHome.dc.html'], ['Quotes', 'doc', 'violet', 'Quotes.dc.html'], ['Jobs', 'cone', 'amber', 'Jobs.dc.html'], ['Clients', 'users', 'sage', 'Clients.dc.html'], ['Invoices', 'receipt', 'rose', 'Invoices.dc.html'], ['Schedule', 'cal', 'azure', 'Schedule.dc.html']];
    return {
      rail: RAIL.map(function (r) { var on = r[0] === 'Quotes'; return { label: r[0], ic: ic(r[1], r[2]), href: r[3], cls: on ? 'on' : '', cur: on ? 'page' : 'false' }; }),
      menuIc: ic('list', 'slate'), emptyIc: ic('search', 'slate'),
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Waiting', value: '$15,396', sub: '4 quotes', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Won this month', value: '$6,165', sub: '2 accepted', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Win rate', value: '62%', sub: '↑ 4 pts', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0,
      d: {
        no: D[0], client: D[1], job: D[2], addr: D[7], ini: ini(D[1]), tn: tints[data.indexOf(D) % 5], status: s[0], st: s[1],
        statusLine: D[4] === 'draft' ? 'Not sent yet · valid until ' + D[8] : D[6], valid: ['draft', 'sent', 'viewed', 'expiring'].indexOf(D[4]) >= 0 ? D[8] : D[6].replace(/^\w+ /, ''), validLabel: ['draft', 'sent', 'viewed', 'expiring'].indexOf(D[4]) >= 0 ? 'Valid until' : D[6].split(' ')[0], scope: D[9],
        lineCount: D[10].length + ' lines',
        lines: D[10].map(function (l, i) { return { name: l[0], amt: money(l[1]), detail: l[2], sep: i ? 'border-top: 1px solid var(--line)' : '' }; }),
        sub: money(sub), hst: money(hst), total: money(D[3]), totWhole: tw[0], totCents: '.' + tw[1], deposit: money(Math.round(D[3] * 30) / 100),
        activity: act.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], dot: i === 0 ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === act.length - 1 ? 'display: none' : '' }; }),
        primary: acted[D[0]] ? pr[2] : pr[0], secondary: pr[1], href: D[4] === 'accepted' ? 'Job.dc.html' : '#',
        act: function () { if (D[4] === 'accepted') return; var n = Object.assign({}, self.g('acted', {})); n[D[0]] = [pr[2], pr[3]]; set({ acted: n }); }
      }
    };
