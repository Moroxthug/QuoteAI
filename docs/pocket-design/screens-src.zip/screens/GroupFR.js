    var st = this.props.state || 'default', locked = st === 'locked';
    var scope = this.g('scope', 'all'), swOpen = this.g('sw', false), pb = this.g('pb', true), dup = this.g('dup', false), added = this.g('added', false);
    var money = function (n) { return Math.round(n).toLocaleString('fr-CA').replace(/\s/g, ' ') + ' $'; };
    var C = {
      reno: { name: 'Rossi Renovations', sub: 'Toronto · résidentiel · 5 pers.', inv: 41870, cost: 28630, out: 3120, m: [38200, 36900, 41870], ic: ['building', 'violet'] },
      comm: { name: 'Rossi Commercial', sub: 'Mississauga · commercial · 3 pers.', inv: 18450, cost: 13100, out: 6420, m: [12100, 15600, 18450], ic: ['building', 'teal'] }
    };
    var ELIM = 2400;
    var tot = scope === 'all'
      ? { inv: C.reno.inv + C.comm.inv - ELIM, cost: C.reno.cost + C.comm.cost - ELIM, out: C.reno.out + C.comm.out }
      : C[scope];
    var margin = (tot.inv - tot.cost) / tot.inv * 100;
    var MAX = 62000;
    var mn = ['Juil.', 'Août', 'Sept.'];
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var s = sw(pb);
    var scopeName = scope === 'all' ? 'Toutes les entreprises' : C[scope].name;
    return {
      locked: locked, open: !locked,
      tierIc: ic('tier4', 'violet'), bldIc: ic('building', 'violet'), bld2Ic: ic('building', 'slate'), infoIc: ic('help', 'sky'),
      feats: [['Finances combinées des entreprises', 'bars', 'violet'], ['Heures de toutes les équipes', 'users', 'teal'], ['Une liste de prix commune', 'tag', 'amber'], ['Une seule facture pour toutes', 'receipt', 'sage']].map(function (f) { return { label: f[0], ic: ic(f[1], f[2]) }; }),
      scopeIc: ic(scope === 'all' ? 'grid' : 'building', scope === 'comm' ? 'teal' : 'violet'), scopeName: scopeName,
      swOpen: swOpen, chev: swOpen ? 'transform: rotate(180deg)' : '',
      toggleSw: function () { set({ sw: !swOpen }); },
      scopes: [['all', 'Toutes les entreprises', '2 entreprises · combinées', 'grid', 'violet'], ['reno', 'Rossi Renovations', 'Toronto · résidentiel', 'building', 'violet'], ['comm', 'Rossi Commercial', 'Mississauga · commercial', 'building', 'teal']].map(function (o) {
        return { label: o[1], sub: o[2], ic: ic(o[3], o[4]), on: o[0] === scope, pick: function () { set({ scope: o[0], sw: false }); } };
      }),
      elimNote: scope === 'all' ? money(ELIM) + ' entre entreprises exclus' : 'Cette entreprise seulement',
      kpis: [
        { label: 'Facturé', value: money(tot.inv), sub: '↑ 11 % sur août', subStyle: 'color: var(--ok)', sep: '' },
        { label: 'Coûts', value: money(tot.cost), sub: 'Main-d’œuvre, matériaux, sous-traitants', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Marge', value: margin.toFixed(1).replace('.', ',') + ' %', sub: money(tot.inv - tot.cost) + ' de profit', subStyle: 'color: var(--ok)', sep: 'border-top: 1px solid var(--line)' },
        { label: 'À recevoir', value: money(tot.out), sub: scope === 'reno' ? '1 en retard' : '2 en retard', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line); border-top: 1px solid var(--line)' }
      ],
      months: mn.map(function (m, i) {
        var a = scope === 'comm' ? 0 : C.reno.m[i], b = scope === 'reno' ? 0 : C.comm.m[i];
        return { m: m, a: 'width: ' + (a / MAX * 100).toFixed(1) + '%; background: var(--inv); border-radius: 6px', b: 'width: ' + (b / MAX * 100).toFixed(1) + '%; background: var(--acc); border-radius: 6px', total: money(a + b) };
      }),
      companies: ['reno', 'comm'].map(function (k) {
        var c = C[k], mg = (c.inv - c.cost) / c.inv * 100;
        return { name: c.name, sub: c.sub, inv: money(c.inv), margin: 'Marge ' + mg.toFixed(1).replace('.', ',') + ' %', mStyle: 'color: var(--muted)', ic: ic(c.ic[0], c.ic[1]), pick: function () { set({ scope: k, sw: false }); } };
      }),
      addLabel: added ? 'Invitation envoyée pour créer l’entreprise' : 'Ajouter une entreprise', addSub: added ? 'Vérifiez vos courriels pour finir sur quoteai.ca' : 'Jusqu’à 3 avec votre forfait',
      addCo: function () { set({ added: true }); },
      billIc: ic('receipt', 'sage'), pbIc: ic('tag', 'amber'), usersIc: ic('users', 'indigo'), linkIc: ic('link', 'azure'), okIc: ic('check', 'sage'),
      pbOn: pb, pbTrack: s.t, pbKnob: s.k, pbSub: pb ? '212 articles utilisés par les deux' : 'Chaque entreprise a la sienne',
      flipPb: function () { set({ pb: !pb }); },
      dupOpen: !dup, dupDone: dup, linkDup: function () { set({ dup: true }); }
    };
