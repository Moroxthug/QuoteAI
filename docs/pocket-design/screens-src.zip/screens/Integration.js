    var mode = this.g('mode', this.props.state || 'connected');
    var fixed = this.g('fixed', false);
    var isErr = mode === 'error' && !fixed;
    var isOn = mode !== 'notConnected';
    var ret = this.g('ret', '');
    var sw = function (on) { return { t: on ? 'background: var(--acc)' : 'background: var(--track-off)', k: on ? 'transform: translateX(20px)' : 'transform: translateX(0)' }; };
    var master = this.g('master', true), ms = sw(master);
    var running = this.g('running', false), synced = this.g('synced', false);

    var SY = [
      ['inv', 'Invoices', 'Sent invoices go to QuickBooks with their tax codes', 'receipt', 'amber'],
      ['pay', 'Payments', 'Both ways. Payments recorded in QuickBooks come back here', 'card', 'violet'],
      ['cli', 'Clients', 'New clients become QuickBooks customers', 'users', 'azure'],
      ['exp', 'Expenses', 'Confirmed job costs go in as expenses', 'box', 'clay']
    ];
    var on = this.g('on', { inv: true, pay: true, cli: true, exp: false });
    var syncs = SY.map(function (s) {
      var o = on[s[0]] && master, x = sw(o);
      return { title: s[1], sub: s[2], ic: ic(s[3], s[4]), on: o, track: x.t, knob: x.k, flip: function () { var n = Object.assign({}, self.g('on', on)); n[s[0]] = !n[s[0]]; set({ on: n, master: true }); } };
    });

    var code = this.g('code', isErr ? '' : 'HST ON');
    var MAPS = [
      ['HST 13%', 'Tax · Ontario', code, 'tax'],
      ['GST 5%', 'Tax · out-of-province work', 'GST', ''],
      ['Tax-exempt', 'Tax', 'Exempt', ''],
      ['Job income', 'Income account', 'Sales · Renovation income', ''],
      ['Deposits', 'Deposit account', 'Undeposited Funds', ''],
      ['Materials', 'Expense account', 'Job Materials', '']
    ];
    var openPicker = function () { set({ picker: true, pick: self.g('pick', 'HST ON') }); };
    var maps = MAPS.map(function (m, i) {
      var bad = m[3] === 'tax' && !m[2];
      return { from: m[0], kind: m[1], to: m[2], ok: !bad, bad: bad, sep: '', tap: m[3] === 'tax' ? openPicker : function () {} };
    });

    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var retried = this.g('retried', false);
    var LOG = [];
    if (isErr) {
      LOG.push({ k: 'inv', title: 'INV-0423 · Okoye Condo', sub: money(2210) + ' · HST 13% has no QuickBooks tax code', st: 'st-bad si-x', status: 'Failed', time: '8:12', fix: 'Match tax code', go: openPicker });
      LOG.push({ k: 'inv', title: 'INV-0422 · Priya Nair', sub: money(1865.10) + ' · same reason', st: 'st-bad si-x', status: 'Failed', time: '8:12' });
    }
    if (mode === 'error' && fixed) {
      LOG.push({ k: 'inv', title: 'INV-0423 · Okoye Condo', sub: money(2210) + ' · resent with HST ON', st: 'st-ok si-check', status: 'Sent', time: 'now' });
      LOG.push({ k: 'inv', title: 'INV-0422 · Priya Nair', sub: money(1865.10) + ' · resent with HST ON', st: 'st-ok si-check', status: 'Sent', time: 'now' });
    }
    LOG.push({ k: 'inv', title: 'INV-0421 · Gill Residence', sub: money(2980) + ' · with HST ON', st: 'st-ok si-check', status: 'Sent', time: '7:58' });
    LOG.push({ k: 'pay', title: 'Payment · INV-0412', sub: 'Tom & Lena Hart · ' + money(2340) + ' · recorded in QuickBooks', st: 'st-info si-q2', status: 'Came back', time: '7:40' });
    if (!isErr && mode !== 'error') {
      LOG.push(retried
        ? { k: 'cli', title: 'Client · Marchetti Bakery', sub: 'Added as a customer', st: 'st-ok si-check', status: 'Sent', time: 'now' }
        : { k: 'cli', title: 'Client · Marchetti Bakery', sub: 'QuickBooks didn’t answer in time', st: 'st-bad si-x', status: 'Failed', time: '7:31', fix: 'Retry', go: function () { set({ retried: true }); } });
    }
    LOG.push({ k: 'pay', title: 'Payment · INV-0415', sub: 'Harbourfront Dental · ' + money(1450) + ' · card', st: 'st-ok si-check', status: 'Sent', time: '6:02' });
    var LIC = { inv: ['receipt', 'amber'], pay: ['card', 'violet'], cli: ['user', 'azure'], exp: ['box', 'clay'] };
    var log = LOG.map(function (l, i) {
      var bad = l.status === 'Failed';
      return { title: l.title, sub: l.sub, st: l.st, status: l.status, time: l.time, ic: bad ? ic('warn', 'rose') : ic(LIC[l.k][0], LIC[l.k][1]), sep: '', canFix: !!l.fix, fixLabel: l.fix || '', fix: l.go || function () {} };
    });

    var pick = this.g('pick', 'HST ON');
    var CODES = [['HST ON', '13% · Ontario'], ['GST', '5%'], ['HST NS', '14% · Nova Scotia'], ['Exempt', '0%']];
    var codes = CODES.map(function (c, i) {
      var o = c[0] === pick;
      return { name: c[0], sub: c[1], on: o, sep: '', dot: o ? 'background: var(--inv); color: var(--on-inv)' : 'box-shadow: inset 0 0 0 1.6px var(--line2); color: transparent', chk: o ? 'opacity: 1' : 'opacity: 0', pick: function () { set({ pick: c[0] }); } };
    });

    var connecting = this.g('connecting', false);
    var bf = this.g('bf', 0);
    var RET = {
      fixed: ['b-ok', ['check', 'sage'], 'Tax code matched.', '2 invoices sent to QuickBooks.'],
      connected: ['b-ok', ['check', 'sage'], 'Connected to Rossi Renovations Inc.', 'Check the matching below before the first sync.'],
      disconnected: ['b-info', ['sync', 'azure'], 'QuickBooks is disconnected.', 'Nothing in QuickBooks was changed.'],
      cancelled: ['b-warn', ['warn', 'amber'], 'Connecting was cancelled.', 'Nothing was shared. Try again when you’re ready.']
    };
    var r = RET[ret];
    var stW = !isOn ? ['Not connected', 'st-mute si-off'] : isErr ? ['Needs attention', 'st-bad'] : !master ? ['Paused', 'st-warn si-pause'] : ['Connected', 'st-ok'];
    var tries = this.g('tries', 0);
    return {
      appIc: ic('bars', 'sage'), errIc: ic('warn', 'rose'), backIc: ic('export', 'slate'), discIc: ic('warn', 'rose'),
      stWord: stW[0], stCls: stW[1],
      isOn: isOn, isOff: !isOn, isErr: isErr,
      returnMsg: !!r, retCls: r ? r[0] : '', retIc: r ? ic(r[1][0], r[1][1]) : ic('dot', 'slate'), retTitle: r ? r[2] : '', retSub: r ? r[3] : '',
      master: master, masterTrack: ms.t, masterKnob: ms.k, flipMaster: function () { set({ master: !master }); },
      syncSub: master ? 'Every 15 minutes, and right after a payment' : 'Paused. Nothing is sent until you turn it back on',
      lastSync: synced ? 'Just now' : 'Today, 8:12 am', running: running, runLabel: running ? 'Syncing…' : 'Run now',
      runNow: function () { if (self.g('running', false)) return; set({ running: true }); setTimeout(function () { set({ running: false, synced: true }); }, 1500); },
      syncs: syncs, maps: maps, log: log, openPicker: openPicker,
      backSub: bf === 2 ? '38 invoices sent · Jan 1 to Aug 31' : 'Since Jan 1, 2026 · 38 invoices', backLabel: bf === 1 ? 'Sending…' : bf === 2 ? 'Done' : 'Send',
      backfill: function () { if (self.g('bf', 0)) return; set({ bf: 1 }); setTimeout(function () { set({ bf: 2 }); }, 1600); },
      pickerOpen: this.g('picker', false), discOpen: this.g('disc', false), codes: codes,
      closeSheets: function () { set({ picker: false, disc: false }); },
      saveCode: function () { set({ picker: false, code: self.g('pick', 'HST ON'), fixed: true, ret: 'fixed' }); },
      askDisc: function () { set({ disc: true }); },
      disconnect: function () { set({ disc: false, mode: 'notConnected', ret: 'disconnected' }); },
      does: [
        { ic: ic('receipt', 'amber'), title: 'Invoices go to your books', sub: 'With the right tax code, so HST lines up at filing time' },
        { ic: ic('card', 'violet'), title: 'Payments go both ways', sub: 'Mark an invoice paid in either place and the other one knows' },
        { ic: ic('box', 'clay'), title: 'Job costs become expenses', sub: 'Only the ones you confirm, filed to the account you pick' }
      ],
      steps: [
        { n: '1', title: 'Sign in to QuickBooks', sub: 'On Intuit’s own page' },
        { n: '2', title: 'Pick your company', sub: 'If you have more than one' },
        { n: '3', title: 'Match tax codes and accounts', sub: 'We suggest a match for each one' }
      ],
      perms: ['Read your tax codes and chart of accounts', 'Add customers, invoices and payments', 'Add expenses for confirmed costs', 'Read payments you record in QuickBooks'],
      nots: ['See your bank login or run payroll', 'Delete or change past entries'],
      connecting: connecting, connectLabel: connecting ? 'Opening QuickBooks…' : 'Connect QuickBooks',
      connect: function () {
        if (self.g('connecting', false)) return;
        set({ connecting: true, ret: '' });
        setTimeout(function () {
          var t = self.g('tries', 0);
          if (t === 0 && self.g('ret', '') === '' && self.props.state === 'notConnected') set({ connecting: false, ret: 'cancelled', tries: 1 });
          else set({ connecting: false, mode: 'connected', ret: 'connected', fixed: true, code: 'HST ON' });
        }, 1500);
      }
    };
