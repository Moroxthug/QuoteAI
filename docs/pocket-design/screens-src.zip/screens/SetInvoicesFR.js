    // ---- shared settings-row helpers (same rows as Settings) ----
    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var mk = function (icon, tone, label, sub, extra) {
      var r = { ic: ic(icon || 'dot', tone || 'slate'), label: label, sub: sub || '', hasSub: !!sub, labelStyle: '', sep: '',
        isA: false, notA: true, href: '#', isVal: false, isLink: false, isStatus: false, isBtn: false, isSwitch: false, isStepper: false, isSeg: false, hasNote: false,
        val: '', valCls: '', stCls: '', stWord: '', btn: '', btnCls: 'btn-s', act: function () {}, note: '',
        on: false, track: '', knob: '', flip: function () {}, dec: function () {}, inc: function () {}, decLabel: '', incLabel: '', segCols: '', ind: '', opts: [], lineStyle: '', rowStyle: '', icStyle: '', stepStyle: '' };
      var o = Object.assign(r, extra || {});
      o.notA = !o.isA;
      return o;
    };
    var val = function (icon, tone, label, sub, v, mono) { return mk(icon, tone, label, sub, { isVal: true, val: v, valCls: mono ? 'mono' : '' }); };
    var lnk = function (icon, tone, label, sub, v, href, mono) { return mk(icon, tone, label, sub, { isLink: true, val: v || '', valCls: mono ? 'mono' : '', isA: !!href, href: href || '#' }); };
    var btnRow = function (icon, tone, label, sub, b, act, cls) { return mk(icon, tone, label, sub, { isBtn: true, btn: b, act: act || function () {}, btnCls: cls || 'btn-s' }); };
    var sw = function (key, def, icon, tone, label, sub) {
      var on = self.g(key, def);
      return mk(icon, tone, label, sub, { isSwitch: true, on: on,
        track: (on ? 'background: var(--acc)' : 'background: var(--track-off)') + (RO ? '; opacity: .45; cursor: default' : ''),
        knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { if (RO) return; var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var step = function (key, def, st, min, max, fmt, icon, tone, label, sub) {
      var v = self.g(key, def);
      var f = typeof fmt === 'function' ? fmt : function (x) { return x + fmt; };
      return mk(icon, tone, label, sub, { isStepper: true, val: f(v), decLabel: 'Diminuer : ' + label.toLowerCase(), incLabel: 'Augmenter : ' + label.toLowerCase(),
        stepStyle: RO ? 'opacity: .5' : '',
        dec: function () { if (RO) return; var o = {}; o[key] = Math.max(min, self.g(key, def) - st); set(o); },
        inc: function () { if (RO) return; var o = {}; o[key] = Math.min(max, self.g(key, def) + st); set(o); } });
    };
    var seg = function (key, def, icon, tone, label, sub, labels) {
      var cur = self.g(key, def), n = labels.length;
      return mk(icon, tone, label, sub, { isSeg: true, lineStyle: 'min-height: 56px', rowStyle: 'align-items: flex-start', icStyle: 'margin-top: 14px',
        segCols: 'grid-template-columns: repeat(' + n + ', minmax(0, 1fr))' + (RO ? '; opacity: .55' : ''),
        ind: 'width: calc((100% - 4px) / ' + n + '); transform: translateX(' + (cur * 100) + '%)',
        opts: labels.map(function (l, i) { return { label: l, on: i === cur, style: i === cur ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var o = {}; o[key] = i; set(o); } }; }) });
    };
    var stat = function (r, word, cls) { r.isStatus = true; r.stWord = word; r.stCls = cls; return r; };
    var note = function (r, t) { r.hasNote = true; r.note = t; return r; };
    var grp = function (title, rows, foot, delay) {
      rows.forEach(function (r, i) { r.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
      return { title: title || '', hasTitle: !!title, rows: rows, hasFoot: !!foot, foot: foot || '', delay: 'animation-delay: ' + (delay || 0) + 'ms' + (title ? '' : '; padding-top: 12px') };
    };
    var roBanner = { show: RO, ic: ic('lock', 'slate') };
    // ---- screen ----
    var stripe = ST !== 'stripeNotConnected';
    var terms = self.g('terms', 1), termsW = ['À réception', 'Net 15 j', 'Net 30 j'][terms];
    var r1 = self.g('r1', true), r2 = self.g('r2', true), r3 = self.g('r3', true);
    var dot = function (on) { return on ? 'background: var(--acc)' : 'background: var(--card); box-shadow: inset 0 0 0 2px var(--line2)'; };
    var late = self.g('late', true), hold = self.g('hold', true), auto = self.g('auto', true);
    var dayFmt = function (x) { return x === 0 ? 'Même jour' : x + (x === 1 ? ' jour' : ' jours'); };
    var pay = [
      sw('etr', true, 'bank', 'sage', 'Virement Interac', 'À pay@rossireno.ca · dépôt automatique activé')
    ];
    if (stripe) pay.push(stat(lnk('card', 'violet', 'Carte, via Stripe', 'Versements en 2 jours ouvrables', '', 'Integration.dc.html'), 'Connecté', 'st-ok'));
    else pay.push(btnRow('card', 'violet', 'Carte, via Stripe', 'Pas encore connecté', 'Connecter', function () {}, 'btn-p'));
    pay.push(sw('chq', true, 'receipt', 'stone', 'Chèque', 'À l’ordre de Rossi Renovations Inc.'));
    var dep = [ step('dep', 30, 5, 0, 50, ' %', 'percent', 'amber', 'Dépôt par défaut', 'Demandé à l’acceptation de la soumission'),
      sw('hold', true, 'lock', 'indigo', 'Retenue', hold ? '10 % retenus sur les factures d’étape' : 'Désactivée. À activer pour la Loi sur la construction (Ont.)') ];
    if (hold) dep.push(val('cal', 'teal', 'Libération de la retenue', 'Facturée à la fin du délai de privilège', '60 jours après'));
    var lateRows = [ sw('late', true, 'warn', 'rose', 'Facturer des frais', 'Indiqués sur chaque facture') ];
    if (late) { lateRows.push(step('rate', 2, 0.5, 0.5, 5, function (x) { return String(x).replace('.', ',') + ' %/mois'; }, 'percent', 'clay', 'Taux', 'Par mois sur le solde')); lateRows.push(step('after', 30, 5, 0, 60, dayFmt, 'clock', 'amber', 'Débute après', 'Après l’échéance')); }
    return {
      roBanner: roBanner, noStripe: !stripe, cardWarn: ic('card', 'amber'), invIc: ic('receipt', 'violet'),
      nextNo: 'INV-0' + self.g('nextN', 425), termsTag: termsW,
      gNum: grp('Numérotation et conditions', [
        lnk('tag', 'lilac', 'Format du numéro', 'Préfixe, puis 4 chiffres', 'INV-0425', RO ? '' : '#', true),
        seg('terms', 1, 'cal', 'teal', 'Conditions de paiement', 'Échéance des nouvelles factures', ['À réception', 'Net 15 j', 'Net 30 j']),
        sw('auto', true, 'send', 'sky', 'Envoi automatique', auto ? 'Selon l’échéancier de paiement du chantier' : 'Désactivé. Vous envoyez chaque facture'),
      ].concat(auto ? [step('delay', 1, 1, 0, 7, dayFmt, 'clock', 'stone', 'Délai d’envoi', 'Après la fin de l’étape')] : []), '', 80),
      tl: [
        { lbl: '3 jours avant', pos: 'left: 0; align-items: flex-start', dot: dot(r1), lblStyle: r1 ? 'color: var(--ink)' : 'color: var(--faint)' },
        { lbl: 'Échéance', pos: 'left: 50%; transform: translateX(-50%); align-items: center', dot: dot(r2), lblStyle: r2 ? 'color: var(--ink)' : 'color: var(--faint)' },
        { lbl: '7 jours après', pos: 'right: 0; align-items: flex-end', dot: dot(r3), lblStyle: r3 ? 'color: var(--ink)' : 'color: var(--faint)' }
      ],
      gRem: (function (g) { g.rows[0].sep = 'border-top: 1px solid var(--line)'; return g; })(grp('Rappels', [
        sw('r1', true, 'bell', 'amber', '3 jours avant', 'Un rappel amical avec le lien de paiement'),
        sw('r2', true, 'cal', 'teal', 'Le jour de l’échéance', 'Solde et façons de payer'),
        sw('r3', true, 'warn', 'rose', '7 jours après', late ? 'Plus ferme, mentionne les frais de retard' : 'Plus ferme, demande une date'),
        seg('remBy', 2, 'chat', 'sky', 'Envoyer par', '', ['Courriel', 'Texto', 'Les deux'])
      ], 'Les rappels cessent dès qu’un paiement arrive ou que vous marquez la facture payée.', 130)),
      gPay: grp('Modes de paiement', pay, '', 180),
      gDep: grp('Dépôts et retenue', dep, '', 230),
      gLate: grp('Frais de retard', lateRows, late ? 'Les factures indiquent aussi le taux annuel, comme l’exige la Loi sur l’intérêt.' : '', 280)
    };
