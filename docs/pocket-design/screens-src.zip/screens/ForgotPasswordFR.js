    var PS = this.props.step || 'request';
    var MAP = { request: 'request', requestOffline: 'request', sent: 'sent', newPassword: 'newPassword', linkExpired: 'newPassword', done: 'done' };
    var step = self.g('step', MAP[PS] || 'request');
    var email = self.g('email', 'marco@rossireno.ca');
    var sending = self.g('sending', false), saving = self.g('saving', false), shown = self.g('shown', false);
    var sec = self.g('sec', 30), resent = self.g('resent', false);
    var p1 = self.g('p1', PS === 'newPassword' ? 'galloway-48' : ''), p2 = self.g('p2', PS === 'newPassword' ? 'galloway-4' : '');
    var expired = PS === 'linkExpired' && !self.g('clearExp', false);
    if (!self._timer) { self._timer = setInterval(function () { if (self.g('step', MAP[PS]) !== 'sent') return; var s = self.g('sec', 30); if (s > 0) self.setState({ sec: s - 1 }); }, 1000); }
    var r1 = p1.length >= 8, r2 = /[0-9]/.test(p1) || /[^A-Za-z0-9]/.test(p1), r3 = p1.length > 0 && p1 === p2;
    var mismatch = p2.length >= p1.length && p2.length > 0 && p1 !== p2;
    var RULES = [[r1, '8 caractères ou plus'], [r2, 'Un chiffre ou un symbole'], [r3, 'Les deux mots de passe concordent']];
    var offline = PS === 'requestOffline' && !self.g('online', false);
    return {
      isReq: step === 'request', isSent: step === 'sent', isNew: step === 'newPassword', isDone: step === 'done',
      backLink: step === 'request' || step === 'newPassword', backBtn: step === 'sent', noBack: step === 'done',
      back: function () { set({ step: 'request' }); },
      toReq: function () { set({ step: 'request', sec: 30, resent: false, clearExp: true }); },
      email: email, onEmail: function (e) { set({ email: e.target.value }); },
      offline: offline, sending: sending, sendLabel: sending ? 'Envoi…' : 'Envoyer le lien', cantSend: email.indexOf('@') < 1 || sending || offline,
      send: function () {
        if (offline) return;
        set({ sending: true });
        setTimeout(function () { set({ sending: false, step: 'sent', sec: 30 }); }, 1100);
      },
      sec: sec, waiting: sec > 0, canResend: sec === 0, resent: resent,
      resend: function () { set({ sec: 30, resent: true }); },
      openMail: function () { set({ step: 'newPassword' }); },
      expired: expired,
      p1: p1, p2: p2,
      onP1: function (e) { set({ p1: e.target.value }); }, onP2: function (e) { set({ p2: e.target.value }); },
      p2Cls: mismatch ? 'fp-bad' : '', p2Label: mismatch ? 'Ne concorde pas encore' : 'Confirmer le mot de passe',
      shown: shown, notShown: !shown, passType: shown ? 'text' : 'password', showLabel: shown ? 'Masquer les mots de passe' : 'Afficher les mots de passe',
      toggleShow: function () { set({ shown: !self.g('shown', false) }); },
      rules: RULES.map(function (r) { return { cls: r[0] ? 'on' : '', label: r[1], sr: r[0] ? 'fait' : 'pas encore' }; }),
      cantSave: !(r1 && r2 && r3) || expired || saving, saving: saving, saveLabel: saving ? 'Enregistrement…' : 'Enregistrer le mot de passe',
      save: function () { set({ saving: true }); setTimeout(function () { set({ saving: false, step: 'done' }); }, 1100); },
      mailIc: ic('mail', 'sky'), cloudIc: ic('cloud', 'amber'), checkIc: ic('check', 'sage'), clockIc: ic('clock', 'amber'),
      keyIc: ic('key', 'violet'), lockIc: ic('lock', 'indigo'), doneIc: ic('check', 'sage'), faceIc: ic('face', 'slate'), shieldIc: ic('shield', 'violet')
    };
