    var phs = self.g('phs', 'idle'), rjGone = self.g('rj', '');
    var cf = self.g('cf', { dep: 'mine', start: '' });
    var CF = [['dep', 'Deposit', '30%', '25%', 'Luca'], ['start', 'Start date', 'Mon Oct 5', 'Wed Oct 7', 'office']];
    var nPicked = CF.filter(function (c) { return cf[c[0]]; }).length;
    return {
      i: { cloud: ic('cloud', 'amber'), sync: ic('sync', 'sky'), photo: ic('photo', 'sky'), warn: ic('warn', 'clay'), sync2: ic('sync', 'violet'), star: ic('star', 'violet'), cloud2: ic('cloud', 'slate'),
        lock: ic('lock', 'violet'), eye: ic('eye', 'sky'), shield: ic('shield', 'slate'), cone: ic('cone', 'amber'), gift: ic('gift', 'violet'), lock2: ic('lock', 'violet'), face: ic('face', 'lilac'), face2: ic('face', 'violet') },
      ph: {
        title: phs === 'done' ? 'Photos sent' : '6 photos waiting for Wi-Fi',
        sub: phs === 'busy' ? 'Sending 38 MB on mobile data…' : phs === 'done' ? 'Added to Hart basement · just now' : '38 MB · Hart basement, drywall phase',
        idle: phs === 'idle', busy: phs === 'busy', done: phs === 'done',
        send: function () { set({ phs: 'busy' }); setTimeout(function () { set({ phs: 'done' }); }, 2300); }
      },
      rj: {
        title: rjGone ? 'Nothing waiting' : '1 change couldn\'t be sent',
        sub: rjGone ? 'Everything on this phone is up to date.' : 'Tap Retry, or Discard to keep what the server has.',
        items: rjGone ? [] : [{ what: 'Price on Q-2026-119, line 3', from: '$860.00', to: '$920.00', at: '9:52', why: 'The quote was sent to Dana before this edit arrived.',
          retry: function () { set({ rj: 'retried' }); }, discard: function () { set({ rj: 'discarded' }); } }],
        clear: !!rjGone, clearMsg: rjGone === 'retried' ? 'Sent on retry at 9:54.' : 'Change discarded. The quote keeps $860.00.',
        reset: function () { set({ rj: '' }); }
      },
      cf: CF.map(function (c) {
        var v = cf[c[0]];
        var pick = function (w) { return function () { var o = Object.assign({}, self.g('cf', { dep: 'mine', start: '' })); o[c[0]] = w; set({ cf: o }); }; };
        return { field: c[1], mine: c[2], theirs: c[3], who: c[4], mineOn: v === 'mine', theirsOn: v === 'theirs', mineCls: v === 'mine' ? 'on' : '', theirsCls: v === 'theirs' ? 'on' : '', pickMine: pick('mine'), pickTheirs: pick('theirs') };
      }),
      cfNotReady: nPicked < CF.length, cfBtn: nPicked < CF.length ? 'Choose ' + (CF.length - nPicked) + ' more' : 'Save my choices',
      meters: [
        { ic: ic('receipt', 'amber'), label: 'Receipt scans', used: 42, max: 100, hasSt: false, st: '', status: '', bar: 'width: 42%', note: 'Resets Oct 1' },
        { ic: ic('chat', 'sage'), label: 'WhatsApp messages', used: 184, max: 200, hasSt: true, st: 'st-warn', status: 'Almost used', bar: 'width: 92%; background: var(--warn-dot)', note: '16 left · resets Oct 1' },
        { ic: ic('phone', 'sky'), label: 'SMS texts', used: 250, max: 250, hasSt: true, st: 'st-bad', status: 'Used up', bar: 'width: 100%; background: var(--bad)', note: 'Texts pause until Oct 1. Email and WhatsApp still send.' }
      ],
      perms: [
        { ic: ic('camera', 'sky'), title: 'Allow the camera', body: 'For receipts and site photos. Nothing is taken unless you tap.' },
        { ic: ic('mic', 'violet'), title: 'Allow the microphone', body: 'Only while the mic is on, to describe jobs and write notes.' },
        { ic: ic('pin', 'clay'), title: 'Allow location at clock-in', body: 'Only at clock-in and clock-out, to confirm you are on site.' },
        { ic: ic('bell', 'violet'), title: 'Allow notifications', body: 'Know when a quote is viewed, signed or paid.' }
      ]
    };
