    var step = self.g('step', null) || Number(this.props.step || 1);
    var picked = self.g('picked', ['renovation', 'painting', 'drywall']);
    var provId = self.g('prov', 'ON'), provOpen = self.g('provOpen', false);
    var co = self.g('co', 'Rossi Renovations'), ph = self.g('ph', '416 555 0182'), em = self.g('em', 'marco@rossireno.ca'), bn = self.g('bn', '');
    var more = self.g('more', false), size = self.g('size', 1), field = self.g('field', true), codes = self.g('codes', false);
    var people = self.g('people', [['Luca Bianchi', 'luca@rossireno.ca', 1], ['Amara Okafor', '647 555 0133', 2]]);
    var TR = [['general', 'Entreprise générale', 'house', 'slate'], ['renovation', 'Rénovation', 'hammer', 'violet'], ['painting', 'Peinture', 'brush', 'rose'], ['electrical', 'Électricité', 'bolt', 'gold'], ['plumbing', 'Plomberie', 'drop', 'azure'], ['hvac', 'Chauffage et climatisation', 'fan', 'sky'], ['roofing', 'Toiture', 'roof', 'clay'], ['flooring', 'Planchers', 'grid', 'amber'], ['drywall', 'Gypse', 'box', 'stone'], ['masonry', 'Maçonnerie', 'bricks', 'clay'], ['landscaping', 'Aménagement paysager', 'leaf', 'sage'], ['other', 'Autre chose', 'plus', 'lilac']];
    var P = [['ON', 'Ontario', 'TVH 13 %', 'sur les soumissions et les factures.'], ['QC', 'Québec', 'TPS 5 % + TVQ 9,975 %', 'sur deux lignes distinctes des soumissions et des factures.'], ['BC', 'Colombie-Britannique', 'TPS 5 % + TVP 7 %', 'La TVP s’applique aux matériaux, pas à la main-d’œuvre.'], ['AB', 'Alberta', 'TPS 5 %', 'sur les soumissions et les factures.'], ['SK', 'Saskatchewan', 'TPS 5 % + TVP 6 %', 'sur les soumissions et les factures.'], ['MB', 'Manitoba', 'TPS 5 % + TVD 7 %', 'sur les soumissions et les factures.'], ['NS', 'Nouvelle-Écosse', 'TVH 14 %', 'sur les soumissions et les factures.'], ['NB', 'Nouveau-Brunswick', 'TVH 15 %', 'sur les soumissions et les factures.'], ['NL', 'Terre-Neuve-et-Labrador', 'TVH 15 %', 'sur les soumissions et les factures.'], ['PE', 'Île-du-Prince-Édouard', 'TVH 15 %', 'sur les soumissions et les factures.'], ['YT', 'Yukon', 'TPS 5 %', 'sur les soumissions et les factures.'], ['NT', 'Territoires du Nord-Ouest', 'TPS 5 %', 'sur les soumissions et les factures.'], ['NU', 'Nunavut', 'TPS 5 %', 'sur les soumissions et les factures.']];
    var pr = P.filter(function (p) { return p[0] === provId; })[0] || P[0];
    var trades = TR.map(function (t) {
      var on = picked.indexOf(t[0]) > -1;
      return { name: t[1], ic: ic(t[2], t[3]), on: on, cls: on ? 'on' : '', toggle: function () { var cur = self.g('picked', ['renovation', 'painting', 'drywall']).slice(), i = cur.indexOf(t[0]); if (i > -1) cur.splice(i, 1); else cur.push(t[0]); set({ picked: cur }); } };
    });
    var names = TR.filter(function (t) { return picked.indexOf(t[0]) > -1; }).map(function (t) { return t[1]; });
    var pickedLine = names.length ? names.length + (names.length > 1 ? ' choisis · ' : ' choisi · ') + names.join(', ') : 'Rien de choisi pour l’instant. Vous pourrez le changer plus tard.';
    var ROLES = [['Admin', 'tag-acc'], ['Contremaître', ''], ['Équipe', '']];
    var TN = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    var ppl = people.map(function (p, i) {
      var r = ROLES[p[2]];
      return { name: p[0], contact: p[1], ini: p[0].split(' ').map(function (w) { return w[0]; }).join('').slice(0, 2), tn: TN[i % 5], role: r[0], roleCls: r[1], cycle: function () { var cur = self.g('people', people).map(function (x) { return x.slice(); }); cur[i][2] = (cur[i][2] + 1) % 3; set({ people: cur }); } };
    });
    var SZ = ['Juste moi', '2 à 5', '6 à 15', '16 et +'];
    var go = function (n) { set({ step: n }); };
    var nm = co.trim() || 'Votre entreprise';
    return {
      step: step, isS1: step === 1, isS2: step === 2, isS3: step === 3, notLast: step < 3, canBack: step > 1, noBack: step === 1,
      s1: 'on', s2: step >= 2 ? 'on' : '', s3: step >= 3 ? 'on' : '',
      back: function () { go(Math.max(1, step - 1)); }, next: function () { go(Math.min(3, step + 1)); },
      skip: function () { if (step < 3) go(step + 1); else window.location.href = 'SmartHome.dc.html'; },
      nextLabel: step === 1 && !names.length ? 'Continuer sans métier' : 'Continuer',
      trades: trades, pickedLine: pickedLine,
      prov: { name: pr[1], tax: pr[2], note: pr[3], short: pr[1] + ' · ' + pr[2] },
      openProv: function () { set({ provOpen: true }); }, closeProv: function () { set({ provOpen: false }); }, provOpen: provOpen,
      provs: P.map(function (p) { return { name: p[1], tax: p[2], on: p[0] === provId, pick: function () { set({ prov: p[0], provOpen: false }); } }; }),
      co: co, ph: ph, em: em, bn: bn,
      onCo: function (e) { set({ co: e.target.value }); }, onPh: function (e) { set({ ph: e.target.value }); }, onEm: function (e) { set({ em: e.target.value }); }, onBn: function (e) { set({ bn: e.target.value }); },
      coShow: nm, phShow: ph || '—', emShow: em || 'pas encore de courriel', bnShow: bn ? 'TPS/TVH ' + bn : 'Numéro de TPS/TVH non ajouté',
      more: more, moreRot: more ? 'transform: rotate(180deg)' : 'transform: rotate(0)', toggleMore: function () { set({ more: !self.g('more', false) }); },
      licLabel: provId === 'QC' ? 'Numéro de licence RBQ' : 'Numéro de licence d’entrepreneur',
      sizeInd: 'transform: translateX(' + (size * 100) + '%)',
      sizes: SZ.map(function (l, i) { return { label: l, on: i === size, cls: i === size ? '' : '', style: i === size ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ size: i }); } }; }),
      solo: size === 0, hasTeam: size > 0,
      field: field, fieldTrack: field ? 'background: var(--acc)' : 'background: var(--track-off)', fieldKnob: field ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipField: function () { set({ field: !self.g('field', true) }); },
      people: ppl, addPerson: function () { var cur = self.g('people', people).slice(); if (cur.length < 4) cur.push([['Sofia Marin', 'sofia.marin@gmail.com', 2], ['Dev Patel', '416 555 0177', 2]][cur.length - 2] || ['Nouvelle personne', 'Ajouter un téléphone ou un courriel', 2]); set({ people: cur }); },
      codesMade: codes, codesNot: !codes, makeCodes: function () { set({ codes: true }); },
      codeSub: codes ? 'Partagez-les depuis Équipe en tout temps' : 'Pour l’équipe sans courriel',
      pinIc: ic('pin', 'rose'), taxIc: ic('percent', 'violet'),
      coIc: ic('building', 'violet'), phIc: ic('phone', 'teal'), emIc: ic('mail', 'sky'), moreIc: ic('list', 'slate'),
      logoIc: ic('camera', 'lilac'), bnIc: ic('doc', 'indigo'), licIc: ic('shield', 'sage'), adIc: ic('pin', 'rose'), etIc: ic('bank', 'gold'),
      soloIc: ic('user', 'violet'), crewIc: ic('cone', 'amber'), codeIc: ic('key', 'indigo')
    };
