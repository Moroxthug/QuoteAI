    var ps = this.props.state || 'single';
    var view = self.g('view', ps);
    var declined = self.g('declined', false);
    var ans = self.g('ans', { r: '', h: '' });
    var pick = self.g('pick', 'r');
    var INV = [['r', 'Rossi Renovations', 'Foreman', 'Marco Rossi', 'Sep 27', 'building', 'violet'], ['h', 'Harbourfront Builders', 'Office', 'Nadia Haddad', 'Sep 28', 'house', 'teal']];
    var setAns = function (k, v) { var cur = self.g('ans', { r: '', h: '' }), n = { r: cur.r, h: cur.h }; n[k] = v; set({ ans: n }); };
    var invites = INV.map(function (v) {
      var a = ans[v[0]];
      return { co: v[1], role: v[2], from: v[3], when: v[4], ic: ic(v[5], v[6]), open: !a, done: !!a,
        stCls: a === 'yes' ? 'st-ok si-check' : 'st-bad si-x', stLabel: a === 'yes' ? 'Joined' : 'Declined',
        accept: function () { setAns(v[0], 'yes'); }, decline: function () { setAns(v[0], 'no'); }, undo: function () { setAns(v[0], ''); } };
    });
    var yes = INV.filter(function (v) { return ans[v[0]] === 'yes'; });
    var COS = [['r', 'Rossi Renovations', 'Toronto · 6 people', 'Foreman', 'building', 'violet', 'ForemanHome.dc.html'], ['h', 'Harbourfront Builders', 'Mississauga · 14 people', 'Office', 'house', 'teal', 'SmartHome.dc.html']];
    var cur = COS.filter(function (c) { return c[0] === pick; })[0];
    var TT = {
      single: [declined ? 'Invite declined' : 'Pending invitation', declined ? 'Marco won’t be told why. You can still join later from a new invite.' : 'Signed in as luca@rossireno.ca'],
      multiple: ['Pending invitations', 'Two teams want you. Join one or both.'],
      picker: ['Choose a company', 'You’re on two teams. Which one now?'],
      wrongAccount: ['Wrong account', 'Invites are tied to one email.'],
      expired: ['Pending invitation', 'Signed in as luca@rossireno.ca']
    }[view];
    return {
      title: TT[0], sub: TT[1],
      isSingle: view === 'single', isMulti: view === 'multiple', isPicker: view === 'picker', isWrong: view === 'wrongAccount', isExpired: view === 'expired',
      can: ['Run jobs on site, log costs and photos', 'See quotes and invoices, without changing them'],
      declined: declined, notDeclined: !declined,
      declineOne: function () { set({ declined: !self.g('declined', false) }); },
      invites: invites, singleOpen: view === 'single' && !declined, singleDeclined: view === 'single' && declined,
      multiClick: function (e) { if (yes.length === 2) { if (e && e.preventDefault) e.preventDefault(); set({ view: 'picker' }); } },
      multiGo: view === 'multiple' && yes.length > 0,
      multiHref: yes.length === 2 ? '#' : yes.length === 1 && yes[0][0] === 'h' ? 'SmartHome.dc.html' : 'ForemanHome.dc.html',
      cos: COS.map(function (c) { return { name: c[1], meta: c[2], role: c[3], ic: ic(c[4], c[5]), on: c[0] === pick, cls: c[0] === pick ? 'on' : '', tagCls: '', pick: function () { set({ pick: c[0] }); } }; }),
      pickHref: cur[6], pickLabel: 'Open ' + cur[1],
      showOwn: view === 'single' || view === 'multiple' || view === 'expired',
      coIc: ic('building', 'violet'), mailIc: ic('mail', 'amber'), linkIc: ic('clock', 'amber')
    };
