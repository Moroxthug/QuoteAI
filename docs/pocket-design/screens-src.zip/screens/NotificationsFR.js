    var f = self.g('f', 'all'), read = self.g('read', {}), ask = self.g('ask', this.props.state === 'optin');
    var D = [
      ['brief', 'today', 'sun', 'gold', 'Votre journée', '3 visites prévues · Luca, Amara et Sofia sur place · 12°, pluie après 15 h', '6 h 30', '', '', 'SmartHome.dc.html'],
      ['viewed', 'today', 'eye', 'violet', 'Priya Nair a ouvert votre soumission', 'Dosseret de cuisine · Q-2026-118 · 1 865,10 $', '9 h 12', '', '', 'Quote.dc.html'],
      ['paid', 'today', 'card', 'sage', 'Paiement reçu d’Okoye Condo', '2 210,00 $ par carte · INV-0421, plancher du corridor', '8 h 47', '', '', 'Invoice.dc.html'],
      ['etransfer', 'today', 'bank', 'amber', 'Chen Family a envoyé un virement Interac', '1 650,00 $ pour INV-0417. Vérifiez votre compte, puis confirmez ici.', '8 h 05', 'Confirmer', '#', '#'],
      ['hours', 'today', 'clock', 'teal', 'Heures de l’équipe à approuver', 'Luca Bianchi et Amara Okafor · 31,5 h la semaine dernière', '7 h 58', 'Voir les heures', '#', '#'],
      ['blocker', 'today', 'warn', 'clay', 'Blocage au 48 Galloway Rd', 'Amara : il manque 12 feuilles de gypse à la livraison. Le sous-sol Hart attend.', '7 h 40', '', '', 'Job.dc.html'],
      ['signed', 'earlier', 'pen', 'sage', 'Tom & Lena Hart ont signé l’ordre de changement', 'Ordre de changement, sous-sol · 3 955,00 $', 'lun.', '', '', 'Contract.dc.html'],
      ['budget', 'earlier', 'bars', 'amber', 'Le sous-sol Hart atteint 90 % du budget', '27 630 $ dépensés sur 30 700 $ de coûts · étape du gypse', 'lun.', '', '', 'Job.dc.html'],
      ['overdue2', 'earlier', 'receipt', 'clay', 'INV-0419 est en retard', 'Harbourfront Dental · 780,00 $, due le 26 sept.', '27 sept.', '', '', 'Invoice.dc.html'],
      ['overdue', 'earlier', 'receipt', 'clay', 'INV-0412 est en retard', 'Tom & Lena Hart · 2 340,00 $, due le 20 sept.', '21 sept.', 'Envoyer un rappel', '#', '#']
    ];
    var unreadIds = ['viewed', 'paid', 'etransfer', 'hours', 'blocker', 'brief'];
    var isUnread = function (d) { return unreadIds.indexOf(d[0]) >= 0 && !read[d[0]]; };
    var nUn = D.filter(isUnread).length;
    var rows = D.filter(function (d) { return f === 'all' || isUnread(d); });
    var groups = [['today', 'Aujourd’hui'], ['earlier', 'Plus tôt']].map(function (g) {
      return { title: g[1], rows: rows.filter(function (d) { return d[1] === g[0]; }).map(function (d) {
        var u = isUnread(d);
        return { ic: ic(d[2], d[3]), title: d[4], body: d[5], time: d[6], hasAct: !!d[7], act: d[7], href: d[8] || '#', bcls: u ? 'u' : '', dot: u ? '' : 'off', aria: (u ? 'Non lue. ' : '') + d[4],
          open: function () { var r = Object.assign({}, self.g('read', {})); r[d[0]] = true; set({ read: r }); if (d[9] && d[9] !== '#' && !d[7]) setTimeout(function () { location.href = d[9]; }, 250); } };
      }) };
    }).filter(function (g) { return g.rows.length; });
    return {
      groups: groups, empty: groups.length === 0, bellIc: ic('bell', 'violet'), orbIc: ic('orb', 'violet'), orbIc2: ic('orb', 'violet'),
      noneUnread: nUn === 0,
      markAll: function () { var r = {}; D.forEach(function (d) { r[d[0]] = true; }); set({ read: r }); },
      showAll: function () { set({ f: 'all' }); },
      filters: [['all', 'Toutes', D.length], ['unread', 'Non lues', nUn]].map(function (x) { var on = x[0] === f; return { label: x[1], count: x[2], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      ask: ask, closeAsk: function () { set({ ask: false }); }
    };
