    var st = this.props.state || 'default';
    var offline = st === 'offline', ro = st === 'readonly';
    var DEF = { fu: 0, rem: 1, rec: 1, sch: 0, crew: 1 };
    var lv = Object.assign({}, DEF, this.g('lv', {}));
    var toast = this.g('toast', null);
    var LAB = ['Ask me first', 'Do it and tell me', 'Off'];
    var FR = [1, 1.3, 0.7], indAt = function (i) { var a = 0; for (var k = 0; k < i; k++) a += FR[k]; return 'left: calc(2px + (100% - 4px) * ' + (a / 3).toFixed(4) + '); width: calc((100% - 4px) * ' + (FR[i] / 3).toFixed(4) + ')'; };
    var flash = function (b, s, prev) {
      var tid = Date.now();
      set({ toast: { b: b, s: s, prev: prev, t: tid } });
      setTimeout(function () { var t = self.g('toast', null); if (t && t.t === tid) set({ toast: null }); }, 5000);
    };
    var base = function (gl, tone, label, sub) { return { ic: ic(gl, tone), label: label, sub: sub, isSeg: false, isSwitch: false, isStepper: false, isLink: false, isVoice: false, isFixed: false }; };
    var seg = function (key, gl, tone, label, subs) {
      var cur = lv[key];
      return Object.assign(base(gl, tone, label, subs[cur]), { isSeg: true, segCls: '',
        ind: indAt(cur),
        opts: LAB.map(function (l, i) { return { label: l, on: i === cur, cls: i === cur ? 'on' : '', off: ro, pick: function () {
          if (i === self.g('lv', {})[key] || (self.g('lv', {})[key] === undefined && i === DEF[key])) return;
          var prev = Object.assign({}, DEF, self.g('lv', {})); var n = Object.assign({}, prev); n[key] = i;
          set({ lv: n }); flash(label + ':', l.toLowerCase() + (offline ? '. Applies when you’re back online.' : '.'), prev);
        } }; }) });
    };
    var fixed = function (gl, tone, label, sub) {
      return Object.assign(base(gl, tone, label, sub), { isSeg: true, isFixed: true, segCls: 'fixed', ind: indAt(0),
        opts: LAB.map(function (l, i) { return { label: l, on: i === 0, cls: i === 0 ? 'on' : '', off: true, pick: function () {} }; }) });
    };
    var sw = function (key, def, gl, tone, label, sub) {
      var on = self.g(key, def);
      return Object.assign(base(gl, tone, label, sub), { isSwitch: true, on: on, track: on ? 'background: var(--acc)' : 'background: var(--track-off)', knob: on ? 'transform: translateX(20px)' : 'transform: translateX(0)',
        flip: function () { var o = {}; o[key] = !self.g(key, def); set(o); } });
    };
    var lim = this.g('lim', 300);
    var money = function (n) { return '$' + n.toLocaleString('en-CA'); };
    var quiet = this.g('quiet', true);
    var groups = [
      { title: 'Clients', rows: [
        seg('fu', 'chat', 'violet', 'Follow-ups', ['Drafts a nudge for quotes nobody answered, for your yes', 'Nudges after 3 days, twice at most, then tells you', 'Won’t follow up on quotes']),
        seg('rem', 'bell', 'amber', 'Invoice reminders', ['Drafts a reminder when an invoice is 7 days late', 'Sends a friendly reminder at 7 days late, then tells you', 'Won’t remind clients about invoices'])
      ] },
      { title: 'Money', rows: [
        seg('rec', 'receipt', 'amber', 'Receipts', ['Reads receipt photos and asks which job they belong to', 'Reads receipt photos and files them to the right job', 'Won’t read receipts']),
        fixed('tag', 'clay', 'Price changes', 'Prices on quotes and invoices always need your tap'),
        Object.assign(base('card', 'sage', 'Spending limit', 'Orders above this always ask first'), { isStepper: true, val: money(lim),
          dec: function () { set({ lim: Math.max(0, self.g('lim', 300) - 100) }); }, inc: function () { set({ lim: Math.min(5000, self.g('lim', 300) + 100) }); } })
      ], note: 'Anything over $5,000 always needs your tap, whatever you set here.' },
      { title: 'Team and schedule', rows: [
        seg('sch', 'cal', 'sky', 'Scheduling', ['Suggests new days for weather or crew changes', 'Moves job days for weather, then tells you and the crew', 'Won’t move anything on the schedule']),
        seg('crew', 'users', 'teal', 'Crew messages', ['Drafts schedule texts to your crew for your yes', 'Texts the crew their plan the night before, then tells you', 'Won’t message your crew'])
      ] },
      { title: 'Quiet hours', rows: [
        sw('quiet', true, 'moon', 'indigo', 'Quiet hours', quiet ? 'No client or crew messages go out. They wait until morning.' : 'Messages can go out any time'),
        Object.assign(base('clock', 'slate', 'From', 'Weeknights'), { isLink: true, val: '8:00 pm', href: '#', aria: 'Quiet hours start, 8:00 pm' }),
        Object.assign(base('sun', 'amber', 'Until', 'Next morning'), { isLink: true, val: '7:00 am', href: '#', aria: 'Quiet hours end, 7:00 am' }),
        sw('sun', true, 'cal', 'stone', 'Quiet all Sunday', 'Nothing goes out on Sundays')
      ] },
      { title: 'Voice', rows: [
        Object.assign(base('wave', 'violet', 'Voice', 'Aurora · change it in Settings'), { isVoice: true }),
        sw('readback', true, 'speaker', 'lilac', 'Read it back first', 'Says what it will send before you confirm')
      ] }
    ].map(function (g, gi) { return { title: g.title, rows: g.rows, note: g.note || '', hasNote: !!g.note, delay: 'animation-delay: ' + (60 + gi * 60) + 'ms' }; });
    return {
      offline: offline, readonly: ro, ro: ro, pendingCount: '4', hasCount: true, groups: groups,
      voices: [['#160e36', '#7b3fe4', '#6ec8f5', '#4c9de5'], ['#08172a', '#3d8bff', '#6ef0d2', '#b7a6ff'], ['#1a1a1c', '#c9c4ba', '#8e8a84', '#f4efe6']].map(function (v, i) { return { base: v[0], c1: v[1], c2: v[2], c3: v[3], cls: i === 0 ? 'on' : '' }; }),
      reset: function () { var prev = Object.assign({}, DEF, self.g('lv', {})); set({ lv: {}, lim: 300 }); flash('Back to recommended.', 'Follow-ups and scheduling ask first.', prev); },
      toast: !!toast, toastB: toast ? toast.b : '', toastS: toast ? toast.s : '',
      toastUndo: function () { var t = self.g('toast', null); if (t) set({ lv: t.prev, toast: null }); },
      cloudIc: ic('cloud', 'amber'), eyeIc: ic('eye', 'sky'), actIc: ic('list', 'indigo'), propIc: ic('bell', 'violet')
    };
