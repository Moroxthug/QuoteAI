    var f = this.g('f', 'all'), q = this.g('q', '');
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // name, contact, quotes, lifetime value, status, last activity, tint
    var data = [
      ['Tom & Lena Hart', '(416) 555-0148 · Scarborough', 3, 42355, 'active', 'Invoice reminder today', 2],
      ['Dana Whitfield', 'dana.w@rogers.com · Rosedale', 1, 0, 'prospect', 'Quote drafted today', 0],
      ['Priya Nair', '(647) 555-0121 · Dovercourt', 2, 6240, 'active', 'Viewed a quote 2 h ago', 1],
      ['Harbourfront Dental', 'office@hfdental.ca · Queens Quay W', 4, 14860, 'active', 'Quote sent Sep 24', 3],
      ['Gill Residence', '(905) 555-0187 · Mississauga', 1, 0, 'prospect', 'Quote sent Mon', 4],
      ['Okoye Condo', '(416) 555-0133 · Liberty Village', 1, 2210, 'active', 'Job booked Sep 15', 0],
      ['Marchetti Bakery', 'hello@marchetti.ca · Roncesvalles', 1, 0, 'prospect', 'Declined a quote Sep 12', 1],
      ['Chen Family', '(416) 555-0164 · North York', 3, 9850, 'active', 'Quote expired Sep 9', 2]
    ];
    var FIL = [['all', 'All'], ['active', 'Active'], ['prospect', 'Prospects']];
    var money = function (n) { return '$' + n.toLocaleString('en-CA'); };
    var xo = self.g('xo', null), xd = self.g('xd', {});
    var DONE = { Nudge: 'Nudged', Send: 'Sent', Review: 'Reviewed', Resend: 'Resent', Remind: 'Reminder set', Call: 'Calling', Text: 'Texted', Email: 'Emailed' };
    var flip = function (k) { return function () { var n = Object.assign({}, self.g('xd', {})); n[k] = !n[k]; set({ xd: n }); }; };
    var rowsOf = function (key, list) { return (list || []).map(function (r, i) { var k = key + i, d2 = !!xd[k]; return { t: r[0], s: r[1] || '', hasS: !!r[1], st: r[2] || '', stCls: r[3] || '', hasSt: !!r[2], amt: r[5] || '', hasAmt: !!r[5], hasBtn: !!r[4], btnLabel: d2 ? (DONE[r[4]] || 'Done') : r[4], btnCls: d2 ? 'done' : '', act: flip(k) }; }); };
    var btnOf = function (key, label) { var k = key + ':' + label, d2 = !!xd[k]; return { label: d2 ? DONE[label] : label, cls: d2 ? 'done' : '', act: flip(k) }; };
    var toggleOf = function (id) { return function (e) { var el = e && e.currentTarget; var cur = self.g('xo', null); set({ xo: cur === id ? null : id }); if (cur !== id && el) setTimeout(function () { var c = el.closest('.xc'); if (c) c.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }, 120); }; };
    // cap, rows [title, context, status, status class, action, amount], stats [label, value, owed?]
    var DET = {
      'Tom & Lena Hart': { cap: '(416) 555-0148 · lena.hart@gmail.com · 48 Galloway Rd', rows: [['Basement finish', 'Job · 64% done · drywall phase', 'Active', 'st-ok si-live', '', '$42,355'], ['INV-0412 · Drywall milestone', 'Due Sep 20 · 9 days overdue', 'Overdue', 'st-bad si-alert', 'Nudge', '$2,340.00'], ['Q-2026-114 · Change order', 'Accepted Sep 19', 'Accepted', 'st-ok si-check', '', '$3,955.00'], ['Last contact', 'Invoice reminder sent today, 8:00 am'], ['Notes', 'Use the side door. Lena prefers texts after 5 pm.']], stats: [['Lifetime', '$42,355'], ['Owed', '$2,340', 1], ['Quotes', '3']] },
      'Dana Whitfield': { cap: '(416) 555-0172 · dana.w@rogers.com · 17 Castle Frank Cres', rows: [['Q-2026-119 · Bedrooms and bath ceiling', 'Drafted today after the site visit', 'Draft', 'st-mute si-draft', 'Send', '$4,131.05'], ['Came from', 'Referral from Priya Nair · Sep 27'], ['Last contact', 'Site visit Sep 28 · measured 3 rooms'], ['Notes', 'Wants it done before family visits in November.']], stats: [['Lifetime', '$0'], ['Owed', '$0'], ['Quotes', '1']] },
      'Priya Nair': { cap: '(647) 555-0121 · priya.nair@gmail.com · 212 Dovercourt Rd', rows: [['Q-2026-118 · Kitchen backsplash', 'Viewed 2 h ago · not signed yet', 'Viewed', 'st-acc si-q2', 'Nudge', '$1,865.10'], ['Powder room', 'Job · finished Sep 11', 'Completed', 'st-mute si-check', '', '$3,120'], ['Last contact', 'Sent the backsplash quote Sep 28'], ['Notes', 'Works from home. Mornings are quiet hours.']], stats: [['Lifetime', '$6,240'], ['Owed', '$0'], ['Quotes', '2']] },
      'Harbourfront Dental': { cap: '(416) 555-0190 · office@hfdental.ca · Queens Quay W', rows: [['Clinic hallway refresh', 'Job · 35% done · prep and prime', 'Active', 'st-ok si-live', '', '$12,850'], ['INV-0419 · Final', 'Due Sep 26 · 3 days overdue', 'Overdue', 'st-bad si-alert', 'Nudge', '$780.00'], ['Q-2026-117 · Reception repaint', 'Sent Sep 24 · expires Fri', 'Expiring', 'st-warn si-clock', 'Call', '$6,420.00'], ['Last contact', 'Quote sent Sep 24 to the office manager'], ['Notes', 'Work after 6 pm or on weekends only.']], stats: [['Lifetime', '$14,860'], ['Owed', '$780', 1], ['Quotes', '4']] },
      'Gill Residence': { cap: '(905) 555-0187 · gill.family@outlook.com · Mississauga', rows: [['Q-2026-116 · Deck refinish', 'Sent Mon · not opened yet', 'Sent', 'st-info si-q1', 'Nudge', '$2,980.00'], ['Last contact', 'Quote sent Mon by email'], ['Notes', 'Wants a weekend start. Gate code at the side.']], stats: [['Lifetime', '$0'], ['Owed', '$0'], ['Quotes', '1']] },
      'Okoye Condo': { cap: '(416) 555-0133 · n.okoye@gmail.com · Liberty Village', rows: [['Hallway flooring', 'Job · AI plan from Q-2026-112', 'Review setup', 'st-acc si-q2', 'Review', '$2,210'], ['Last contact', 'Job booked Sep 15'], ['Notes', 'Condo board needs a certificate of insurance before work starts.']], stats: [['Lifetime', '$2,210'], ['Owed', '$0'], ['Quotes', '1']] },
      'Marchetti Bakery': { cap: '(416) 555-0156 · hello@marchetti.ca · Roncesvalles', rows: [['Q-2026-110 · Storefront trim', 'Declined Sep 12 · price too high this season', 'Declined', 'st-bad si-x', '', '$1,480.00'], ['Try again in spring', 'A reminder in March', '', '', 'Remind'], ['Last contact', 'Call with Gina Marchetti, Sep 12'], ['Notes', 'Closed Mondays. Park in the back lane.']], stats: [['Lifetime', '$0'], ['Owed', '$0'], ['Quotes', '1']] },
      'Chen Family': { cap: '(416) 555-0164 · chen.home@gmail.com · North York', rows: [['Q-2026-108 · Laundry room refresh', 'Expired Sep 9 · no reply', 'Expired', 'st-mute si-off', 'Resend', '$3,300.00'], ['Front porch rebuild', 'Job · finished Aug 21 · 5 stars on Google', 'Completed', 'st-mute si-check'], ['Last contact', 'Quote follow-up Sep 2'], ['Notes', 'Start after 9 am on weekdays.']], stats: [['Lifetime', '$9,850'], ['Owed', '$0'], ['Quotes', '3']] }
    };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return (f === 'all' || d[4] === f) && (!ql || (d[0] + ' ' + d[1]).toLowerCase().indexOf(ql) >= 0); }).map(function (d) {
      var ini = d[0].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
      var act = d[4] === 'active';
      return {
        name: d[0], contact: d[1], meta: d[2] + (d[2] === 1 ? ' quote' : ' quotes') + ' · ' + d[5],
        value: d[3] ? money(d[3]) : 'No jobs yet', valStyle: d[3] ? 'font-size: 14.5px; font-weight: 600' : 'font-size: 12.5px; font-weight: 500; color: var(--faint)',
        status: act ? 'Active' : 'Prospect', st: act ? 'st-ok' : 'st-info', ini: ini, tn: tints[d[6]],
        open: xo === d[0], xcls: xo === d[0] ? 'open' : '', toggle: toggleOf(d[0]),
        x: (function (x) { return { cap: x.cap, rows: rowsOf(d[0], x.rows), stats: x.stats.map(function (q) { return { l: q[0], v: q[1], style: q[2] ? 'color: var(--bad)' : '' }; }), call: btnOf(d[0], 'Call'), text: btnOf(d[0], 'Text'), mail: btnOf(d[0], 'Email') }; })(DET[d[0]])
      };
    });
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'Active', value: '5', sub: '2 jobs running', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Lifetime value', value: '$75,515', sub: '↑ 18% this year', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Owed', value: '$3,120', sub: '2 overdue', subStyle: 'color: var(--bad)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[0] === 'all' || d[4] === x[0]; }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      kx: { open: xo === 'kpi', cls: xo === 'kpi' ? 'open' : '', toggle: toggleOf('kpi'),
        owed: rowsOf('kpi', [['Tom & Lena Hart', 'INV-0412 · 9 days overdue', 'Overdue', 'st-bad si-alert', 'Nudge', '$2,340.00'], ['Harbourfront Dental', 'INV-0419 · 3 days overdue', 'Overdue', 'st-bad si-alert', 'Nudge', '$780.00']]),
        top: rowsOf('kpt', [['Tom & Lena Hart', 'Basement finish · 3 quotes', '', '', '', '$42,355'], ['Harbourfront Dental', '4 quotes · clinic hallway', '', '', '', '$14,860'], ['Chen Family', '3 quotes · porch rebuild', '', '', '', '$9,850']]) },
      openCls: rows.some(function (r) { return r.open; }) ? 'has-open' : '',
      rows: rows, has: rows.length > 0, countLabel: rows.length + (rows.length === 1 ? ' client' : ' clients'),
      empty: rows.length === 0, emptyIc: ic('users', 'slate')
    };
