    var ST = this.props.state || 'default';
    var locked = ST === 'locked', empty = ST === 'empty';
    var SITE = { st: ['st-ok', 'si-live'].join(' ') }, WAY = { st: ['st-info', 'si-q1'].join(' ') }, OFF = { st: ['st-mute', 'si-off'].join(' ') };
    var PEOPLE = [
      { id: 'jonah', name: 'Jonah Reyes', ini: 'JR', tn: 'tn4', k: 'way', status: 'On the way', sub: 'Hart basement', eta: '14 min', etaAt: 'about 9:52', x: 118, y: 352, phone: '+14165550142' },
      { id: 'luca', name: 'Luca Bianchi', ini: 'LB', tn: 'tn1', k: 'site', status: 'On site', sub: 'Hart basement', eta: '7:02', etaAt: 'arrived', x: 270, y: 284, phone: '+14165550188' },
      { id: 'amara', name: 'Amara Okafor', ini: 'AO', tn: 'tn3', k: 'site', status: 'On site', sub: 'Hart basement', eta: '7:04', etaAt: 'arrived', x: 222, y: 292, phone: '+14165550119' },
      { id: 'dev', name: 'Dev Patel', ini: 'DP', tn: 'tn2', k: 'site', status: 'On site', sub: 'Gill Residence', eta: '7:30', etaAt: 'arrived', x: 108, y: 192, phone: '+14165550163' },
      { id: 'sofia', name: 'Sofia Marin', ini: 'SM', tn: 'tn5', k: 'off', status: 'Off', sub: 'Location off · starts at 1:00', x: 0, y: 0, phone: '+14165550177' }
    ];
    if (empty) PEOPLE = PEOPLE.map(function (p) { return Object.assign({}, p, { k: 'off', status: 'Off', sub: p.id === 'sofia' ? 'Starts at 1:00' : 'Not clocked in yet', eta: '' }); });
    var KST = { site: SITE.st, way: WAY.st, off: OFF.st };
    var sel = this.g('sel', 'jonah'), filt = this.g('filt', 'all'), open = this.g('open', false);
    var count = function (k) { return PEOPLE.filter(function (p) { return k === 'all' || p.k === k; }).length; };
    var chips = [['all', 'All'], ['site', 'On site'], ['way', 'On the way'], ['off', 'Off']].map(function (c) {
      return { label: c[1], n: String(count(c[0])), on: filt === c[0], cls: filt === c[0] ? 'on' : '', pick: function () { set({ filt: c[0] }); } };
    });
    var list = PEOPLE.filter(function (p) { return filt === 'all' || p.k === filt; });
    var rows = list.map(function (p) {
      var first = p.name.split(' ')[0];
      return {
        name: p.name, ini: p.ini, tn: p.tn, status: p.status, st: KST[p.k], sub: p.sub,
        hasEta: p.k !== 'off', eta: p.eta || '', etaAt: p.etaAt || '', etaStyle: p.k === 'way' ? 'color: var(--ink)' : 'color: var(--t2); font-size: 15px',
        selCls: sel === p.id && p.k !== 'off' ? 'sel' : '',
        aria: p.name + ', ' + p.status + (p.eta ? ', ' + p.eta : ''),
        tel: 'tel:' + p.phone, sms: 'sms:' + p.phone, callLabel: 'Call ' + first, textLabel: 'Text ' + first,
        pick: function () { if (p.k !== 'off') set({ sel: p.id }); }
      };
    });
    var DOT = { site: 'background: var(--ok-dot)', way: 'background: var(--acc)' };
    var markers = locked ? [] : PEOPLE.filter(function (p) { return p.k !== 'off'; }).map(function (p) {
      return { ini: p.ini, tn: p.tn, selCls: sel === p.id ? 'sel' : '', pos: 'left: ' + p.x + 'px; top: ' + p.y + 'px', dot: DOT[p.k],
        aria: p.name + ', ' + p.status + (p.eta ? ', ' + p.eta : ''), pick: function () { set({ sel: p.id, open: false }); } };
    });
    var live = PEOPLE.filter(function (p) { return p.k !== 'off'; }).length;
    var siteN = PEOPLE.filter(function (p) { return p.k === 'site'; }).length, wayN = PEOPLE.filter(function (p) { return p.k === 'way'; }).length;
    return {
      sites: [
        { name: 'Hart basement', ic: ic('house', 'clay'), pos: 'left: 238px; top: 246px' },
        { name: 'Gill Residence', ic: ic('house', 'sage'), pos: 'left: 96px; top: 160px' },
        { name: 'Harbourfront Dental', ic: ic('building', 'azure'), pos: 'left: 280px; top: 392px' }
      ],
      markers: markers,
      showRoute: !locked && !empty, routeStyle: !locked && !empty ? 'opacity: 1' : 'opacity: 0',
      liveWord: locked ? 'Off' : (live ? live + ' live' : 'None live'),
      liveSt: locked || !live ? ['st-mute', 'si-off'].join(' ') : ['st-ok', 'si-live'].join(' '),
      recenter: function () { set({ sel: '' }); },
      sheetH: 'height: ' + (locked ? 330 : (open ? 620 : 408)) + 'px',
      toggleSheet: function () { set({ open: !self.g('open', false) }); },
      grabLabel: open ? 'Show less' : 'Show more',
      sheetMeta: locked ? '' : (empty ? 'Nobody on the clock' : siteN + ' on site · ' + wayN + ' on the way'),
      isLocked: locked, notLocked: !locked, lockIc: ic('lock', 'violet'),
      chips: chips, rows: rows,
      isEmpty: !locked && rows.length === 0, emptyIc: ic('pin', 'slate'),
      emptyTitle: 'Nobody here right now', emptyText: 'People show up when their status changes.',
      showFoot: rows.length > 0
    };
