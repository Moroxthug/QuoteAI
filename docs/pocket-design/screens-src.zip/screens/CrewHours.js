    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var sent = this.g('sent', mode === 'submitted');
    var s = this.g('s', 420), e = this.g('e', 930), brk = this.g('brk', 30), day = this.g('day', 4), reason = this.g('reason', mode === 'submitted' ? 0 : -1), jobI = this.g('job', 0);
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var fmt = function (m) { var h = Math.floor(m / 60), mm = m % 60; return ((h % 12) || 12) + ':' + pad(mm) + (h < 12 ? ' am' : ' pm'); };
    var short = function (m) { var h = Math.floor(m / 60), mm = m % 60; return h + ':' + pad(mm); };
    var dur = function (m) { return Math.floor(m / 60) + 'h ' + pad(m % 60) + 'm'; };
    var worked = Math.max(0, e - s - brk);
    var DAYS = [['Tue', '29', 'Today'], ['Mon', '28', 'Monday, Sep 28'], ['Sun', '27', 'Sunday, Sep 27'], ['Sat', '26', 'Saturday, Sep 26'], ['Fri', '25', 'Friday, Sep 25'], ['Thu', '24', 'Thursday, Sep 24'], ['Wed', '23', 'Wednesday, Sep 23']];
    var JOBS = [['Hart basement', '48 Galloway Rd · Drywall'], ['Harbourfront Dental', 'Queens Quay W · Patch and paint'], ['Gill Residence', 'Ceiling patch']];
    var BR = [0, 15, 30, 60];
    var bi = BR.indexOf(brk);
    var REASONS = ['Forgot to clock', 'Phone died', 'No signal', 'Something else'];
    var clamp = function (v) { return Math.max(300, Math.min(1320, v)); };
    var week = [
      { dow: 'Mon', n: '28', hours: '8h 02m', range: '7:02–15:34', where: 'Hart basement', st: 'st-ok si-check', status: 'Approved' },
      { dow: 'Thu', n: '24', hours: '8h 10m', range: '7:10–15:50', where: 'Clocked in 400 m from site', st: 'st-bad si-alert', status: 'Off site at clock-in' },
      { dow: 'Wed', n: '23', hours: '7h 30m', range: '7:30–15:30', where: 'Added by hand · phone died', st: 'st-warn si-clock', status: 'To approve' }
    ];
    var total = 8 * 60 + 2 + 8 * 60 + 10 + 7 * 60 + 30;
    if (sent) {
      week.push({ dow: DAYS[day][0], n: DAYS[day][1], hours: dur(worked), range: short(s) + '–' + short(e), where: 'Added by hand · ' + REASONS[Math.max(0, reason)].toLowerCase(), st: offline ? 'st-mute si-draft' : 'st-warn si-clock', status: offline ? 'Saved on phone' : 'To approve' });
      total += worked;
      week.sort(function (a, b) { return (+b.n) - (+a.n); });
    }
    return {
      offline: offline, sent: sent, editing: !sent,
      sentIc: offline ? ic('cloud', 'amber') : ic('send', 'azure'), cloudIc: ic('cloud', 'amber'), jobIc: ic('house', 'clay'),
      sentTitle: offline ? 'Saved on your phone' : 'Sent to Luca',
      sentSub: offline ? 'It goes to Luca as soon as you have signal. Keep this page open or come back later.' : 'He’ll approve it or ask you about it. You’ll get a text either way.',
      dayLong: DAYS[day][2], range: short(s) + '–' + short(e), total: dur(worked),
      days: DAYS.map(function (d, i) { var on = i === day; return { dow: d[0], n: d[1], label: d[2], on: on, cls: on ? 'on' : '', pick: function () { set({ day: i }); } }; }),
      job: JOBS[jobI][0], jobSub: JOBS[jobI][1], swapJob: function () { set({ job: (self.g('job', 0) + 1) % JOBS.length }); },
      start: fmt(s), end: fmt(e),
      sMinus: function () { set({ s: clamp(self.g('s', 420) - 15) }); }, sPlus: function () { set({ s: Math.min(clamp(self.g('s', 420) + 15), self.g('e', 930) - 15) }); },
      eMinus: function () { set({ e: Math.max(clamp(self.g('e', 930) - 15), self.g('s', 420) + 15) }); }, ePlus: function () { set({ e: clamp(self.g('e', 930) + 15) }); },
      breaks: BR.map(function (b, i) { var on = i === bi; return { label: b ? b + ' min' : 'None', on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ brk: b }); } }; }),
      brkInd: 'transform: translateX(' + (Math.max(0, bi) * 100) + '%)',
      quick: [
        { label: 'Usual day', range: '7:00–15:30', pick: function () { set({ s: 420, e: 930, brk: 30 }); } },
        { label: 'Half day', range: '7:00–11:30', pick: function () { set({ s: 420, e: 690, brk: 0 }); } },
        { label: 'Long day', range: '7:00–17:30', pick: function () { set({ s: 420, e: 1050, brk: 30 }); } }
      ],
      reasons: REASONS.map(function (r, i) { var on = i === reason; return { label: r, on: on, cls: on ? 'on' : '', pick: function () { set({ reason: i, needR: false }); } }; }),
      note: this.g('note', ''), onNote: function (ev) { set({ note: ev.target.value }); },
      needReason: this.g('needR', false),
      submitLabel: offline ? 'Save ' + dur(worked) : 'Send ' + dur(worked) + ' for approval',
      submit: function () { if (self.g('reason', -1) < 0) { set({ needR: true }); return; } set({ sent: true }); },
      another: function () { set({ sent: false, reason: -1, note: '', day: 3 }); },
      week: week, weekTotal: dur(total)
    };
