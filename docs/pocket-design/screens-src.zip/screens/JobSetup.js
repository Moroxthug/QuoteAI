    var M = {
      a: { title: 'Prep and old floor removal', tasks: 3, days: 1, pct: 15, term: '' },
      b: { title: 'Levelling and underlayment', tasks: 2, days: 1, pct: 20, term: '' },
      c: { title: 'Lay vinyl plank, hall and entry', tasks: 4, days: 2, pct: 45, term: 'Progress 40% · $884' },
      d: { title: 'Trim, transitions and cleanup', tasks: 3, days: 1, pct: 20, term: 'Final 30% · $663' },
      e: { title: 'New milestone', tasks: 0, days: 1, pct: 0, term: '' }
    };
    var order = this.g('order', ['a', 'b', 'c', 'd']), removed = this.g('removed', null);
    var si = this.g('si', 0), started = this.g('started', false);
    var STARTS = [[5, 'Mon, Oct 5'], [7, 'Wed, Oct 7'], [12, 'Mon, Oct 12'], [14, 'Wed, Oct 14']];
    var MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    var fmt = function (d) { return MON[d.getMonth()] + ' ' + d.getDate(); };
    var nextWork = function (d) { var x = new Date(d); while (x.getDay() === 0 || x.getDay() === 6) x.setDate(x.getDate() + 1); return x; };
    var addWork = function (d, n) { var x = new Date(d); while (n > 0) { x.setDate(x.getDate() + 1); if (x.getDay() !== 0 && x.getDay() !== 6) n--; } return x; };
    var cur = nextWork(new Date(2026, 9, STARTS[si][0])), first = cur, last = cur, totalDays = 0;
    var ms = order.map(function (id, i) {
      var m = M[id], s = cur, e = addWork(s, m.days - 1); last = e; cur = addWork(e, 1); totalDays += m.days;
      return {
        title: m.title, tasks: m.tasks, pct: m.pct + '%', dates: m.days > 1 ? fmt(s) + ' – ' + e.getDate() : fmt(s),
        term: m.term || 'No payment linked', termCls: m.term ? '' : 'none',
        upLabel: 'Move ' + m.title + ' up', delLabel: 'Delete ' + m.title,
        up: function () { if (i === 0) return; var o = order.slice(); o.splice(i - 1, 0, o.splice(i, 1)[0]); set({ order: o }); },
        del: function () { var o = order.slice(); o.splice(i, 1); set({ order: o, removed: { id: id, at: i } }); }
      };
    });
    var cdef = { mat: 820, lab: 540, sub: 0, per: 0, eq: 45, misc: 60 };
    var CATS = [
      ['mat', 'Materials', 'Vinyl plank, underlay', 'box', 'amber'],
      ['lab', 'Labour', 'Dev Patel · 18 h', 'users', 'teal'],
      ['sub', 'Subcontractors', 'None planned', 'hammer', 'clay'],
      ['per', 'Permits and fees', 'None needed', 'shield', 'azure'],
      ['eq', 'Equipment', 'Floor saw rental, 1 day', 'gear', 'slate'],
      ['misc', 'Misc', 'Disposal and sundries', 'dot', 'stone']
    ];
    var total = 0;
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var money0 = function (n) { return '$' + n.toLocaleString('en-CA', { maximumFractionDigits: 0 }); };
    var cats = CATS.map(function (c) {
      var v = self.g('c_' + c[0], cdef[c[0]]); total += v;
      return {
        name: c[1], note: c[2], ic: ic(c[3], c[4]), amt: money0(v), amtStyle: v ? '' : 'color: var(--faint)',
        decLabel: 'Less ' + c[1], incLabel: 'More ' + c[1],
        dec: function () { var o = {}; o['c_' + c[0]] = Math.max(0, v - 25); set(o); },
        inc: function () { var o = {}; o['c_' + c[0]] = v + 25; set(o); }
      };
    });
    var value = 2210, margin = value - total, pct = Math.round(margin / value * 1000) / 10;
    return {
      name: this.g('name', 'Hallway flooring'), onName: function (e) { set({ name: e.target.value }); },
      window: fmt(first) + ' – ' + (last.getMonth() === first.getMonth() ? last.getDate() : fmt(last)),
      windowSub: totalDays + ' working days',
      ms: ms, mCount: ms.length + ' milestones', removed: !!removed,
      restore: function () { var o = order.slice(); o.splice(removed.at, 0, removed.id); set({ order: o, removed: null }); },
      addM: function () { if (order.indexOf('e') < 0) set({ order: order.concat(['e']) }); },
      calIc: ic('cal', 'violet'),
      starts: STARTS.map(function (s, i) { var on = i === si; return { label: s[1], on: on, cls: on ? 'on' : '', pick: function () { set({ si: i }); } }; }),
      cats: cats, costTotal: money(total), marginAmt: money(margin), marginPct: pct + '%',
      marginNote: pct >= 30 ? 'Above your 30% target' : 'Below your 30% target',
      marginNoteStyle: pct >= 30 ? 'color: var(--ok)' : 'color: var(--warn)',
      marginW: Math.max(0, Math.min(100, pct)) + '%', marginBar: pct >= 30 ? 'background: var(--ok-dot)' : 'background: var(--warn-dot)',
      start: function () { set({ started: true }); },
      startLabel: started ? 'Job started · Dev is notified' : 'Looks good, start the job',
      startStyle: started ? 'background: var(--ok); color: var(--on-inv)' : ''
    };
