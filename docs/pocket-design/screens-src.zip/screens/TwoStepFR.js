    var ps = this.props.state || 'default';
    var PS = { default: ['31', 'typing', 24, 5, 'sms'], wrong: ['318207', 'wrong', 24, 4, 'sms'], locked: ['', 'locked', 0, 0, 'sms'], backup: ['', 'typing', 0, 5, 'backup'], verified: ['318274', 'ok', 24, 5, 'sms'] }[ps] || ['', 'typing', 30, 5, 'sms'];
    var code = self.g('code', PS[0]), st = self.g('st', PS[1]), sec = self.g('sec', PS[2]), tries = self.g('tries', PS[3]);
    var mode = self.g('mode', PS[4]), sheet = self.g('sheet', false), trust = self.g('trust', true), bk = self.g('bk', ps === 'backup' ? 'R7KD-' : '');
    if (!self._timer) { self._timer = setInterval(function () { var s = self.g('sec', PS[2]); if (s > 0) self.setState({ sec: s - 1 }); }, 1000); }
    var RIGHT = '318274';
    var submit = function (c) {
      set({ code: c, st: 'checking' });
      setTimeout(function () {
        if (c === RIGHT) set({ st: 'ok' });
        else { var t = self.g('tries', 5) - 1; set(t <= 0 ? { st: 'locked', tries: 0 } : { st: 'wrong', tries: t }); }
      }, 900);
    };
    var wrong = st === 'wrong', ok = st === 'ok', locked = st === 'locked', checking = st === 'checking';
    var isBackup = mode === 'backup';
    var boxes = [0, 1, 2, 3, 4, 5].map(function (n) {
      var cls = ok ? 'ok' : wrong ? 'bad' : locked ? 'off' : (!checking && n === code.length) ? 'act' : '';
      return { d: code[n] || '', cls: cls };
    });
    var M = [['sms', 'Texto', '••• ••• 0182', 'phone', 'teal'], ['email', 'Courriel', 'm•••@rossireno.ca', 'mail', 'sky'], ['backup', 'Code de secours', 'Un des 10 codes que vous avez conservés', 'key', 'violet']];
    var sub = mode === 'email' ? ['Entrez le code à 6 chiffres envoyé par courriel à ', 'm•••@rossireno.ca', '.', ''] : isBackup ? ['Entrez un des codes de secours conservés lors de l’activation.', '', '', ''] : ['Entrez le code à 6 chiffres envoyé par texto au ', '••• ••• 0182', '.', 'mono'];
    var bkClean = bk.replace(/[^A-Za-z0-9]/g, '');
    return {
      orbIc: ok ? ic('check', 'sage') : locked ? ic('lock', 'clay') : isBackup ? ic('key', 'violet') : ic('shield', 'violet'),
      lockIc: ic('lock', 'clay'), keyIc: ic('key', 'violet'), phoneIc: ic('phone', 'teal'),
      title: ok ? 'Vous êtes connecté' : 'Vérification en deux étapes',
      subA: ok ? 'Retour à votre écran d’accueil.' : sub[0], subB: ok ? '' : sub[1], subC: ok ? '' : sub[2], subCls: sub[3],
      isCode: !isBackup, isBackup: isBackup,
      boxA: boxes.slice(0, 3), boxB: boxes.slice(3),
      shake: wrong ? 'ts-shake' : '',
      inVal: (wrong || locked) ? '' : code, wrong: wrong && !isBackup, ok: ok, locked: locked && !isBackup, checking: checking, triesLeft: tries,
      onCode: function (e) {
        var c = (e.target.value || '').replace(/\D/g, '').slice(0, 6);
        if (c.length === 6) submit(c); else set({ code: c, st: 'typing' });
      },
      sec: sec, waiting: sec > 0 && !ok && !isBackup, canResend: sec === 0 && !ok && !isBackup && !locked,
      resend: function () { set({ sec: 30, code: '', st: 'typing', tries: 5 }); },
      bk: bk, onBk: function (e) { var v = (e.target.value || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8); set({ bk: v.length > 4 ? v.slice(0, 4) + '-' + v.slice(4) : v }); },
      bkShort: bkClean.length < 8, backupErr: '',
      useBackup: function () { set({ st: 'ok', mode: 'sms', code: RIGHT }); },
      showCta: ok || isBackup,
      trust: trust, trustTrack: trust ? 'background: var(--acc)' : 'background: var(--track-off)', trustKnob: trust ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipTrust: function () { set({ trust: !self.g('trust', true) }); },
      sheet: sheet, openSheet: function () { set({ sheet: true }); }, closeSheet: function () { set({ sheet: false }); },
      methods: M.map(function (m) {
        return { name: m[1], sub: m[2], ic: ic(m[3], m[4]), on: mode === m[0], cls: mode === m[0] ? 'on' : '',
          pick: function () { set({ mode: m[0], sheet: false, code: '', st: m[0] === 'backup' ? 'typing' : (self.g('st', PS[1]) === 'locked' ? 'locked' : 'typing'), sec: m[0] === 'backup' ? 0 : 30 }); } };
      })
    };
