    var ST = this.props.state || 'default';
    var ended = ST === 'accessEnded';
    var J = function (a) { return a.join(' '); };
    var mi = this.g('month', 2);
    var ck = function (t, a, b, note, money) {
      var pct = Math.round(a / b * 100);
      return { t: t, v: money || (a + ' of ' + b), vStyle: pct < 100 ? 'color: var(--ink)' : 'color: var(--ok)', note: note,
        bar: 'width: ' + pct + '%; background: ' + (pct < 100 ? 'var(--warn-dot)' : 'var(--ok-dot)') };
    };
    var MONTHS = [
      { label: 'July', name: 'July 2026', short: 'July', sub: 'Closed by Rosa Lima, Aug 6', w: 'Closed', st: J(['st-mute', 'si-check']),
        checks: [ck('Bank lines matched', 171, 171, 'RBC business chequing and Visa'), ck('Receipts attached', 46, 46, 'All expenses over $30'), ck('Invoices issued', 1, 1, '12 invoices', '$44,910'), ck('Payroll runs', 2, 2, 'Jul 15 and Jul 31')] },
      { label: 'August', name: 'August 2026', short: 'August', sub: 'Closed by Rosa Lima, Sep 4', w: 'Closed', st: J(['st-mute', 'si-check']),
        checks: [ck('Bank lines matched', 158, 158, 'RBC business chequing and Visa'), ck('Receipts attached', 39, 39, 'All expenses over $30'), ck('Invoices issued', 1, 1, '11 invoices', '$41,275'), ck('Payroll runs', 2, 2, 'Aug 14 and Aug 31')] },
      { label: 'September', name: 'September 2026', short: 'September', sub: 'Rosa is working on it', w: 'In progress', st: J(['st-ok', 'si-live']),
        checks: [ck('Bank lines matched', 142, 160, '18 left, mostly card payments from Sep 24 on'), ck('Receipts attached', 38, 41, '3 missing: Home Depot, Rona, Esso'), ck('Invoices issued', 1, 1, '14 invoices', '$52,380'), ck('Payroll runs', 1, 2, 'Sep 15 done · Sep 30 is tomorrow')] }
    ];
    var mo = MONTHS[mi];
    var dl = this.g('dl', {});
    var EXP = [
      ['tx', 'Transactions', 'CSV · every bank and card line', 'file', 'sage'],
      ['qb', 'QuickBooks Online', 'Journal entries · IIF', 'sync', 'teal'],
      ['hst', 'HST worksheet', 'PDF · Q3, with every source line', 'percent', 'violet'],
      ['pay', 'Payroll summary', 'CSV · gross, deductions, remittance', 'bank', 'azure']
    ];
    var exports = EXP.map(function (e) {
      var key = e[0] + mi, st = dl[key];
      return { t: e[1], s: e[2], ic: ic(e[3], e[4]), done: st === 'done', notDone: st !== 'done', doneSt: J(['st-ok', 'si-check']),
        btn: st === 'busy' ? 'Preparing…' : 'Download', aria: 'Download ' + e[1] + ', ' + mo.short,
        dl: function () {
          var d = Object.assign({}, self.g('dl', {})); if (d[key]) return; d[key] = 'busy'; set({ dl: d });
          setTimeout(function () { var x = Object.assign({}, self.g('dl', {})); x[key] = 'done'; set({ dl: x }); }, 1100);
        } };
    });
    var BASE = [
      { who: 'Farah Haddad', me: true, time: 'Sep 28, 4:10 pm', text: 'Two Home Depot receipts on Sep 12 look like the same purchase, $412.66 each. Can someone check?', ref: 'Home Depot · Warden Ave · $412.66', refIc: 'receipt' },
      { who: 'Rosa Lima', me: false, time: 'Sep 29, 8:40 am', text: 'One was returned. The refund is on Sep 14, I’ll match them today.', ref: '', refIc: '' },
      { who: 'Marco Rossi', me: false, time: 'Sep 29, 9:02 am', text: 'Thanks Farah. HST file by Oct 20 works for us.', ref: '', refIc: '' }
    ];
    var extra = this.g('extra', []);
    var thread = BASE.concat(extra).map(function (m) {
      return { who: m.who, time: m.time, text: m.text, hasRef: !!m.ref, ref: m.ref, refIc: ic(m.refIc || 'receipt', 'rose'),
        wrap: m.me ? 'align-self: flex-end; align-items: flex-end' : 'align-self: flex-start',
        metaAlign: m.me ? 'text-align: right' : '',
        bubble: m.me ? 'background: var(--inv); color: var(--on-inv); border-radius: 18px 18px 6px 18px' : 'background: var(--sunk); color: var(--ink); border-radius: 18px 18px 18px 6px' };
    });
    var draft = this.g('draft', '');
    return {
      ended: ended, active: !ended, lockIc: ic('lock', 'azure'),
      shareLine: ended ? 'Farah Haddad, CPA' : 'Farah Haddad, CPA · shared by Marco Rossi',
      months: MONTHS.map(function (m, i) { return { label: m.label, on: i === mi, cls: i === mi ? 'on' : '', pick: function () { set({ month: i }); } }; }),
      mo: mo, exports: exports,
      dueSt: J(['st-warn', 'si-clock']),
      deadlines: [
        { ic: ic('truck', 'clay'), t: 'Van plate renewal', s: 'ServiceOntario · Sep 26', w: '3 days late', st: J(['st-bad', 'si-alert']) },
        { ic: ic('bank', 'sage'), t: 'Payroll remittance, Sep', s: '$4,386.20 · CRA', w: 'Due Oct 15', st: J(['st-warn', 'si-clock']) },
        { ic: ic('shield', 'teal'), t: 'WSIB clearance', s: 'Rossi Renovations', w: 'Expires Oct 20', st: J(['st-warn', 'si-clock']) }
      ],
      thread: thread, draft: draft,
      onDraft: function (e) { set({ draft: e.target.value }); },
      send: function () {
        var t = (self.g('draft', '') || '').trim(); if (!t) t = 'Got it, thanks. I’ll start the Q3 return once September is closed.';
        set({ extra: self.g('extra', []).concat([{ who: 'Farah Haddad', me: true, time: 'Now', text: t, ref: '', refIc: '' }]), draft: '' });
      }
    };
