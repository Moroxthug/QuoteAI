    var lang = self.g('lang', 'fr'), shown = self.g('shown', false), email = self.g('email', 'marco@rossireno.ca'), pass = self.g('pass', 'rossi-reno-24');
    var loading = self.g('loading', false), err = self.g('err', null);
    var st = err || (this.props.state || 'default');
    var T = {
      en: { title: 'Welcome back', sub: 'Sign in to pick up where your crew left off.', email: 'Email', password: 'Password', forgot: 'Forgot password?', signin: 'Sign in', signing: 'Signing in…', or: 'or', faceid: 'Sign in with Face ID', newTo: 'New to quoteAI?', create: 'Create an account', crew: 'On a crew? Join your team' },
      fr: { title: 'Bon retour!', sub: 'Connectez-vous pour reprendre là où votre équipe s’est arrêtée.', email: 'Courriel', password: 'Mot de passe', forgot: 'Mot de passe oublié?', signin: 'Se connecter', signing: 'Connexion…', or: 'ou', faceid: 'Se connecter avec Face ID', newTo: 'Nouveau sur quoteAI?', create: 'Créer un compte', crew: 'Membre d’une équipe? Rejoignez-la' }
    };
    var t = T[lang];
    var B = {
      wrong: ['b-bad', 'warn', 'rose', 'Courriel ou mot de passe incorrect.', 'Vérifiez-les ou réinitialisez votre mot de passe.', '', ''],
      unverified: ['b-info', 'mail', 'sky', 'Confirmez d’abord votre courriel.', 'Nous avons envoyé un code à 6 chiffres à marco@rossireno.ca.', 'Entrer le code', 'Verify.dc.html'],
      offline: ['b-warn', 'cloud', 'amber', 'Aucune connexion.', 'La connexion requiert Internet. Votre travail enregistré reste sur ce téléphone.', '', ''],
      expired: ['b-warn', 'clock', 'amber', 'Ce lien a expiré.', 'Connectez-vous et nous vous en enverrons un nouveau.', '', ''],
      cancelled: ['b-ok', 'check', 'sage', 'Suppression du compte annulée.', 'Tout est comme vous l’avez laissé.', '', '']
    };
    var b = B[st];
    var banner = b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4], hasLink: !!b[5], link: b[5], href: b[6] || '#' } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '', hasLink: false, link: '', href: '#' };
    return {
      t: t, banner: banner, email: email, pass: pass,
      isEn: lang === 'en', isFr: lang === 'fr', langInd: lang === 'en' ? 'transform: translateX(0)' : 'transform: translateX(100%)',
      enStyle: lang === 'en' ? 'color: var(--ink)' : 'color: var(--muted)', frStyle: lang === 'fr' ? 'color: var(--ink)' : 'color: var(--muted)',
      en: function () { set({ lang: 'en' }); }, fr: function () { set({ lang: 'fr' }); },
      onEmail: function (e) { set({ email: e.target.value, err: null }); }, onPass: function (e) { set({ pass: e.target.value, err: null }); },
      shown: shown, notShown: !shown, passType: shown ? 'text' : 'password', showLabel: shown ? 'Masquer le mot de passe' : 'Afficher le mot de passe',
      toggleShow: function () { set({ shown: !self.g('shown', false) }); },
      formCls: st === 'wrong' ? 'err' : '', loading: loading, btnLabel: loading ? t.signing : t.signin,
      submit: function () {
        var p = self.g('pass', 'rossi-reno-24');
        if (p.length < 8) { set({ err: 'wrong' }); return; }
        set({ loading: true, err: null });
        setTimeout(function () { set({ loading: false }); }, 1400);
      },
      mailIc: ic('mail', 'sky'), keyIc: ic('key', 'violet'), faceIc: ic('face', 'slate'), crewIc: ic('cone', 'amber')
    };
