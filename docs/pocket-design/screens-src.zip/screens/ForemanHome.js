    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var clockedIn = this.g('clock', mode !== 'clockedOut');
    var justClocked = this.g('justClocked', false);
    var sorted = this.g('sorted', {}), done = this.g('done', { t1: true, t2: true });
    var appr = this.g('appr', { amara: true }), sent = this.g('sent', false), nudged = this.g('nudged', false);
    var rsorted = this.g('rsorted', {}), ask = this.g('ask', '');
    var markSorted = function (k) { var n = Object.assign({}, self.g('sorted', {})); n[k] = true; set({ sorted: n }); };
    var cls = function (t, s) { return 'st-' + t + ' si-' + s; };

    var blockers = [
      ['b1', 'Short 6 sheets of 1/2" drywall', 'Amara · Galloway Rd · bedroom 2 ceiling can’t close until they’re here', ic('bricks', 'clay')],
      ['b2', 'Pot light over the stairs hits a joist', 'Jonah · Galloway Rd · needs a call on moving it 8 in', ic('bolt', 'amber')]
    ];
    var openB = 0;
    var bl = blockers.map(function (b, i) {
      var isS = !!sorted[b[0]]; if (!isS) openB++;
      return { title: b[1], sub: b[2], ic: b[3], open: !isS, word: isS ? 'Sorted' : 'Blocker', cls: isS ? cls('mute', 'check') : cls('bad', 'alert'),
        strike: isS ? 'color: var(--muted); text-decoration: line-through' : '', sep: i ? 'border-top: 1px solid var(--line)' : '',
        answer: function () { set({ ask: 'Re: ' + b[1] + ' · ' }); }, sort: function () { markSorted(b[0]); } };
    });

    var crew = [
      ['AO', 'Amara Okafor', 'Drywall · Galloway Rd', 'On site', cls('ok', 'live'), 'since 7:05', 'tn1', 'var(--ok-dot)'],
      ['SM', 'Sofia Marin', 'Apprentice · Galloway Rd', 'On site', cls('ok', 'live'), 'since 7:20', 'tn2', 'var(--ok-dot)'],
      ['DP', 'Dev Patel', 'Carpenter · Okoye Condo', 'Elsewhere', cls('info', 'q1'), 'since 7:40', 'tn4', 'var(--info)'],
      ['JR', 'Jonah Reyes', 'Electrician, sub · Galloway Rd', 'Later', cls('warn', 'clock'), 'starts 1:00', 'tn3', 'var(--warn-dot)']
    ].map(function (c) { return { ini: c[0], name: c[1], sub: c[2], word: c[3], cls: c[4], time: c[5], tn: c[6], dot: 'background: ' + c[7] }; });

    var TASKS = [
      ['t1', 'Hang ceiling, bedroom 1', 'Amara, Sofia'],
      ['t2', 'Fire-stop around the panel', 'Amara · photo needed'],
      ['t3', 'Hang ceiling, bedroom 2', 'Amara · waiting on 6 sheets'],
      ['t4', 'Electrical rough-in inspection', 'City of Toronto · 2:00 pm'],
      ['t5', 'Daily report and photos', 'You · before 3:30 pm']
    ];
    var nDone = 0;
    var tasks = TASKS.map(function (t) {
      var d = !!done[t[0]]; if (d) nDone++;
      return { title: t[1], sub: t[2], done: d, aria: 'Done: ' + t[1], late: t[0] === 't3' && !d,
        strike: d ? 'color: var(--muted); text-decoration: line-through' : '',
        tickStyle: d ? 'background: var(--ok-dot); color: #ffffff' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
        svgStyle: d ? '' : 'opacity: 0',
        tog: function () { var n = Object.assign({}, self.g('done', { t1: true, t2: true })); n[t[0]] = !n[t[0]]; set({ done: n }); } };
    });

    var waits = [
      ['Change order: 2 more pot lights', 'Harts asked Sunday · Marco to price and send', 'Waiting', cls('warn', 'clock'), ic('doc', 'violet')],
      ['Drywall top-up delivery', '6 sheets 1/2", 2 boxes screws · for Thu morning', 'To confirm', cls('warn', 'clock'), ic('truck', 'azure')],
      ['Paint colour for Harbourfront', 'Reception walls · client to pick by Wed', 'Awaiting', cls('warn', 'clock'), ic('brush', 'rose')]
    ].map(function (w) { return { title: w[0], sub: w[1], word: w[2], cls: w[3], ic: w[4] }; });

    var HRS = [
      ['amara', 'AO', 'Amara Okafor', 'Mon 8.0 · Tue so far 2.8', 10.8, 'tn1'],
      ['sofia', 'SM', 'Sofia Marin', 'Mon 8.0 · Tue so far 2.5', 10.5, 'tn2'],
      ['dev', 'DP', 'Dev Patel', 'Mon 9.5 · 1.5 h over', 12.1, 'tn4'],
      ['jonah', 'JR', 'Jonah Reyes', 'Mon 4.0 · sub, by invoice', 4.0, 'tn3']
    ];
    var nAppr = 0, tot = 0;
    var hours = HRS.map(function (h) {
      var a = !!appr[h[0]]; if (a) nAppr++; tot += h[4];
      var over = h[0] === 'dev';
      var st = sent ? ['Sent', cls('info', 'q1')] : a ? ['Approved', cls('ok', 'check')] : over ? ['Overtime', cls('warn', 'clock')] : ['To approve', cls('warn', 'clock')];
      var setA = function (v) { return function (e) { var row = e && e.currentTarget && e.currentTarget.closest('.swr'); if (row) row.scrollTo({ left: 0, behavior: 'smooth' }); var n = Object.assign({}, self.g('appr', { amara: true })); n[h[0]] = v; set({ appr: n }); }; };
      return { ini: h[1], name: h[2], sub: h[3], hrs: h[4].toFixed(1) + ' h', tn: h[5], word: st[0], cls: st[1],
        acts: a ? [{ label: 'Undo', ic: ic('sync', 'slate'), cls: 'sw-mute', go: setA(false) }, { label: 'Edit', ic: ic('pen', 'violet'), cls: 'sw-acc', go: function () {} }]
                : [{ label: 'Approve', ic: ic('check', 'sage'), cls: 'sw-ok', go: setA(true) }, { label: 'Question', ic: ic('chat', 'amber'), cls: 'sw-warn', go: setA(false) }] };
    });
    var allA = nAppr === HRS.length;

    var reports = [
      ['r1', 'AO', 'Amara Okafor', 'Galloway Rd', '8:02', 'Water stain on the north wall behind the furnace. Dry now, but I don’t want to board over it without someone looking.', ['4', ''], 'tn1'],
      ['r2', 'DP', 'Dev Patel', 'Okoye Condo', '8:40', 'Subfloor dips about 1/4 in by the closet. Levelling it before the planks go down, half a day extra.', ['2', ''], 'tn4']
    ];
    var nOpenR = 0;
    var reps = reports.map(function (r) {
      var s = rsorted[r[0]], cost = r[0] === 'r2';
      if (!s) nOpenR++;
      var st = s ? ['Sorted', cls('mute', 'check')] : cost ? ['In cost review', cls('acc', 'q2')] : ['New', cls('info', 'dot')];
      return { ini: r[1], name: r[2], where: r[3], when: r[4], text: r[5], tn: r[7], word: st[0], cls: st[1], open: !s,
        photos: [{ ic: ic('photo', 'sky'), n: '1/' + r[6][0] }, { ic: ic('photo', 'teal'), n: '2/' + r[6][0] }],
        sort: function () { var n = Object.assign({}, self.g('rsorted', {})); n[r[0]] = true; set({ rsorted: n }); } };
    });

    var sites = [
      ['Basement finish · Hart', 'Drywall phase · next: taping Oct 2', 64, 'On site', cls('ok', 'live')],
      ['Hallway flooring · Okoye Condo', 'Subfloor prep · next: planks Oct 1', 30, 'On site', cls('ok', 'live')],
      ['Reception repaint · Harbourfront', 'Prep and prime · Luca, Sofia', 0, 'Starts Thu', cls('warn', 'clock')]
    ].map(function (s, i) { return { name: s[0], sub: s[1], pct: s[2] + '%', bar: 'width: ' + Math.max(s[2], 2) + '%; background: ' + (s[2] ? 'var(--ok-dot)' : 'var(--line2)'), word: s[3], cls: s[4], sep: i ? 'border-top: 1px solid var(--line)' : '' }; });

    var next = [
      ['2:00 pm', 'Rough-in inspection', 'Galloway Rd · be on site'],
      ['3:30 pm', 'Daily report due', 'Photos of bedroom 1 ceiling'],
      ['Wed', 'Harbourfront walk-through', 'Queens Quay W · 7:30 am'],
      ['Thu', 'Drywall top-up delivery', 'Galloway Rd · 8:00–10:00'],
      ['Fri', 'Send hours to the office', 'Week of Sep 28']
    ].map(function (n) { return { when: n[0], title: n[1], sub: n[2] }; });

    var toggleClock = function () { set({ clock: !self.g('clock', mode !== 'clockedOut'), justClocked: true }); };
    return {
      offline: offline, pending: offline ? 2 + (justClocked ? 1 : 0) : 0, cloudIc: ic('cloud', 'amber'),
      askPh: offline ? 'Report now, it sends later' : 'Ask or report', ask: ask, onAsk: function (e) { set({ ask: e.target.value }); },
      clockWord: clockedIn ? 'On site' : 'Not clocked in', clockCls: clockedIn ? cls('ok', 'live') : cls('mute', 'off'),
      timer: clockedIn ? (justClocked && mode === 'clockedOut' ? '0h 00m' : '2h 41m') : (justClocked ? '2h 41m' : '0h 00m'),
      timerStyle: clockedIn ? '' : 'color: var(--faint)',
      clockSub: clockedIn ? (justClocked && mode === 'clockedOut' ? 'Clocked in now · 48 Galloway Rd' : 'Since 7:12 · 48 Galloway Rd') : (justClocked ? 'Clocked out now' : 'Crew started 7:05 at Galloway Rd'),
      clockBtn: clockedIn ? 'Clock out' : 'Clock in', clockBtnCls: clockedIn ? 'btn-s' : 'btn-p', toggleClock: toggleClock,
      clockSaved: offline && justClocked,
      blockers: bl, blockLbl: openB ? openB + ' open' : 'All sorted',
      quick: [
        { label: 'Schedule', ic: ic('cal', 'violet'), href: 'Schedule.dc.html' },
        { label: 'Jobs', ic: ic('hammer', 'clay'), href: 'Jobs.dc.html' },
        { label: 'Hours', ic: ic('clock', 'teal'), href: 'CrewHours.dc.html' },
        { label: 'Crew', ic: ic('users', 'azure'), href: 'CrewNow.dc.html' }
      ],
      crew: crew, crewLbl: '3 on site · 1 later',
      tasks: tasks, taskLbl: nDone + ' of ' + TASKS.length + ' done',
      waits: waits, waitCount: '3', nudge: function () { set({ nudged: true }); }, nudgeLbl: nudged ? (offline ? 'Nudge saved, sends later' : 'Marco nudged') : 'Nudge Marco',
      hours: hours, hrsTotal: tot.toFixed(1) + ' h',
      approveAll: function () { set({ appr: { amara: true, sofia: true, dev: true, jonah: true } }); },
      approveAllStyle: allA || sent ? 'display: none' : '',
      sendHours: function () { if (allA) set({ sent: true }); },
      sendLbl: sent ? (offline ? 'Queued' : 'Sent to office') : 'Send',
      sendStyle: sent ? 'background: var(--ok-soft); color: var(--ok)' : allA ? '' : 'opacity: .4',
      reports: reps, fieldLbl: nOpenR ? nOpenR + ' open' : 'All sorted',
      sites: sites, next: next
    };
