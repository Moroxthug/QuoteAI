    var M = {
      a: { title: 'Préparation et retrait de l’ancien plancher', tasks: 3, days: 1, pct: 15, term: '' },
      b: { title: 'Nivellement et sous-couche', tasks: 2, days: 1, pct: 20, term: '' },
      c: { title: 'Pose du vinyle, corridor et entrée', tasks: 4, days: 2, pct: 45, term: 'Avancement 40 % · 884 $' },
      d: { title: 'Moulures, seuils et nettoyage', tasks: 3, days: 1, pct: 20, term: 'Final 30 % · 663 $' },
      e: { title: 'Nouvelle étape', tasks: 0, days: 1, pct: 0, term: '' }
    };
    var order = this.g('order', ['a', 'b', 'c', 'd']), removed = this.g('removed', null);
    var si = this.g('si', 0), started = this.g('started', false);
    var STARTS = [[5, 'lun. 5 oct.'], [7, 'mer. 7 oct.'], [12, 'lun. 12 oct.'], [14, 'mer. 14 oct.']];
    var MON = ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'];
    var dn = function (d) { return d.getDate() === 1 ? '1er' : d.getDate() + ''; };
    var fmt = function (d) { return dn(d) + ' ' + MON[d.getMonth()]; };
    var nextWork = function (d) { var x = new Date(d); while (x.getDay() === 0 || x.getDay() === 6) x.setDate(x.getDate() + 1); return x; };
    var addWork = function (d, n) { var x = new Date(d); while (n > 0) { x.setDate(x.getDate() + 1); if (x.getDay() !== 0 && x.getDay() !== 6) n--; } return x; };
    var cur = nextWork(new Date(2026, 9, STARTS[si][0])), first = cur, last = cur, totalDays = 0;
    var ms = order.map(function (id, i) {
      var m = M[id], s = cur, e = addWork(s, m.days - 1); last = e; cur = addWork(e, 1); totalDays += m.days;
      return {
        title: m.title, tasks: m.tasks, pct: m.pct + ' %', dates: m.days > 1 ? (s.getMonth() === e.getMonth() ? dn(s) : fmt(s)) + ' – ' + fmt(e) : fmt(s),
        term: m.term || 'Aucun paiement lié', termCls: m.term ? '' : 'none',
        upLabel: 'Monter : ' + m.title, delLabel: 'Supprimer : ' + m.title,
        up: function () { if (i === 0) return; var o = order.slice(); o.splice(i - 1, 0, o.splice(i, 1)[0]); set({ order: o }); },
        del: function () { var o = order.slice(); o.splice(i, 1); set({ order: o, removed: { id: id, at: i } }); }
      };
    });
    var cdef = { mat: 820, lab: 540, sub: 0, per: 0, eq: 45, misc: 60 };
    var CATS = [
      ['mat', 'Matériaux', 'Planches de vinyle, sous-couche', 'box', 'amber'],
      ['lab', 'Main-d’œuvre', 'Dev Patel · 18 h', 'users', 'teal'],
      ['sub', 'Sous-traitants', 'Aucun prévu', 'hammer', 'clay'],
      ['per', 'Permis et frais', 'Aucun requis', 'shield', 'azure'],
      ['eq', 'Équipement', 'Location de scie à plancher, 1 jour', 'gear', 'slate'],
      ['misc', 'Divers', 'Rebuts et fournitures', 'dot', 'stone']
    ];
    var total = 0;
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var money0 = function (n) { return n.toLocaleString('fr-CA', { maximumFractionDigits: 0 }).replace(/\s/g, ' ') + ' $'; };
    var cats = CATS.map(function (c) {
      var v = self.g('c_' + c[0], cdef[c[0]]); total += v;
      return {
        name: c[1], note: c[2], ic: ic(c[3], c[4]), amt: money0(v), amtStyle: v ? '' : 'color: var(--faint)',
        decLabel: 'Moins : ' + c[1], incLabel: 'Plus : ' + c[1],
        dec: function () { var o = {}; o['c_' + c[0]] = Math.max(0, v - 25); set(o); },
        inc: function () { var o = {}; o['c_' + c[0]] = v + 25; set(o); }
      };
    });
    var value = 2210, margin = value - total, pct = Math.round(margin / value * 1000) / 10;
    return {
      name: this.g('name', 'Plancher du corridor'), onName: function (e) { set({ name: e.target.value }); },
      window: (last.getMonth() === first.getMonth() ? dn(first) : fmt(first)) + ' – ' + fmt(last),
      windowSub: totalDays + ' jours ouvrables',
      ms: ms, mCount: ms.length + ' étapes', removed: !!removed,
      restore: function () { var o = order.slice(); o.splice(removed.at, 0, removed.id); set({ order: o, removed: null }); },
      addM: function () { if (order.indexOf('e') < 0) set({ order: order.concat(['e']) }); },
      calIc: ic('cal', 'violet'),
      starts: STARTS.map(function (s, i) { var on = i === si; return { label: s[1], on: on, cls: on ? 'on' : '', pick: function () { set({ si: i }); } }; }),
      cats: cats, costTotal: money(total), marginAmt: money(margin), marginPct: String(pct).replace('.', ',') + ' %',
      marginNote: pct >= 30 ? 'Au-dessus de votre cible de 30 %' : 'Sous votre cible de 30 %',
      marginNoteStyle: pct >= 30 ? 'color: var(--ok)' : 'color: var(--warn)',
      marginW: Math.max(0, Math.min(100, pct)) + '%', marginBar: pct >= 30 ? 'background: var(--ok-dot)' : 'background: var(--warn-dot)',
      start: function () { set({ started: true }); },
      startLabel: started ? 'Chantier lancé · Dev est avisé' : 'C’est bon, lancer le chantier',
      startStyle: started ? 'background: var(--ok); color: var(--on-inv)' : ''
    };
