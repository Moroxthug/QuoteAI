    var tab = this.g('tab', 0), copied = this.g('copied', false), invited = this.g('invited', false), reminded = this.g('reminded', false);
    var TABS = ['Soumissions', 'Chantiers', 'Factures', 'Messages'];
    var sep = function (i) { return i ? 'border-top: 1px solid var(--line)' : ''; };
    return {
      acts: [
        { label: 'Appeler', ic: ic('phone', 'sage'), aria: 'Appeler Tom & Lena Hart' },
        { label: 'Texto', ic: ic('chat', 'azure'), aria: 'Envoyer un texto à Tom & Lena Hart' },
        { label: 'Courriel', ic: ic('mail', 'sky'), aria: 'Écrire un courriel à Tom & Lena Hart' },
        { label: 'Carte', ic: ic('pin', 'clay'), aria: 'Ouvrir 48 Galloway Rd dans Cartes' }
      ],
      stats: [
        { label: 'Soumissions gagnées', value: '2 sur 3', sub: '67 % de réussite', subStyle: 'color: var(--muted)', br: 'border-right: 1px solid var(--line); border-bottom: 1px solid var(--line)' },
        { label: 'Valeur totale', value: '42 355 $', sub: 'Depuis août 2026', subStyle: 'color: var(--muted)', br: 'border-bottom: 1px solid var(--line)' },
        { label: 'Dû', value: '2 340 $', sub: '9 jours de retard', subStyle: 'color: var(--bad)', br: 'border-right: 1px solid var(--line)' },
        { label: 'Chantiers', value: '1', sub: 'En cours, 64 % terminé', subStyle: 'color: var(--ok)', br: '' }
      ],
      details: [
        { k: 'Adresse', v: '48 Galloway Rd, Scarborough', mono: false },
        { k: 'Téléphone', v: '(416) 555-0148', mono: true },
        { k: 'Courriel', v: 'lena.hart@gmail.com', mono: false },
        { k: 'Numéro de TPS/TVH', v: 'Non requis, client résidentiel', mono: false },
        { k: 'Numéro d’entreprise', v: 'Aucun', mono: false },
        { k: 'Taxe sur les soumissions', v: 'TVH, Ontario 13 %', mono: false }
      ].map(function (d, i) { return { k: d.k, v: d.v, sep: sep(i), cls: d.mono ? 'mono' : '' }; }),
      tabs: TABS.map(function (t, i) { var on = i === tab; return { label: t, cls: on ? 'on' : '', on: on, pick: function () { set({ tab: i }); } }; }),
      isQ: tab === 0, isJ: tab === 1, isI: tab === 2, isM: tab === 3,
      quotes: [
        ['Q-2026-114', 'Ordre de changement', 'Acceptée le 19 sept.', '3 955,00 $', 'Acceptée', 'st-ok si-check'],
        ['Q-2026-107', 'Finition du sous-sol', 'Acceptée le 28 août', '38 400,00 $', 'Acceptée', 'st-ok si-check'],
        ['Q-2026-092', 'Mur de rangement du garage', 'Refusée le 30 juil.', '2 150,00 $', 'Refusée', 'st-bad si-x']
      ].map(function (q, i) { return { no: q[0], title: q[1], when: q[2], amt: q[3], status: q[4], st: q[5], ic: ic('doc', i === 2 ? 'slate' : 'indigo') }; }),
      jobIc: ic('hammer', 'amber'),
      invoices: [
        ['INV-0412', 'Étape du gypse', 'Échue le 20 sept. · 9 jours de retard', '2 340,00 $', 'En retard', 'st-bad si-alert'],
        ['INV-0405', 'Étape de la charpente', 'Payée le 18 sept. · Interac', '9 600,00 $', 'Payée', 'st-ok si-check'],
        ['INV-0398', 'Dépôt, 30 %', 'Payée le 28 août · Carte', '11 520,00 $', 'Payée', 'st-ok si-check']
      ].map(function (v, i) { return { no: v[0], title: v[1], when: v[2], amt: v[3], status: v[4], st: v[5], ic: ic('receipt', i === 0 ? 'clay' : 'sage') }; }),
      msgs: [
        { who: 'Lena', text: 'Amara peut-elle passer par la porte de côté jeudi ? Nous serons absents jusqu’à 17 h.', time: 'lun. 19 h 42', mine: false },
        { who: 'Vous', text: 'Oui, elle va verrouiller à 16 h. Je vous envoie les photos du gypse ce soir.', time: 'lun. 19 h 50', mine: true },
        { who: 'Lena', text: 'Parfait, merci. Le coin près de l’escalier est superbe.', time: 'Hier, 20 h 16', mine: false }
      ].map(function (m) { return { text: m.text, time: m.time, wrap: m.mine ? 'align-items: flex-end' : 'align-items: flex-start', bubble: m.mine ? 'background: var(--inv); color: var(--on-inv); border-bottom-right-radius: 6px' : 'background: var(--card); color: var(--ink); box-shadow: 0 0 0 1px var(--ring); border-bottom-left-radius: 6px' }; }),
      portalIc: ic('globe', 'violet'),
      copyLabel: copied ? 'Lien copié' : 'Copier le lien', copy: function () { set({ copied: true }); },
      inviteLabel: invited ? 'Invitation envoyée' : 'Inviter Tom', invite: function () { set({ invited: true }); },
      remindLabel: reminded ? 'Rappel envoyé' : 'Envoyer un rappel', remind: function () { set({ reminded: true }); }, remindDis: reminded,
      warnIc: ic('bell', 'clay')
    };
