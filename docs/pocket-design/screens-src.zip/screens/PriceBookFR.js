    var st = this.props.state || 'default';
    var f = this.g('f', 'all'), q = this.g('q', st === 'empty' ? 'plinthe' : ''), open = this.g('open', 'a1'), addOpen = this.g('add', false);
    var nName = this.g('nName', ''), nCat = this.g('nCat', 'lab'), nUnit = this.g('nUnit', 'pi lin.'), nRate = this.g('nRate', ''), nCost = this.g('nCost', ''), added = this.g('added', []);
    var money = function (n) { return n.toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $'; };
    var num = function (s) { var n = parseFloat(String(s).replace(',', '.').replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    // id, cat, name, rate, unit, meta, markCls, mark, icon, tone, parts, cost
    var D = [
      ['l1', 'lab', 'Peinture des murs, 2 couches', 2.10, 'pi²', 'Utilisé aujourd’hui · Q-2026-119', '', '', 'brush', 'violet'],
      ['l2', 'lab', 'Pose et joints de gypse', 3.40, 'pi²', 'Utilisé le 24 sept. · était 3,10 $', 'warn', 'Prix modifié', 'bricks', 'amber'],
      ['l3', 'lab', 'Peinture des plafonds', 1.85, 'pi²', 'Utilisé le 22 sept.', '', '', 'brush', 'indigo'],
      ['l4', 'lab', 'Menuiserie de finition', 68.00, 'heure', 'Utilisé le 19 sept.', '', '', 'hammer', 'clay'],
      ['l5', 'lab', 'Pose de carrelage au sol', 12.50, 'pi²', 'De Rossi Commercial', '', '', 'grid', 'teal'],
      ['m1', 'mat', 'Panneau de gypse ½ po 4×8', 19.95, 'unité', 'Utilisé le 24 sept. · était 18,40 $', 'warn', 'Hausse 8 %', 'bricks', 'stone'],
      ['m2', 'mat', 'Benjamin Moore Regal, 3,79 L', 78.99, 'unité', 'Utilisé aujourd’hui', '', '', 'drop', 'sky'],
      ['m3', 'mat', 'Composé à joints, 17 L', 24.60, 'unité', 'Utilisé le 24 sept.', '', '', 'box', 'sage'],
      ['m4', 'mat', 'Montant SPF 2×4×8', 5.48, 'unité', 'Utilisé le 12 sept. · était 5,65 $', 'ok', 'Baisse 3 %', 'ruler', 'gold'],
      ['a1', 'asm', 'Mur de sous-sol fini', 38.60, 'pi lin.', '6 éléments · utilisé le 28 août', '', '', 'house', 'violet', [['Montants et lisses', '6,20 $'], ['Isolant R14 et pare-vapeur', '5,10 $'], ['Gypse, deux côtés', '9,80 $'], ['Ruban, composé et sablage', '7,40 $'], ['Apprêt et 2 couches', '6,30 $'], ['Plinthe', '3,80 $']], '26,10 $'],
      ['a2', 'asm', 'Repeindre un plafond de salle de bain', 420.00, 'unité', '4 éléments · utilisé le 29 sept.', '', '', 'drop', 'teal', [['Lavage antimoisissure et préparation', '95,00 $'], ['Apprêt bloque-taches', '85,00 $'], ['Peinture salle de bain, 2 couches', '190,00 $'], ['Nettoyage et remise du couvercle du ventilateur', '50,00 $']], '238,00 $'],
      ['a3', 'asm', 'Encastré, fourni et installé', 145.00, 'unité', '3 éléments · Jonah Reyes', 'warn', 'Prix modifié', 'bolt', 'amber', [['Encastré DEL mince 4 po', '32,00 $'], ['Fil et boîtier', '18,00 $'], ['Électricien, 0,75 h', '63,75 $']], '113,75 $']
    ];
    added.forEach(function (a, i) { D.unshift(['n' + i, a.cat, a.name, a.rate, a.unit, 'Ajouté à l’instant', 'acc', 'Nouveau', a.cat === 'mat' ? 'box' : 'hammer', 'lilac']); });
    var CAT = { lab: 'Main-d’œuvre', mat: 'Matériaux', asm: 'Assemblages' };
    var TOT = { all: 212 + added.length, lab: 64 + added.filter(function (a) { return a.cat === 'lab'; }).length, mat: 134 + added.filter(function (a) { return a.cat === 'mat'; }).length, asm: 14 };
    var ql = q.trim().toLowerCase();
    var rows = D.filter(function (d) { return (f === 'all' || d[1] === f) && (!ql || (d[2] + ' ' + d[5]).toLowerCase().indexOf(ql) >= 0); });
    var groups = ['lab', 'mat', 'asm'].map(function (c) {
      var rs = rows.filter(function (d) { return d[1] === c; });
      return {
        title: CAT[c], note: ql ? rs.length + ' trouvé(s)' : (c === 'asm' ? 'Touchez pour voir le détail' : 'Les plus utilisés'), has: rs.length > 0,
        rows: rs.map(function (d, i) {
          var isA = c === 'asm', o = open === d[0];
          return { name: d[2], meta: d[5], rate: money(d[3]), unit: '/ ' + d[4], hasMark: !!d[7], mark: d[7], markCls: 'st-' + d[6] + ' si-dot', ic: ic(d[8], d[9]),
            open: isA && o, parts: isA ? d[10].map(function (p) { return { n: p[0], v: p[1] }; }) : [], cost: d[11] || '',
            sep: i ? 'border-top: 1px solid var(--line)' : '', wrapCls: d[0].charAt(0) === 'n' ? 'pb-new' : '',
            tap: function () { if (isA) set({ open: o ? '' : d[0] }); } };
        })
      };
    }).filter(function (g) { return g.has; });
    var r = num(nRate), c = num(nCost);
    var reset = { nName: '', nRate: '', nCost: '', nCat: 'lab', nUnit: 'pi lin.' };
    return {
      addQLabel: 'Ajouter « ' + q.trim() + ' »', q: q, onSearch: function (e) { set({ q: e.target.value }); },
      kpis: [
        { label: 'Articles', value: String(TOT.all), sub: '14 assemblages', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Utilisés ce mois‑ci', value: '86', sub: '19 soumissions', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Prix modifiés', value: '3', sub: 'Depuis le 1er sept.', subStyle: 'color: var(--warn)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: [['all', 'Tous'], ['lab', 'Main-d’œuvre'], ['mat', 'Matériaux'], ['asm', 'Assemblages']].map(function (x) { var on = x[0] === f; return { label: x[1], count: TOT[x[0]], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate'), importIc: ic('export', 'azure'),
      addOpen: addOpen,
      openAdd: function () { set(Object.assign({ add: true }, reset)); },
      openAddQ: function () { set(Object.assign({ add: true }, reset, { nName: q.charAt(0).toUpperCase() + q.slice(1) })); },
      closeAdd: function () { set({ add: false }); },
      nName: nName, nRate: nRate, nCost: nCost,
      onName: function (e) { set({ nName: e.target.value }); }, onRate: function (e) { set({ nRate: e.target.value }); }, onCost: function (e) { set({ nCost: e.target.value }); },
      cats: [['lab', 'Main-d’œuvre'], ['mat', 'Matériau'], ['asm', 'Assemblage']].map(function (x) { var on = x[0] === nCat; return { label: x[1], on: on, cls: on ? 'on' : '', pick: function () { set({ nCat: x[0] }); } }; }),
      units: ['pi²', 'pi lin.', 'heure', 'unité', 'jour'].map(function (u) { var on = u === nUnit; return { label: u, on: on, cls: on ? 'on' : '', pick: function () { set({ nUnit: u }); } }; }),
      hasMargin: r > 0 && c > 0, marginTxt: r > 0 ? Math.round((r - c) / r * 100) + ' %' : '',
      cantSave: !nName.trim() || r <= 0,
      saveItem: function () { set({ add: false, q: '', f: 'all', added: added.concat([{ name: nName.trim(), cat: nCat === 'asm' ? 'lab' : nCat, rate: r, unit: nUnit }]) }); }
    };
