#!/bin/bash
# _set_build.sh NAME "Title" HEIGHT 'DC_PROPS'
S=/tmp/claude-0/-home-claude/623c0fab-b115-55d7-b946-c161fcbc5c10/scratchpad
cd $S/screens && python3 _set_gen.py $1 >/dev/null || exit 1
python3 $S/kit/normalize.py $S/screens/$1.body.html $S/screens/$1.js >/dev/null
DC_PROPS="$4" python3 $S/kit/assemble.py $1 "$2" $S/screens/$1.body.html $S/screens/$1.js $3 >/dev/null || exit 1
cp $S/design/project/$1.dc.html $S/prev/
sed -e 's/"dark":{"editor":"boolean","default":false}/"dark":{"editor":"boolean","default":true}/' -e 's/var DARK_DEFAULT = false;/var DARK_DEFAULT = true;/' $S/design/project/$1.dc.html > $S/prev/${1}_D.dc.html
awk '/data-dc-script/{f=1;next} /<\/script>/{f=0} f' $S/prev/$1.dc.html | sed 's/extends DCLogic//' > /tmp/chk_$1.js; node --check /tmp/chk_$1.js 2>&1 | head -5
# state variants
for st in $5; do sed -e "s/\"default\":\"default\"/\"default\":\"$st\"/" $S/prev/$1.dc.html > $S/prev/${1}_$st.dc.html; done
echo built $1
