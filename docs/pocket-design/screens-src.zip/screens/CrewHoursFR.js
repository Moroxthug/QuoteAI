    var mode = this.props.state || 'default';
    var offline = mode === 'offline';
    var sent = this.g('sent', mode === 'submitted');
    var s = this.g('s', 420), e = this.g('e', 930), brk = this.g('brk', 30), day = this.g('day', 4), reason = this.g('reason', mode === 'submitted' ? 0 : -1), jobI = this.g('job', 0);
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var fmt = function (m) { var h = Math.floor(m / 60), mm = m % 60; return h + ' h' + (mm ? ' ' + pad(mm) : ''); };
    var short = function (m) { var h = Math.floor(m / 60), mm = m % 60; return h + ' h' + (mm ? ' ' + pad(mm) : ''); };
    var dur = function (m) { return Math.floor(m / 60) + ' h ' + pad(m % 60); };
    var worked = Math.max(0, e - s - brk);
    var DAYS = [['mar.', '29', 'Aujourd’hui'], ['lun.', '28', 'Lundi 28 sept.'], ['dim.', '27', 'Dimanche 27 sept.'], ['sam.', '26', 'Samedi 26 sept.'], ['ven.', '25', 'Vendredi 25 sept.'], ['jeu.', '24', 'Jeudi 24 sept.'], ['mer.', '23', 'Mercredi 23 sept.']];
    var JOBS = [['Sous-sol Hart', '48 Galloway Rd · Gypse'], ['Harbourfront Dental', 'Queens Quay W · Réparation et peinture'], ['Gill Residence', 'Réparation du plafond']];
    var BR = [0, 15, 30, 60];
    var bi = BR.indexOf(brk);
    var REASONS = ['Oubli de pointer', 'Téléphone mort', 'Pas de réseau', 'Autre raison'];
    var clamp = function (v) { return Math.max(300, Math.min(1320, v)); };
    var week = [
      { dow: 'lun.', n: '28', hours: '8 h 02', range: '7 h 02–15 h 34', where: 'Sous-sol Hart', st: 'st-ok si-check', status: 'Approuvées' },
      { dow: 'jeu.', n: '24', hours: '8 h 10', range: '7 h 10–15 h 50', where: 'Arrivée pointée à 400 m du chantier', st: 'st-bad si-alert', status: 'Hors chantier à l’arrivée' },
      { dow: 'mer.', n: '23', hours: '7 h 30', range: '7 h 30–15 h 30', where: 'Ajoutées à la main · téléphone mort', st: 'st-warn si-clock', status: 'À approuver' }
    ];
    var total = 8 * 60 + 2 + 8 * 60 + 10 + 7 * 60 + 30;
    if (sent) {
      week.push({ dow: DAYS[day][0], n: DAYS[day][1], hours: dur(worked), range: short(s) + '–' + short(e), where: 'Ajoutées à la main · ' + REASONS[Math.max(0, reason)].toLowerCase(), st: offline ? 'st-mute si-draft' : 'st-warn si-clock', status: offline ? 'Sur le téléphone' : 'À approuver' });
      total += worked;
      week.sort(function (a, b) { return (+b.n) - (+a.n); });
    }
    return {
      offline: offline, sent: sent, editing: !sent,
      sentIc: offline ? ic('cloud', 'amber') : ic('send', 'azure'), cloudIc: ic('cloud', 'amber'), jobIc: ic('house', 'clay'),
      sentTitle: offline ? 'Gardées sur votre téléphone' : 'Envoyées à Luca',
      sentSub: offline ? 'Elles partent à Luca dès que vous avez du réseau. Gardez cette page ouverte ou revenez plus tard.' : 'Il va les approuver ou vous poser une question. Vous recevrez un texto dans les deux cas.',
      dayLong: DAYS[day][2], range: short(s) + '–' + short(e), total: dur(worked),
      days: DAYS.map(function (d, i) { var on = i === day; return { dow: d[0], n: d[1], label: d[2], on: on, cls: on ? 'on' : '', pick: function () { set({ day: i }); } }; }),
      job: JOBS[jobI][0], jobSub: JOBS[jobI][1], swapJob: function () { set({ job: (self.g('job', 0) + 1) % JOBS.length }); },
      start: fmt(s), end: fmt(e),
      sMinus: function () { set({ s: clamp(self.g('s', 420) - 15) }); }, sPlus: function () { set({ s: Math.min(clamp(self.g('s', 420) + 15), self.g('e', 930) - 15) }); },
      eMinus: function () { set({ e: Math.max(clamp(self.g('e', 930) - 15), self.g('s', 420) + 15) }); }, ePlus: function () { set({ e: clamp(self.g('e', 930) + 15) }); },
      breaks: BR.map(function (b, i) { var on = i === bi; return { label: b ? b + ' min' : 'Aucune', on: on, style: on ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ brk: b }); } }; }),
      brkInd: 'transform: translateX(' + (Math.max(0, bi) * 100) + '%)',
      quick: [
        { label: 'Journée normale', range: '7 h–15 h 30', pick: function () { set({ s: 420, e: 930, brk: 30 }); } },
        { label: 'Demi-journée', range: '7 h–11 h 30', pick: function () { set({ s: 420, e: 690, brk: 0 }); } },
        { label: 'Longue journée', range: '7 h–17 h 30', pick: function () { set({ s: 420, e: 1050, brk: 30 }); } }
      ],
      reasons: REASONS.map(function (r, i) { var on = i === reason; return { label: r, on: on, cls: on ? 'on' : '', pick: function () { set({ reason: i, needR: false }); } }; }),
      note: this.g('note', ''), onNote: function (ev) { set({ note: ev.target.value }); },
      needReason: this.g('needR', false),
      submitLabel: offline ? 'Enregistrer ' + dur(worked) : 'Envoyer ' + dur(worked) + ' pour approbation',
      submit: function () { if (self.g('reason', -1) < 0) { set({ needR: true }); return; } set({ sent: true }); },
      another: function () { set({ sent: false, reason: -1, note: '', day: 3 }); },
      week: week, weekTotal: dur(total)
    };
