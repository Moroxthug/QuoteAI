    if (!self._t0) self._t0 = Date.now() - (2 * 3600 + 41 * 60 + 8) * 1000;
    if (!self._iv) self._iv = setInterval(function () { if (self.g('on', true)) self.setState({ tick: Date.now() }); }, 1000);
    var on = this.g('on', true), phase = this.g('phase', ''), start = this.g('start', self._t0), accum = this.g('accum', 0);
    var inAt = this.g('inAt', '7:02 am'), outAt = this.g('outAt', '');
    var locating = phase === 'locating';
    var now = Date.now();
    var worked = accum + (on ? now - start : 0);
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    var sec = Math.floor(worked / 1000);
    var timer = Math.floor(sec / 3600) + ':' + pad(Math.floor(sec / 60) % 60) + ':' + pad(sec % 60);
    var hm = function (d) { var h = d.getHours(), m = d.getMinutes(); return ((h % 12) || 12) + ':' + pad(m) + (h < 12 ? ' am' : ' pm'); };
    var dur = Math.floor(sec / 3600) + 'h ' + pad(Math.floor(sec / 60) % 60) + 'm';

    var toggleClock = function () {
      if (self.g('phase', '') === 'locating') return;
      self.setState({ phase: 'locating' });
      setTimeout(function () {
        var t = Date.now();
        if (self.g('on', true)) {
          self.setState({ on: false, phase: 'done', accum: self.g('accum', 0) + (t - self.g('start', self._t0)), outAt: hm(new Date(t)) });
        } else {
          self.setState({ on: true, phase: 'done', start: t, inAt: hm(new Date(t)) });
        }
        setTimeout(function () { self.setState({ phase: '' }); }, 1800);
      }, 1600);
    };

    var clockBtn, clockBtnSub, clockBtnStyle, clockDiscStyle;
    var isDone = phase === 'done';
    if (isDone) {
      clockBtn = on ? 'Clocked in' : 'Clocked out'; clockBtnSub = (on ? inAt : outAt) + ' · location matched';
      clockBtnStyle = 'background: var(--ok-soft); color: var(--ok)'; clockDiscStyle = 'background: var(--ok-dot); color: #ffffff';
    } else if (locating) {
      clockBtn = 'Locating…'; clockBtnSub = 'Checking you are at 48 Galloway Rd';
      clockBtnStyle = 'background: var(--sunk); color: var(--ink)'; clockDiscStyle = 'background: var(--card); color: var(--acc-t); box-shadow: 0 0 0 1px var(--ring)';
    } else if (on) {
      clockBtn = 'Clock out'; clockBtnSub = 'Tap when you leave the site';
      clockBtnStyle = 'background: var(--sunk); color: var(--ink)'; clockDiscStyle = 'background: var(--bad-soft); color: var(--bad)';
    } else {
      clockBtn = 'Clock in'; clockBtnSub = 'At Hart basement · 48 Galloway Rd';
      clockBtnStyle = 'background: var(--inv); color: var(--on-inv); box-shadow: 0 12px 28px -12px var(--shadow)'; clockDiscStyle = 'background: var(--ok-dot); color: #ffffff';
    }

    var taskDone = this.g('tasks', [true, false, false, false]);
    var TASKS = [
      ['Hang board, back wall', 'Done at 8:40 am', false],
      ['Tape and first coat, bedroom', 'Use the setting compound, 45 min', false],
      ['Corner bead, hallway', 'Added by Luca this morning', true],
      ['Sand and sweep before you leave', 'Vacuum is in the furnace room', false]
    ];
    var doneN = taskDone.filter(Boolean).length;
    var tasks = TASKS.map(function (t, i) {
      var d = taskDone[i];
      return {
        title: t[0], sub: d && i !== 0 ? 'Done' : t[1], done: d, isNew: t[2] && !d, sep: i ? 'border-top: 1px solid var(--line)' : '',
        tickStyle: d ? 'background: var(--ok-dot); box-shadow: none' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
        checkStyle: d ? 'opacity: 1' : 'opacity: 0',
        textStyle: d ? 'color: var(--muted)' : 'color: var(--ink)',
        toggle: function () { var a = self.g('tasks', [true, false, false, false]).slice(); a[i] = !a[i]; self.setState({ tasks: a }); }
      };
    });

    var kind = this.g('kind', 0), sheetOpen = this.g('sheet', false), hasPhoto = this.g('photo', true), repText = this.g('repText', '');
    var KINDS = [['Update', 'What did you get done?', 'Back wall hung, starting tape in the bedroom', 'Send update'], ['Blocker', 'What is stopping you?', 'Short 4 sheets of 1/2" board for the hallway', 'Send blocker'], ['Materials', 'Anything to note?', 'Picked up at Home Depot, Warden Ave', 'Send materials']];
    var kinds = KINDS.map(function (k, i) { var o = i === kind; return { label: k[0], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { self.setState({ kind: i }); } }; });

    var reports = this.g('reports', [
      { k: 'blocker', title: 'Blocker · board short', sub: 'Luca: extra sheets arrive at 11 am', st: 'st-ok', status: 'Answered', time: '7:48' },
      { k: 'photo', title: 'Photo · back wall hung', sub: 'Saved on your phone, sends when you have signal', st: 'st-warn', status: 'Pending sync', time: '8:42' },
      { k: 'materials', title: 'Materials · mesh tape', sub: 'Did not send. Tap to try again', st: 'st-bad', status: 'Failed', time: '9:05' }
    ]);
    var RIC = { blocker: ['warn', 'amber'], photo: ['camera', 'azure'], materials: ['box', 'clay'], update: ['chat', 'violet'] };
    var reportRows = reports.map(function (r, i) {
      return {
        title: r.title, sub: r.sub, st: r.st, status: r.status, time: r.time, ic: ic(RIC[r.k][0], RIC[r.k][1]), sep: i ? 'border-top: 1px solid var(--line)' : '',
        tap: function () {
          if (r.status !== 'Failed') return;
          var a = self.g('reports', reports).slice(); a[i] = Object.assign({}, r, { st: 'st-mute', status: 'Sending', sub: 'Sending now' }); self.setState({ reports: a });
          setTimeout(function () { var b = self.g('reports', a).slice(); b[i] = Object.assign({}, r, { st: 'st-ok', status: 'Sent', sub: 'Luca will see it on his next check' }); self.setState({ reports: b }); }, 1300);
        }
      };
    });

    var changesOpen = this.g('chOpen', false);
    return {
      greet: 'Morning, Amara',
      showChanges: !this.g('gotIt', false), changesOpen: changesOpen,
      chevRot: changesOpen ? 'transform: rotate(180deg)' : 'transform: rotate(0deg)',
      toggleChanges: function () { self.setState({ chOpen: !self.g('chOpen', false) }); },
      gotIt: function () { self.setState({ gotIt: true }); },
      changes: [
        { ic: ic('cal', 'azure'), title: 'Thursday moved to 8:00', sub: 'Harbourfront Dental, reception walls. It was 7:00.' },
        { ic: ic('list', 'violet'), title: 'New task today', sub: 'Corner bead in the hallway, added by Luca' },
        { ic: ic('chat', 'sage'), title: 'Luca answered your blocker', sub: 'Extra sheets arrive at 11 am' }
      ],
      clockSt: locating ? 'st-info' : (on ? 'st-ok' : 'st-mute'),
      clockLabel: locating ? 'Checking location' : (on ? 'On the clock' : 'Off the clock'),
      timer: timer,
      timerStyle: on ? 'color: var(--ink)' : 'color: var(--muted)',
      timerSub: on ? 'Since ' + inAt + ' · on site' : 'Clocked out at ' + outAt + ' · ' + dur + ' today',
      locating: locating, isDone: isDone, showPower: !locating && !isDone,
      toggleClock: toggleClock, clockBtn: clockBtn, clockBtnSub: clockBtnSub, clockBtnStyle: clockBtnStyle, clockDiscStyle: clockDiscStyle,
      jobIc: ic('house', 'clay'), pinIc: ic('pin', 'rose'), phoneIc: ic('phone', 'sage'), jobIc2: ic('house', 'clay'),
      gate: this.g('showCode', true) ? '4417 #' : '•••• #', gateSub: 'Side door lockbox',
      toggleCode: function () { self.setState({ showCode: !self.g('showCode', true) }); },
      tasks: tasks, taskCount: doneN + ' of ' + TASKS.length, allDone: doneN === TASKS.length, doneIc: ic('check', 'sage'),
      upcoming: [
        { dow: 'Wed', day: '30', job: 'Hart basement', time: '7:00–15:30', what: 'Drywall, second coat', hasTag: false, tag: '', tagSt: '' },
        { dow: 'Thu', day: '1', job: 'Harbourfront Dental', time: '8:00–16:00', what: 'Patch reception walls', hasTag: true, tag: 'Moved', tagSt: 'st-acc' },
        { dow: 'Fri', day: '2', job: 'Hart basement', time: '7:00–15:30', what: 'Sand and prime', hasTag: false, tag: '', tagSt: '' },
        { dow: 'Mon', day: '5', job: 'Gill Residence', time: '7:30–12:00', what: 'Ceiling patch, half day', hasTag: false, tag: '', tagSt: '' }
      ],
      reports: reportRows,
      openReport: function () { self.setState({ sheet: true }); },
      closeReport: function () { self.setState({ sheet: false }); },
      sheetOpen: sheetOpen, kinds: kinds, kindInd: 'transform: translateX(' + (kind * 100) + '%)',
      isBlocker: kind === 1, isMaterials: kind === 2,
      textLabel: KINDS[kind][1], textPh: KINDS[kind][2], sendLabel: KINDS[kind][3],
      repText: repText, onRepText: function (e) { self.setState({ repText: e.target.value }); },
      hasPhoto: hasPhoto, togglePhoto: function () { self.setState({ photo: !self.g('photo', true) }); },
      warnIc: ic('warn', 'amber'),
      sendReport: function () {
        var k = ['update', 'blocker', 'materials'][self.g('kind', 0)];
        var txt = (self.g('repText', '') || KINDS[self.g('kind', 0)][2]);
        var t = hm(new Date()).replace(/ (am|pm)$/, '');
        var nr = { k: k, title: KINDS[self.g('kind', 0)][0] + ' · ' + (txt.length > 26 ? txt.slice(0, 26) + '…' : txt), sub: k === 'blocker' ? 'Sent to Luca and Marco' : 'Sent to the office', st: 'st-ok', status: 'Sent', time: t };
        self.setState({ sheet: false, repText: '', reports: [nr].concat(self.g('reports', reports)) });
      }
    };
