    var f = this.g('f', 'all'), q = this.g('q', '');
    var S = { draft: ['Draft', 'st-mute si-draft'], await: ['Awaiting', 'st-warn si-clock'], viewed: ['Viewed', 'st-acc si-q2'], signed: ['Signed', 'st-ok si-check'], void: ['Voided', 'st-bad si-x'], done: ['Completed', 'st-mute si-check'] };
    var tints = ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'];
    // no, client, title, total, status, group, sent, signed, tint
    var data = [
      ['C-2026-034', 'Dana Whitfield', 'Bedrooms and bath ceiling', 4131.05, 'draft', 'open', 'Drafted today', '', 0],
      ['C-2026-033', 'Harbourfront Dental', 'Reception repaint', 6420.00, 'viewed', 'open', 'Sent Sep 24', 'Viewed Sep 26', 3],
      ['C-2026-032', 'Tom & Lena Hart', 'Change order 2, egress window', 2860.00, 'await', 'open', 'Sent Sep 28', 'Not opened', 2],
      ['C-2026-029', 'Okoye Condo', 'Hallway flooring', 2210.00, 'signed', 'signed', 'Sent Sep 15', 'Signed Sep 16', 0],
      ['C-2026-027', 'Tom & Lena Hart', 'Change order 1, basement', 3955.00, 'signed', 'signed', 'Sent Sep 19', 'Signed Sep 20', 2],
      ['C-2026-025', 'Tom & Lena Hart', 'Basement finish', 38400.00, 'signed', 'signed', 'Sent Aug 28', 'Signed Aug 29', 2],
      ['C-2026-022', 'Marchetti Bakery', 'Storefront trim', 1480.00, 'void', 'closed', 'Sent Sep 8', 'Voided Sep 13', 1],
      ['C-2026-018', 'Chen Family', 'Laundry room refresh', 3300.00, 'done', 'closed', 'Completed Jul 30', '', 2]
    ];
    var FIL = [['all', 'All', function () { return true; }], ['draft', 'Drafts', function (s) { return s === 'draft'; }], ['await', 'Awaiting', function (s) { return s === 'await' || s === 'viewed'; }], ['signed', 'Signed', function (s) { return s === 'signed'; }], ['closed', 'Closed', function (s) { return s === 'void' || s === 'done'; }]];
    var fn = FIL.filter(function (x) { return x[0] === f; })[0][2];
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ql = q.trim().toLowerCase();
    var rows = data.filter(function (d) { return fn(d[4]) && (!ql || (d[0] + ' ' + d[1] + ' ' + d[2]).toLowerCase().indexOf(ql) >= 0); });
    var groups = [['open', 'Needs a signature'], ['signed', 'Signed'], ['closed', 'Closed']].map(function (g) {
      var rs = rows.filter(function (d) { return d[5] === g[0]; });
      return { title: g[1], count: rs.length ? rs.length + '' : '', has: rs.length > 0, rows: rs.map(function (d) {
        var ini = d[1].replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase();
        return { no: d[0], client: d[1], title: d[2], amt: money(d[4] === 'draft' ? d[3] : d[3]), status: S[d[4]][0], st: S[d[4]][1], ini: ini, tn: tints[d[8]], dates: d[6] + (d[7] ? ' · ' + d[7] : '') };
      }) };
    }).filter(function (g) { return g.has; });
    return {
      q: q, onSearch: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', f: 'all' }); },
      kpis: [
        { label: 'To sign', value: '3', sub: '1 is yours', subStyle: 'color: var(--warn)', sep: '' },
        { label: 'Signed this month', value: '$6,165', sub: '2 contracts', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Avg. time to sign', value: '1.2 d', sub: '↓ 0.4 d', subStyle: 'color: var(--ok)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: FIL.map(function (x) { var on = x[0] === f; return { label: x[1], count: data.filter(function (d) { return x[2](d[4]); }).length, on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate')
    };
