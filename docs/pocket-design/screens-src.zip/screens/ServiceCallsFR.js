    var ST = this.props.state || 'default';
    var RO = ST === 'readOnly';
    var f = this.g('f', 'active'), sheet = this.g('sheet', null), booked = this.g('booked', {}), bill = this.g('bill', {});
    var day = this.g('day', 1), time = this.g('time', 0), who = this.g('who', 0), txt = this.g('txt', true);
    var DAYS = ['jeu. 1er oct.', 'ven. 2 oct.', 'lun. 5 oct.', 'mar. 6 oct.'], TIMES = ['8 h–10 h', '10 h–12 h', '13 h–15 h'];
    var CREW = [['Dev Patel', 'DP', 'tn4', 'L’a installé'], ['Luca Bianchi', 'LB', 'tn2', 'Contremaître'], ['Amara Okafor', 'AO', 'tn1', '']];
    var C = [
      { id: 'ok', client: 'Okoye Condo', ini: 'OC', tn: 'tn3', job: 'Plancher du corridor · terminé le 24 sept.', issue: 'Planche qui craque à l’entrée',
        reported: 'Signalé le 28 sept. par Grace Okoye, depuis le portail client', note: 'Une planche près de la porte d’entrée craque sous le tapis. Pas d’écart ni de soulèvement. Il faut sans doute une vis de finition dans la solive.',
        photos: [['a', 'photo', 'amber', 'Photo de la planche à l’entrée'], ['b', 'camera', 'violet', 'Vidéo du craquement']],
        warranty: true, wTitle: 'Sous garantie jusqu’en sept. 2027', wSub: 'Main-d’œuvre 1 an · matériaux par le fabricant', defBill: 0, prebooked: null, sec: 'Appeler Grace' },
      { id: 'gi', client: 'Gill Residence', ini: 'GR', tn: 'tn1', job: 'Remise à neuf du patio · terminé en août 2025', issue: 'Teinture qui pèle sur la marche du haut',
        reported: 'Signalé le 26 sept. par téléphone, Harjit Gill', note: 'Marche du haut et première planche du palier. Beaucoup de passage. Le reste du patio est beau.',
        photos: [['a', 'photo', 'amber', 'Photo de la marche du haut']],
        warranty: false, wTitle: 'Garantie terminée en août 2026', wSub: 'Soumissionner la réparation ou facturer l’appel', defBill: 1, prebooked: null, sec: 'Soumissionner' },
      { id: 'hd', client: 'Harbourfront Dental', ini: 'HD', tn: 'tn4', job: 'Repeinture · terminé en mars 2025', issue: 'Marques sur le mur de la réception',
        reported: 'Signalé le 21 sept. par courriel, gestionnaire du bureau', note: 'Marques de chaises derrière l’accueil. Retouche avec le même fini coquille d’œuf, Dulux Timeless Grey.',
        photos: [['b', 'photo', 'violet', 'Photo des marques']],
        warranty: true, wTitle: 'Sous garantie jusqu’en mars 2027', wSub: 'Main-d’œuvre 2 ans sur les chantiers commerciaux', defBill: 0, prebooked: [0, 0, 1], sec: 'Reporter' }
    ];
    var NW = 'Nouveau', NC = 'Sans frais';
    var calls = C.map(function (c, i) {
      var bk = booked[c.id] || c.prebooked, bi = bill[c.id] !== undefined ? bill[c.id] : c.defBill;
      var status = bk ? ['Planifié', 'st-info si-q1'] : [NW, 'st-warn si-alert'];
      return { client: c.client, ini: c.ini, tn: c.tn, job: c.job, issue: c.issue, reported: c.reported, note: c.note, status: status[0], st: status[1],
        photos: c.photos.map(function (p) { return { cls: p[0], ic: ic(p[1], p[2]), label: p[3] }; }),
        wIc: c.warranty ? ic('shield', 'sage') : ic('shield', 'stone'), wTitle: c.wTitle, wSub: c.wSub,
        isBooked: !!bk, visit: bk ? DAYS[bk[0]] + ', ' + TIMES[bk[1]] : '', visitWho: bk ? CREW[bk[2]][0] : '', calIc: ic('cal', 'azure'),
        segStyle: RO ? 'opacity: .55' : '', ind: 'width: calc((100% - 4px) / 2); transform: translateX(' + (bi * 100) + '%)',
        bill: ['Sans frais', 'Facturer le client'].map(function (l, j) { return { label: l, on: j === bi, style: j === bi ? 'color: var(--ink)' : 'color: var(--muted)', pick: function () { if (RO) return; var n = Object.assign({}, self.g('bill', {})); n[c.id] = j; set({ bill: n }); } }; }),
        canAct: !RO, primLabel: bk ? 'Détails de la visite' : 'Planifier la visite', primCls: bk ? 'btn-s' : 'btn-p', secLabel: c.sec,
        schedule: function () { if (bk) return; set({ sheet: i, day: 1, time: 0, who: 0 }); } };
    });
    var D = [
      ['Retouche de coulis dans la salle de lavage', 'Chen Family', '3 sept.', 0, NC, 'st-mute si-check', 'check', 'sage'],
      ['Ajustement de portes d’armoire', 'Priya Nair', '19 août', 95, 'Payé', 'st-ok si-check', 'receipt', 'amber'],
      ['Retouche de peinture, corridor', 'Dana Whitfield', '30 juil.', 0, NC, 'st-mute si-check', 'check', 'sage'],
      ['Calfeutrage des moulures de la devanture', 'Marchetti Bakery', '12 juin', 180, 'Payé', 'st-ok si-check', 'receipt', 'amber']
    ];
    var done = D.map(function (d) { return { issue: d[0], client: d[1], when: d[2], amt: d[3].toLocaleString('fr-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).replace(/\s/g, ' ') + ' $', status: d[4], st: d[5], ic: ic(d[6], d[7]) }; });
    var W = [
      ['Okoye Condo · plancher du corridor', 'Terminé le 24 sept. 2026 · jusqu’en sept. 2027', 'Couvert', 'st-ok', 'si-check', 2],
      ['Harbourfront Dental · repeinture de la réception', 'Terminé en mars 2025 · jusqu’en mars 2027', 'Couvert', 'st-ok', 'si-check', 75],
      ['Priya Nair · peinture de la cuisine', 'Terminé en nov. 2025 · jusqu’au 3 nov.', 'Fin dans 5 sem.', 'st-warn', 'si-clock', 90],
      ['Gill Residence · remise à neuf du patio', 'Terminé en août 2025 · fini en août 2026', 'Terminée', 'st-mute', 'si-off', 100]
    ];
    var warranty = W.map(function (w, i) { return { job: w[0], sub: w[1], status: w[2], st: w[3] + ' ' + w[4], sep: i ? 'border-top: 1px solid var(--line)' : '',
      bar: 'width: ' + w[5] + '%; background: ' + (w[5] >= 100 ? 'var(--line2)' : w[5] >= 85 ? 'var(--warn-dot)' : 'var(--ok-dot)') }; });
    var cur = sheet === null ? null : C[sheet];
    var sh = { title: '', days: [], times: [], crew: [], cta: '' };
    if (cur) sh = { title: cur.client + ' · ' + cur.issue.toLowerCase(),
      days: DAYS.map(function (d, j) { var on = j === day; return { label: d, on: on, cls: on ? 'on' : '', pick: function () { set({ day: j }); } }; }),
      times: TIMES.map(function (t, j) { var on = j === time; return { label: t, on: on, cls: on ? 'on' : '', pick: function () { set({ time: j }); } }; }),
      crew: CREW.map(function (c, j) { var on = j === who; return { name: c[0].split(' ')[0], ini: c[1], tn: c[2], note: c[3] || ' ', on: on, bg: on ? 'background: var(--sunk)' : '', ring: on ? 'box-shadow: 0 0 0 2px var(--card), 0 0 0 4px var(--ink)' : '', pick: function () { set({ who: j }); } }; }),
      cta: 'Réserver ' + DAYS[day] + ', ' + TIMES[time] };
    var nOpen = calls.length;
    var B = {
      offline: ['b-warn', 'cloud', 'amber', 'Vous êtes hors ligne.', 'Appels gardés sur ce téléphone. Les réservations partent au retour du réseau.'],
      readOnly: ['b-info', 'eye', 'sky', 'Lecture seule.', 'Votre rôle permet de voir les appels, mais pas de les réserver ni de les facturer.']
    };
    var b = B[ST];
    var hasData = ST !== 'empty';
    return {
      banner: b ? { show: true, cls: b[0], ic: ic(b[1], b[2]), title: b[3], text: b[4] } : { show: false, cls: '', ic: ic('dot', 'slate'), title: '', text: '' },
      isEmpty: ST === 'empty', hasData: hasData, emptyIc: ic('shield', 'sage'),
      kpis: [
        { label: 'Appels ouverts', value: String(nOpen), sub: (function (n) { return n + (n > 1 ? ' planifiés' : ' planifié'); })(Object.keys(booked).length + 1), sep: '' },
        { label: 'Sous garantie', value: '5', sub: 'chantiers terminés', sep: 'border-left: 1px solid var(--line)' },
        { label: '1re visite', value: '2,4 j', sub: 'en moyenne', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: [['active', 'Ouverts', nOpen], ['done', 'Terminés', done.length]].map(function (x) { var on = x[0] === f; return { label: x[1], count: x[2], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      showActive: f === 'active', showDone: f === 'done', calls: calls, done: done, warranty: warranty,
      sheetOpen: !!cur, sh: sh, close: function () { set({ sheet: null }); },
      txt: txt, txtTrack: txt ? 'background: var(--acc)' : 'background: var(--track-off)', txtKnob: txt ? 'transform: translateX(20px)' : 'transform: translateX(0)', toggleTxt: function () { set({ txt: !txt }); },
      book: function () { var n = Object.assign({}, booked); n[C[sheet].id] = [day, time, who]; set({ booked: n, sheet: null }); }
    };
