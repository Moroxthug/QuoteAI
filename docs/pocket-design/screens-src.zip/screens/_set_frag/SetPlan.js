    var failed = ST === 'paymentFailed', down = ST === 'downgraded', member = ST === 'member';
    var meter = function (label, used, total, sub) {
      var pct = Math.min(100, Math.round(used / total * 100)), full = pct >= 100, near = pct >= 80;
      return { label: label, used: used.toLocaleString('en-CA'), total: total.toLocaleString('en-CA'),
        bar: 'width: ' + pct + '%; background: ' + (full ? 'var(--bad)' : near ? 'var(--warn-dot)' : 'var(--inv)'),
        numStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : '', sub: sub, subStyle: full ? 'color: var(--bad)' : near ? 'color: var(--warn)' : 'color: var(--muted)' };
    };
    var meters = down ? [
      meter('Logins', 2, 2, 'Luca Bianchi’s login is paused'),
      meter('Quotes', 51, 60, 'Almost used · resets Oct 1'),
      meter('Active jobs', 3, 3, 'Finish one to start another'),
      meter('Receipt scans', 38, 100, 'Resets Oct 1')
    ] : [
      meter('Logins', 3, 5, 'Marco, Luca and the office'),
      meter('AI quotes', 142, 500, 'Resets Oct 1'),
      meter('Texts', 412, 1000, 'Resets Oct 1'),
      meter('Receipt scans', 38, 200, 'Resets Oct 1')
    ];
    var B = ['Unlimited quotes and jobs', 'Team time and crew links', 'Assistant', 'Analytics', 'QuickBooks and Wave sync', 'Calendar sync', 'Card payments', 'Send from Gmail'];
    var inc;
    if (down) {
      var P = ['60 quotes a month', 'Price book and contracts', '3 active jobs', 'Costs and invoicing', '2 logins'];
      var L = ['Team time and crew links', 'Assistant', 'Analytics', 'QuickBooks and Wave sync', 'Card payments'];
      inc = P.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; })
        .concat(L.map(function (t) { return { t: t, ic: ic('lock', 'slate'), locked: true, style: 'color: var(--muted)' }; }));
    } else inc = B.map(function (t) { return { t: t, ic: ic('check', 'sage'), locked: false, style: '' }; });
    inc.forEach(function (f, i) { f.sep = i ? 'border-top: 1px solid var(--line)' : ''; });
    var bn = failed ? { show: true, cls: 'b-bad', ic: ic('card', 'rose'), t: 'Your last payment didn’t go through.', s: 'Update your payment method on quoteai.ca by Oct 6. Everything keeps working until then.' }
      : down ? { show: true, cls: 'b-info', ic: ic('tier2', 'azure'), t: 'You’re on Pro since Sep 14.', s: 'Business features are paused, not deleted. Your crew hours and reports are still here.' }
      : member ? { show: true, cls: 'b-info', ic: ic('lock', 'slate'), t: 'Usage only.', s: 'Your role can see how much of the plan is used.' }
      : { show: false, cls: '', ic: ic('dot', 'slate'), t: '', s: '' };
    var billRows = [
      failed ? stat(val('card', 'violet', 'Payment method', 'Visa ending 4242', ''), 'Declined', 'st-bad si-x') : val('card', 'violet', 'Payment method', 'On file at quoteai.ca', 'Visa ••4242', true),
      val('receipt', 'stone', 'Receipts', 'Emailed to marco@rossireno.ca', 'Monthly')
    ];
    return {
      roBanner: roBanner, bn: bn, member: member, canManage: !member,
      plan: down ? 'Pro' : 'Business', tierIc: down ? ic('tier2', 'azure') : ic('tier3', 'violet'),
      planSt: failed ? { w: 'Payment due Oct 6', cls: 'st-bad si-alert' } : down ? { w: 'Changed Sep 14', cls: 'st-mute si-check' } : { w: 'Active', cls: 'st-ok si-live' },
      k1: failed ? { l: 'Update by', v: 'Oct 6', st: 'color: var(--bad)' } : { l: 'Renews', v: 'Oct 14, 2026', st: '' },
      k2: { l: 'Logins', v: down ? '2 of 2' : '3 of 5' },
      meters: meters, incTitle: down ? 'On Pro' : 'Included in Business', inc: inc,
      gBill: grp('Billing', billRows, '', 190),
      webIc: ic('globe', 'violet')
    };
