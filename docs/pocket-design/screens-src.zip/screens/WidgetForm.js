    var lang = this.g('lang', 'en'), fr = lang === 'fr';
    var step = this.g('step', null) || this.props.step || 'form';
    var job = this.g('job', 0), consent = this.g('consent', true), nPh = this.g('nPh', 2);
    var EN = {
      menu: 'Menu', hero: 'Renovations done right, across Toronto', heroSub: 'Painting, drywall, basements and kitchens since 2011.',
      widget: 'Free estimate', stepOf: 'Step {n} of 3', result: 'Your estimate', offShort: 'Not available right now', off: 'Online estimates are paused',
      what: 'What’s the job?', desc: 'Tell us a bit more', descV: 'Three bedrooms and a hallway. Walls and ceilings, some nail holes to fill.',
      size: 'Rough size', sqft: 'sq ft', next: 'Next', back: 'Back',
      photos: 'Add a few photos', photosSub: 'Optional, but they make the range tighter.', add: 'Add', remove: 'Remove photo',
      postal: 'Postal code', serve: 'We work here',
      where: 'Where should we send it?', whereSub: 'You’ll see the range right away. Marco follows up within one business day.',
      name: 'Name', emailPhone: 'Email or phone',
      consent: 'Rossi Renovations can contact me about this estimate. I can unsubscribe any time.',
      get: 'Get my estimate', working: 'Working out your estimate', workingSub: 'Up to half a minute.',
      thanks: 'Thanks, Sam. Here’s your range.', range: 'Estimated range', taxIn: 'HST included', jobTag: 'Painting · 900 sq ft',
      basis: 'Based on similar jobs we’ve done nearby. Marco confirms the price after a quick visit.',
      call: 'Call (416) 555-0142', again: 'Start again',
      offSub: 'Call or email us and we’ll get you a price the same week.',
      powered: 'Powered by quoteAI', onGoogle: 'on Google', reviews: '128 reviews from Toronto homeowners',
      jobs: ['Painting', 'Drywall', 'Flooring', 'Kitchen', 'Bathroom', 'Basement']
    };
    var FR = {
      menu: 'Menu', hero: 'Des rénovations bien faites, partout à Toronto', heroSub: 'Peinture, cloisons sèches, sous-sols et cuisines depuis 2011.',
      widget: 'Estimation gratuite', stepOf: 'Étape {n} de 3', result: 'Votre estimation', offShort: 'Non disponible pour le moment', off: 'Les estimations en ligne sont en pause',
      what: 'Quels travaux?', desc: 'Dites-nous-en un peu plus', descV: 'Trois chambres et un couloir. Murs et plafonds, quelques trous de clous à boucher.',
      size: 'Superficie approximative', sqft: 'pi²', next: 'Suivant', back: 'Retour',
      photos: 'Ajoutez quelques photos', photosSub: 'Facultatif, mais la fourchette sera plus précise.', add: 'Ajouter', remove: 'Retirer la photo',
      postal: 'Code postal', serve: 'Nous desservons ce secteur',
      where: 'Où vous l’envoyer?', whereSub: 'Vous verrez la fourchette tout de suite. Marco fait un suivi en un jour ouvrable.',
      name: 'Nom', emailPhone: 'Courriel ou téléphone',
      consent: 'Rossi Renovations peut me contacter au sujet de cette estimation. Je peux me désabonner en tout temps.',
      get: 'Obtenir mon estimation', working: 'Calcul de votre estimation', workingSub: 'Jusqu’à une demi-minute.',
      thanks: 'Merci, Sam. Voici votre fourchette.', range: 'Fourchette estimée', taxIn: 'TVH incluse', jobTag: 'Peinture · 900 pi²',
      basis: 'Selon des travaux semblables faits dans le secteur. Marco confirme le prix après une courte visite.',
      call: 'Appeler le 416 555-0142', again: 'Recommencer',
      offSub: 'Appelez-nous ou écrivez-nous et vous aurez un prix la même semaine.',
      powered: 'Propulsé par quoteAI', onGoogle: 'sur Google', reviews: '128 avis de propriétaires torontois',
      jobs: ['Peinture', 'Cloisons sèches', 'Planchers', 'Cuisine', 'Salle de bain', 'Sous-sol']
    };
    var t = fr ? FR : EN;
    var money0 = function (n) { var s = n.toLocaleString(fr ? 'fr-CA' : 'en-CA'); return fr ? s + ' $' : '$' + s; };
    var no = { form: 1, photos: 2, contact: 3 }[step] || 0;
    var go = function (s) { return function () { set({ step: s }); }; };
    var GL = [['brush', 'violet'], ['bricks', 'clay'], ['grid', 'amber'], ['house', 'teal'], ['drop', 'azure'], ['hammer', 'stone']];
    var photos = [];
    for (var i = 0; i < nPh; i++) (function (i) {
      photos.push({ ic: ic('photo', i % 2 ? 'teal' : 'sky'), name: 'IMG_20' + (41 + i), aria: t.remove + ' ' + (i + 1), remove: function () { set({ nPh: Math.max(0, self.g('nPh', 2) - 1) }); } });
    })(i);
    return {
      t: t,
      langs: [['en', 'EN'], ['fr', 'FR']].map(function (l) { var o = l[0] === lang; return { label: l[1], on: o, style: o ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)', pick: function () { set({ lang: l[0] }); } }; }),
      langInd: 'transform: translateX(' + (fr ? 100 : 0) + '%)',
      stepLabel: no ? t.stepOf.replace('{n}', no) : (step === 'unavailable' ? t.offShort : t.result),
      showSteps: no > 0, stepNo: no, s1: no >= 1 ? 'on' : '', s2: no >= 2 ? 'on' : '', s3: no >= 3 ? 'on' : '',
      isForm: step === 'form', isPhotos: step === 'photos', isContact: step === 'contact', isWorking: step === 'working', isDone: step === 'done', isOff: step === 'unavailable',
      jobs: t.jobs.map(function (n, i) { var on = i === job; return { name: n, on: on, cls: on ? 'on' : '', ic: ic(GL[i][0], GL[i][1]), pick: function () { set({ job: i }); } }; }),
      photos: photos, addPhoto: function () { set({ nPh: Math.min(5, self.g('nPh', 2) + 1) }); },
      pinIc: ic('pin', 'rose'), okIc: ic('check', 'sage'), offIc: ic('clock', 'slate'), starIc: ic('star', 'gold'),
      consent: consent, noConsent: !consent,
      chkStyle: consent ? 'background: var(--inv)' : 'background: transparent; box-shadow: inset 0 0 0 1.6px var(--line2)',
      tickStyle: consent ? 'opacity: 1' : 'opacity: 0',
      toggleConsent: function () { set({ consent: !self.g('consent', true) }); },
      toForm: go('form'), toPhotos: go('photos'), toContact: go('contact'),
      submit: function () { if (!self.g('consent', true)) return; set({ step: 'working' }); setTimeout(function () { set({ step: 'done' }); }, 2200); },
      restart: function () { set({ step: 'form', job: 0, nPh: 2 }); },
      rangeStr: money0(2900) + ' – ' + money0(3700)
    };
