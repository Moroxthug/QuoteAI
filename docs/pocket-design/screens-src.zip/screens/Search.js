    var q = self.g('q', ''), t = self.g('t', 'all');
    var ql = q.trim().toLowerCase();
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var ini = function (s) { return s.replace('&', '').split(/\s+/).filter(Boolean).map(function (w) { return w[0]; }).join('').slice(0, 2).toUpperCase(); };
    var QS = { draft: ['Draft', 'st-mute si-draft'], sent: ['Sent', 'st-info si-q1'], viewed: ['Viewed', 'st-acc si-q2'], accepted: ['Accepted', 'st-ok si-check'], declined: ['Declined', 'st-bad si-x'], expired: ['Expired', 'st-mute si-off'] };
    var ALL = [];
    [['Q-2026-119', 'Dana Whitfield', 'Bedrooms and bath ceiling', 4131.05, 'draft'], ['Q-2026-118', 'Priya Nair', 'Kitchen backsplash', 1865.10, 'viewed'], ['Q-2026-117', 'Harbourfront Dental', 'Reception repaint', 6420, 'sent'], ['Q-2026-116', 'Gill Residence', 'Deck refinish', 2980, 'sent'], ['Q-2026-114', 'Tom & Lena Hart', 'Basement change order', 3955, 'accepted'], ['Q-2026-112', 'Okoye Condo', 'Hallway flooring', 2210, 'accepted'], ['Q-2026-110', 'Marchetti Bakery', 'Storefront trim', 1480, 'declined'], ['Q-2026-108', 'Chen Family', 'Laundry room refresh', 3300, 'expired'], ['Q-2026-107', 'Tom & Lena Hart', 'Basement finish', 38400, 'accepted']]
      .forEach(function (d) { ALL.push({ type: 'quotes', title: d[1], sub: d[0] + ' · ' + d[2], key: d[0] + ' ' + d[1] + ' ' + d[2], amt: money(d[3]), st: QS[d[4]], ic: ['doc', 'violet'], href: 'Quote.dc.html' }); });
    [['Dana Whitfield', '17 Castle Frank Cres, Toronto'], ['Priya Nair', '212 Dovercourt Rd, Toronto'], ['Tom & Lena Hart', '48 Galloway Rd, Scarborough'], ['Harbourfront Dental', 'Queens Quay W, Toronto'], ['Gill Residence', 'Etobicoke'], ['Okoye Condo', 'Liberty Village, Toronto'], ['Marchetti Bakery', 'College St, Toronto'], ['Chen Family', 'North York']]
      .forEach(function (d, n) { ALL.push({ type: 'clients', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], av: ini(d[0]), tn: ['tn1', 'tn2', 'tn3', 'tn4', 'tn5'][n % 5], href: 'Client.dc.html' }); });
    [['Basement finish', 'Tom & Lena Hart · 64% · drywall phase', ['Active', 'st-ok si-live'], 'house', 'teal'], ['Hallway flooring', 'Okoye Condo · starts Oct 5', ['Planning', 'st-info si-q1'], 'cone', 'amber'], ['Kitchen repaint', 'Chen Family · finished Aug 30', ['Completed', 'st-mute si-check'], 'house', 'slate'], ['Deck refinish', 'Gill Residence · waiting on the weather', ['On hold', 'st-warn si-pause'], 'cone', 'amber']]
      .forEach(function (d) { ALL.push({ type: 'jobs', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], st: d[2], ic: [d[3], d[4]], href: 'Job.dc.html' }); });
    [['INV-0412', 'Tom & Lena Hart', 2340, ['9 days overdue', 'st-bad']], ['INV-0419', 'Harbourfront Dental', 780, ['3 days overdue', 'st-bad']], ['INV-0417', 'Chen Family', 1650, ['To confirm', 'st-warn si-clock']], ['INV-0421', 'Okoye Condo', 2210, ['Paid', 'st-ok si-check']], ['INV-0415', 'Tom & Lena Hart', 11520, ['Paid', 'st-ok si-check']]]
      .forEach(function (d) { ALL.push({ type: 'invoices', title: d[0], sub: d[1], key: d[0] + ' ' + d[1] + (d[3][1] === 'st-bad' ? ' overdue' : ''), amt: money(d[2]), st: d[3], ic: ['receipt', d[3][1] === 'st-bad' ? 'clay' : 'amber'], href: 'Invoice.dc.html' }); });
    [['Settings', 'Language, appearance, notifications', 'gear', 'slate', 'Settings.dc.html'], ['Notifications', '6 unread', 'bell', 'violet', 'Notifications.dc.html'], ['Menu', 'Profile, company, plan', 'list', 'slate', 'Menu.dc.html'], ['Team', 'People who sign in and field crew', 'users', 'lilac', 'Team.dc.html'], ['Price list', 'Your items and rates', 'tag', 'sage', '#'], ['Compliance', 'Tax and licence deadlines', 'shield', 'teal', '#'], ['Connected apps', 'QuickBooks, Google Calendar, Gmail', 'link', 'azure', '#'], ['Home', 'Today, money and the field', 'house', 'violet', 'SmartHome.dc.html']]
      .forEach(function (d) { ALL.push({ type: 'pages', title: d[0], sub: d[1], key: d[0] + ' ' + d[1], ic: [d[2], d[3]], href: d[4] }); });
    var TY = [['all', 'All'], ['quotes', 'Quotes'], ['clients', 'Clients'], ['jobs', 'Jobs'], ['invoices', 'Invoices'], ['pages', 'Pages']];
    var hits = ql ? ALL.filter(function (x) { return x.key.toLowerCase().indexOf(ql) >= 0; }) : [];
    var mk = function (x) {
      var i = ql ? x.title.toLowerCase().indexOf(ql) : -1;
      var a = i >= 0 ? x.title.slice(0, i) : x.title, b = i >= 0 ? x.title.slice(i, i + ql.length) : '', c = i >= 0 ? x.title.slice(i + ql.length) : '';
      return { a: a, b: b, c: c, hlc: b ? 'sr-hl' : '', title: x.title, sub: x.sub, href: x.href, isAv: !!x.av, isIc: !x.av, ini: x.av, tn: x.tn, ic: x.ic ? ic(x.ic[0], x.ic[1]) : ic('dot', 'slate'),
        hasAmt: !!x.amt, amt: x.amt, hasSt: !!x.st, st: x.st ? x.st[1] : '', status: x.st ? x.st[0] : '', chev: !x.amt && !x.st };
    };
    var groups = TY.slice(1).filter(function (ty) { return t === 'all' || t === ty[0]; }).map(function (ty) {
      var rs = hits.filter(function (x) { return x.type === ty[0]; });
      var lim = t === 'all' ? 3 : 99;
      return { title: ty[1], n: rs.length, rows: rs.slice(0, lim).map(mk), more: rs.length > lim, pick: function () { set({ t: ty[0] }); } };
    }).filter(function (g) { return g.n > 0; });
    var RQ = self.g('rq', ['hart', 'backsplash', 'overdue', 'Harbourfront']);
    return {
      q: q, hasQ: q.length > 0, noQ: !ql, none: !!ql && groups.length === 0,
      onQ: function (e) { set({ q: e.target.value }); }, clear: function () { set({ q: '', t: 'all' }); var el = document.getElementById('sr-q'); if (el) el.focus(); },
      types: TY.map(function (ty) { var on = ty[0] === t; var c = ty[0] === 'all' ? hits.length : hits.filter(function (x) { return x.type === ty[0]; }).length; return { label: ty[1], on: on, cls: on ? 'on' : '', count: c, showCnt: !!ql, pick: function () { set({ t: ty[0] }); } }; }),
      groups: groups, emptyIc: ic('search', 'slate'),
      recentQ: RQ.map(function (r) { return { label: r, pick: function () { set({ q: r }); } }; }),
      clearRecent: function () { set({ rq: [] }); },
      recent: [
        { title: 'Dana Whitfield', sub: 'Q-2026-119 · Bedrooms and bath ceiling', kind: 'Quote', isIc: true, isAv: false, ic: ic('doc', 'violet'), href: 'Quote.dc.html' },
        { title: 'Basement finish', sub: 'Tom & Lena Hart · 64%', kind: 'Job', isIc: true, isAv: false, ic: ic('house', 'teal'), href: 'Job.dc.html' },
        { title: 'INV-0412', sub: 'Tom & Lena Hart · $2,340.00', kind: 'Invoice', isIc: true, isAv: false, ic: ic('receipt', 'clay'), href: 'Invoice.dc.html' },
        { title: 'Harbourfront Dental', sub: 'Queens Quay W, Toronto', kind: 'Client', isIc: false, isAv: true, ini: 'HD', tn: 'tn3', ic: ic('dot', 'slate'), href: 'Client.dc.html' }
      ]
    };
