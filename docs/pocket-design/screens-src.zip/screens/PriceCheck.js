    var mode = this.props.state || 'default';
    var loading = mode === 'loading', thin = mode === 'noHistory';
    var applied = this.g('applied', {});
    var r2 = function (n) { return Math.round(n * 100) / 100; };
    var money = function (n) { var s = Math.abs(n).toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); return (n < 0 ? '−$' : '$') + s; };
    var pct = function (n) { return (n * 100).toFixed(1) + '%'; };
    var LINES = [
      { id: 'a', name: 'Remove existing backsplash', qty: 32, unit: 'sq ft', rate: 4.50, cost: 3.10, lo: 5.00, hi: 8.00, avg: 6.10, sug: 6.00, v: 'Low',
        why: 'Below your own average and under the Toronto range. You charged $6.10 on average on your last 9 kitchens.' },
      { id: 'b', name: 'Cement board and waterproofing', qty: 32, unit: 'sq ft', rate: 6.25, cost: 3.90, lo: 5.50, hi: 8.00, avg: 6.40, v: 'In range',
        why: 'Close to what you usually charge.' },
      { id: 'c', name: 'Tile install, herringbone', qty: 32, unit: 'sq ft', rate: 18.50, cost: 11.20, lo: 16.00, hi: 24.00, avg: 19.20, v: 'In range',
        why: 'A little under your average for herringbone. Nothing to change.' },
      { id: 'd', name: 'Tile, grout and trim supply', qty: 37, unit: 'sq ft', rate: 13.69, cost: 9.80, lo: 9.00, hi: 12.50, avg: 11.10, sug: 12.40, v: 'High',
        why: 'Above the range for supply. Keep it if this tile cost more than your usual, the receipt isn’t in yet.' },
      { id: 'e', name: 'Outlet extenders and cover plates', qty: 4, unit: 'each', rate: 22.00, cost: 9.00, v: 'Not enough data',
        why: 'Only on 2 past jobs. Nothing reliable to compare against yet.' },
      { id: 'f', name: 'Silicone, sealing and cleanup', qty: 1, unit: 'lot', rate: 120.00, cost: 70.00, lo: 150, hi: 240, avg: 185, sug: 175, v: 'Low',
        why: 'Your last 9 kitchens averaged $185 for this. At $120 it barely covers the half day.' }
    ];
    var VCLS = { 'Low': ['warn', 'alert'], 'High': ['info', 'alert'], 'In range': ['ok', 'check'], 'Not enough data': ['mute', 'off'] };
    var subB = 0, subA = 0, cost = 0, nSug = 0, nApp = 0;
    var rows = LINES.map(function (l) {
      var ap = !!applied[l.id], hasSug = l.sug !== undefined;
      if (hasSug) { nSug++; if (ap) nApp++; }
      var cur = ap ? l.sug : l.rate;
      subB += r2(l.qty * l.rate); subA += r2(l.qty * cur); cost += l.qty * l.cost;
      var hasBar = l.lo !== undefined && !(thin && l.id === 'e');
      var o = { name: l.name, rate: money(l.rate) + ' / ' + (l.unit === 'lot' ? 'lot' : l.unit), qty: l.qty + ' ' + l.unit, why: l.why, hasBar: hasBar, hasSug: hasSug, applied: ap };
      var vc = VCLS[l.v]; var word = ap ? 'Applied' : l.v;
      o.word = word; o.cls = ap ? 'st-ok si-check' : 'st-' + vc[0] + ' si-' + vc[1];
      if (hasBar) {
        var mn = Math.min(l.lo, l.rate, l.avg) * 0.8, mx = Math.max(l.hi, l.rate) * 1.15;
        var p = function (x) { return ((x - mn) / (mx - mn) * 100).toFixed(1) + '%'; };
        o.band = 'left: ' + p(l.lo) + '; width: calc(' + p(l.hi) + ' - ' + p(l.lo) + ')';
        o.avg = 'left: ' + p(l.avg);
        o.you = 'left: ' + p(cur) + '; background: ' + (ap || l.v === 'In range' ? 'var(--ok-dot)' : 'var(--ink)');
        o.showSug = hasSug && !ap; o.sug = hasSug ? 'left: ' + p(l.sug) : '';
        o.lo = money(l.lo); o.hi = money(l.hi); o.avgTxt = 'Your average ' + money(l.avg); o.hi = money(l.hi).slice(1);
        o.aria = 'Toronto ' + money(l.lo) + ' to ' + money(l.hi) + ', your average ' + money(l.avg) + ', this quote ' + money(cur);
      }
      if (hasSug) {
        var d = r2(l.qty * (l.sug - l.rate));
        o.sugTxt = 'Try ' + money(l.sug) + (l.unit === 'lot' ? '' : ' / ' + l.unit);
        o.sugDelta = (d > 0 ? '+' : '') + money(d); o.dCol = d > 0 ? 'color: var(--ok)' : 'color: var(--muted)';
        o.mB = Math.round((l.rate - l.cost) / l.rate * 100) + '%'; o.mA = Math.round((l.sug - l.cost) / l.sug * 100) + '%';
        o.btn = ap ? 'Undo' : 'Apply'; o.btnCls = ap ? 'btn-s' : 'btn-p';
        o.toggle = function () { var n = Object.assign({}, self.g('applied', {})); n[l.id] = !n[l.id]; set({ applied: n }); };
      }
      return o;
    });
    subB = r2(subB); subA = r2(subA);
    var totB = r2(subB * 1.13), totA = r2(subA * 1.13);
    var allSug = {}; LINES.forEach(function (l) { if (l.sug !== undefined) allSug[l.id] = true; });
    var fullA = 0; LINES.forEach(function (l) { fullA += r2(l.qty * (l.sug !== undefined ? l.sug : l.rate)); });
    var fullTot = r2(r2(fullA) * 1.13);
    var showTot = nApp ? totA : fullTot;
    var tw = money(showTot);
    var allDone = nApp === nSug;
    return {
      loading: loading, thin: thin, ready: !loading, infoIc: ic('help', 'azure'),
      headline: loading ? 'Checking 6 lines' : allDone ? 'All suggestions applied' : (nSug - nApp) + ' prices worth a look',
      basis: loading ? 'Comparing with your past jobs and Toronto ranges.' : thin ? 'Based on 2 of your jobs and Toronto quotes for similar work.' : 'Based on 14 of your backsplash jobs and Toronto quotes for similar work.',
      totLabel: nApp ? 'New total, incl. HST' : 'Total if you apply all',
      totWhole: tw.slice(0, -3), totCents: tw.slice(-3),
      totDelta: (showTot - totB >= 0 ? '+' : '') + money(r2(showTot - totB)) + ' vs now',
      deltaCol: showTot > totB ? 'color: var(--ok)' : 'color: var(--muted)',
      mBefore: pct((subB - cost) / subB),
      mAfterLbl: nApp ? 'After changes' : 'If applied',
      mAfter: pct(((nApp ? subA : fullA) - cost) / (nApp ? subA : fullA)), mAfterCol: 'color: var(--ok)',
      rows: rows,
      applyAll: function () { if (allDone) return; set({ applied: allSug }); },
      allLabel: allDone ? 'Applied to the quote' : 'Apply all ' + (nSug - nApp),
      allStyle: allDone ? 'background: var(--ok-dot); color: #ffffff' : ''
    };
