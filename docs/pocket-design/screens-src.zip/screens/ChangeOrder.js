    var ORDER = ['describe', 'review', 'sent', 'signed'];
    var LABELS = ['Describe', 'Review', 'Sent', 'Signed'];
    var step = self.g('step', null) || (this.props.step || 'describe');
    var si = ORDER.indexOf(step); if (si < 0) { step = 'describe'; si = 0; }
    var mode = self.g('mode', 'talk'), rec = self.g('rec', 'done');
    var title = self.g('title', 'Four pot lights, family room');
    var transcript = self.g('text', 'Tom and Lena want four pot lights in the family room ceiling, on a dimmer by the stairs. Jonah can wire them Thursday before we tape. About a day of work.');
    var nPhotos = self.g('nPhotos', 2), bill = self.g('bill', 'next'), chan = self.g('chan', { email: true, text: true });
    var reminded = self.g('reminded', false), autoRem = self.g('autoRem', true), copied = self.g('copied', false);
    var go = function (s) { set({ step: s }); };
    var PH = [['co-p1', 'photo', 'azure', 'Family room ceiling'], ['co-p2', 'camera', 'violet', 'Switch by the stairs'], ['co-p3', 'photo', 'amber', 'Joist layout']];
    var L = [
      ['LED pot lights, 4 in slim', '4 × $42.00 · IC-rated, dimmable', '$168.00'],
      ['Dimmer switch and box', 'By the stairs', '$46.00'],
      ['Electrician, Jonah Reyes', '5.5 h × $95.00', '$522.50'],
      ['Cut, patch and touch-up', 'Around each light, before taping', '$165.00'],
      ['ESA notification', 'Electrical Safety Authority', '$89.65']
    ];
    var B = [['next', 'Add to the next progress bill', 'INV-0421 · term 3, drywall'], ['own', 'Separate invoice', 'Sent when the work is done'], ['sign', 'Due on signing', 'Card or e-Transfer from the link']];
    var tl = function (rows) { return rows.map(function (a, i) { return { text: a[0], when: a[1], sub: a[2], tStyle: a[3] ? '' : 'color: var(--muted)', dot: a[3] ? 'background: var(--acc)' : 'background: var(--card); border: 1.5px solid var(--line2)', line: i === rows.length - 1 ? 'display: none' : '' }; }); };
    var trackRows = [['Sent to Lena Hart', '10:42 am', 'Email and text, with the signing link', true]];
    if (reminded) trackRows.push(['Reminder sent', '10:58 am', 'Text to 416 555 0148', true]);
    trackRows = trackRows.concat([['Opens the link', 'Waiting', 'You’ll get a notification', false], ['Signs', 'Waiting', 'Budget, schedule and billing update on their own', false]]);
    return {
      stepNo: si + 1,
      steps: LABELS.map(function (l, i) { return { label: l, cls: (i <= si ? 'on' : '') + (i === si ? ' cur' : '') }; }),
      isDescribe: step === 'describe', isReview: step === 'review', isSent: step === 'sent', isSigned: step === 'signed',
      toReview: function () { go('review'); }, toDescribe: function () { go('describe'); }, toSent: function () { go('sent'); }, toSigned: function () { go('signed'); },
      isTalk: mode === 'talk', isType: mode === 'type',
      modeInd: mode === 'talk' ? 'transform: translateX(0)' : 'transform: translateX(100%)',
      talkStyle: mode === 'talk' ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
      typeStyle: mode === 'type' ? 'color: var(--ink); font-weight: 600' : 'color: var(--muted)',
      talk: function () { set({ mode: 'talk' }); }, type: function () { set({ mode: 'type' }); },
      listening: rec === 'live', notListening: rec !== 'live', hasText: rec === 'done',
      micCls: rec === 'live' ? 'live' : '', micLabel: rec === 'live' ? 'Stop recording' : 'Start recording',
      recTitle: rec === 'live' ? 'Listening…' : (rec === 'done' ? 'Got it' : 'Tap to talk'),
      recSub: rec === 'done' ? 'Tap the mic to add more' : 'Say what the client asked for',
      toggleRec: function () { set({ rec: self.g('rec', 'done') === 'live' ? 'done' : 'live' }); },
      transcript: transcript, onText: function (e) { set({ text: e.target.value }); },
      title: title, onTitle: function (e) { set({ title: e.target.value }); },
      photos: PH.slice(0, nPhotos).map(function (p) { return { cls: p[0], ic: ic(p[1], p[2]), cap: p[3] }; }),
      photoCount: nPhotos + ' added',
      addPhoto: function () { set({ nPhotos: Math.min(3, nPhotos + 1) }); },
      orbIc: ic('orb', 'violet'),
      lines: L.map(function (l, i) { return { name: l[0], detail: l[1], amt: l[2], sep: i ? 'border-top: 1px solid var(--line)' : '' }; }),
      sched: [
        { name: 'Pot lights and wiring', sub: 'Jonah Reyes · new task', was: 'New', wasStyle: 'color: var(--acc-t); font-weight: 600', now: 'Thu Oct 1', ic: ic('bolt', 'gold') },
        { name: 'Drywall phase ends', sub: 'Taping waits one day', was: 'Oct 2', wasStyle: 'text-decoration: line-through; color: var(--faint)', now: 'Oct 5', ic: ic('box', 'stone') },
        { name: 'Job finishes', sub: 'Paint and flooring shift too', was: 'Oct 30', wasStyle: 'text-decoration: line-through; color: var(--faint)', now: 'Nov 2', ic: ic('cal', 'sky') }
      ],
      bills: B.map(function (b) { var on = b[0] === bill; return { label: b[1], sub: b[2], on: on, dot: on ? 'border: 7px solid var(--inv)' : 'border: 1.6px solid var(--line2)', pick: function () { set({ bill: b[0] }); } }; }),
      chans: [['email', 'Email'], ['text', 'Text message']].map(function (c) { var on = !!chan[c[0]]; return { label: c[1], on: on, cls: on ? 'on' : '', flip: function () { var o = Object.assign({}, self.g('chan', { email: true, text: true })); o[c[0]] = !o[c[0]]; set({ chan: o }); } }; }),
      sentIc: ic('send', 'violet'), penIc: ic('pen', 'indigo'), okIc: ic('check', 'sage'), warnIc: ic('warn', 'amber'), linkIc: ic('link', 'azure'),
      doneIc: ic('check', 'sage'), crewIc: ic('bolt', 'gold'),
      reminded: reminded, remindLabel: reminded ? 'Reminder sent' : 'Remind Lena now',
      remind: function () { set({ reminded: true }); },
      track: tl(trackRows),
      autoRem: autoRem, autoSub: autoRem ? 'Tomorrow at 9:00 am if it’s not signed' : 'Off · you’ll remind her yourself',
      autoTrack: autoRem ? 'background: var(--acc)' : 'background: var(--track-off)', autoKnob: autoRem ? 'transform: translateX(20px)' : 'transform: translateX(0)',
      flipAuto: function () { set({ autoRem: !self.g('autoRem', true) }); },
      copyLabel: copied ? 'Copied' : 'Copy link', copy: function () { set({ copied: true }); },
      updates: [
        { name: 'Contract value', sub: 'C-2026-014 with CO-1 and CO-3', was: '$42,355', now: '$43,475', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('doc', 'indigo') },
        { name: 'Job budget', sub: 'Lights, dimmer, electrician and ESA added to costs', was: '$28,500', now: '$29,326', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('bars', 'stone') },
        { name: 'Schedule', sub: 'Pot lights Thu Oct 1, finish moves one working day', was: 'Oct 30', now: 'Nov 2', wasStyle: 'text-decoration: line-through; color: var(--faint)', ic: ic('cal', 'sky') },
        { name: 'Next progress bill', sub: 'Added as its own line on INV-0421, term 3', was: 'INV-0421', now: '+$1,120.00', wasStyle: 'color: var(--muted)', ic: ic('receipt', 'teal') }
      ]
    };
