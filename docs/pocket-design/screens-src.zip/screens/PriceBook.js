    var st = this.props.state || 'default';
    var f = this.g('f', 'all'), q = this.g('q', st === 'empty' ? 'baseboard' : ''), open = this.g('open', 'a1'), addOpen = this.g('add', false);
    var nName = this.g('nName', ''), nCat = this.g('nCat', 'lab'), nUnit = this.g('nUnit', 'lin ft'), nRate = this.g('nRate', ''), nCost = this.g('nCost', ''), added = this.g('added', []);
    var money = function (n) { return '$' + n.toLocaleString('en-CA', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); };
    var num = function (s) { var n = parseFloat(String(s).replace(/[^0-9.]/g, '')); return isNaN(n) ? 0 : n; };
    // id, cat, name, rate, unit, meta, markCls, mark, icon, tone, parts, cost
    var D = [
      ['l1', 'lab', 'Paint walls, 2 coats', 2.10, 'sq ft', 'Used today · Q-2026-119', '', '', 'brush', 'violet'],
      ['l2', 'lab', 'Drywall hang and tape', 3.40, 'sq ft', 'Used Sep 24 · was $3.10', 'warn', 'Price changed', 'bricks', 'amber'],
      ['l3', 'lab', 'Paint ceilings', 1.85, 'sq ft', 'Used Sep 22', '', '', 'brush', 'indigo'],
      ['l4', 'lab', 'Trim carpentry', 68.00, 'hour', 'Used Sep 19', '', '', 'hammer', 'clay'],
      ['l5', 'lab', 'Floor tile install', 12.50, 'sq ft', 'From Rossi Commercial', '', '', 'grid', 'teal'],
      ['m1', 'mat', 'Drywall sheet, ½ in 4×8', 19.95, 'each', 'Used Sep 24 · was $18.40', 'warn', 'Up 8%', 'bricks', 'stone'],
      ['m2', 'mat', 'Benjamin Moore Regal, 3.79 L', 78.99, 'each', 'Used today', '', '', 'drop', 'sky'],
      ['m3', 'mat', 'Joint compound, 17 L', 24.60, 'each', 'Used Sep 24', '', '', 'box', 'sage'],
      ['m4', 'mat', 'SPF stud 2×4×8', 5.48, 'each', 'Used Sep 12 · was $5.65', 'ok', 'Down 3%', 'ruler', 'gold'],
      ['a1', 'asm', 'Basement wall, finished', 38.60, 'lin ft', '6 parts · used Aug 28', '', '', 'house', 'violet', [['Studs and plates', '$6.20'], ['Insulation R14 and vapour barrier', '$5.10'], ['Drywall, both sides', '$9.80'], ['Tape, mud and sand', '$7.40'], ['Primer and 2 coats', '$6.30'], ['Baseboard', '$3.80']], '$26.10'],
      ['a2', 'asm', 'Bathroom ceiling repaint', 420.00, 'each', '4 parts · used Sep 29', '', '', 'drop', 'teal', [['Mould wash and prep', '$95.00'], ['Stain-block primer', '$85.00'], ['Bathroom paint, 2 coats', '$190.00'], ['Fan cover clean and refit', '$50.00']], '$238.00'],
      ['a3', 'asm', 'Pot light, supply and install', 145.00, 'each', '3 parts · Jonah Reyes', 'warn', 'Price changed', 'bolt', 'amber', [['4 in LED slim light', '$32.00'], ['Wire and box', '$18.00'], ['Electrician, 0.75 h', '$63.75']], '$113.75']
    ];
    added.forEach(function (a, i) { D.unshift(['n' + i, a.cat, a.name, a.rate, a.unit, 'Added just now', 'acc', 'New', a.cat === 'mat' ? 'box' : 'hammer', 'lilac']); });
    var CAT = { lab: 'Labour', mat: 'Materials', asm: 'Assemblies' };
    var TOT = { all: 212 + added.length, lab: 64 + added.filter(function (a) { return a.cat === 'lab'; }).length, mat: 134 + added.filter(function (a) { return a.cat === 'mat'; }).length, asm: 14 };
    var ql = q.trim().toLowerCase();
    var rows = D.filter(function (d) { return (f === 'all' || d[1] === f) && (!ql || (d[2] + ' ' + d[5]).toLowerCase().indexOf(ql) >= 0); });
    var groups = ['lab', 'mat', 'asm'].map(function (c) {
      var rs = rows.filter(function (d) { return d[1] === c; });
      return {
        title: CAT[c], note: ql ? rs.length + ' found' : (c === 'asm' ? 'Tap to see parts' : 'Most used'), has: rs.length > 0,
        rows: rs.map(function (d, i) {
          var isA = c === 'asm', o = open === d[0];
          return { name: d[2], meta: d[5], rate: money(d[3]), unit: '/ ' + d[4], hasMark: !!d[7], mark: d[7], markCls: 'st-' + d[6] + ' si-dot', ic: ic(d[8], d[9]),
            open: isA && o, parts: isA ? d[10].map(function (p) { return { n: p[0], v: p[1] }; }) : [], cost: d[11] || '',
            sep: i ? 'border-top: 1px solid var(--line)' : '', wrapCls: d[0].charAt(0) === 'n' ? 'pb-new' : '',
            tap: function () { if (isA) set({ open: o ? '' : d[0] }); } };
        })
      };
    }).filter(function (g) { return g.has; });
    var r = num(nRate), c = num(nCost);
    var reset = { nName: '', nRate: '', nCost: '', nCat: 'lab', nUnit: 'lin ft' };
    return {
      addQLabel: 'Add “' + q.trim() + '”', q: q, onSearch: function (e) { set({ q: e.target.value }); },
      kpis: [
        { label: 'Items', value: String(TOT.all), sub: '14 assemblies', subStyle: 'color: var(--muted)', sep: '' },
        { label: 'Used this month', value: '86', sub: 'in 19 quotes', subStyle: 'color: var(--muted)', sep: 'border-left: 1px solid var(--line)' },
        { label: 'Prices changed', value: '3', sub: 'Since Sep 1', subStyle: 'color: var(--warn)', sep: 'border-left: 1px solid var(--line)' }
      ],
      filters: [['all', 'All'], ['lab', 'Labour'], ['mat', 'Materials'], ['asm', 'Assemblies']].map(function (x) { var on = x[0] === f; return { label: x[1], count: TOT[x[0]], on: on, cls: on ? 'on' : '', pick: function () { set({ f: x[0] }); } }; }),
      groups: groups, empty: groups.length === 0, emptyIc: ic('search', 'slate'), importIc: ic('export', 'azure'),
      addOpen: addOpen,
      openAdd: function () { set(Object.assign({ add: true }, reset)); },
      openAddQ: function () { set(Object.assign({ add: true }, reset, { nName: q.charAt(0).toUpperCase() + q.slice(1) })); },
      closeAdd: function () { set({ add: false }); },
      nName: nName, nRate: nRate, nCost: nCost,
      onName: function (e) { set({ nName: e.target.value }); }, onRate: function (e) { set({ nRate: e.target.value }); }, onCost: function (e) { set({ nCost: e.target.value }); },
      cats: [['lab', 'Labour'], ['mat', 'Material'], ['asm', 'Assembly']].map(function (x) { var on = x[0] === nCat; return { label: x[1], on: on, cls: on ? 'on' : '', pick: function () { set({ nCat: x[0] }); } }; }),
      units: ['sq ft', 'lin ft', 'hour', 'each', 'day'].map(function (u) { var on = u === nUnit; return { label: u, on: on, cls: on ? 'on' : '', pick: function () { set({ nUnit: u }); } }; }),
      hasMargin: r > 0 && c > 0, marginTxt: r > 0 ? Math.round((r - c) / r * 100) + '%' : '',
      cantSave: !nName.trim() || r <= 0,
      saveItem: function () { set({ add: false, q: '', f: 'all', added: added.concat([{ name: nName.trim(), cat: nCat === 'asm' ? 'lab' : nCat, rate: r, unit: nUnit }]) }); }
    };
